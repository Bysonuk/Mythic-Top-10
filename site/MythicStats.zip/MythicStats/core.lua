-- MythicStats: top 10 Mythic logs per spec, with stats, trinkets, potions and talent codes.
-- Data lives in the data/*.lua files, written by wcl_mythic_stats.py.

MythicStatsDB = MythicStatsDB or {}
local DB = MythicStatsDB

local CLASS_ORDER = {
  "DeathKnight", "DemonHunter", "Druid", "Evoker", "Hunter", "Mage", "Monk",
  "Paladin", "Priest", "Rogue", "Shaman", "Warlock", "Warrior",
}
local QUESTION = "Interface\\Icons\\INV_Misc_QuestionMark"
local ROW_H, SIDE_W, SIDE_ROW = 62, 210, 32

local state = { key = nil, boss = 1 }
local specs, byKey, iconFor, classFileFor = {}, {}, {}, {}
local main, sideButtons, bossButtons, rows = nil, {}, {}, {}

----------------------------------------------------------------------
-- Lookups
----------------------------------------------------------------------
local function classColor(slug)
  local file = classFileFor[slug] or slug:upper()
  local c = RAID_CLASS_COLORS and RAID_CLASS_COLORS[file]
  return c or { r = 0.9, g = 0.9, b = 0.9 }
end

local function colorCode(slug)
  local c = classColor(slug)
  return string.format("|cff%02x%02x%02x", c.r * 255, c.g * 255, c.b * 255)
end

-- Spec icons and class file names come from the game, matched up by name
local function buildLookups()
  local slugByFile = {}
  for _, slug in ipairs(CLASS_ORDER) do slugByFile[slug:upper()] = slug end
  local n = (GetNumClasses and GetNumClasses()) or 13
  for i = 1, n do
    local _, classFile, classID = GetClassInfo(i)
    local slug = classFile and slugByFile[classFile]
    if slug then
      classFileFor[slug] = classFile
      local count = (GetNumSpecializationsForClassID and GetNumSpecializationsForClassID(classID)) or 0
      for s = 1, count do
        local _, specName, _, icon = GetSpecializationInfoForClassID(classID, s)
        if specName and icon then iconFor[slug .. "|" .. specName] = icon end
      end
    end
  end
end

local function buildSpecList()
  specs, byKey = {}, {}
  for _, slug in ipairs(CLASS_ORDER) do
    local cd = DB.classes and DB.classes[slug]
    if cd then
      for _, sp in ipairs(cd.specs) do
        local entry = {
          key = slug .. "|" .. sp.spec, cls = slug, className = cd.className,
          spec = sp.spec, role = sp.role, metric = sp.metric, players = sp.players,
        }
        specs[#specs + 1] = entry
        byKey[entry.key] = entry
      end
    end
  end
end

local function playerSpecKey()
  local _, classFile = UnitClass("player")
  local slug
  for _, s in ipairs(CLASS_ORDER) do if s:upper() == classFile then slug = s end end
  if not slug then return nil end
  local idx = GetSpecialization and GetSpecialization()
  if idx then
    local _, specName = GetSpecializationInfo(idx)
    if specName and byKey[slug .. "|" .. specName] then return slug .. "|" .. specName end
  end
  for _, e in ipairs(specs) do if e.cls == slug then return e.key end end
end

----------------------------------------------------------------------
-- Formatting
----------------------------------------------------------------------
local function fmtAmount(v)
  if not v or v == 0 then return "-" end
  if v >= 1e6 then return string.format("%.2fM", v / 1e6) end
  if v >= 1e3 then return string.format("%.1fK", v / 1e3) end
  return tostring(math.floor(v))
end

local function comma(v)
  if not v or v == 0 then return "-" end
  local out = tostring(math.floor(v)):reverse():gsub("(%d%d%d)", "%1,"):reverse()
  return (out:gsub("^,", ""))
end

local function itemIcon(id)
  if C_Item and C_Item.GetItemIconByID then
    local icon = C_Item.GetItemIconByID(id)
    if icon then return icon end
  end
  if GetItemIcon then return GetItemIcon(id) end
end

local function itemName(id, fallback)
  if C_Item and C_Item.GetItemNameByID then
    local n = C_Item.GetItemNameByID(id)
    if n then return n end
  end
  if fallback and fallback ~= "" then return fallback end
  return "Item " .. id
end

local function spellName(id)
  if C_Spell and C_Spell.GetSpellInfo then
    local info = C_Spell.GetSpellInfo(id)
    if info and info.name then return info.name end
  end
  if GetSpellInfo then return (GetSpellInfo(id)) end
end

local function spellIcon(id)
  if C_Spell and C_Spell.GetSpellInfo then
    local info = C_Spell.GetSpellInfo(id)
    if info and info.iconID then return info.iconID end
  end
  if GetSpellTexture then return GetSpellTexture(id) end
end

----------------------------------------------------------------------
-- Copy window
----------------------------------------------------------------------
local copyFrame
local function showCopy(text, label)
  if not copyFrame then
    local f = CreateFrame("Frame", "MythicStatsCopyFrame", UIParent, "BasicFrameTemplateWithInset")
    f:SetSize(470, 150)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f.TitleText:SetText("Talent code")

    f.info = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.info:SetPoint("TOPLEFT", 14, -32)
    f.info:SetPoint("TOPRIGHT", -14, -32)
    f.info:SetJustifyH("LEFT")

    local box = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    box:SetPoint("TOPLEFT", 18, -72)
    box:SetPoint("TOPRIGHT", -18, -72)
    box:SetHeight(24)
    box:SetAutoFocus(false)
    box:SetFontObject(ChatFontNormal)
    box:SetScript("OnEscapePressed", function() f:Hide() end)
    box:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    box:SetScript("OnTextChanged", function(self, user)
      if user then self:SetText(self.value or ""); self:HighlightText() end
    end)
    f.box = box

    f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.hint:SetPoint("TOPLEFT", 18, -104)
    f.hint:SetPoint("TOPRIGHT", -18, -104)
    f.hint:SetJustifyH("LEFT")
    f.hint:SetText("Press Ctrl+C to copy, then open your talents, click the loadout dropdown and choose Import.")
    copyFrame = f
  end
  copyFrame.info:SetText(label or "")
  copyFrame.box.value = text
  copyFrame.box:SetText(text)
  copyFrame:Show()
  copyFrame.box:SetFocus()
  copyFrame.box:HighlightText()
end

----------------------------------------------------------------------
-- Icon plus name, used for trinkets and potions
----------------------------------------------------------------------
local function makeSlot(parent, x, y, width)
  local f = CreateFrame("Button", nil, parent)
  f:SetSize(width, 18)
  f:SetPoint("TOPLEFT", x, y)
  f.icon = f:CreateTexture(nil, "ARTWORK")
  f.icon:SetSize(16, 16)
  f.icon:SetPoint("LEFT", 0, 0)
  f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  f.border = f:CreateTexture(nil, "BACKGROUND")
  f.border:SetPoint("TOPLEFT", f.icon, -1, 1)
  f.border:SetPoint("BOTTOMRIGHT", f.icon, 1, -1)
  f.border:SetColorTexture(0, 0, 0, 0.8)
  f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.text:SetPoint("LEFT", f.icon, "RIGHT", 6, 0)
  f.text:SetPoint("RIGHT", 0, 0)
  f.text:SetJustifyH("LEFT")
  f:SetScript("OnEnter", function(self)
    if not self.tipID or self.tipID == 0 then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    if self.tipKind == "spell" then GameTooltip:SetSpellByID(self.tipID)
    else GameTooltip:SetItemByID(self.tipID) end
    GameTooltip:Show()
  end)
  f:SetScript("OnLeave", function() GameTooltip:Hide() end)
  f:Hide()
  return f
end

local function fillItemSlot(slot, entry)
  if not entry or not entry.id or entry.id == 0 then slot:Hide() return end
  slot.icon:SetTexture(itemIcon(entry.id) or QUESTION)
  local ilvl = (entry.ilvl and entry.ilvl > 0) and ("  |cff9d9d9d" .. entry.ilvl .. "|r") or ""
  slot.text:SetText(itemName(entry.id, entry.name) .. ilvl)
  slot.tipID, slot.tipKind = entry.id, "item"
  slot:Show()
end

local function fillPotionSlot(slot, potion, loaded)
  local name = potion and potion.name
  if (not name or name == "") and potion and potion.id and potion.id > 0 then
    name = spellName(potion.id)
  end
  if name and name ~= "" then
    slot.icon:SetTexture((potion.id and potion.id > 0 and spellIcon(potion.id)) or QUESTION)
    slot.text:SetText("|cff8fd6ffPotion:|r " .. name)
    slot.tipID, slot.tipKind = potion.id or 0, "spell"
  else
    slot.icon:SetTexture(QUESTION)
    slot.text:SetText(loaded and "|cff808080Potion: none cast in the fight|r"
      or "|cff808080Potion: not loaded yet|r")
    slot.tipID = nil
  end
  slot:Show()
end

----------------------------------------------------------------------
-- Content
----------------------------------------------------------------------
local function current() return state.key and byKey[state.key] end

local function playersFor(sp)
  if not sp then return {} end
  local bossName = DB.bosses and DB.bosses[state.boss]
  local out = {}
  for _, p in ipairs(sp.players or {}) do
    if state.boss == 0 or p.boss == bossName then out[#out + 1] = p end
  end
  table.sort(out, function(a, b) return (a.amount or 0) > (b.amount or 0) end)
  return out
end

local function updateRows()
  local sp = current()
  local players = playersFor(sp)
  for i, row in ipairs(rows) do
    local p = players[i]
    if p and sp then
      row.rank:SetText("#" .. i)
      row.name:SetText(colorCode(sp.cls) .. p.name .. "|r  |cff9d9d9d" .. (p.guild or "") .. "|r")
      row.top:SetText(string.format("%s %s   ilvl %.1f   |cff9d9d9d%s|r",
        fmtAmount(p.amount), sp.metric or "DPS", p.ilvl or 0, p.boss or ""))
      if p.crit then
        row.stats:SetText(string.format(
          "|cffff6b5bCrit|r %s   |cfff4c542Haste|r %s   |cffa98cffMastery|r %s   |cff3ecf9aVers|r %s",
          comma(p.crit), comma(p.haste), comma(p.mastery), comma(p.vers)))
      else
        row.stats:SetText("|cff808080No stats in this log|r")
      end
      fillItemSlot(row.t1, p.trinkets and p.trinkets[1])
      fillItemSlot(row.t2, p.trinkets and p.trinkets[2])
      fillPotionSlot(row.pot, p.potion, p.potion ~= nil)
      row.copy:SetShown(p.talents and p.talents ~= "")
      row.copy.code = p.talents
      row.copy.label = string.format("%s %s, rank %d on %s", sp.spec, sp.className, i, p.boss or "")
      row:Show()
    else
      row:Hide()
    end
  end
  if main then
    main.empty:SetShown(#players == 0)
    main.TitleText:SetText("Mythic Stat Sheet - " .. (DB.zone or ""))
    if sp then
      main.sub:SetText(string.format("%s%s %s|r   top 10 %s   |cff808080updated %s|r",
        colorCode(sp.cls), sp.spec, sp.className,
        state.boss == 0 and "across all bosses" or ("on " .. ((DB.bosses or {})[state.boss] or "")),
        DB.updated or "?"))
    end
  end
end

local function updateSide()
  for _, b in ipairs(sideButtons) do
    b.sel:SetShown(b.key == state.key)
  end
end

local function select(key)
  state.key = key
  updateSide(); updateRows()
end

local function buildSide(parent)
  for i, e in ipairs(specs) do
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(SIDE_W - 22, SIDE_ROW)
    b:SetPoint("TOPLEFT", 0, -(i - 1) * SIDE_ROW)
    b.key = e.key

    b.sel = b:CreateTexture(nil, "BACKGROUND")
    b.sel:SetAllPoints()
    b.sel:SetColorTexture(1, 1, 1, 0.1)
    b.sel:Hide()
    b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")

    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(24, 24)
    b.icon:SetPoint("LEFT", 4, 0)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b.icon:SetTexture(iconFor[e.key] or QUESTION)

    b.spec = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    b.spec:SetPoint("TOPLEFT", b.icon, "TOPRIGHT", 7, 1)
    b.spec:SetText(e.spec)
    local c = classColor(e.cls)
    b.spec:SetTextColor(c.r, c.g, c.b)

    b.class = b:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    b.class:SetPoint("TOPLEFT", b.spec, "BOTTOMLEFT", 0, -1)
    b.class:SetText(e.className)

    b:SetScript("OnClick", function(self) select(self.key) end)
    sideButtons[#sideButtons + 1] = b
  end
end

local BOSS_TOP, BOSS_H, PER_LINE = -54, 23, 5

local function bossLines()
  return math.ceil((1 + #(DB.bosses or {})) / PER_LINE)
end

local function buildBossButtons()
  local names = { "All bosses" }
  for i, n in ipairs(DB.bosses or {}) do names[i + 1] = n end
  for i, n in ipairs(names) do
    local b = bossButtons[i]
    if not b then
      b = CreateFrame("Button", nil, main, "UIPanelButtonTemplate")
      b:SetSize(136, 20)
      local col, line = (i - 1) % PER_LINE, math.floor((i - 1) / PER_LINE)
      b:SetPoint("TOPLEFT", SIDE_W + 16 + col * 140, BOSS_TOP - line * BOSS_H)
      bossButtons[i] = b
    end
    b:SetText(n)
    b:SetScript("OnClick", function() state.boss = i - 1; updateRows(); buildBossButtons() end)
    b:SetEnabled(state.boss ~= i - 1)
    b:Show()
  end
end

local function createMain()
  local f = CreateFrame("Frame", "MythicStatsFrame", UIParent, "BasicFrameTemplateWithInset")
  f:SetSize(1000, 700)   -- height is worked out below, once the boss rows are known
  f:SetPoint("CENTER")
  f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "MythicStatsFrame")
  main = f

  f.sub = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.sub:SetPoint("TOPLEFT", SIDE_W + 16, -34)
  f.sub:SetJustifyH("LEFT")

  -- Scrolling list of every spec
  local scroll = CreateFrame("ScrollFrame", "MythicStatsSideScroll", f, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", 12, -34)
  local child = CreateFrame("Frame", nil, scroll)
  child:SetSize(SIDE_W - 22, math.max(1, #specs * SIDE_ROW))
  scroll:SetScrollChild(child)
  buildSide(child)

  buildBossButtons()

  f.empty = f:CreateFontString(nil, "OVERLAY", "GameFontDisable")
  f.empty:SetPoint("CENTER", SIDE_W / 2, 0)
  f.empty:SetText("No rankings for this spec on this boss.")

  local top = BOSS_TOP - bossLines() * BOSS_H - 10
  local height = math.abs(top) + 10 * (ROW_H + 3) + 22
  f:SetSize(1000, height)
  scroll:SetSize(SIDE_W - 6, height - 46)
  for i = 1, 10 do
    local row = CreateFrame("Frame", nil, f)
    row:SetSize(750, ROW_H)
    row:SetPoint("TOPLEFT", SIDE_W + 16, top - (i - 1) * (ROW_H + 3))

    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()
    row.bg:SetColorTexture(1, 1, 1, i % 2 == 0 and 0.03 or 0.06)

    row.rank = row:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    row.rank:SetPoint("TOPLEFT", 6, -5)
    row.rank:SetWidth(36)

    row.name = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.name:SetPoint("TOPLEFT", 46, -5)
    row.name:SetJustifyH("LEFT")

    row.top = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.top:SetPoint("TOPRIGHT", -104, -5)
    row.top:SetJustifyH("RIGHT")

    row.stats = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.stats:SetPoint("TOPLEFT", 46, -23)
    row.stats:SetJustifyH("LEFT")

    row.t1 = makeSlot(row, 46, -40, 210)
    row.t2 = makeSlot(row, 262, -40, 210)
    row.pot = makeSlot(row, 478, -40, 180)

    row.copy = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.copy:SetSize(92, 22)
    row.copy:SetPoint("TOPRIGHT", -6, -22)
    row.copy:SetText("Talents")
    row.copy:SetScript("OnClick", function(self) showCopy(self.code, self.label) end)

    rows[i] = row
  end
  f:Hide()
end

----------------------------------------------------------------------
-- Open, close, and following your spec
----------------------------------------------------------------------
local function scrollToSelected()
  for i, b in ipairs(sideButtons) do
    if b.key == state.key and MythicStatsSideScroll then
      MythicStatsSideScroll:SetVerticalScroll(math.max(0, (i - 4) * SIDE_ROW))
      return
    end
  end
end

local function toggle()
  if not DB.classes then
    print("|cff3fc7ebMythicStats|r: no data found. Download a newer copy of the addon.")
    return
  end
  if not main then
    buildLookups(); buildSpecList()
    createMain()
    state.key = playerSpecKey() or (specs[1] and specs[1].key)
    select(state.key)
  end
  if main:IsShown() then
    main:Hide()
  else
    state.key = playerSpecKey() or state.key   -- follow the spec you're in now
    select(state.key)
    main:Show()
    scrollToSelected()
  end
end

SLASH_MYTHICSTATS1 = "/mythicstats"
SLASH_MYTHICSTATS2 = "/ms"
SlashCmdList["MYTHICSTATS"] = toggle

local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
loader:SetScript("OnEvent", function(_, event, unit)
  if event == "PLAYER_LOGIN" then
    print("|cff3fc7ebMythicStats|r loaded. Type |cffffff00/ms|r for the top 10 per spec. Data from "
      .. (DB.updated or "?") .. ".")
  elseif unit == "player" and main and main:IsShown() then
    local key = playerSpecKey()
    if key then select(key); scrollToSelected() end
  end
end)
