MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["DemonHunter"] = {
  ["className"] = "Demon Hunter",
  ["specs"] = {
    {
      ["spec"] = "Havoc",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Cursedgodx",
          ["guild"] = "Myth",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 243482,
          ["ilvl"] = 325,
          ["crit"] = 1388,
          ["haste"] = 337,
          ["mastery"] = 1456,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMzMzkxMDAAAAAAYWMmtZYmBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Ptheve",
          ["guild"] = "Denial of Service",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 235106,
          ["ilvl"] = 326,
          ["crit"] = 1472,
          ["haste"] = 346,
          ["mastery"] = 1283,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Nyaruouo",
          ["guild"] = "咏冻黎明12.0",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 234744,
          ["ilvl"] = 325,
          ["crit"] = 1546,
          ["haste"] = 227,
          ["mastery"] = 1331,
          ["vers"] = 112,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMzYmMmZAAAAAAAzyDMmtZYmBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawwkdh",
          ["guild"] = "Consequence",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 234708,
          ["ilvl"] = 324,
          ["crit"] = 1384,
          ["haste"] = 156,
          ["mastery"] = 1384,
          ["vers"] = 237,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Zardh",
          ["guild"] = "Easy Katka",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 231827,
          ["ilvl"] = 327,
          ["crit"] = 1494,
          ["haste"] = 307,
          ["mastery"] = 1365,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Evne",
          ["guild"] = "Twitch Prime",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 230428,
          ["ilvl"] = 323,
          ["crit"] = 1412,
          ["haste"] = 518,
          ["mastery"] = 1082,
          ["vers"] = 138,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBPwMWmZegZYmxYWGYZWMjhZjpxMzYYDAAAAAAAgZGMAAAAM",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawkerton",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 229385,
          ["ilvl"] = 326,
          ["crit"] = 1550,
          ["haste"] = 190,
          ["mastery"] = 1337,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzyMmZmxMzEmZAAAAAAAziZmtZwMWmZGLzMPwMzyMzyYMwysYGDzGTDzMzwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Dindrelle",
          ["guild"] = "Awoken",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 228857,
          ["ilvl"] = 322,
          ["crit"] = 1323,
          ["haste"] = 406,
          ["mastery"] = 1197,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzixMzMzMzEmZAAAAAAAzmZmtZGMYmxyMzDMDzMYWGYZWMjhZjpxMzYYDAAAAAAAgZGMAAAAM",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Catsockss",
          ["guild"] = "Infinity",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 228028,
          ["ilvl"] = 324,
          ["crit"] = 1471,
          ["haste"] = 445,
          ["mastery"] = 1211,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZmZmwMDAAAAAAY2MmtZYmBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Revatha",
          ["guild"] = "guppy pond",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 227304,
          ["ilvl"] = 324,
          ["crit"] = 1433,
          ["haste"] = 334,
          ["mastery"] = 1320,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmwMDAAAAAAYWMzsNDMYmxyMjZYmxYWGYZWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawwkdh",
          ["guild"] = "Consequence",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 237900,
          ["ilvl"] = 325,
          ["crit"] = 1510,
          ["haste"] = 156,
          ["mastery"] = 1340,
          ["vers"] = 162,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawkerton",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 221565,
          ["ilvl"] = 326,
          ["crit"] = 1550,
          ["haste"] = 190,
          ["mastery"] = 1337,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzyMmZmxMzEmZAAAAAAAziZmtZwMWmZGLzMPwMzyMzyYMwysYGDzGTDzMzwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Âvril",
          ["guild"] = "Drama",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217612,
          ["ilvl"] = 326,
          ["crit"] = 3281,
          ["haste"] = 328,
          ["mastery"] = 1237,
          ["vers"] = -137,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Akchung",
          ["guild"] = "Mate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 215574,
          ["ilvl"] = 329,
          ["crit"] = 1627,
          ["haste"] = 151,
          ["mastery"] = 1393,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzixMzMmZmwMDAAAAAAY2mZGz8AYsMzMWmZegZmlZmlxYgtZxMGmNmGmZmhNAAAAAAAAmZwAAAAwA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Ldh",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 215066,
          ["ilvl"] = 325,
          ["crit"] = 1579,
          ["haste"] = 135,
          ["mastery"] = 1368,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Nereo",
          ["guild"] = "velocity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 211370,
          ["ilvl"] = 324,
          ["crit"] = 1494,
          ["haste"] = 200,
          ["mastery"] = 1183,
          ["vers"] = 293,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzixMzMmZmwMDAAAAAAYWegZmtZwM4BmxyMzDMDzMGzyALziZMMLMNmZmZYDAAAAAAAgZGMAAAAM",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Cursedgodx",
          ["guild"] = "Myth",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 211007,
          ["ilvl"] = 325,
          ["crit"] = 1404,
          ["haste"] = 353,
          ["mastery"] = 1456,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMzMzkxMDAAAAAAYWMmtZYmBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Yunadh",
          ["guild"] = "Unluck",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 210847,
          ["ilvl"] = 322,
          ["crit"] = 1532,
          ["haste"] = 357,
          ["mastery"] = 1205,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMYmxyMjZYmxYWGYZWMjhZhpxMzYGbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Mayder",
          ["guild"] = "Retired Extremely Bad",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 210287,
          ["ilvl"] = 324,
          ["crit"] = 1336,
          ["haste"] = 488,
          ["mastery"] = 1229,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxMzkxMDAAAAAAY2MmtZYmBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Kiimainen",
          ["guild"] = "Vespertine",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 208996,
          ["ilvl"] = 324,
          ["crit"] = 1607,
          ["haste"] = 415,
          ["mastery"] = 1159,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzmxMzMzMzEmZAAAAAAAz2DMmtZYmxyMzYZm5BmZWmZWGjBWmFzYY2YaYmxwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Waslo",
          ["guild"] = "Perfectly Adequate",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 346355,
          ["ilvl"] = 321,
          ["crit"] = 1634,
          ["haste"] = 273,
          ["mastery"] = 1139,
          ["vers"] = 57,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "雾独独",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 344083,
          ["ilvl"] = 325,
          ["crit"] = 1778,
          ["haste"] = 214,
          ["mastery"] = 1198,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMzMzEmZAAAAAAAz2DMmtZYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Yargi",
          ["guild"] = "OG Feedback",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 338346,
          ["ilvl"] = 317,
          ["crit"] = 1187,
          ["haste"] = 447,
          ["mastery"] = 1053,
          ["vers"] = 245,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "冰雪丷",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 336918,
          ["ilvl"] = 323,
          ["crit"] = 1527,
          ["haste"] = 313,
          ["mastery"] = 1318,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmMmZAAAAAAAz2MGGmZwMjlZmHYGmZwsMwysYGDzGTjZmxwGAAAAAAAAzMMDAAAAD",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hammymeta",
          ["guild"] = "Disambiguation",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 334613,
          ["ilvl"] = 325,
          ["crit"] = 3358,
          ["haste"] = 109,
          ["mastery"] = 1393,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxMzkxMDAAAAAAYWMzsNDMYmxyMjZYmxYWGYbWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Teddy",
          ["guild"] = "Mate",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 334151,
          ["ilvl"] = 324,
          ["crit"] = 1495,
          ["haste"] = 62,
          ["mastery"] = 1350,
          ["vers"] = 210,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMzMzMhZGAAAAAAwsYMbzMGDmZsMz8AzwMDmlBWmFzYY2YaMzMG2AAAAAAAAYmBDAAAAD",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bbaic",
          ["guild"] = "B L C",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 333855,
          ["ilvl"] = 326,
          ["crit"] = 1440,
          ["haste"] = 386,
          ["mastery"] = 1252,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZGzkxMDAAAAAAY2MmtxDYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Evôx",
          ["guild"] = "K L I K A",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 333812,
          ["ilvl"] = 324,
          ["crit"] = 1524,
          ["haste"] = 172,
          ["mastery"] = 1255,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzixMzMzMzkxMDAAAAAAYWMmtZYmBzMWmZegZYmBzyAbziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Toxiccønt",
          ["guild"] = "Fragglene",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 333387,
          ["ilvl"] = 323,
          ["crit"] = 1551,
          ["haste"] = 256,
          ["mastery"] = 1318,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmxMzEmZAAAAAAAziZmtZwMYmxyMzDMDzMYWGYZWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Jumpdh",
          ["guild"] = "Lost Canvas",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 333244,
          ["ilvl"] = 325,
          ["crit"] = 1744,
          ["haste"] = 117,
          ["mastery"] = 1368,
          ["vers"] = 16,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzixMzMzMzkxMDAAAAAAY2egZmtZgBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Dauflo",
          ["guild"] = "Offline",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 284687,
          ["ilvl"] = 326,
          ["crit"] = 1492,
          ["haste"] = 118,
          ["mastery"] = 1406,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzixMzMzMzkxMDAAAAAAYWMmtZYmBzMWmZegZYmBzyAbziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bobybigplays",
          ["guild"] = "Honestly",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 284230,
          ["ilvl"] = 325,
          ["crit"] = 1669,
          ["haste"] = 210,
          ["mastery"] = 1239,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMDjZmZMzMhZGAAAAAAwsZmZbmhZwMjlZmHYGmZwsMwysYGDzGTjZmxM2AAAAAAAAYmBDAAAAD",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Smallnik",
          ["guild"] = "Revoke",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 275546,
          ["ilvl"] = 323,
          ["crit"] = 1406,
          ["haste"] = 499,
          ["mastery"] = 1174,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZmZmwMDAAAAAAY2MmtZYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawkerton",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 270469,
          ["ilvl"] = 326,
          ["crit"] = 1550,
          ["haste"] = 190,
          ["mastery"] = 1337,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmxMzEmZAAAAAAAziZmtZwM4BmxyMzMDzMYWGYZWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Ldh",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 268630,
          ["ilvl"] = 324,
          ["crit"] = 1548,
          ["haste"] = 164,
          ["mastery"] = 1365,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZMDzMbMLDsMLmxwsx0YmZMsBAAAAAAAwMDGAAAAG",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Akchung",
          ["guild"] = "Mate",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 267363,
          ["ilvl"] = 329,
          ["crit"] = 1627,
          ["haste"] = 151,
          ["mastery"] = 1393,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmMmZAAAAAAAzyDMzsNDMYmxyMzDMDzMYWGYZWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Nsdh",
          ["guild"] = "Quichons",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 265447,
          ["ilvl"] = 324,
          ["crit"] = 1543,
          ["haste"] = 334,
          ["mastery"] = 1284,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMzMmJjZGAAAAAAwsZMbjxMDmZsMz8AzwMDmlBWmFzYYWYaMzMG2AAAAAAAAYmBDAAAAD",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Cursedgodx",
          ["guild"] = "Myth",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 263622,
          ["ilvl"] = 325,
          ["crit"] = 1404,
          ["haste"] = 353,
          ["mastery"] = 1456,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMzMzkxMDAAAAAAYWMmtZYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Vervayn",
          ["guild"] = "F L A M E",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 263216,
          ["ilvl"] = 323,
          ["crit"] = 1594,
          ["haste"] = 375,
          ["mastery"] = 1244,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bensondh",
          ["guild"] = "Infinity",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 262491,
          ["ilvl"] = 326,
          ["crit"] = 1462,
          ["haste"] = 200,
          ["mastery"] = 1366,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZmZmwMDAAAAAAYWMzsNDMYmxyMzDMDzMYWGYZWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Akchung",
          ["guild"] = "Mate",
          ["boss"] = "Sszorak",
          ["amount"] = 233253,
          ["ilvl"] = 329,
          ["crit"] = 1627,
          ["haste"] = 151,
          ["mastery"] = 1393,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzixMzMmZmwMDAAAAAAY2mZGz8AYsMzMWmZegZmlZmlxYgtZxMGmNmGmZmhNAAAAAAAAmZwAAAAwA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawkerton",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Sszorak",
          ["amount"] = 230984,
          ["ilvl"] = 326,
          ["crit"] = 1550,
          ["haste"] = 190,
          ["mastery"] = 1337,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzyMmZmxMzEmZAAAAAAAziZmtZwMWmZGLzMPwMzyMzyYMwysYGDzGTDzMzwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Folidan",
          ["guild"] = "Oblivion",
          ["boss"] = "Sszorak",
          ["amount"] = 227237,
          ["ilvl"] = 325,
          ["crit"] = 3251,
          ["haste"] = 333,
          ["mastery"] = 1313,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmxyMzYZm5BmZWmZWGjBWmFzYY2YaYmxwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bobybigplays",
          ["guild"] = "Honestly",
          ["boss"] = "Sszorak",
          ["amount"] = 224563,
          ["ilvl"] = 325,
          ["crit"] = 1669,
          ["haste"] = 210,
          ["mastery"] = 1239,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMDjZmZMzMhZGAAAAAAwsZmZbmhZsMzMWmZegZmlZmlxYgtZxMGmNmGmZMjNAAAAAAAAmZwAAAAwA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Mayder",
          ["guild"] = "Retired Extremely Bad",
          ["boss"] = "Sszorak",
          ["amount"] = 223675,
          ["ilvl"] = 324,
          ["crit"] = 1336,
          ["haste"] = 488,
          ["mastery"] = 1229,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmxyMzYZm5BmZWmZWGjB2mFzYY2YaYmxwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawwkdh",
          ["guild"] = "Consequence",
          ["boss"] = "Sszorak",
          ["amount"] = 222931,
          ["ilvl"] = 324,
          ["crit"] = 1411,
          ["haste"] = 156,
          ["mastery"] = 1357,
          ["vers"] = 237,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzyMmZmZmZmMmZAAAAAAAzmxsNDjxyMzYZm5BmZWmZWGjBWmFzYY2YaYmxwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bulinoran",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 221529,
          ["ilvl"] = 326,
          ["crit"] = 1320,
          ["haste"] = 585,
          ["mastery"] = 1192,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzixMzMmZmwMDAAAAAAY2egZmtZwMWmZGLzMPwMzyMzyYMwysYGDzGTDzMzwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Dragonhead",
          ["guild"] = "Tusk",
          ["boss"] = "Sszorak",
          ["amount"] = 220444,
          ["ilvl"] = 326,
          ["crit"] = 1700,
          ["haste"] = 130,
          ["mastery"] = 1243,
          ["vers"] = 91,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzmxMzMmZmMmZAAAAAAAzyDMGz8AmZsMzMWmZegZmlZmlxYglZxMGmNmGmZMsBAAAAAAAwMDGAAAAG",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Ptheve",
          ["guild"] = "Denial of Service",
          ["boss"] = "Sszorak",
          ["amount"] = 220278,
          ["ilvl"] = 326,
          ["crit"] = 1472,
          ["haste"] = 346,
          ["mastery"] = 1283,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Friedfalafel",
          ["guild"] = "Fun Detected",
          ["boss"] = "Sszorak",
          ["amount"] = 220207,
          ["ilvl"] = 325,
          ["crit"] = 1547,
          ["haste"] = 252,
          ["mastery"] = 1346,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmxyMzYZm5BmZWmZWGjBWmFzYY2YaYmxwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawwkdh",
          ["guild"] = "Consequence",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 302382,
          ["ilvl"] = 325,
          ["crit"] = 1483,
          ["haste"] = 156,
          ["mastery"] = 1367,
          ["vers"] = 162,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Neymartwo",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 276570,
          ["ilvl"] = 321,
          ["crit"] = 1479,
          ["haste"] = 448,
          ["mastery"] = 982,
          ["vers"] = 238,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmxMzEmZAAAAAAAziZmtZwMYmxyMzDMDzMYWGYZWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Zardh",
          ["guild"] = "Easy Katka",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 275808,
          ["ilvl"] = 327,
          ["crit"] = 1496,
          ["haste"] = 307,
          ["mastery"] = 1368,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Mayder",
          ["guild"] = "Retired Extremely Bad",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 275138,
          ["ilvl"] = 325,
          ["crit"] = 1336,
          ["haste"] = 488,
          ["mastery"] = 1231,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxMzkxMDAAAAAAY2MmtZYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Cursedgodx",
          ["guild"] = "Myth",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 273772,
          ["ilvl"] = 325,
          ["crit"] = 1404,
          ["haste"] = 353,
          ["mastery"] = 1456,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMzMzkxMDAAAAAAYWMmtZYmBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Verrottung",
          ["guild"] = "Dedicated Casuals",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 270469,
          ["ilvl"] = 325,
          ["crit"] = 3406,
          ["haste"] = 291,
          ["mastery"] = 1101,
          ["vers"] = -114,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Forhurtig",
          ["guild"] = "Ascendance",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 269672,
          ["ilvl"] = 325,
          ["crit"] = 1380,
          ["haste"] = 359,
          ["mastery"] = 1314,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMYmxyMzDMDzMYWGYZWMjhZjpxMzYGbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawkerton",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 269444,
          ["ilvl"] = 326,
          ["crit"] = 1550,
          ["haste"] = 190,
          ["mastery"] = 1337,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmmxMDAAAAAAYWMzsNDmBzMWmZegZYmBzyALzmZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Justdante",
          ["guild"] = "The Reckless",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 269227,
          ["ilvl"] = 325,
          ["crit"] = 1484,
          ["haste"] = 299,
          ["mastery"] = 1300,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZegZYmBzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Kaströ",
          ["guild"] = "Incarnate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 269169,
          ["ilvl"] = 323,
          ["crit"] = 1530,
          ["haste"] = 561,
          ["mastery"] = 1010,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZegZYmBzyAbziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Streakdh",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 235075,
          ["ilvl"] = 325,
          ["crit"] = 1542,
          ["haste"] = 171,
          ["mastery"] = 1381,
          ["vers"] = 59,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZmZmwMDAAAAAAYWMzsNDMYmxyMjZYmxYWGYZWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bobybigplays",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 232250,
          ["ilvl"] = 325,
          ["crit"] = 1669,
          ["haste"] = 210,
          ["mastery"] = 1239,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMDjZmZMzMhZGAAAAAAwsZmZbmhZwDMjlZmHYGmZMmlBWmFzYY2YaMzMmxGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Ldh",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 231880,
          ["ilvl"] = 324,
          ["crit"] = 1548,
          ["haste"] = 164,
          ["mastery"] = 1365,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZMDzMbMLDsMLmxwsx0YmZMsBAAAAAAAwMDGAAAAG",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Akchung",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 231346,
          ["ilvl"] = 330,
          ["crit"] = 1575,
          ["haste"] = 151,
          ["mastery"] = 1447,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZGzkxMDAAAAAAY2MzsNDM4BmxyMzDMDzMGzyALziZMMbMNmZmZYDAAAAAAAgZGMAAAAM",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Cursedgodx",
          ["guild"] = "Myth",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 229847,
          ["ilvl"] = 326,
          ["crit"] = 1409,
          ["haste"] = 353,
          ["mastery"] = 1457,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMzMzkxMDAAAAAAYWMmtZYmBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawkerton",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 228580,
          ["ilvl"] = 324,
          ["crit"] = 1426,
          ["haste"] = 300,
          ["mastery"] = 1302,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxMzkxMDAAAAAAYWMmtZYmBzMWmZMDzMGzyALzmZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Toxiccønt",
          ["guild"] = "Fragglene",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 225523,
          ["ilvl"] = 327,
          ["crit"] = 1551,
          ["haste"] = 241,
          ["mastery"] = 1390,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZmZmwMDAAAAAAYWMzsNDMYmxyMjZYmxYWGYZWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Cruzz",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 222691,
          ["ilvl"] = 325,
          ["crit"] = 1420,
          ["haste"] = 384,
          ["mastery"] = 1302,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZGzkxMDAAAAAAY2MmtZYmBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "安妮波尼",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 221874,
          ["ilvl"] = 330,
          ["crit"] = 1465,
          ["haste"] = 239,
          ["mastery"] = 1417,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMzMzEmZAAAAAAAziZmtZYMYmxyMjZYmxYWGYZWMjhZjpxMzMDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Frostepurple",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 220982,
          ["ilvl"] = 326,
          ["crit"] = 1613,
          ["haste"] = 312,
          ["mastery"] = 1185,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmwMDAAAAAAY2MmtZeAjBPwMWmZegZYmxYWGYZWMjhZjpxMzYYDAAAAAAAgZGMAAAAM",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bobybigplays",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 466389,
          ["ilvl"] = 329,
          ["crit"] = 1645,
          ["haste"] = 245,
          ["mastery"] = 1257,
          ["vers"] = 1354,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMDjZmZMmJjZGAAAAAAwsZMbzMmZwDMjlZmHYGmZwsMwysYGDzGTjZmxM2AAAAGAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Akchung",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 427607,
          ["ilvl"] = 330,
          ["crit"] = 1577,
          ["haste"] = 151,
          ["mastery"] = 1453,
          ["vers"] = 1260,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZGzkxMDAAAAAAY2MzsNDM4BmxyMzDMDzMYWGYZWMjhZjpxMzMDbAAAADAAAgZGMAAAAM",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bobybigplays",
          ["guild"] = "Honestly",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 250618,
          ["ilvl"] = 329,
          ["crit"] = 1645,
          ["haste"] = 245,
          ["mastery"] = 1257,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMDjZmZMmJjZGAAAAAAwsZMbzMmZwDMjlZmHYGmZMmlBWmFzYY2YaMzMmxGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawkerton",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 245633,
          ["ilvl"] = 326,
          ["crit"] = 1550,
          ["haste"] = 190,
          ["mastery"] = 1337,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzyMmZmxMzEmZAAAAAAAziZmtZwMWmZGLzMPwMzyMzyYMwysYGDzGTDzMzwGAAAAAAAAzMYAAAAYA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Hawwkdh",
          ["guild"] = "Consequence",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 244882,
          ["ilvl"] = 323,
          ["crit"] = 1373,
          ["haste"] = 153,
          ["mastery"] = 1360,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Pinx",
          ["guild"] = "Ritual",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 244470,
          ["ilvl"] = 326,
          ["crit"] = 3259,
          ["haste"] = -98,
          ["mastery"] = 1478,
          ["vers"] = 176,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMYmxyMjZYmxYWGYZWMjhZjpxMzYGbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Plazoom",
          ["guild"] = "R e t i r e d",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 242183,
          ["ilvl"] = 322,
          ["crit"] = 1546,
          ["haste"] = 322,
          ["mastery"] = 1166,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZMDzMGzyALziZMMbMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Melonyummy",
          ["guild"] = "Paradox",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 240304,
          ["ilvl"] = 323,
          ["crit"] = 1641,
          ["haste"] = 160,
          ["mastery"] = 1297,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzyMmZmxMz0MmZAAAAAAAzmxsNDjBmxyMzMDzMYWGYZ2MjhZjpxMzYYDAAAYAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bensondh",
          ["guild"] = "Infinity",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 239919,
          ["ilvl"] = 326,
          ["crit"] = 1460,
          ["haste"] = 200,
          ["mastery"] = 1365,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmZmZmwMDAAAAAAYWMzsNDM4BmxyMzDMDzMGzyALziZMMbMNmZmZYDAAAAAAAgZGMAAAAM",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Akchung",
          ["guild"] = "Mate",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 239694,
          ["ilvl"] = 329,
          ["crit"] = 1627,
          ["haste"] = 151,
          ["mastery"] = 1393,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMzixMzMmZmwMDAAAAAAY2mZGz8AYsMzMWmZegZmlZmlxYgtZxMGmNmGmZmhNAAAAAAAAmZwAAAAwA",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Pezglebo",
          ["guild"] = "Low Expectations",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 238787,
          ["ilvl"] = 321,
          ["crit"] = 1574,
          ["haste"] = 268,
          ["mastery"] = 1217,
          ["vers"] = 79,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxMzkxMDAAAAAAY2MmtZYmBPwMWmZegZYmxYWGYbWMjhZjpxMzYYDAAAAAAAgZGMAAAAM",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Dragonhead",
          ["guild"] = "Tusk",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 238124,
          ["ilvl"] = 326,
          ["crit"] = 1697,
          ["haste"] = 130,
          ["mastery"] = 1242,
          ["vers"] = 91,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxMzkxMDAAAAAAYWMmtZYmBzMWmZMDzMGzyAbzmZMMLMNmZGDbAAAAAAAAMzgBAAAgB",
          ["hero"] = {
            ["name"] = "Fel-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        }
      }
    },
    {
      ["spec"] = "Vengeance",
      ["role"] = "tank",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 142368,
          ["ilvl"] = 321,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Avade",
          ["guild"] = "Lucid",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 127182,
          ["ilvl"] = 324,
          ["crit"] = 988,
          ["haste"] = 1073,
          ["mastery"] = 523,
          ["vers"] = 567,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZmxMjMzMYWMzMDMjZGzYmZGDzMzM2MzsNGAAAAAAAAwMzYDAAAADMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Riemi",
          ["guild"] = "Awakeníng",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 117782,
          ["ilvl"] = 325,
          ["crit"] = 860,
          ["haste"] = 1135,
          ["mastery"] = 618,
          ["vers"] = 402,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmBziZmZgZMzYGzMzYYmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Onlytankxd",
          ["guild"] = "High Quality",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 114008,
          ["ilvl"] = 325,
          ["crit"] = 1035,
          ["haste"] = 1374,
          ["mastery"] = 512,
          ["vers"] = 248,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMkZmBziZMDMjZGz8AzMzYYmZmx2DMzsNGAAAAAAAAwMzYDAAAADmZmZmZrtZmZAAAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Yodadhz",
          ["guild"] = "xD",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 113756,
          ["ilvl"] = 322,
          ["crit"] = 927,
          ["haste"] = 1246,
          ["mastery"] = 301,
          ["vers"] = 699,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMjMzMGzyMzMjhZMzYGzMzYwwM2MzsNGzAAAAAAAAwMGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Venandí",
          ["guild"] = "Disciples Reborn",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 113095,
          ["ilvl"] = 323,
          ["crit"] = 1104,
          ["haste"] = 1347,
          ["mastery"] = 375,
          ["vers"] = 121,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYYmZGYGzMm5BmZmxwMzMjlHYmZbMAAAAAAAAgZmxGAAAAGMzMzMzWbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Gigabozo",
          ["guild"] = "Moron",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 112133,
          ["ilvl"] = 320,
          ["crit"] = 1191,
          ["haste"] = 1057,
          ["mastery"] = 428,
          ["vers"] = 387,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMzMDMjZGzYmZGDzMzM2egZmtxAAAAAAAAAmZGbAAAAYwYmZmZrtZmZAAAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Hamtoos",
          ["guild"] = "신기하게 생겼어",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 109974,
          ["ilvl"] = 321,
          ["crit"] = 976,
          ["haste"] = 1417,
          ["mastery"] = 498,
          ["vers"] = 205,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYYmZGDzYmxMmZmxwMzMjtZmxYAAAAAAAAAzMjNAAAAMYmZmZml2mZmBAGAAAAD",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Crazie",
          ["guild"] = "Wipe and Rewind",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 109871,
          ["ilvl"] = 321,
          ["crit"] = 876,
          ["haste"] = 1318,
          ["mastery"] = 297,
          ["vers"] = 636,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAWMmZmxYmZyMzgZxMzMGmxMMjZMjxMzMzYzMz2YAAAAAAAAAzMjNAAAAMwMzMzs02MzMAwAAAAYA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Chase",
          ["guild"] = "mythic raid guild",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 109556,
          ["ilvl"] = 321,
          ["crit"] = 1171,
          ["haste"] = 1237,
          ["mastery"] = 343,
          ["vers"] = 354,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZmxMjMzMYWMzMDMjZGzYmZGDzMzM2MzsNGAAAAAAAAwMzYDAAAADGzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Супсуп",
          ["guild"] = "Кайзер",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 114529,
          ["ilvl"] = 322,
          ["crit"] = 1239,
          ["haste"] = 1174,
          ["mastery"] = 346,
          ["vers"] = 410,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmBziZmZgZMzYGzMzYYmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Rydia",
          ["guild"] = "Redemption Arc",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 112177,
          ["ilvl"] = 320,
          ["crit"] = 1054,
          ["haste"] = 1274,
          ["mastery"] = 421,
          ["vers"] = 327,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMzMzMjMzMYWMzMDMjZGzYmZGDzMzM2MzYMMAAAAAAAAMzM2AAAAwAzMzMzWbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Yodadhz",
          ["guild"] = "xD",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 111640,
          ["ilvl"] = 322,
          ["crit"] = 927,
          ["haste"] = 1246,
          ["mastery"] = 301,
          ["vers"] = 699,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMjMzMGzyMzMDMjZGzYmZGDzwM2MzsNGzAAAAAAAAwMGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Toyhazard",
          ["guild"] = "The Shadowstalkers",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 111021,
          ["ilvl"] = 323,
          ["crit"] = 935,
          ["haste"] = 1141,
          ["mastery"] = 624,
          ["vers"] = 474,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmBDzMzYYGzMmxMzMGmZmZsNzMbjBAAAAAAAAMzM2AAAAwgxMzMzWbzMzAAAAAAMA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Velstatd",
          ["guild"] = "Star Doggo Royal Club",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 110842,
          ["ilvl"] = 327,
          ["crit"] = 1455,
          ["haste"] = 1388,
          ["mastery"] = 122,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZmZmZkZmBziZMjhZMzYGzMzYYmZmx2DMzYMAAAAAAAAgZM2AAAAwgZmZmZ2abmZGAAAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Ittell",
          ["guild"] = "Defenestrate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 110760,
          ["ilvl"] = 323,
          ["crit"] = 823,
          ["haste"] = 1191,
          ["mastery"] = 619,
          ["vers"] = 334,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmxYWMzMjhZMzYGzMzYYGmx2MzYMAAAAAAAAgZmxGAAAAGMmZmZ2abmZGAYAAAAMA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Riemi",
          ["guild"] = "Awakeníng",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 110256,
          ["ilvl"] = 325,
          ["crit"] = 860,
          ["haste"] = 1135,
          ["mastery"] = 618,
          ["vers"] = 402,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmBziZmZgZMzYGzMzYYmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Bentwo",
          ["guild"] = "vodka",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 109532,
          ["ilvl"] = 321,
          ["crit"] = 747,
          ["haste"] = 1219,
          ["mastery"] = 197,
          ["vers"] = 797,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmBziZmZgZMzYmHYmZGDmZmx2MzsMGAAAAAAAAwMzYDAAAADMzMzMbtNzMDAAAAAwA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 108310,
          ["ilvl"] = 322,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Felvix",
          ["guild"] = "Reflection",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 108116,
          ["ilvl"] = 319,
          ["crit"] = 1026,
          ["haste"] = 1260,
          ["mastery"] = 278,
          ["vers"] = 343,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMzkZmZYYmZGDzYmxMmxMzwMmZsZmZbMMAAAAAAAAMjxGAAAAGMzMzMzSbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Супсуп",
          ["guild"] = "Кайзер",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 211011,
          ["ilvl"] = 322,
          ["crit"] = 1257,
          ["haste"] = 1174,
          ["mastery"] = 391,
          ["vers"] = 353,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmBziZmZgZMzYGzMzYYmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Soapdh",
          ["guild"] = "Resonance",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 210758,
          ["ilvl"] = 324,
          ["crit"] = 795,
          ["haste"] = 1308,
          ["mastery"] = 378,
          ["vers"] = 686,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYWMzMDMjZGzYmZGDzMzM2egZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Toyhazard",
          ["guild"] = "The Shadowstalkers",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 207549,
          ["ilvl"] = 323,
          ["crit"] = 935,
          ["haste"] = 1141,
          ["mastery"] = 624,
          ["vers"] = 474,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmBDzMzYYGzMmxMzMGmZmZsNzMbjBAAAAAAAAMzM2AAAAwgxMzMzWbzMzAAAAAAMA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Cspøwer",
          ["guild"] = "Mandragore",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 201656,
          ["ilvl"] = 322,
          ["crit"] = 929,
          ["haste"] = 1253,
          ["mastery"] = 598,
          ["vers"] = 270,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYWMzMDMjZGzYmZGDzMzM2GzsNGGAAAAAAAAmZGbAAAAYgZmZmZrtZmZAgBAAAwA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Velstatd",
          ["guild"] = "Star Doggo Royal Club",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 199744,
          ["ilvl"] = 327,
          ["crit"] = 1455,
          ["haste"] = 1388,
          ["mastery"] = 122,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZmZmZkZmBziZMjhZMzYGzMzYYmZmx2DMzYMAAAAAAAAgZM2AAAAwgZmZmZ2abmZGAAAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Riemi",
          ["guild"] = "Awakeníng",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 196857,
          ["ilvl"] = 325,
          ["crit"] = 860,
          ["haste"] = 1135,
          ["mastery"] = 618,
          ["vers"] = 402,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmBziZmZmhZMzYGzYGDmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Frostyu",
          ["guild"] = "DMG",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 196784,
          ["ilvl"] = 324,
          ["crit"] = 829,
          ["haste"] = 1127,
          ["mastery"] = 154,
          ["vers"] = 908,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmBziZmZgZMzYmHYmZGDmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Xkito",
          ["guild"] = "Mate",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 195992,
          ["ilvl"] = 323,
          ["crit"] = 899,
          ["haste"] = 1469,
          ["mastery"] = 363,
          ["vers"] = 477,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYWMzMDMjZGzYmZGDzMzM2MzsNGGAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Venandí",
          ["guild"] = "Disciples Reborn",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 193206,
          ["ilvl"] = 323,
          ["crit"] = 1104,
          ["haste"] = 1347,
          ["mastery"] = 375,
          ["vers"] = 121,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYYmZGYGzMm5BmZmxwMzMjlHYmZbMAAAAAAAAgZmxGAAAAGMzMzMzWbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Tcdh",
          ["guild"] = "Lost Boys",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 192624,
          ["ilvl"] = 322,
          ["crit"] = 973,
          ["haste"] = 1128,
          ["mastery"] = 388,
          ["vers"] = 766,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZMjMzMYWMzMDMjZGzYmZGDzMzM2egZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 156282,
          ["ilvl"] = 321,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Rydia",
          ["guild"] = "Redemption Arc",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 144299,
          ["ilvl"] = 322,
          ["crit"] = 1008,
          ["haste"] = 1307,
          ["mastery"] = 482,
          ["vers"] = 327,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMzMzMjMzMYWMzMDMjZGzYmZGDzMzM2MzYMMAAAAAAAAMzM2AAAAwAzMzMzWbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Yodadhz",
          ["guild"] = "xD",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 142077,
          ["ilvl"] = 322,
          ["crit"] = 927,
          ["haste"] = 1246,
          ["mastery"] = 301,
          ["vers"] = 699,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMjMzMGzyMzMjhZMzYGzMzYwwM2MzsNGzAAAAAAAAwMGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Geffyz",
          ["guild"] = "Nox Venari",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 140737,
          ["ilvl"] = 324,
          ["crit"] = 791,
          ["haste"] = 1278,
          ["mastery"] = 596,
          ["vers"] = 312,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmBziZmZgZMzYmHYmZGDmZmx2MzYMAAAAAAAAgZmxGAAAAGMmZmZ2abmZGAYAAAAMA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Venandí",
          ["guild"] = "Disciples Reborn",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 139406,
          ["ilvl"] = 323,
          ["crit"] = 1104,
          ["haste"] = 1347,
          ["mastery"] = 375,
          ["vers"] = 121,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYYmZGYGzMm5BmZmxwMzMjlHYmZbMAAAAAAAAgZmxGAAAAGMzMzMzWbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Riemi",
          ["guild"] = "Awakeníng",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 138912,
          ["ilvl"] = 325,
          ["crit"] = 860,
          ["haste"] = 1135,
          ["mastery"] = 618,
          ["vers"] = 402,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmBziZmZgZMzYGzMzYYmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Zoomy",
          ["guild"] = "Hogs of War",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 138776,
          ["ilvl"] = 324,
          ["crit"] = 988,
          ["haste"] = 1136,
          ["mastery"] = 557,
          ["vers"] = 333,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjhZkZmBWMzMDmZMzYGzMzYYmZmx2YmtxYGAAAAAAAAmZGbAAAAYgZmZmZptZmZAgBAAAwA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Chase",
          ["guild"] = "mythic raid guild",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 137618,
          ["ilvl"] = 322,
          ["crit"] = 1172,
          ["haste"] = 1239,
          ["mastery"] = 344,
          ["vers"] = 354,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZmxMjMzMYWMzMDMjZGzYmZGDzMzM2MzsNGAAAAAAAAwMzYDAAAADGzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Velstatd",
          ["guild"] = "Star Doggo Royal Club",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 137603,
          ["ilvl"] = 327,
          ["crit"] = 1455,
          ["haste"] = 1388,
          ["mastery"] = 122,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZmZmZkZmBziZMjhZMzYGzMzYYmZmx2DMzYMAAAAAAAAgZM2AAAAwgZmZmZ2abmZGAAAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Pjålman",
          ["guild"] = "Trivial Content",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 137507,
          ["ilvl"] = 322,
          ["crit"] = 753,
          ["haste"] = 1085,
          ["mastery"] = 490,
          ["vers"] = 691,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmxYYmZGDzYmxMmZmxwMmZsZmZbMMAAAAAAAAMzM2AAAAwAzMzMzWbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Felvix",
          ["guild"] = "Reflection",
          ["boss"] = "Sszorak",
          ["amount"] = 120685,
          ["ilvl"] = 319,
          ["crit"] = 1026,
          ["haste"] = 1260,
          ["mastery"] = 278,
          ["vers"] = 343,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMzkZmZYYmZGDzYmxMmZmxwMmZsZmZbMMAAAAAAAAMjxGAAAAGMzMzMzSbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Avade",
          ["guild"] = "Lucid",
          ["boss"] = "Sszorak",
          ["amount"] = 113061,
          ["ilvl"] = 319,
          ["crit"] = 1179,
          ["haste"] = 1054,
          ["mastery"] = 359,
          ["vers"] = 349,
          ["trinkets"] = {
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZmxMjMzMYWMzMDMjZGzYmZGDzMzM2MzsNGAAAAAAAAwMzYDAAAADMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Riemi",
          ["guild"] = "Awakeníng",
          ["boss"] = "Sszorak",
          ["amount"] = 112720,
          ["ilvl"] = 326,
          ["crit"] = 864,
          ["haste"] = 1138,
          ["mastery"] = 622,
          ["vers"] = 405,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMzMDMjZGzYmZGDzMzM2MzsNGAAAAAAAAwMzYDAAAADGzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Супсуп",
          ["guild"] = "Кайзер",
          ["boss"] = "Sszorak",
          ["amount"] = 112295,
          ["ilvl"] = 320,
          ["crit"] = 1092,
          ["haste"] = 1172,
          ["mastery"] = 346,
          ["vers"] = 410,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmBziZmZgZMzYGzMzYYmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Bentwo",
          ["guild"] = "vodka",
          ["boss"] = "Sszorak",
          ["amount"] = 107491,
          ["ilvl"] = 326,
          ["crit"] = 929,
          ["haste"] = 1318,
          ["mastery"] = 201,
          ["vers"] = 818,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmBziZmZgZMzYmHYmZGDmZmx2MzsMGAAAAAAAAwMzYDAAAADMzMzMbtNzMDAAAAAwA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Slickezpz",
          ["guild"] = "miscalculated",
          ["boss"] = "Sszorak",
          ["amount"] = 107059,
          ["ilvl"] = 320,
          ["crit"] = 959,
          ["haste"] = 1239,
          ["mastery"] = 229,
          ["vers"] = 524,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjhZkZmBziZmZgZMzYGzMzYYmZmx2YmtxYGAAAAAAAAmZGbAAAAYgZmZmZptZmZAgBAAAwA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Soapdh",
          ["guild"] = "Resonance",
          ["boss"] = "Sszorak",
          ["amount"] = 105034,
          ["ilvl"] = 325,
          ["crit"] = 1101,
          ["haste"] = 1123,
          ["mastery"] = 262,
          ["vers"] = 695,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYWMzMDMjZGzYmZGDzMzM2egZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Cybeedh",
          ["guild"] = "Ethical",
          ["boss"] = "Sszorak",
          ["amount"] = 104473,
          ["ilvl"] = 316,
          ["crit"] = 796,
          ["haste"] = 1243,
          ["mastery"] = 514,
          ["vers"] = 500,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYYmZGDzYmxMPwMzMGMzMjtHYmZbMAAAAAAAAgZmxGAAAAGMzMzMzSbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Зефиреоса",
          ["guild"] = "Движуха (1 статик)",
          ["boss"] = "Sszorak",
          ["amount"] = 104207,
          ["ilvl"] = 324,
          ["crit"] = 1176,
          ["haste"] = 1152,
          ["mastery"] = 503,
          ["vers"] = 387,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmBziZmZgZMzYGzMzYYmZmx2MzYMAAAAAAAAgZmxGAAAAGMmZmZWabmZGAYAAAAMA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Frostyu",
          ["guild"] = "DMG",
          ["boss"] = "Sszorak",
          ["amount"] = 104200,
          ["ilvl"] = 318,
          ["crit"] = 954,
          ["haste"] = 1094,
          ["mastery"] = 240,
          ["vers"] = 634,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmBziZmZgZMzYmHYmZGDmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Avade",
          ["guild"] = "Lucid",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 183830,
          ["ilvl"] = 323,
          ["crit"] = 1091,
          ["haste"] = 1232,
          ["mastery"] = 455,
          ["vers"] = 394,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1234969,
            ["name"] = "Ethereal Augmentation"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmBWMzMDmZMzYGzMzYYmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Супсуп",
          ["guild"] = "Кайзер",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 174529,
          ["ilvl"] = 323,
          ["crit"] = 1149,
          ["haste"] = 1240,
          ["mastery"] = 461,
          ["vers"] = 335,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZmMzMwiZmZGmZMzYGzYGDzMzM2MzsNGAAAAAAAAwMzYDAAAADMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Thanquiol",
          ["guild"] = "Rain",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 144159,
          ["ilvl"] = 322,
          ["crit"] = 1043,
          ["haste"] = 1269,
          ["mastery"] = 440,
          ["vers"] = 389,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMzkZmBziZMDmZMzYmHYmZGDmZmx2MzsNGAAAAAAAAwMGbAAAAYwMzMzMLtNzMDAAAAAwA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Luthien",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 135598,
          ["ilvl"] = 325,
          ["crit"] = 773,
          ["haste"] = 1343,
          ["mastery"] = 260,
          ["vers"] = 798,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZmMzMYWMjZGmZMDz8AzYGDzMzM2egZmtxAAAAAAAAAmZGbAAAAYgZmZmZrtZmZAAAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Супсуп",
          ["guild"] = "Кайзер",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 129641,
          ["ilvl"] = 324,
          ["crit"] = 1432,
          ["haste"] = 503,
          ["mastery"] = 1059,
          ["vers"] = 194,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMmZkZmBziZmZgZMzYGzMzYYmZmxmZmtxAAAAAAAAAmZGbAAAAYwMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 123333,
          ["ilvl"] = 320,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Avade",
          ["guild"] = "Lucid",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 121967,
          ["ilvl"] = 321,
          ["crit"] = 1189,
          ["haste"] = 1269,
          ["mastery"] = 354,
          ["vers"] = 293,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZmxMjMzMYWMzMDMjZGzYmZGDzMzM2MzsNGAAAAAAAAwMzYDAAAADMzMzMbtNzMDAMAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Rydia",
          ["guild"] = "Redemption Arc",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 120318,
          ["ilvl"] = 322,
          ["crit"] = 1008,
          ["haste"] = 1307,
          ["mastery"] = 482,
          ["vers"] = 327,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMzMzMjMzMYWMzMDMjZGzYmZGDzMzM2MzYMMAAAAAAAAMzM2AAAAwAzMzMzWbzMzAADAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "正义必胜丶",
          ["guild"] = "毛会",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 116577,
          ["ilvl"] = 321,
          ["crit"] = 913,
          ["haste"] = 1411,
          ["mastery"] = 204,
          ["vers"] = 594,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmBziZmZMYMzYGzMzYYmZmx2MzgBAAAAAAAAMzM2AAAAwgZmZmZ2abmZGAYAAAAMA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Gigabozo",
          ["guild"] = "Moron",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 115081,
          ["ilvl"] = 322,
          ["crit"] = 1208,
          ["haste"] = 1118,
          ["mastery"] = 430,
          ["vers"] = 328,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMzMDMjZGzYmZGDzMzM2egZmtxAAAAAAAAAmZGbAAAAYwYmZmZrtZmZAAAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Velstatd",
          ["guild"] = "Star Doggo Royal Club",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 112613,
          ["ilvl"] = 327,
          ["crit"] = 1455,
          ["haste"] = 1388,
          ["mastery"] = 122,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZmZmZkZmBziZMjhZMzYGzMzYYmZmx2DMzYMAAAAAAAAgZM2AAAAwgZmZmZ2abmZGAAAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Velidela",
          ["guild"] = "Propaganda",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 110261,
          ["ilvl"] = 320,
          ["crit"] = 856,
          ["haste"] = 1453,
          ["mastery"] = 415,
          ["vers"] = 474,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1234969,
            ["name"] = "Ethereal Augmentation"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmZYWMzMDMjZGzMzMzYwwM2GzYMAAAAAAAAgZmxGAAAAGMmZmZWabmZGAMDAAAgB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Cspøwer",
          ["guild"] = "Mandragore",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 109305,
          ["ilvl"] = 321,
          ["crit"] = 908,
          ["haste"] = 1290,
          ["mastery"] = 423,
          ["vers"] = 269,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 159617,
              ["name"] = "Lustrous Golden Plumage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjxMjMzMYWMzMDMjZGzYmZGDzMzM2GzsNGGAAAAAAAAmZGbAAAAYgZmZmZrtZmZAgBAAAwA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Gøtøøne",
          ["guild"] = "Blue Castle",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 107477,
          ["ilvl"] = 318,
          ["crit"] = 1072,
          ["haste"] = 701,
          ["mastery"] = 859,
          ["vers"] = 309,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUkAAAAAAAAAAAAAAAAAAAAAAAAYMzMjZmZkZmZYWMzMzMMjZGzYGzYYGmx2DMzsNGAAAAAAAAwMzYDAAAADmZmZmZrtZmZAAAAAAG",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        }
      }
    },
    {
      ["spec"] = "Devourer",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Razzagall",
          ["guild"] = "Above Average",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 232394,
          ["ilvl"] = 326,
          ["crit"] = 1032,
          ["haste"] = 877,
          ["mastery"] = 1106,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mZmZmZmZMGmBAAAAAAgxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZZmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Vendyr",
          ["guild"] = "Return of the Watchers",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 230346,
          ["ilvl"] = 326,
          ["crit"] = 1019,
          ["haste"] = 825,
          ["mastery"] = 1241,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Gaminggamer",
          ["guild"] = "Xallytoes",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 228076,
          ["ilvl"] = 320,
          ["crit"] = 1132,
          ["haste"] = 862,
          ["mastery"] = 855,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAY5BGz2gZAAAAAAAAYGzwYmZmZmZmhZ2mZM202CAAMAzYmZ2mZmmtZWmZGjZA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Chuchx",
          ["guild"] = "The Chub Club",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 227047,
          ["ilvl"] = 321,
          ["crit"] = 808,
          ["haste"] = 1090,
          ["mastery"] = 1046,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMwMAAAAAAAbGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Soxxs",
          ["guild"] = "guppy pond",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 225014,
          ["ilvl"] = 324,
          ["crit"] = 1161,
          ["haste"] = 728,
          ["mastery"] = 1031,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "天渊丨漓梦",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 223239,
          ["ilvl"] = 324,
          ["crit"] = 979,
          ["haste"] = 985,
          ["mastery"] = 1126,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMmZmZmZmZGzsNzYsptFAAYAMmZmtZmpZbmlZmxYmB",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Vikdh",
          ["guild"] = "Reko",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 222250,
          ["ilvl"] = 325,
          ["crit"] = 1108,
          ["haste"] = 861,
          ["mastery"] = 1126,
          ["vers"] = 102,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Ahahahaxd",
          ["guild"] = "The Exiles",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 221252,
          ["ilvl"] = 322,
          ["crit"] = 1035,
          ["haste"] = 738,
          ["mastery"] = 1122,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzYmBzMAAAAAAAMmthZGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAAADgxMzsNzMNbzsMzMGzA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Pwnmuffinx",
          ["guild"] = "sound issues",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220713,
          ["ilvl"] = 322,
          ["crit"] = 947,
          ["haste"] = 864,
          ["mastery"] = 1132,
          ["vers"] = 176,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzwYmZmZmZmZMz2Mjxm2WAAgB4BGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Pewbee",
          ["guild"] = "Easy Katka",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220707,
          ["ilvl"] = 324,
          ["crit"] = 896,
          ["haste"] = 861,
          ["mastery"] = 1322,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZGzMGmBAAAAAAY5BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Grape",
          ["guild"] = "인앤아웃",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 207399,
          ["ilvl"] = 324,
          ["crit"] = 1406,
          ["haste"] = 765,
          ["mastery"] = 938,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAYZGjBzAAAAAAAAwMmhxMzMjZmZGzsNzYsptFAAYAmxMzsNzMNbzsMzMmxA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Âvril",
          ["guild"] = "Drama",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 204836,
          ["ilvl"] = 320,
          ["crit"] = 1214,
          ["haste"] = 800,
          ["mastery"] = 901,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Aeledrra",
          ["guild"] = "Review the Data",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 204042,
          ["ilvl"] = 323,
          ["crit"] = 1164,
          ["haste"] = 1060,
          ["mastery"] = 741,
          ["vers"] = 176,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Leahsalive",
          ["guild"] = "Without Limits",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 202457,
          ["ilvl"] = 325,
          ["crit"] = 933,
          ["haste"] = 894,
          ["mastery"] = 1117,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Omogucitelj",
          ["guild"] = "Kodeks",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 202255,
          ["ilvl"] = 317,
          ["crit"] = 1012,
          ["haste"] = 790,
          ["mastery"] = 1033,
          ["vers"] = 170,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Nathanail",
          ["guild"] = "Retreat",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 201965,
          ["ilvl"] = 324,
          ["crit"] = 1309,
          ["haste"] = 780,
          ["mastery"] = 988,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmxMzMzMzMwMAAAAAAAbGz2gZAAAAAAAAYGzwYmZmxMzMjZ2mZM202CAAMAzYmZ2mZmmtZWmZGzYA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Brisingar",
          ["guild"] = "Health Potion",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 199769,
          ["ilvl"] = 321,
          ["crit"] = 1034,
          ["haste"] = 803,
          ["mastery"] = 1151,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzwYmZmxMzMjZ2mZM202CAAMAzYmZ2mZmmtZWmZGzYA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Schizoiddh",
          ["guild"] = "Eternal Shadows",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198932,
          ["ilvl"] = 325,
          ["crit"] = 1085,
          ["haste"] = 843,
          ["mastery"] = 885,
          ["vers"] = 205,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmBmBAAAAAAwDMmtxDYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Purplebaba",
          ["guild"] = "Soft Enrage",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198657,
          ["ilvl"] = 320,
          ["crit"] = 1333,
          ["haste"] = 795,
          ["mastery"] = 870,
          ["vers"] = 164,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmxMGmBAAAAAAYZGjBzAAAAAAAAwMmhxMzMjZmZGzsNzYsptFAAYAmxMzsNzMNbzsMzMmxA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Nvs",
          ["guild"] = "Still Rooted",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198336,
          ["ilvl"] = 321,
          ["crit"] = 1088,
          ["haste"] = 832,
          ["mastery"] = 941,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMmZmZmZmZYmtZGjNttAAADwMmZmtZmpZbmlZmxYGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "无终恨意",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 338256,
          ["ilvl"] = 323,
          ["crit"] = 2745,
          ["haste"] = 812,
          ["mastery"] = 1086,
          ["vers"] = -116,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmBmBAAAAAAwMGjHwMAAAAAAAAMjZYegZmZmZmZmxMbzMGbabBAAGAjZmZbmZa2mZZmZMmBA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Kimbully",
          ["guild"] = "Death Star Architect",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 332858,
          ["ilvl"] = 321,
          ["crit"] = 1214,
          ["haste"] = 811,
          ["mastery"] = 906,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mZmZmZmhZGmBAAAAAAYxY2GMDAAAAAAAAzYw8AzMzMzMzMMz2MjxmsAAADwMmZmtZmpZZmlZmhZGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Huangdh",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 331897,
          ["ilvl"] = 328,
          ["crit"] = 1150,
          ["haste"] = 808,
          ["mastery"] = 1045,
          ["vers"] = 129,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMMz2MjxmsAAADwMmZmtZmpZbmlZmhZGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Leahsalive",
          ["guild"] = "Without Limits",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327860,
          ["ilvl"] = 325,
          ["crit"] = 933,
          ["haste"] = 894,
          ["mastery"] = 1117,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmZmZmZGjxwMAAAAAAALGz2gZAAAAAAAAYGzw8AzMzMzMzMMz2MjxmsAAADwMmZmtZmpZZmlZmhZGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Preddh",
          ["guild"] = "Gray Parses Only",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327305,
          ["ilvl"] = 321,
          ["crit"] = 1288,
          ["haste"] = 619,
          ["mastery"] = 993,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAAADgxMzsNzMNbzsMzMGzA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Castorice",
          ["guild"] = "Mostly Harmless",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 326519,
          ["ilvl"] = 324,
          ["crit"] = 751,
          ["haste"] = 1032,
          ["mastery"] = 1129,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Gonzlo",
          ["guild"] = "TED",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 325508,
          ["ilvl"] = 322,
          ["crit"] = 1076,
          ["haste"] = 789,
          ["mastery"] = 1075,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMzMwMAAAAAAAegxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAAADgxMzsNzMNbzsMzMGzA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Vendyr",
          ["guild"] = "Return of the Watchers",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 325352,
          ["ilvl"] = 322,
          ["crit"] = 1226,
          ["haste"] = 815,
          ["mastery"] = 1007,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Vv",
          ["guild"] = "POLAR",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323455,
          ["ilvl"] = 325,
          ["crit"] = 981,
          ["haste"] = 741,
          ["mastery"] = 1202,
          ["vers"] = 116,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMjBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzwMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "阿洋",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323145,
          ["ilvl"] = 325,
          ["crit"] = 1017,
          ["haste"] = 672,
          ["mastery"] = 2943,
          ["vers"] = -130,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMzMwMAAAAAAALPwY2GMDAAAAAAAAzYw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Pve",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 269140,
          ["ilvl"] = 324,
          ["crit"] = 1038,
          ["haste"] = 813,
          ["mastery"] = 1154,
          ["vers"] = 178,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAAADgxMzsNzMNbzsMzMGzA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Vendyr",
          ["guild"] = "Return of the Watchers",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 265845,
          ["ilvl"] = 326,
          ["crit"] = 1019,
          ["haste"] = 825,
          ["mastery"] = 1241,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Grape",
          ["guild"] = "인앤아웃",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 261098,
          ["ilvl"] = 322,
          ["crit"] = 1355,
          ["haste"] = 824,
          ["mastery"] = 902,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMjBmBAAAAAAY5BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Gonzlo",
          ["guild"] = "TED",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 260708,
          ["ilvl"] = 322,
          ["crit"] = 1076,
          ["haste"] = 789,
          ["mastery"] = 1075,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMzMwMAAAAAAAegxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAAADgxMzsNzMNbzsMzMGzA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "風靡万千少女",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 259548,
          ["ilvl"] = 324,
          ["crit"] = 982,
          ["haste"] = 1087,
          ["mastery"] = 962,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAMjZmZmZmZgZAAAAAAA8AjxYMDAAAAAAAAzYGmZmZmZmZmhZWMjxiswMzMzWbzMzAYYAAYGDGzA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Daysixx",
          ["guild"] = "Muisted",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 259184,
          ["ilvl"] = 322,
          ["crit"] = 1045,
          ["haste"] = 865,
          ["mastery"] = 1167,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFtswMzMzWbzMzAYGDAAGDGzA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "阿洋",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 259116,
          ["ilvl"] = 325,
          ["crit"] = 1017,
          ["haste"] = 672,
          ["mastery"] = 1219,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMzMwMAAAAAAALPwY2GMDAAAAAAAAzYw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Polteran",
          ["guild"] = "Salty Tears",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 257181,
          ["ilvl"] = 326,
          ["crit"] = 888,
          ["haste"] = 877,
          ["mastery"] = 1225,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Demerit",
          ["guild"] = "evicted",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 256620,
          ["ilvl"] = 323,
          ["crit"] = 1345,
          ["haste"] = 879,
          ["mastery"] = 817,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMzMwMAAAAAAAbPwY2GMDAAAAAAAAzYw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "镶钢戟折",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 256327,
          ["ilvl"] = 326,
          ["crit"] = 1014,
          ["haste"] = 841,
          ["mastery"] = 1317,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MzMzMzMzMwMAAAAAAAegxsMYGAAAAAAAAmxMMmZmZmZmZGzsNzYsptFAAYAegxMzsNzMNbzsMzMGzA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "샤샥샤샥퍽퍽",
          ["guild"] = "CRYSTAL",
          ["boss"] = "Sszorak",
          ["amount"] = 224603,
          ["ilvl"] = 326,
          ["crit"] = 1031,
          ["haste"] = 779,
          ["mastery"] = 1296,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Pve",
          ["guild"] = "Deception",
          ["boss"] = "Sszorak",
          ["amount"] = 223030,
          ["ilvl"] = 326,
          ["crit"] = 1040,
          ["haste"] = 824,
          ["mastery"] = 1158,
          ["vers"] = 178,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMzMwMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Dxh",
          ["guild"] = "Mentioned",
          ["boss"] = "Sszorak",
          ["amount"] = 221099,
          ["ilvl"] = 321,
          ["crit"] = 1084,
          ["haste"] = 748,
          ["mastery"] = 1178,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmxMzMGzMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Grape",
          ["guild"] = "인앤아웃",
          ["boss"] = "Sszorak",
          ["amount"] = 220191,
          ["ilvl"] = 324,
          ["crit"] = 1406,
          ["haste"] = 765,
          ["mastery"] = 938,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAYZGjBzAAAAAAAAwMmhxMzMjZmZGzsNzYsptFAAYAmxMzsNzMNbzsMzMmxA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Purplebaba",
          ["guild"] = "Soft Enrage",
          ["boss"] = "Sszorak",
          ["amount"] = 219771,
          ["ilvl"] = 327,
          ["crit"] = 1127,
          ["haste"] = 728,
          ["mastery"] = 1218,
          ["vers"] = 164,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmxMGmBAAAAAAYZGjBzAAAAAAAAwMmhxMzMjZmZGzsNzYsptFAAYAmxMzsNzMNbzsMzMmxA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Kaströ",
          ["guild"] = "Incarnate",
          ["boss"] = "Sszorak",
          ["amount"] = 218884,
          ["ilvl"] = 316,
          ["crit"] = 1296,
          ["haste"] = 791,
          ["mastery"] = 894,
          ["vers"] = 108,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmxMzMGzMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Huangdh",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 218089,
          ["ilvl"] = 328,
          ["crit"] = 1150,
          ["haste"] = 808,
          ["mastery"] = 1045,
          ["vers"] = 129,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAbPwY2GMDAAAAAAAAzYwYmZmxMzMjZ2mZM202CAAMAzYmZ2mZmmtZWmZGzYA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Crìms",
          ["guild"] = "Mental Apocalypse",
          ["boss"] = "Sszorak",
          ["amount"] = 217598,
          ["ilvl"] = 324,
          ["crit"] = 1022,
          ["haste"] = 790,
          ["mastery"] = 1159,
          ["vers"] = 196,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mZmZmZmZMGmBAAAAAAYxY2GMDAAAAAAAAzYwYmZmxMzMjZ2mZM202CAAMAzYmZ2mZmmtZ2mZGzYA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Influka",
          ["guild"] = "SEEREAL",
          ["boss"] = "Sszorak",
          ["amount"] = 216646,
          ["ilvl"] = 324,
          ["crit"] = 1174,
          ["haste"] = 938,
          ["mastery"] = 925,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAAADwMmZmtZmpZbmlZmxMGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Suolbeam",
          ["guild"] = "Slack",
          ["boss"] = "Sszorak",
          ["amount"] = 216480,
          ["ilvl"] = 324,
          ["crit"] = 969,
          ["haste"] = 745,
          ["mastery"] = 1182,
          ["vers"] = 229,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMYmBAAAAAAYxY2GMDAAAAAAAAzYwYmZmxMzMjZ2mZM202CAAMAzYmZ2mZmmtZ2mZGzYA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bobybigplays",
          ["guild"] = "Honestly",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 278956,
          ["ilvl"] = 323,
          ["crit"] = 886,
          ["haste"] = 840,
          ["mastery"] = 1194,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmxMzMzYmZGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Huangdh",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 273398,
          ["ilvl"] = 327,
          ["crit"] = 736,
          ["haste"] = 1027,
          ["mastery"] = 1224,
          ["vers"] = 129,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDAAGDGzA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "샤샥샤샥퍽퍽",
          ["guild"] = "CRYSTAL",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 272367,
          ["ilvl"] = 327,
          ["crit"] = 992,
          ["haste"] = 967,
          ["mastery"] = 1287,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzYmxwMAAAAAAAMmtxDYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Crìms",
          ["guild"] = "Mental Apocalypse",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 272041,
          ["ilvl"] = 324,
          ["crit"] = 990,
          ["haste"] = 987,
          ["mastery"] = 994,
          ["vers"] = 196,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Sylang",
          ["guild"] = "Divergence",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 271325,
          ["ilvl"] = 326,
          ["crit"] = 978,
          ["haste"] = 1056,
          ["mastery"] = 1064,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Flyveged",
          ["guild"] = "Rhythm",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 269965,
          ["ilvl"] = 326,
          ["crit"] = 953,
          ["haste"] = 934,
          ["mastery"] = 1250,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxYmBAAAAAAwDMmtBDAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Nepadh",
          ["guild"] = "macht DRUCK",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 269123,
          ["ilvl"] = 324,
          ["crit"] = 1010,
          ["haste"] = 846,
          ["mastery"] = 1054,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAMjZmZmxMjhZAAAAAAAYMbjxMAAAAAAAAMjZYmZmZmZmZmxMLmxYRLLMzMzs12MzMAGGAAMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Pve",
          ["guild"] = "Deception",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 268207,
          ["ilvl"] = 326,
          ["crit"] = 644,
          ["haste"] = 1082,
          ["mastery"] = 1296,
          ["vers"] = 178,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzYmxwMAAAAAAAMmthZGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDAAGDGzA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Jmý",
          ["guild"] = "颠倒梦想",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 266003,
          ["ilvl"] = 325,
          ["crit"] = 922,
          ["haste"] = 1038,
          ["mastery"] = 1116,
          ["vers"] = 99,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAMjZmZmZmZwMDAAAAAAw2DMzYMAAAAAAAAgZMYmZmZmZmZGmZxMGLyCzMzMbtNzMDghBAgZMYMD",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Rodeodh",
          ["guild"] = "TRK",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 265370,
          ["ilvl"] = 328,
          ["crit"] = 929,
          ["haste"] = 936,
          ["mastery"] = 1086,
          ["vers"] = 108,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmxMzMzMzMGmBAAAAAAYxY2GMDAAAAAAAAzYwMzMzMzMzMMziZMWkFmZmZ2abmZGADDAAzYwYGA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Joily",
          ["guild"] = "Ехо",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 269081,
          ["ilvl"] = 324,
          ["crit"] = 1046,
          ["haste"] = 804,
          ["mastery"] = 1055,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMYmBAAAAAAY7BGjBzAAAAAAAAwMGMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Khalîsî",
          ["guild"] = "Banelings",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 253344,
          ["ilvl"] = 318,
          ["crit"] = 821,
          ["haste"] = 1220,
          ["mastery"] = 748,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "阿洋",
          ["guild"] = "青春",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 252669,
          ["ilvl"] = 321,
          ["crit"] = 793,
          ["haste"] = 906,
          ["mastery"] = 1181,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZGzMGmBAAAAAAwDMmthZGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAAwMGMmB",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Crìms",
          ["guild"] = "Mental Apocalypse",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 252181,
          ["ilvl"] = 324,
          ["crit"] = 1073,
          ["haste"] = 814,
          ["mastery"] = 1148,
          ["vers"] = 102,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mZmZmZGjxwMAAAAAAALGz2gZAAAAAAAAYGzw8AzMzMzMzMMz2MjxmsAAADwMmZmtZmpZZmlZmhZGA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Twitchered",
          ["guild"] = "No Big Deal",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 251328,
          ["ilvl"] = 318,
          ["crit"] = 1099,
          ["haste"] = 1013,
          ["mastery"] = 805,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMzMwMAAAAAAAegxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAAADgxMzsNzMNbzsMzMGzA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Ercege",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 250091,
          ["ilvl"] = 322,
          ["crit"] = 846,
          ["haste"] = 989,
          ["mastery"] = 1093,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDAAGDGzA",
          ["hero"] = {
            ["name"] = "Annihilator",
            ["atlas"] = "talents-heroclass-demonhunter-annihilator",
            ["icon"] = "inv_12_dh_void_ability_voidfall"
          }
        },
        {
          ["name"] = "Vendyr",
          ["guild"] = "Return of the Watchers",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 250001,
          ["ilvl"] = 325,
          ["crit"] = 1017,
          ["haste"] = 814,
          ["mastery"] = 1241,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CAAMAGzMz2Mz0sNzyMzYMDA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Nathanail",
          ["guild"] = "Retreat",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 249643,
          ["ilvl"] = 324,
          ["crit"] = 1309,
          ["haste"] = 948,
          ["mastery"] = 819,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAAADgxMzsNzMNbzsMzMGzA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "Bevelarden",
          ["guild"] = "Pylon",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 248378,
          ["ilvl"] = 324,
          ["crit"] = 981,
          ["haste"] = 775,
          ["mastery"] = 1097,
          ["vers"] = 180,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MzMzMzYmZGmBAAAAAAgxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAAADgxMzsNzMNbzsMzMGzA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        },
        {
          ["name"] = "无终恨意",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 246718,
          ["ilvl"] = 319,
          ["crit"] = 2792,
          ["haste"] = 820,
          ["mastery"] = 986,
          ["vers"] = -116,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmBmBAAAAAAwMGjHwMAAAAAAAAMjZYegZmZmZmZmxMbzMGbabBAAGAjZmZbmZa2mZZmZYmBA",
          ["hero"] = {
            ["name"] = "Void-Scarred",
            ["atlas"] = "talents-heroclass-demonhunter-felscarred2",
            ["icon"] = "inv_ability_felscarreddemonhunter_demonsurge"
          }
        }
      }
    }
  }
}
