MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Mage"] = {
  ["className"] = "Mage",
  ["specs"] = {
    {
      ["spec"] = "Arcane",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Khanixx",
          ["guild"] = "Probability",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 255760,
          ["ilvl"] = 324,
          ["crit"] = 1472,
          ["haste"] = 1253,
          ["mastery"] = 477,
          ["vers"] = 619,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Søurx",
          ["guild"] = "Pool Noodle Pirates",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 255706,
          ["ilvl"] = 324,
          ["crit"] = 677,
          ["haste"] = 1053,
          ["mastery"] = 707,
          ["vers"] = 573,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswDMDamZGAAAGAwMz0sssMDAgNAAWgZmhNLzYmlZMmZmZGWYGzMzAAMAAADwMDYGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "理想舆祢想",
          ["guild"] = "为了联盟",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 254195,
          ["ilvl"] = 327,
          ["crit"] = 989,
          ["haste"] = 883,
          ["mastery"] = 510,
          ["vers"] = 625,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMPwswMDamZGAAAGAwMz0sssNDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "井芹仁菜",
          ["guild"] = "你说的都队",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 252189,
          ["ilvl"] = 325,
          ["crit"] = 967,
          ["haste"] = 757,
          ["mastery"] = 459,
          ["vers"] = 808,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswDMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Minamage",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 248593,
          ["ilvl"] = 322,
          ["crit"] = 1031,
          ["haste"] = 836,
          ["mastery"] = 491,
          ["vers"] = 614,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlltZAAsBAwGMzMsZZGzsMjxMzMzwCzYmZGAgBAAYAmZAGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Binmanbob",
          ["guild"] = "Vestige",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 247927,
          ["ilvl"] = 327,
          ["crit"] = 1042,
          ["haste"] = 1134,
          ["mastery"] = 592,
          ["vers"] = 295,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Neverr",
          ["guild"] = "炉火糖粥",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 247524,
          ["ilvl"] = 326,
          ["crit"] = 935,
          ["haste"] = 1149,
          ["mastery"] = 324,
          ["vers"] = 624,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswDMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "丶荒年",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 247173,
          ["ilvl"] = 324,
          ["crit"] = 809,
          ["haste"] = 1040,
          ["mastery"] = 805,
          ["vers"] = 345,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGmZZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwCzMzYGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "하은잉",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 245787,
          ["ilvl"] = 323,
          ["crit"] = 706,
          ["haste"] = 1028,
          ["mastery"] = 633,
          ["vers"] = 569,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Celaria",
          ["guild"] = "Inprogress",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 245718,
          ["ilvl"] = 321,
          ["crit"] = 881,
          ["haste"] = 963,
          ["mastery"] = 544,
          ["vers"] = 675,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmxsgZGamZGAAAGAwMz0sssMDAgNAA2gZmhNLzYmlZMmZmZGWYmZmZGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Khaelt",
          ["guild"] = "Honolulu",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 223551,
          ["ilvl"] = 325,
          ["crit"] = 958,
          ["haste"] = 833,
          ["mastery"] = 667,
          ["vers"] = 575,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAAYmZYzyMzMLzYMPwMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Thickchief",
          ["guild"] = "Pig Pen",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 221286,
          ["ilvl"] = 327,
          ["crit"] = 739,
          ["haste"] = 1262,
          ["mastery"] = 767,
          ["vers"] = 412,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "喵灬小柒",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 219300,
          ["ilvl"] = 323,
          ["crit"] = 926,
          ["haste"] = 1068,
          ["mastery"] = 295,
          ["vers"] = 649,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMPwswMDamZGAAAGAwMz0sssMDAgNAA2gZmhNLzYmlZMmZmZGWYGzMzAAMAAADwMDYGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "顶级帅哥",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 218995,
          ["ilvl"] = 325,
          ["crit"] = 924,
          ["haste"] = 1164,
          ["mastery"] = 597,
          ["vers"] = 333,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGLjlZmHYWwMDNzMDAAADAYmZaWW2mBAwGAAbwMzwmlZMzyMGzMzMDLMzMzMDAwAAAMAzMADAGmZG",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Lucasmagi",
          ["guild"] = "Sabotage",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 218239,
          ["ilvl"] = 326,
          ["crit"] = 1158,
          ["haste"] = 956,
          ["mastery"] = 399,
          ["vers"] = 637,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMPwswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Tazaras",
          ["guild"] = "Crystal Method",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217929,
          ["ilvl"] = 328,
          ["crit"] = 1617,
          ["haste"] = 1168,
          ["mastery"] = 439,
          ["vers"] = 525,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlllZAAsBAAYmZYzyMzMLzYMPwMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "大骂四方",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 216642,
          ["ilvl"] = 325,
          ["crit"] = 922,
          ["haste"] = 1093,
          ["mastery"] = 339,
          ["vers"] = 634,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGYZmZmFmZQzMzAAAwAAmZmmlltZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Vicmage",
          ["guild"] = "Fortune",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 216486,
          ["ilvl"] = 327,
          ["crit"] = 895,
          ["haste"] = 957,
          ["mastery"] = 509,
          ["vers"] = 674,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAwwYZm5BmFmZQzMzAAAwAAmZmmlltZAAsBAAYmZYzyMzMLzYMPwMzMswMzMzMAADAAwAMzAzMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Podocee",
          ["guild"] = "Mentality",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 215937,
          ["ilvl"] = 323,
          ["crit"] = 777,
          ["haste"] = 1244,
          ["mastery"] = 560,
          ["vers"] = 417,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "杨过",
          ["guild"] = "Scary maze",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 215466,
          ["ilvl"] = 329,
          ["crit"] = 904,
          ["haste"] = 953,
          ["mastery"] = 556,
          ["vers"] = 801,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Shandwà",
          ["guild"] = "WarGuilds",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 394853,
          ["ilvl"] = 325,
          ["crit"] = 810,
          ["haste"] = 998,
          ["mastery"] = 426,
          ["vers"] = 853,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Jayfuel",
          ["guild"] = "Poverty",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 382647,
          ["ilvl"] = 325,
          ["crit"] = 889,
          ["haste"] = 979,
          ["mastery"] = 496,
          ["vers"] = 587,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMsxMzMzMAADAAwAMzAMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "理想舆祢想",
          ["guild"] = "为了联盟",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 378693,
          ["ilvl"] = 323,
          ["crit"] = 993,
          ["haste"] = 858,
          ["mastery"] = 494,
          ["vers"] = 615,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssNDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "멜링",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 375998,
          ["ilvl"] = 322,
          ["crit"] = 596,
          ["haste"] = 1065,
          ["mastery"] = 719,
          ["vers"] = 519,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hazardmagee",
          ["guild"] = "Dumbrava Minunata",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 375141,
          ["ilvl"] = 323,
          ["crit"] = 710,
          ["haste"] = 1000,
          ["mastery"] = 779,
          ["vers"] = 486,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMGAAAGAwMz0sssMDAgNAA2gZmhNLzYmlZMmZmZGWYmZmZGAgBAAYAmZAGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Havocm",
          ["guild"] = "Medium",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 374233,
          ["ilvl"] = 328,
          ["crit"] = 830,
          ["haste"] = 852,
          ["mastery"] = 689,
          ["vers"] = 681,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlllZAAsBAwCMzMsZZGzsMjxMzMzwCzMzMzAAMAAADwMDwAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "欢跳的红烧肉",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 369762,
          ["ilvl"] = 324,
          ["crit"] = 955,
          ["haste"] = 900,
          ["mastery"] = 418,
          ["vers"] = 940,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYmNjlZmZW4BmBNzYAAAYAAzMTzyyyMAA2AAYDmZG2sMjZWmxYmZmZYhZmZmZAAGAAgBYmBYAwwMzA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "张来喜",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 367433,
          ["ilvl"] = 325,
          ["crit"] = 975,
          ["haste"] = 1032,
          ["mastery"] = 421,
          ["vers"] = 550,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMPwswMDamZGAAAGAwMz0sssNDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Tguy",
          ["guild"] = "The Amazing Zoo",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 367089,
          ["ilvl"] = 321,
          ["crit"] = 664,
          ["haste"] = 1077,
          ["mastery"] = 624,
          ["vers"] = 554,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmZmZZGj5BmZmhFmxMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Komako",
          ["guild"] = "ducks",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 366192,
          ["ilvl"] = 325,
          ["crit"] = 922,
          ["haste"] = 1117,
          ["mastery"] = 550,
          ["vers"] = 571,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Tguy",
          ["guild"] = "The Amazing Zoo",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 302165,
          ["ilvl"] = 327,
          ["crit"] = 676,
          ["haste"] = 1194,
          ["mastery"] = 593,
          ["vers"] = 520,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssNDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Azunazx",
          ["guild"] = "Twitch Prime",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 301584,
          ["ilvl"] = 326,
          ["crit"] = 848,
          ["haste"] = 1100,
          ["mastery"] = 427,
          ["vers"] = 598,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGamZGAAAGAwMz0sssMDAgNAA2gZmhNLzYmlZMmZmZGWYmZmZGAgBAAYAmZAGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Royaly",
          ["guild"] = "Proper Guild Name",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 298851,
          ["ilvl"] = 327,
          ["crit"] = 893,
          ["haste"] = 983,
          ["mastery"] = 838,
          ["vers"] = 516,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmZmZZGj5BmZmhFmxMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Keeraxm",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 297824,
          ["ilvl"] = 328,
          ["crit"] = 958,
          ["haste"] = 1115,
          ["mastery"] = 538,
          ["vers"] = 467,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlllZAAsBAAYmZYzyMzMLzYMPwMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Loobsta",
          ["guild"] = "velocity",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 295629,
          ["ilvl"] = 326,
          ["crit"] = 811,
          ["haste"] = 1051,
          ["mastery"] = 551,
          ["vers"] = 622,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAMzwMLzMzsgZQzMGAAAGAwMz0sssMDAgNAA2gZmhNLzMzsMjx8AzMzwCzMzMzAAMAAADwMDwAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Vaniljm",
          ["guild"] = "The Reckless",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 291909,
          ["ilvl"] = 325,
          ["crit"] = 841,
          ["haste"] = 1011,
          ["mastery"] = 626,
          ["vers"] = 654,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "玉玉",
          ["guild"] = "CLEAR_LOVE",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 289619,
          ["ilvl"] = 328,
          ["crit"] = 840,
          ["haste"] = 1065,
          ["mastery"] = 536,
          ["vers"] = 589,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmZmZZGj5BmZmhFmxMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Halkiasprime",
          ["guild"] = "Нет пути назад",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 289408,
          ["ilvl"] = 326,
          ["crit"] = 887,
          ["haste"] = 988,
          ["mastery"] = 726,
          ["vers"] = 404,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGamZGAAAGAwMz0sssMDAgNAAWgZmhNLzYmlZMmZmZGWYGzMzAAMAAADwMDYGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Màzz",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 288181,
          ["ilvl"] = 329,
          ["crit"] = 854,
          ["haste"] = 1124,
          ["mastery"] = 591,
          ["vers"] = 663,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Neverr",
          ["guild"] = "炉火糖粥",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 286241,
          ["ilvl"] = 325,
          ["crit"] = 914,
          ["haste"] = 1137,
          ["mastery"] = 324,
          ["vers"] = 623,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswDMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmZmZZGj5BmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Nanohaa",
          ["guild"] = "绝世丶",
          ["boss"] = "Sszorak",
          ["amount"] = 222748,
          ["ilvl"] = 323,
          ["crit"] = 898,
          ["haste"] = 946,
          ["mastery"] = 581,
          ["vers"] = 577,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGamZGAAAGAwMz0sssMDAgNAA2YMzMsZZGzsMjxMmZGWYGzMzAAMAAADwMDYGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Gladrien",
          ["guild"] = "Northern Sky",
          ["boss"] = "Sszorak",
          ["amount"] = 219634,
          ["ilvl"] = 330,
          ["crit"] = 778,
          ["haste"] = 1204,
          ["mastery"] = 730,
          ["vers"] = 503,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAgZmZGbWmZmZZGjxMzgFmxMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Kfcdwarf",
          ["guild"] = "TERRA",
          ["boss"] = "Sszorak",
          ["amount"] = 218653,
          ["ilvl"] = 324,
          ["crit"] = 750,
          ["haste"] = 1189,
          ["mastery"] = 570,
          ["vers"] = 453,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGmZZmZmFMDamZGAAAGAwMz0sssMDAgNAA2wMzMjNLzMzsMjxYmZwCzMzMzAAMAAADwMDwAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "玉玉",
          ["guild"] = "CLEAR_LOVE",
          ["boss"] = "Sszorak",
          ["amount"] = 216096,
          ["ilvl"] = 328,
          ["crit"] = 840,
          ["haste"] = 1065,
          ["mastery"] = 536,
          ["vers"] = 589,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAwMzMDbWmZmZZGjxMzgFmxMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Êdeñ",
          ["guild"] = "Quichons",
          ["boss"] = "Sszorak",
          ["amount"] = 214810,
          ["ilvl"] = 324,
          ["crit"] = 832,
          ["haste"] = 1114,
          ["mastery"] = 591,
          ["vers"] = 457,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAwCmZmZsZZmZmlZMGzMDWYmZmZGAgBAAYAmZAGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "드레고리",
          ["guild"] = "술공대",
          ["boss"] = "Sszorak",
          ["amount"] = 214718,
          ["ilvl"] = 325,
          ["crit"] = 618,
          ["haste"] = 934,
          ["mastery"] = 667,
          ["vers"] = 788,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAgZmZGbWmZmZZGjxMzgFmxMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Nazzlol",
          ["guild"] = "Sabotage",
          ["boss"] = "Sszorak",
          ["amount"] = 214176,
          ["ilvl"] = 326,
          ["crit"] = 838,
          ["haste"] = 1133,
          ["mastery"] = 392,
          ["vers"] = 630,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAgZmZGbWmZmZZGjxMzgFmxMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Maxîm",
          ["guild"] = "Una Familia",
          ["boss"] = "Sszorak",
          ["amount"] = 213156,
          ["ilvl"] = 324,
          ["crit"] = 788,
          ["haste"] = 1156,
          ["mastery"] = 479,
          ["vers"] = 565,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGYZmZmFmZQzMzAAAwAAmZmmlltZAAsBAAMzMzYzyMzMLzYMmZGswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Vanqbuff",
          ["guild"] = "Pure",
          ["boss"] = "Sszorak",
          ["amount"] = 211714,
          ["ilvl"] = 327,
          ["crit"] = 991,
          ["haste"] = 1150,
          ["mastery"] = 436,
          ["vers"] = 499,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAAMzMzYzyMzMLzYMmZGswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Màzz",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Sszorak",
          ["amount"] = 211501,
          ["ilvl"] = 329,
          ["crit"] = 854,
          ["haste"] = 1124,
          ["mastery"] = 591,
          ["vers"] = 663,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAgZmZGbWmZmZZGjxMzgFmZmZmBAYAAAGgZGgBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Immortious",
          ["guild"] = "Ancient Tempest",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 299340,
          ["ilvl"] = 326,
          ["crit"] = 502,
          ["haste"] = 1143,
          ["mastery"] = 730,
          ["vers"] = 638,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAwYZsMzMzCzMoZGDAAADAYmZaWWWmBAwGAALwMzwmlZMzyMGzMzMDLMzMzMDAwAAAMAzMADAGmZG",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Gladrien",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 298334,
          ["ilvl"] = 330,
          ["crit"] = 778,
          ["haste"] = 1204,
          ["mastery"] = 730,
          ["vers"] = 503,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAwCMzMsZZGzsMjxMzMzwCzMzMzAAMAAADwMDwAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Lunym",
          ["guild"] = "constant",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 297160,
          ["ilvl"] = 327,
          ["crit"] = 802,
          ["haste"] = 931,
          ["mastery"] = 393,
          ["vers"] = 905,
          ["trinkets"] = {
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGLjlZmZWYmBNzYAAAYAAzMTzyyyMAA2AAYBmZG2sMjZWmxYmZmZYhZMzMDAwAAAMAzMADAGmZG",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Boorat",
          ["guild"] = "YEP",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 294824,
          ["ilvl"] = 325,
          ["crit"] = 848,
          ["haste"] = 874,
          ["mastery"] = 766,
          ["vers"] = 505,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAwwYZmZmFmZQzMzAAAwAAmZmmlllZAAsBAwCMzMsZZGzsMjxMzMzwCzYmZGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Sniffuu",
          ["guild"] = "tre dagar",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 293341,
          ["ilvl"] = 329,
          ["crit"] = 995,
          ["haste"] = 967,
          ["mastery"] = 391,
          ["vers"] = 730,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGLjlZMzCzMoZGDAAADAYmZaWWWmBAwGAALwMzwmlZMzyMGzMzMDLMjZmZAAGAAgBYmBMDAGmZG",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "玉玉",
          ["guild"] = "CLEAR_LOVE",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 292153,
          ["ilvl"] = 328,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Wikí",
          ["guild"] = "Vibrant",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 291652,
          ["ilvl"] = 327,
          ["crit"] = 874,
          ["haste"] = 891,
          ["mastery"] = 730,
          ["vers"] = 566,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswDMDamxAAAwAAmZmmlllZAAsBAwCMzMsZZmZmlZMmHYmZGWYmZmZGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Neverr",
          ["guild"] = "炉火糖粥",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 291117,
          ["ilvl"] = 325,
          ["crit"] = 914,
          ["haste"] = 1137,
          ["mastery"] = 324,
          ["vers"] = 623,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZQzMzAAAwAAmZmmlllZAAsBAwCMzMsZZGzsMjxMzMzwCzMzMzAAMAAADwMDYGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Pokixd",
          ["guild"] = "Myth",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 290091,
          ["ilvl"] = 327,
          ["crit"] = 786,
          ["haste"] = 1063,
          ["mastery"] = 725,
          ["vers"] = 475,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlllZAAsBAwCMzMsZZGzsMjxMzMzwCzYmZGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "산성비님",
          ["guild"] = "인앤아웃",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 288849,
          ["ilvl"] = 325,
          ["crit"] = 753,
          ["haste"] = 971,
          ["mastery"] = 588,
          ["vers"] = 717,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssNDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Gladrien",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 248640,
          ["ilvl"] = 332,
          ["crit"] = 780,
          ["haste"] = 1363,
          ["mastery"] = 730,
          ["vers"] = 508,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAwGMzMsZZGzsMjxMzMzwCzMzMzAAMAAADwMDwAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Êdeñ",
          ["guild"] = "Quichons",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 242071,
          ["ilvl"] = 328,
          ["crit"] = 861,
          ["haste"] = 1118,
          ["mastery"] = 614,
          ["vers"] = 460,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAwCMzMsZZGzsMjxMzMzwCzMzMzAAMAAADwMDwAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Zxum",
          ["guild"] = "baited",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 241644,
          ["ilvl"] = 324,
          ["crit"] = 708,
          ["haste"] = 1119,
          ["mastery"] = 722,
          ["vers"] = 623,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Pokixd",
          ["guild"] = "Myth",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 241422,
          ["ilvl"] = 327,
          ["crit"] = 786,
          ["haste"] = 1199,
          ["mastery"] = 725,
          ["vers"] = 475,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwCzYmZGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Asimage",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 239275,
          ["ilvl"] = 330,
          ["crit"] = 1010,
          ["haste"] = 1249,
          ["mastery"] = 452,
          ["vers"] = 531,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Odymage",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 238982,
          ["ilvl"] = 327,
          ["crit"] = 1023,
          ["haste"] = 915,
          ["mastery"] = 648,
          ["vers"] = 613,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzQzMGAAAGAwMz0sssNDAgNAAWgZmhNLzYmlZMmZmZGWYmZGzAAMAAADwMDYGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Raelag",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 237258,
          ["ilvl"] = 328,
          ["crit"] = 593,
          ["haste"] = 1142,
          ["mastery"] = 752,
          ["vers"] = 743,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlllZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Khaelt",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 235463,
          ["ilvl"] = 328,
          ["crit"] = 1024,
          ["haste"] = 1184,
          ["mastery"] = 607,
          ["vers"] = 552,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlltZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "杨过",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 232694,
          ["ilvl"] = 329,
          ["crit"] = 904,
          ["haste"] = 953,
          ["mastery"] = 556,
          ["vers"] = 801,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Màzz",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 232255,
          ["ilvl"] = 325,
          ["crit"] = 1046,
          ["haste"] = 1155,
          ["mastery"] = 604,
          ["vers"] = 531,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Padflash",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 462830,
          ["ilvl"] = 330,
          ["crit"] = 881,
          ["haste"] = 1233,
          ["mastery"] = 411,
          ["vers"] = 1962,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlllZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Doydo",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 426189,
          ["ilvl"] = 329,
          ["crit"] = 683,
          ["haste"] = 1133,
          ["mastery"] = 540,
          ["vers"] = 683,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMPwswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Odymage",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 422070,
          ["ilvl"] = 331,
          ["crit"] = 752,
          ["haste"] = 1262,
          ["mastery"] = 610,
          ["vers"] = 1894,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzQzMGAAAGAwMz0sssNDAgNAA2gZmhNLzYmlZMmZmZGWYmZGzAAMAAADwMDYGAMMzM",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "법사재환이",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 376387,
          ["ilvl"] = 329,
          ["crit"] = 908,
          ["haste"] = 1135,
          ["mastery"] = 459,
          ["vers"] = 1957,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlllZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "玉玉",
          ["guild"] = "CLEAR_LOVE",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 296479,
          ["ilvl"] = 324,
          ["crit"] = 848,
          ["haste"] = 1055,
          ["mastery"] = 494,
          ["vers"] = 587,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGLjlZMzCzMoZmZAAAYAAzMTzyyyMAA2AAAMzMsZZGzsMjxMzMzwCzYmZGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Sãrdîne",
          ["guild"] = "Offline",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 295205,
          ["ilvl"] = 328,
          ["crit"] = 811,
          ["haste"] = 1033,
          ["mastery"] = 451,
          ["vers"] = 705,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamxAAAwAAmZmmlllZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Ajmd",
          ["guild"] = "Café Disco",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 293255,
          ["ilvl"] = 322,
          ["crit"] = 803,
          ["haste"] = 1042,
          ["mastery"] = 762,
          ["vers"] = 349,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGLjlZMzCzMoZmZAAAYAAzMTzyyyMAA2AAAMzMsZZGzsMjxMzMzwCzYmZGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Koldekevin",
          ["guild"] = "Revoke",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 292347,
          ["ilvl"] = 326,
          ["crit"] = 751,
          ["haste"] = 783,
          ["mastery"] = 743,
          ["vers"] = 774,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssNDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "豆腐竿",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 290770,
          ["ilvl"] = 324,
          ["crit"] = 925,
          ["haste"] = 931,
          ["mastery"] = 364,
          ["vers"] = 755,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMPwswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Akkharmage",
          ["guild"] = "Competence Optional",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 289475,
          ["ilvl"] = 325,
          ["crit"] = 660,
          ["haste"] = 970,
          ["mastery"] = 716,
          ["vers"] = 659,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswDMDamZGAAAGAwMz0sssNDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "头酱丶",
          ["guild"] = "重逢",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 288951,
          ["ilvl"] = 326,
          ["crit"] = 917,
          ["haste"] = 1042,
          ["mastery"] = 633,
          ["vers"] = 478,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswDMDamZGAAAGAwMz0sssNDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "冰皮烧饼",
          ["guild"] = "燃烧神话-白银之手",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 288540,
          ["ilvl"] = 321,
          ["crit"] = 806,
          ["haste"] = 902,
          ["mastery"] = 207,
          ["vers"] = 1013,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAYGmZZmxsgZGamZGAAAGAwMz0sssNDAgNAA2YMzMsZZGzsMjxMmZGWYmZmZGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "小沐曾雪菜",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 287775,
          ["ilvl"] = 325,
          ["crit"] = 718,
          ["haste"] = 1091,
          ["mastery"] = 208,
          ["vers"] = 1011,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwCzMzYGAgBAAYAmZAzAghZmB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Chicoop",
          ["guild"] = "Fierce",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 287754,
          ["ilvl"] = 324,
          ["crit"] = 658,
          ["haste"] = 1077,
          ["mastery"] = 864,
          ["vers"] = 357,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAAYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGgBADzMD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        }
      }
    },
    {
      ["spec"] = "Fire",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Volii",
          ["guild"] = "Spite",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 218533,
          ["ilvl"] = 323,
          ["crit"] = 109,
          ["haste"] = 1205,
          ["mastery"] = 748,
          ["vers"] = 873,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMW4BmZkZmZAAAYAAzMTzy2yMAAbmZGbzMzMjNAAAAAsYmZmBAAmxYmZmxMzyAwMDwYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Chillbrô",
          ["guild"] = "Melk Trupp",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215906,
          ["ilvl"] = 325,
          ["crit"] = 126,
          ["haste"] = 2283,
          ["mastery"] = 906,
          ["vers"] = 674,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGLAAAAAYxMjZAAgZMmZmZMzsMAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "来个灌注",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 214299,
          ["ilvl"] = 324,
          ["crit"] = 133,
          ["haste"] = 1456,
          ["mastery"] = 825,
          ["vers"] = 719,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFegZGZmZGAAAGAwMz0sstNDAwmZmx2MzMzAAAAAAWMzMzAAAzYMzMzYmZZAYmBGjBMDjB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hinamonet",
          ["guild"] = "Zero Logic",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 213132,
          ["ilvl"] = 324,
          ["crit"] = 110,
          ["haste"] = 1433,
          ["mastery"] = 782,
          ["vers"] = 788,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzAMGwMMGA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Экседо",
          ["guild"] = "Нет пути назад",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 211378,
          ["ilvl"] = 324,
          ["crit"] = 117,
          ["haste"] = 1740,
          ["mastery"] = 879,
          ["vers"] = 407,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFmZGZmZGAAAGAwMz0sstMDAwmZmx2MzMzYBAAAAAbmZMDAAMjxMzMjZmlBgZGwMGwMMA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hrslkks",
          ["guild"] = "Main Tank Heal",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 211206,
          ["ilvl"] = 321,
          ["crit"] = 130,
          ["haste"] = 1405,
          ["mastery"] = 1101,
          ["vers"] = 487,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmxAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYzMzMzAAgZMmZmZegZmlBgZGgxAMMGA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "小鸟游小埋",
          ["guild"] = "哔哩哔哩-伊利丹",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 209969,
          ["ilvl"] = 318,
          ["crit"] = 83,
          ["haste"] = 1184,
          ["mastery"] = 1076,
          ["vers"] = 523,
          ["trinkets"] = {
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZGDAAADAYmZaW2WmBAYzMzYbmZmZsAAAAAgNzMzMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "周大漂亮",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 197169,
          ["ilvl"] = 325,
          ["crit"] = 123,
          ["haste"] = 1618,
          ["mastery"] = 634,
          ["vers"] = 749,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMPwsMegZIzMzAAAwAAmZmmltlZAA2MzMz2MzMzYBAAAAAbmZmZGAAMjxMzMjZmNAMzAMGghxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Benitok",
          ["guild"] = "The Well",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 196461,
          ["ilvl"] = 318,
          ["crit"] = 121,
          ["haste"] = 1484,
          ["mastery"] = 1811,
          ["vers"] = 498,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYzMjZAAgZMmZmZMzsNAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Pepiberry",
          ["guild"] = "Balkanlink",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 195026,
          ["ilvl"] = 314,
          ["crit"] = 71,
          ["haste"] = 1425,
          ["mastery"] = 1096,
          ["vers"] = 468,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMzAAAwAAmZmmtllZAA2MzM2GzMzYDAAAAALmZmZGAAMmxMmZmZmNAMzAMGDmhBA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hrslkks",
          ["guild"] = "Main Tank Heal",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 193651,
          ["ilvl"] = 321,
          ["crit"] = 130,
          ["haste"] = 1405,
          ["mastery"] = 1101,
          ["vers"] = 487,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMGAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAAbmZmZGAAMjxMzMjZmlBgZGgxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "饿虎扑羊",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 193489,
          ["ilvl"] = 321,
          ["crit"] = 115,
          ["haste"] = 1055,
          ["mastery"] = 981,
          ["vers"] = 830,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAwwYZmZmFmZGZmZGAAAGAwMz0sttMDAwmZmx2MzMzAAAAAAWMzMz8AAAYGjZmZGzMLDAzMwYMgZYMA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Shimon",
          ["guild"] = "운동공부",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 192596,
          ["ilvl"] = 319,
          ["crit"] = 267,
          ["haste"] = 1099,
          ["mastery"] = 1233,
          ["vers"] = 272,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGmZZmZmFmZIzMzAAAwAAmZmmlllZAA2MzM2mZmZGAAAAAwiZmZmBAAzYMzMzYmZZAYmBYMgZYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "小鸟游小埋",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 191472,
          ["ilvl"] = 324,
          ["crit"] = 16,
          ["haste"] = 1212,
          ["mastery"] = 1185,
          ["vers"] = 556,
          ["trinkets"] = {
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZGDAAADAYmZaW2WmBAYzMzYbmZmZsAAAAAgFzMzMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "来个灌注",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 190367,
          ["ilvl"] = 324,
          ["crit"] = 133,
          ["haste"] = 1456,
          ["mastery"] = 825,
          ["vers"] = 719,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFegZGZmZGAAAGAwMz0sstNDAwmZmx2MzMzAAAAAAWMzMzAAAzYMzMzYmZZAYmBGjBMDjB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Émptinêss",
          ["guild"] = "Axon Terminal",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 189480,
          ["ilvl"] = 326,
          ["crit"] = 264,
          ["haste"] = 1135,
          ["mastery"] = 970,
          ["vers"] = 596,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZmZAAAYAAzMTzy22MAAbmZGbzMzMjFAAAAAsYmxMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Benitok",
          ["guild"] = "The Well",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 183234,
          ["ilvl"] = 322,
          ["crit"] = 75,
          ["haste"] = 1405,
          ["mastery"] = 1003,
          ["vers"] = 540,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYzMjZAAgZMmZmZMzsNAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hinamonet",
          ["guild"] = "Zero Logic",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 174181,
          ["ilvl"] = 317,
          ["crit"] = 16,
          ["haste"] = 1274,
          ["mastery"] = 944,
          ["vers"] = 742,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzAMGwMMGA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Eliöt",
          ["guild"] = "The Extendables",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 173184,
          ["ilvl"] = 321,
          ["crit"] = 342,
          ["haste"] = 1364,
          ["mastery"] = 793,
          ["vers"] = 580,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYBAAAAALmZmZAAgZMmZmZMzsMAMzAMGwMMGA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Vli",
          ["guild"] = "Noni",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 172679,
          ["ilvl"] = 325,
          ["crit"] = 515,
          ["haste"] = 1142,
          ["mastery"] = 831,
          ["vers"] = 486,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZmZAAAYAAzMTzy22MAAbmZGbzMzMjFAAAAAsYmxMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Purgymage",
          ["guild"] = "Incendaríus",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 370847,
          ["ilvl"] = 323,
          ["crit"] = 142,
          ["haste"] = 1248,
          ["mastery"] = 1005,
          ["vers"] = 656,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Reidy",
          ["guild"] = "Biggie Chief and da Boys",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 355042,
          ["ilvl"] = 322,
          ["crit"] = 112,
          ["haste"] = 1321,
          ["mastery"] = 920,
          ["vers"] = 699,
          ["trinkets"] = {
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMjZAAgZMmZmZMzsMAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hrslkks",
          ["guild"] = "Main Tank Heal",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 350330,
          ["ilvl"] = 321,
          ["crit"] = 130,
          ["haste"] = 1408,
          ["mastery"] = 1060,
          ["vers"] = 534,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMW4BmhMzYAAAYAAzMTzy22MAAbmZGbzMzMjNAAAAAsYmZmZAAwMGzMzMPwMzCAmZAGDYGGD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Eliöt",
          ["guild"] = "The Extendables",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 348385,
          ["ilvl"] = 324,
          ["crit"] = 577,
          ["haste"] = 1391,
          ["mastery"] = 454,
          ["vers"] = 567,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYBAAAAALmZmZAAgZMmZmZMzsMAMzAMGwMMGA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Asuriax",
          ["guild"] = "SCH",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323741,
          ["ilvl"] = 324,
          ["crit"] = 272,
          ["haste"] = 1429,
          ["mastery"] = 789,
          ["vers"] = 589,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZm5B2mZmZGAAAAAwiZmZmBAAzYMzMzYmZDAzMwYMgZYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "小鸟游小埋",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 304922,
          ["ilvl"] = 319,
          ["crit"] = 83,
          ["haste"] = 1189,
          ["mastery"] = 1248,
          ["vers"] = 364,
          ["trinkets"] = {
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZGDAAADAYmZaW2WmBAYzMzYbmZmZsAAAAAgNzMzMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Shimon",
          ["guild"] = "운동공부",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 301682,
          ["ilvl"] = 319,
          ["crit"] = 267,
          ["haste"] = 1099,
          ["mastery"] = 1233,
          ["vers"] = 272,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGmZZmZmFmZIzMzAAAwAAmZmmlllZAA2MzM2mZmZGAAAAAwiZmZmBAAzYMzMzYmZZAYmBYMgZYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Émptinêss",
          ["guild"] = "Axon Terminal",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 299487,
          ["ilvl"] = 322,
          ["crit"] = 357,
          ["haste"] = 1182,
          ["mastery"] = 827,
          ["vers"] = 524,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZmZAAAYAAzMTzy22MAAbmZGbzMzMjFAAAAAsYmxMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Jellonio",
          ["guild"] = "Milkin Time",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 299068,
          ["ilvl"] = 319,
          ["crit"] = 251,
          ["haste"] = 2452,
          ["mastery"] = 1031,
          ["vers"] = 1088,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwMLzMzsgZGZmZGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAAbmZMDAAMjxMzMjZmtBgZGYMGwMMGA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Âefka",
          ["guild"] = "Tatortreiniger",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 283286,
          ["ilvl"] = 320,
          ["crit"] = 305,
          ["haste"] = 1362,
          ["mastery"] = 1054,
          ["vers"] = 351,
          ["trinkets"] = {
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZmx2MzMzAAAAAA2MzMzMAAYGjZmZGzMbDAzMAjBMDjB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Émptinêss",
          ["guild"] = "Axon Terminal",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 272549,
          ["ilvl"] = 326,
          ["crit"] = 358,
          ["haste"] = 1125,
          ["mastery"] = 822,
          ["vers"] = 706,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZmZAAAYAAzMTzy22MAAbmZGbzMzMjFAAAAAsYmxMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "小鸟游小埋",
          ["guild"] = "哔哩哔哩-伊利丹",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 247858,
          ["ilvl"] = 324,
          ["crit"] = 16,
          ["haste"] = 1212,
          ["mastery"] = 1185,
          ["vers"] = 556,
          ["trinkets"] = {
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZGDAAADAYmZaW2WmBAYzMzYbmZmZsAAAAAgFzMzMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Экседо",
          ["guild"] = "Нет пути назад",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 244470,
          ["ilvl"] = 324,
          ["crit"] = 117,
          ["haste"] = 1740,
          ["mastery"] = 879,
          ["vers"] = 407,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFmZGZmZGAAAGAwMz0sstMDAwmZmx2MzMzYBAAAAAbmZMDAAMjxMzMjZmlBgZGwMGwMMA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Taynï",
          ["guild"] = "Resonance",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 241155,
          ["ilvl"] = 318,
          ["crit"] = 13,
          ["haste"] = 1163,
          ["mastery"] = 1118,
          ["vers"] = 597,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGLjlZmZWwMjMzMDAAADAYmZaW2WmBAYzMzYbmZmZsBAAAAgFzMmBAAmxYmZmxMz2AwMDmxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Chillbrô",
          ["guild"] = "Melk Trupp",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 241055,
          ["ilvl"] = 325,
          ["crit"] = 126,
          ["haste"] = 2283,
          ["mastery"] = 906,
          ["vers"] = 674,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGLAAAAAYxMjZAAgZMmZmZMzsMAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hrslkks",
          ["guild"] = "Main Tank Heal",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 237080,
          ["ilvl"] = 321,
          ["crit"] = 130,
          ["haste"] = 1405,
          ["mastery"] = 1101,
          ["vers"] = 487,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMGAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAAbmZmZGAAMjxMzMjZmlBgZGgxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Shimon",
          ["guild"] = "운동공부",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 226208,
          ["ilvl"] = 319,
          ["crit"] = 267,
          ["haste"] = 1099,
          ["mastery"] = 1231,
          ["vers"] = 271,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGmZZmZmFmZIzMzAAAwAAmZmmlllZAA2MzM2mZmZGAAAAAwiZmZmBAAzYMzMzYmZZAYmBYMgZYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Baddylul",
          ["guild"] = "Last Attempt",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 225944,
          ["ilvl"] = 317,
          ["crit"] = 108,
          ["haste"] = 1351,
          ["mastery"] = 1061,
          ["vers"] = 505,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sttNDAwmZmx2MzMzAAAAAAWMzMzMAAYGjZmZGzMLDAzMAjBMDjB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "来个灌注",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 223396,
          ["ilvl"] = 324,
          ["crit"] = 133,
          ["haste"] = 1456,
          ["mastery"] = 825,
          ["vers"] = 719,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFegZGZmZGAAAGAwMz0sstNDAwmZmx2MzMzAAAAAAWMzMzAAAzYMzMzYmZZAYmBGjBMDjB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hinamonet",
          ["guild"] = "Zero Logic",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 216008,
          ["ilvl"] = 317,
          ["crit"] = 16,
          ["haste"] = 1219,
          ["mastery"] = 1172,
          ["vers"] = 570,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            },
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzAMGwMMGA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Émptinêss",
          ["guild"] = "Axon Terminal",
          ["boss"] = "Sszorak",
          ["amount"] = 203818,
          ["ilvl"] = 326,
          ["crit"] = 358,
          ["haste"] = 1125,
          ["mastery"] = 822,
          ["vers"] = 706,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZmZAAAYAAzMTzy22MAAbmZGbzMzMjFAAAAAsYmxMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Asuriax",
          ["guild"] = "SCH",
          ["boss"] = "Sszorak",
          ["amount"] = 192775,
          ["ilvl"] = 324,
          ["crit"] = 272,
          ["haste"] = 1429,
          ["mastery"] = 789,
          ["vers"] = 589,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZm5B2mZmZGAAAAAwiZmZmBAAzYMzMzYmZbAYmBGjBYYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Nikko",
          ["guild"] = "Aprèm",
          ["boss"] = "Sszorak",
          ["amount"] = 177718,
          ["ilvl"] = 323,
          ["crit"] = 108,
          ["haste"] = 1284,
          ["mastery"] = 1075,
          ["vers"] = 628,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMjZAAgZMmZmZMzsMAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Vli",
          ["guild"] = "Noni",
          ["boss"] = "Sszorak",
          ["amount"] = 177387,
          ["ilvl"] = 325,
          ["crit"] = 515,
          ["haste"] = 1142,
          ["mastery"] = 831,
          ["vers"] = 486,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZmZAAAYAAzMTzy22MAAbmZGbzMzMjFAAAAAsYmxMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Boisvertz",
          ["guild"] = "Blasphemy",
          ["boss"] = "Sszorak",
          ["amount"] = 169624,
          ["ilvl"] = 326,
          ["crit"] = 560,
          ["haste"] = 1252,
          ["mastery"] = 626,
          ["vers"] = 610,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstNDAwmZmx2MzMzAAAAAAWMzMzMAAYGjZmZGzMLDAzMAjBMDjB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Vecordia",
          ["guild"] = "DÅRHUSET",
          ["boss"] = "Sszorak",
          ["amount"] = 143370,
          ["ilvl"] = 321,
          ["crit"] = 234,
          ["haste"] = 1344,
          ["mastery"] = 917,
          ["vers"] = 481,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFmZGZmxAAAwAAmZmmlllZAA2MzM2mZmZGAAAAAwiZmZGAAYGjZmZGzMbDAzMwYMgZYMA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Bhronic",
          ["guild"] = "SDS",
          ["boss"] = "Sszorak",
          ["amount"] = 142651,
          ["ilvl"] = 321,
          ["crit"] = 382,
          ["haste"] = 1294,
          ["mastery"] = 783,
          ["vers"] = 497,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFegZGZmZGAAAGAwMz0sstNDAwmZmx2MzMzYBAAAAAbmZMDAAMjxMzMjZmlBgZGYMGwMMGA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hrslkks",
          ["guild"] = "Main Tank Heal",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 236525,
          ["ilvl"] = 321,
          ["crit"] = 130,
          ["haste"] = 1405,
          ["mastery"] = 1101,
          ["vers"] = 487,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGLjlZmZW4BmhMzYAAAYAAzMTzy22MAAbmZGbzMzMjNAAAAAsYmZmZAAwMGzMzMPwMzCAmZAGDYGGD",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Metitintinae",
          ["guild"] = "Aeterna",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 223703,
          ["ilvl"] = 320,
          ["crit"] = 16,
          ["haste"] = 1438,
          ["mastery"] = 985,
          ["vers"] = 552,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 315
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzssMWmZmZBzMyMzMAAAMAgZmpZZbZGAgNzMjtZmZmxGAAAAAWMzYGAAYGjZmZGzMbDAzMAjBMDjB",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "小鸟游小埋",
          ["guild"] = "哔哩哔哩-伊利丹",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 222056,
          ["ilvl"] = 318,
          ["crit"] = 99,
          ["haste"] = 1155,
          ["mastery"] = 1143,
          ["vers"] = 476,
          ["trinkets"] = {
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZGDAAADAYmZaW2WmBAYzMzYbmZmZsAAAAAgNzMzMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Purgymage",
          ["guild"] = "Incendaríus",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 219318,
          ["ilvl"] = 323,
          ["crit"] = 142,
          ["haste"] = 1248,
          ["mastery"] = 1005,
          ["vers"] = 656,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Asuriax",
          ["guild"] = "SCH",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 213448,
          ["ilvl"] = 318,
          ["crit"] = 216,
          ["haste"] = 1629,
          ["mastery"] = 665,
          ["vers"] = 427,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZmx2MzMzAAAAAAWMzMzMAAYGjZmZmHYmZDAzMwYMgZYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Émptinêss",
          ["guild"] = "Axon Terminal",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 212942,
          ["ilvl"] = 326,
          ["crit"] = 264,
          ["haste"] = 1135,
          ["mastery"] = 970,
          ["vers"] = 596,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzYZsMzMzCmZkZmZAAAYAAzMTzy22MAAbmZGbzMzMjFAAAAAsYmxMAAwMGzMzMmZWGAmZgxYAzwYA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Hinamonet",
          ["guild"] = "Zero Logic",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 210390,
          ["ilvl"] = 318,
          ["crit"] = 16,
          ["haste"] = 1326,
          ["mastery"] = 1052,
          ["vers"] = 628,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250144,
              ["name"] = "Emberwing Feather",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzAMGwMMGA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "我愛蘑菇酱",
          ["guild"] = "Vendetta",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 209621,
          ["ilvl"] = 326,
          ["crit"] = 431,
          ["haste"] = 1220,
          ["mastery"] = 876,
          ["vers"] = 699,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYmtFWmZmZBzQmZmBAAgBAMzMNLbLzAAsZmZsNzMzM2AAAAAwiZmZmBAAzYMzMzYmZZAYmBYMgZYMA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "Chillbrô",
          ["guild"] = "Melk Trupp",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 202557,
          ["ilvl"] = 322,
          ["crit"] = 16,
          ["haste"] = 2250,
          ["mastery"] = 798,
          ["vers"] = 861,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGLAAAAAYxMjZAAgZMmZmZMzsMAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        },
        {
          ["name"] = "菜鸟斌难顶了",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 201030,
          ["ilvl"] = 322,
          ["crit"] = 115,
          ["haste"] = 1335,
          ["mastery"] = 664,
          ["vers"] = 894,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZIzMzMAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAALmZMzAAgZMmZmZMzsMAMzAjxAmhxA",
          ["hero"] = {
            ["name"] = "Sunfury",
            ["atlas"] = "talents-heroclass-mage-sunfury",
            ["icon"] = "inv_1115_mage_spellfirespheresgeneration"
          }
        }
      }
    },
    {
      ["spec"] = "Frost",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Choechoi",
          ["guild"] = "운동공부",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220424,
          ["ilvl"] = 326,
          ["crit"] = 1022,
          ["haste"] = 721,
          ["mastery"] = 1251,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZEzMzYmZmZWMzMjZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZGmthxMsAAAwMbAzADYGMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Zhenglanxin",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215478,
          ["ilvl"] = 325,
          ["crit"] = 1196,
          ["haste"] = 646,
          ["mastery"] = 1114,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMjYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMzwsNMmhFAAAmZDYGYAzghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "饿德",
          ["guild"] = "十字路口",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 211792,
          ["ilvl"] = 326,
          ["crit"] = 1326,
          ["haste"] = 517,
          ["mastery"] = 1207,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "我叫加摩尔",
          ["guild"] = "凝聚",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 205406,
          ["ilvl"] = 323,
          ["crit"] = 1431,
          ["haste"] = 495,
          ["mastery"] = 1069,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAwwYZmZmlhZEzMzMzMzMziZmhZMDAAAMzMzyyMTbAAwGAAAYDgtlxMzMDz28AGzwCAAAzsBMDMgZwwA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Gamamage",
          ["guild"] = "Pull On Two",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 204669,
          ["ilvl"] = 324,
          ["crit"] = 1836,
          ["haste"] = 541,
          ["mastery"] = 1569,
          ["vers"] = 189,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbbMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Sukylol",
          ["guild"] = "Raize",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 204208,
          ["ilvl"] = 322,
          ["crit"] = 1236,
          ["haste"] = 679,
          ["mastery"] = 888,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Dezign",
          ["guild"] = "Odyns Chosen",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 203096,
          ["ilvl"] = 323,
          ["crit"] = 754,
          ["haste"] = 880,
          ["mastery"] = 907,
          ["vers"] = 483,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Nerolís",
          ["guild"] = "Goblinbl",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 202715,
          ["ilvl"] = 321,
          ["crit"] = 1181,
          ["haste"] = 332,
          ["mastery"] = 1422,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 246304,
              ["name"] = "Darkmoon Dominion: Hunt",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZEzMzYmZmZWMzMjZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZGmthxMsAAAwMbAzADYGMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Terstroik",
          ["guild"] = "Skill Issue",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 198414,
          ["ilvl"] = 326,
          ["crit"] = 1319,
          ["haste"] = 613,
          ["mastery"] = 1114,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZmZmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMmBz2wYGWAAAYmNgZgBMDGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Khirran",
          ["guild"] = "Stupid Fat Hobbits",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 197376,
          ["ilvl"] = 323,
          ["crit"] = 1180,
          ["haste"] = 737,
          ["mastery"] = 1105,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmxYmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMzMY2GGzwCAAAzsBMDMgZwwA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Choechoi",
          ["guild"] = "운동공부",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 263773,
          ["ilvl"] = 328,
          ["crit"] = 1027,
          ["haste"] = 723,
          ["mastery"] = 1254,
          ["vers"] = 112,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Zhenglanxin",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 239207,
          ["ilvl"] = 326,
          ["crit"] = 1198,
          ["haste"] = 646,
          ["mastery"] = 1115,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAwwYZmZmFmZEzMzYmZmZWMzMjZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZGmthxMsAAAwMbAzgZAzghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Terstroik",
          ["guild"] = "Skill Issue",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 235245,
          ["ilvl"] = 321,
          ["crit"] = 1216,
          ["haste"] = 705,
          ["mastery"] = 1077,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZmZmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMmBz2wYGWAAAYmNgZgBMDGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Paexs",
          ["guild"] = "Huskies eSports",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 233194,
          ["ilvl"] = 326,
          ["crit"] = 1861,
          ["haste"] = 553,
          ["mastery"] = 1047,
          ["vers"] = 274,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Noribert",
          ["guild"] = "Infinity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 231412,
          ["ilvl"] = 327,
          ["crit"] = 906,
          ["haste"] = 1011,
          ["mastery"] = 750,
          ["vers"] = 451,
          ["trinkets"] = {
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGLjlZMzywMTMzMzMzMzMLmZmxMmBAAAmZmZZZmpNAAYBAAAsBw2yYmZGMbDjZYBAAgZ2AmhxAmBDA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "饿德",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 230602,
          ["ilvl"] = 321,
          ["crit"] = 1349,
          ["haste"] = 397,
          ["mastery"] = 1192,
          ["vers"] = 164,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Magebany",
          ["guild"] = "Пять Бутылок Водки",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 230188,
          ["ilvl"] = 319,
          ["crit"] = 910,
          ["haste"] = 835,
          ["mastery"] = 1081,
          ["vers"] = 232,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZEzMGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMzwsNMmhFAAAmZDYGYAzghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Sukylol",
          ["guild"] = "Raize",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 228169,
          ["ilvl"] = 324,
          ["crit"] = 1300,
          ["haste"] = 504,
          ["mastery"] = 1052,
          ["vers"] = 162,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Kevybaby",
          ["guild"] = "Reckoning",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224440,
          ["ilvl"] = 323,
          ["crit"] = 1163,
          ["haste"] = 654,
          ["mastery"] = 947,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzYmFmZEzMzMzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMjZGmthxMsAAAwMbAzwYAzghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "部落炮艇火炮",
          ["guild"] = "璀璨光域",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 223521,
          ["ilvl"] = 320,
          ["crit"] = 1171,
          ["haste"] = 509,
          ["mastery"] = 1137,
          ["vers"] = 218,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzEzMzYmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMzMY2GGzwCAAAzsBMDMgZwwA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Zhenglanxin",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 299288,
          ["ilvl"] = 326,
          ["crit"] = 1198,
          ["haste"] = 646,
          ["mastery"] = 1115,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMjYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMzwsNMmhFAAAmZDYGYAzghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Terstroik",
          ["guild"] = "Skill Issue",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 291160,
          ["ilvl"] = 319,
          ["crit"] = 983,
          ["haste"] = 678,
          ["mastery"] = 1167,
          ["vers"] = 267,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZmZmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMmBz2wYGWAAAYmNgZgBMDGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Khirran",
          ["guild"] = "Stupid Fat Hobbits",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 283737,
          ["ilvl"] = 324,
          ["crit"] = 1411,
          ["haste"] = 485,
          ["mastery"] = 1272,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmxYmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMzMY2GGzwCAAAzsBMDMgZwwA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Johntiltor",
          ["guild"] = "Revs de Cuba",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 276560,
          ["ilvl"] = 324,
          ["crit"] = 1311,
          ["haste"] = 905,
          ["mastery"] = 804,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGYZmZmlxMzEzMzYmZmZWMzMjZMDAAAMzMzyyMTbAAwCAAAYDgtlxMzMY2GGzwCAAAzsBMDMgZwwA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Choechoi",
          ["guild"] = "운동공부",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 276165,
          ["ilvl"] = 316,
          ["crit"] = 1159,
          ["haste"] = 751,
          ["mastery"] = 1156,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZEzMzYmZmZWMzMjZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZGmthxMsAAAwMbAzADYGMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Хайборная",
          ["guild"] = "Блэкбёрд",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 274491,
          ["ilvl"] = 319,
          ["crit"] = 1102,
          ["haste"] = 596,
          ["mastery"] = 805,
          ["vers"] = 495,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFmZmYmxMzMzMziZmhZMDAAAMzMzyyMTbAAwCAAAYDgtlxMzMY2GGzM2AAAYmNgZgBMDGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "玄幻冰激凌",
          ["guild"] = "神殇",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 274246,
          ["ilvl"] = 321,
          ["crit"] = 1228,
          ["haste"] = 777,
          ["mastery"] = 1023,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmlhZmYmZmZmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMmBz2wYGWAAAYmNgZgBMDGGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Humblefred",
          ["guild"] = "The Full Stick",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 271963,
          ["ilvl"] = 326,
          ["crit"] = 1065,
          ["haste"] = 723,
          ["mastery"] = 923,
          ["vers"] = 313,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Spraynwipe",
          ["guild"] = "Medium",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 270051,
          ["ilvl"] = 325,
          ["crit"] = 1049,
          ["haste"] = 981,
          ["mastery"] = 859,
          ["vers"] = 157,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzEzMmZmZmZWMzMjZMDAAAMzMzyyMTbAAwCAAAYDgtlxMzMY2GGzwGAAAzsBMDjBMDGGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "部落炮艇火炮",
          ["guild"] = "璀璨光域",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 267467,
          ["ilvl"] = 322,
          ["crit"] = 1058,
          ["haste"] = 526,
          ["mastery"] = 1318,
          ["vers"] = 218,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzEzMzYmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMzMY2GGzwCAAAzsBMDMgZwwA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Choechoi",
          ["guild"] = "운동공부",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 324379,
          ["ilvl"] = 326,
          ["crit"] = 1022,
          ["haste"] = 721,
          ["mastery"] = 1251,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZEzMzYmZmZWMzMjZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZGmthxMsAAAwMbAzADYGMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Gorstag",
          ["guild"] = "Offline",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 322285,
          ["ilvl"] = 327,
          ["crit"] = 1182,
          ["haste"] = 764,
          ["mastery"] = 635,
          ["vers"] = 508,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGLjlZmZWGzMTMzMjZMzMLmZmZGmZWmpZmlZBAAAWAAAAAAAAstMmZmBz2MmZGbLAAAgZGMDMgB+AA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Preheat",
          ["guild"] = "velocity",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 319472,
          ["ilvl"] = 327,
          ["crit"] = 1044,
          ["haste"] = 876,
          ["mastery"] = 905,
          ["vers"] = 352,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFmZmYGGzMzMziZmZmZmZmlZamZbWAAAgFAAYBAAAAgtlxMzMY2mxMzYbBAAAMzgZYMgBwA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Huggmark",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 315170,
          ["ilvl"] = 327,
          ["crit"] = 965,
          ["haste"] = 1067,
          ["mastery"] = 572,
          ["vers"] = 505,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAAWAYbZMzMDmthxMsAAAwMbAzwYAzgBA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Sãrdîne",
          ["guild"] = "Offline",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 313913,
          ["ilvl"] = 328,
          ["crit"] = 940,
          ["haste"] = 993,
          ["mastery"] = 703,
          ["vers"] = 411,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAwYZsMjZWGzMiZGjZMzMLmZmZGmZWmpZmtZBAAAWAAgFAAAAA2WGzMzMMbzYmZstAAAAmZwMwAG4DYA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "夕丶神",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 311181,
          ["ilvl"] = 325,
          ["crit"] = 1163,
          ["haste"] = 714,
          ["mastery"] = 908,
          ["vers"] = 254,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Terstroik",
          ["guild"] = "Skill Issue",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 310822,
          ["ilvl"] = 326,
          ["crit"] = 1319,
          ["haste"] = 613,
          ["mastery"] = 1114,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZmZmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMmBz2wYGWAAAYmNgZgBMDGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Zhenglanxin",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 309042,
          ["ilvl"] = 326,
          ["crit"] = 1183,
          ["haste"] = 630,
          ["mastery"] = 1115,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMjYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMzwsNMmhFAAAmZDYGYAzghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Rixtaz",
          ["guild"] = "Nailed It",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 307880,
          ["ilvl"] = 322,
          ["crit"] = 987,
          ["haste"] = 807,
          ["mastery"] = 1079,
          ["vers"] = 139,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmlhZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAA2AAAAbAstMmZmBz2wYG2AAAYmNgZYMgZwAA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Boisvertz",
          ["guild"] = "Blasphemy",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 307190,
          ["ilvl"] = 325,
          ["crit"] = 1193,
          ["haste"] = 531,
          ["mastery"] = 909,
          ["vers"] = 406,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmxYGzMziZmZmhZmlZamZZWAAAgFAAYBAAAAgtlxMzMY2mxMzYbBAAAMzgZgBMwHwA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Choechoi",
          ["guild"] = "운동공부",
          ["boss"] = "Sszorak",
          ["amount"] = 198751,
          ["ilvl"] = 328,
          ["crit"] = 1027,
          ["haste"] = 723,
          ["mastery"] = 1254,
          ["vers"] = 112,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZEzMzYMjZWMzMzMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMzgtZMzMsAAAwMbAzADYgBA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Terstroik",
          ["guild"] = "Skill Issue",
          ["boss"] = "Sszorak",
          ["amount"] = 197458,
          ["ilvl"] = 322,
          ["crit"] = 1217,
          ["haste"] = 705,
          ["mastery"] = 1078,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZmZMjZWMzMzMjZAAAgZmZWWmZaDAA2AAAAbAstMmxMw2MmZGWAAAYmNgZgBMwAA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Yddubme",
          ["guild"] = "Dedicated Casuals",
          ["boss"] = "Sszorak",
          ["amount"] = 195101,
          ["ilvl"] = 325,
          ["crit"] = 1270,
          ["haste"] = 673,
          ["mastery"] = 1263,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsNmZmYmZGjZMziZmZmZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZgtZMzMsAAAwMbAzADYghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Sukylol",
          ["guild"] = "Raize",
          ["boss"] = "Sszorak",
          ["amount"] = 194043,
          ["ilvl"] = 323,
          ["crit"] = 1335,
          ["haste"] = 527,
          ["mastery"] = 1093,
          ["vers"] = 162,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZMziZmZmZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZgtZMzMsAAAwMbAzADYghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Spraynwipe",
          ["guild"] = "Medium",
          ["boss"] = "Sszorak",
          ["amount"] = 192509,
          ["ilvl"] = 325,
          ["crit"] = 3426,
          ["haste"] = 981,
          ["mastery"] = 859,
          ["vers"] = -74,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzEzMmZMjZWMzMzMjZAAAgZmZWWmZaDAAWAAAAbAstMmZmB2mxMzwGAAAzsBMDjBMwwA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Zhenglanxin",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "Sszorak",
          ["amount"] = 192205,
          ["ilvl"] = 326,
          ["crit"] = 1199,
          ["haste"] = 647,
          ["mastery"] = 1115,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMjYmZGjZMziZmZmZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZGsNjZmhFAAAmZDYGYADMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "部落炮艇火炮",
          ["guild"] = "璀璨光域",
          ["boss"] = "Sszorak",
          ["amount"] = 186573,
          ["ilvl"] = 324,
          ["crit"] = 1191,
          ["haste"] = 430,
          ["mastery"] = 1308,
          ["vers"] = 218,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZMziZmZmZMDAAAMzMzyyMTbAAwGAAAYDgtlxMmB2mxMzwCAAAzsBMDMgBGGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Khirran",
          ["guild"] = "Stupid Fat Hobbits",
          ["boss"] = "Sszorak",
          ["amount"] = 186303,
          ["ilvl"] = 324,
          ["crit"] = 1366,
          ["haste"] = 590,
          ["mastery"] = 1226,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmxYMjZWMzMzMjZAAAgZmZWWmZaDAA2AAAAbAstMmZmB2mxMzwCAAAzsBMDMgBGGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Fallen",
          ["guild"] = "Jade Falcons",
          ["boss"] = "Sszorak",
          ["amount"] = 178397,
          ["ilvl"] = 326,
          ["crit"] = 1291,
          ["haste"] = 700,
          ["mastery"] = 1195,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZMziZmZmZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZgtZMzMsAAAwMbAzADYghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Malries",
          ["guild"] = "Afro Ninjas",
          ["boss"] = "Sszorak",
          ["amount"] = 174915,
          ["ilvl"] = 323,
          ["crit"] = 2882,
          ["haste"] = 699,
          ["mastery"] = 1093,
          ["vers"] = -50,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMjYmZGjZMziZmZmZMDAAAMzMzyyMTbAAAAAAwGAbLjZmZGsNjZmhNAAAmZDYGYADMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Asimage",
          ["guild"] = "Incarnate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 340612,
          ["ilvl"] = 329,
          ["crit"] = 1225,
          ["haste"] = 814,
          ["mastery"] = 755,
          ["vers"] = 458,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzYmZWMzMzMMzsMTzMLzCAAAsAAALAAAAAstMmxMY2mxMzYbBAAAMzgZgBMwHwA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Binmanbob",
          ["guild"] = "Vestige",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 326492,
          ["ilvl"] = 327,
          ["crit"] = 1387,
          ["haste"] = 656,
          ["mastery"] = 756,
          ["vers"] = 295,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmxYGzMziZmZmhZmlZamZZWAAAgFAAYBAAAAgtlxMzMY2mxMzYbBAAAMzgZgBMwHwA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Fulloffheat",
          ["guild"] = "Rhapsody",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 325247,
          ["ilvl"] = 328,
          ["crit"] = 1444,
          ["haste"] = 648,
          ["mastery"] = 808,
          ["vers"] = 337,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGLjlZmZWGzMTMzYMjZmZxMzMzwMzyMNzsMLAAAwCAAsAAAAAw2yYmZGMbzYmZstAAAAmZwMwAG4DA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Choechoi",
          ["guild"] = "운동공부",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 324733,
          ["ilvl"] = 326,
          ["crit"] = 3540,
          ["haste"] = 721,
          ["mastery"] = 1251,
          ["vers"] = -121,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzYmZWMzMzMMzsMTzMLzCAAAsAAALAAAAAstMmZmBz2MmZGbLAAAgZGMDMgB+AA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Yasuya",
          ["guild"] = "Soft Enrage",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 322997,
          ["ilvl"] = 325,
          ["crit"] = 1338,
          ["haste"] = 486,
          ["mastery"] = 950,
          ["vers"] = 258,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZmYmZGzYmZWMzMzMMzsMTzMLzCAAAsAAALAAAAAstNmZmZY2mxMzYbBAAAMzgZgBMwHwA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Terstroik",
          ["guild"] = "Skill Issue",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 322509,
          ["ilvl"] = 326,
          ["crit"] = 1319,
          ["haste"] = 613,
          ["mastery"] = 1114,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAwYZsMzMzyYmZiZmZmZMzMLmZmZGmZWmpZmtZBAAAWAAgFAAAAA2WGzYGMbzYmZstAAAAmZwMwAG4DA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Molmar",
          ["guild"] = "Forbidden",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 320790,
          ["ilvl"] = 327,
          ["crit"] = 1085,
          ["haste"] = 580,
          ["mastery"] = 1081,
          ["vers"] = 313,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGLjlZmZWGPwMTMzYMjZmZxMzMzwMzyMNzsNLAAAwCAAsAAAAAw2yYmZGMbzYmZstAAAAmZwMwAG4DYA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "玉玉",
          ["guild"] = "CLEAR_LOVE",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 315124,
          ["ilvl"] = 323,
          ["crit"] = 1184,
          ["haste"] = 668,
          ["mastery"] = 1062,
          ["vers"] = 217,
          ["trinkets"] = {
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYGzYGzMziZmZmhZmlZamZbWAAAgFAAYBAAAAgtlxMzMY2mxMzYbBAAAMzgZgBMwHwA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "淡烟疏雨",
          ["guild"] = "Dim Moon",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 313430,
          ["ilvl"] = 327,
          ["crit"] = 1379,
          ["haste"] = 774,
          ["mastery"] = 877,
          ["vers"] = 227,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzYmFmZmYmZmZGzMziZmZmhZmlZamZZWAAAgFAAYBAAAAgtlxMzMY2mxMzYbBAAAMzgZgBMwHwA",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Thewagon",
          ["guild"] = "Consequence",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 313323,
          ["ilvl"] = 322,
          ["crit"] = 1125,
          ["haste"] = 614,
          ["mastery"] = 813,
          ["vers"] = 437,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGLjlZ8AzyYmRMzYMzMzMLmZmZmZmZWmpZmtZBAAAWAAgFAAAAA2WGzMzMMbzYmZstAAAAmZwMwAGAD",
          ["hero"] = {
            ["name"] = "Frostfire",
            ["atlas"] = "talents-heroclass-mage-frostfire",
            ["icon"] = "inv_ability_frostfiremage_frostfirebolt"
          }
        },
        {
          ["name"] = "Choechoi",
          ["guild"] = "운동공부",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 246097,
          ["ilvl"] = 328,
          ["crit"] = 1152,
          ["haste"] = 691,
          ["mastery"] = 1163,
          ["vers"] = 112,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZEzMzYmZmZWMzMMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMzwsNMmZsAAAwMbAzADYGMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Yddubme",
          ["guild"] = "Dedicated Casuals",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 242320,
          ["ilvl"] = 324,
          ["crit"] = 1252,
          ["haste"] = 682,
          ["mastery"] = 1116,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsNmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Terstroik",
          ["guild"] = "Skill Issue",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 233235,
          ["ilvl"] = 325,
          ["crit"] = 1190,
          ["haste"] = 717,
          ["mastery"] = 1141,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZmZmZmZWMzMMjZAAAgZmZWWmZaDAA2AAAAbAstMmxMY2GGzMWAAAYmNgZgBMDGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Binmanbob",
          ["guild"] = "Vestige",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 232491,
          ["ilvl"] = 324,
          ["crit"] = 1349,
          ["haste"] = 620,
          ["mastery"] = 810,
          ["vers"] = 259,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Zhenglanxin",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 225037,
          ["ilvl"] = 323,
          ["crit"] = 1167,
          ["haste"] = 636,
          ["mastery"] = 1112,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMjYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMzwsNMmhFAAAmZDYGYAzghB",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Хайборная",
          ["guild"] = "Блэкбёрд",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 223377,
          ["ilvl"] = 320,
          ["crit"] = 1102,
          ["haste"] = 441,
          ["mastery"] = 952,
          ["vers"] = 626,
          ["trinkets"] = {
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFmZmYmxMzMzMziZmhZMDAAAMzMzyyMTbAAwCAAAYDgtlxMzMY2GGzM2AAAYmNgZgBMDGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "你會愛我",
          ["guild"] = "For the Glory of JO JO",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 223008,
          ["ilvl"] = 323,
          ["crit"] = 1199,
          ["haste"] = 635,
          ["mastery"] = 1038,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "饿德",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 219116,
          ["ilvl"] = 320,
          ["crit"] = 1344,
          ["haste"] = 394,
          ["mastery"] = 1187,
          ["vers"] = 164,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZEzMzYmZmZWMzMMjZAAAgZmZWWmZaDAAAAAAWAYbZMzMzwsNMmZsAAAwMbAzADYGMA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "Hydrophilic",
          ["guild"] = "Limelight",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 218239,
          ["ilvl"] = 323,
          ["crit"] = 1235,
          ["haste"] = 923,
          ["mastery"] = 1033,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAA2AAAAbAstMmZmBz2wYG2AAAYmNgZgBMDGA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        },
        {
          ["name"] = "部落炮艇火炮",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 216377,
          ["ilvl"] = 322,
          ["crit"] = 1058,
          ["haste"] = 526,
          ["mastery"] = 1318,
          ["vers"] = 218,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzEzMzYmZmZWMzMjZMDAAAMzMzyyMTbAAwGAAAYDgtlxMzMY2GGzwCAAAzsBMDMgZwwA",
          ["hero"] = {
            ["name"] = "Spellslinger",
            ["atlas"] = "talents-heroclass-mage-spellslinger",
            ["icon"] = "achievement_dungeon_arcanevaults"
          }
        }
      }
    }
  }
}
