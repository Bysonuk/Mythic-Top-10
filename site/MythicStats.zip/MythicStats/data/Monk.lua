MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Monk"] = {
  ["className"] = "Monk",
  ["specs"] = {
    {
      ["spec"] = "Brewmaster",
      ["role"] = "tank",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "尼尔多龙爸",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 120684,
          ["ilvl"] = 326,
          ["crit"] = 1739,
          ["haste"] = 147,
          ["mastery"] = 417,
          ["vers"] = 789,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMYmhZ2YwMzMDz2wMGLDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Fortyhands",
          ["guild"] = "Haunted by Murlocs",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 119832,
          ["ilvl"] = 323,
          ["crit"] = 1082,
          ["haste"] = 32,
          ["mastery"] = 1011,
          ["vers"] = 980,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2wMjBAAAAAAYbBzEzMwMM2YwMzMjZ2GmxYZYZz22sNjZBAA2AAAAz2s0MzMbmhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Grootwalker",
          ["guild"] = "Shattered",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 118954,
          ["ilvl"] = 322,
          ["crit"] = 1434,
          ["haste"] = 361,
          ["mastery"] = 664,
          ["vers"] = 629,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMYmhZ2YwMzMDz2wMGLDLb22mtZMLAAwGAAAY2mlmZmZhhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Astrozerg",
          ["guild"] = "I link AOTC",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 116552,
          ["ilvl"] = 319,
          ["crit"] = 1396,
          ["haste"] = 16,
          ["mastery"] = 817,
          ["vers"] = 860,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGPwMWmxGmZMAAAAAAALLYEzMwMM2MwMzMDz2YmxMLDLb22mtZMLAAwysMtMbzsMAAAAzwGYmBMNGAAwA",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "판다리아농부",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 115216,
          ["ilvl"] = 323,
          ["crit"] = 1299,
          ["haste"] = 16,
          ["mastery"] = 1371,
          ["vers"] = 433,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMMzGDmZmZYWGmxMbDLb22GzYWAAgNAAAwsNLNzMziZYBgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Telleria",
          ["guild"] = "Literacy Test",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 113761,
          ["ilvl"] = 322,
          ["crit"] = 1266,
          ["haste"] = 114,
          ["mastery"] = 751,
          ["vers"] = 1399,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGDPwwyM2YmZMAAAAAAALbYmYmBmhxGwMzMjZ2GmxMLDLb22mtxMLAAwGAAAY2mlmZmZzMsBwMDTjBAAMA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Philouumonk",
          ["guild"] = "Reset",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 112799,
          ["ilvl"] = 326,
          ["crit"] = 2996,
          ["haste"] = -96,
          ["mastery"] = 587,
          ["vers"] = 1108,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzYWmxGmZMAAAAAAALbYEzMwMM2MMmZmZY2GzMGLDLb22mthZBAAWmlplZbmlBAAAYG2AzMgpxAAAG",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Sheffym",
          ["guild"] = "Slurp Squad",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 112424,
          ["ilvl"] = 325,
          ["crit"] = 1278,
          ["haste"] = 180,
          ["mastery"] = 837,
          ["vers"] = 971,
          ["trinkets"] = {
            {
              ["id"] = 270174,
              ["name"] = "Idol of the Howling Nexus",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGzyM2wMjBAAAAAAYZBEzMwMM2MDmZmZY2mFzYmlhlNbbjZMLAAwGAAAY2mlmZmZjhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Yohamon",
          ["guild"] = "K E K L E O",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 111510,
          ["ilvl"] = 325,
          ["crit"] = 1353,
          ["haste"] = 110,
          ["mastery"] = 575,
          ["vers"] = 1127,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGz4BGzyM2wMDAAAAAAALLYEzMwMM2MDmZmZMz2wMmZZYZz22sNMLAAwGAAAY2mlmZmZxMsBwMDTjBAAMA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Amobrew",
          ["guild"] = "The Early Shift",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 111061,
          ["ilvl"] = 320,
          ["crit"] = 1171,
          ["haste"] = 458,
          ["mastery"] = 893,
          ["vers"] = 660,
          ["trinkets"] = {
            {
              ["id"] = 260235,
              ["name"] = "Umbral Plume",
              ["ilvl"] = 298
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2wMjBAAAAAAYZBjYmBmhZ2MjxMzMDzGmxYZYZ7B22mtZMLAAwGAAAY2mlmZmZhhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Fortyhands",
          ["guild"] = "Haunted by Murlocs",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 118121,
          ["ilvl"] = 326,
          ["crit"] = 1258,
          ["haste"] = 32,
          ["mastery"] = 822,
          ["vers"] = 1213,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2wMjBAAAAAAYbBzEzMwMM2YwMzMjZ2GmxYZYZz22sNjZBAA2AAAAz2s0MzMbmhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Epiemk",
          ["guild"] = "In Denial",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 114573,
          ["ilvl"] = 325,
          ["crit"] = 923,
          ["haste"] = 101,
          ["mastery"] = 1052,
          ["vers"] = 987,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzw2M2wMDAAAAAAALLgwMwMMzmZMmZmZY2YmxMLDLb22mlZMLAAwysMtMbzsMAAAAzwGYmBMNGwAAG",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Monksea",
          ["guild"] = "냉동 피자의 삶",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 114097,
          ["ilvl"] = 321,
          ["crit"] = 1409,
          ["haste"] = 117,
          ["mastery"] = 607,
          ["vers"] = 1117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzYWmxGzMjBAAAAAAYZBzEzMwMM2gxMzMDz2YmxYZYZ7B22mNMLAAwysMtMbzsMAAAAG2AzMgpxAAAG",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "小太阳尬住了",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 113399,
          ["ilvl"] = 323,
          ["crit"] = 1384,
          ["haste"] = 189,
          ["mastery"] = 351,
          ["vers"] = 1106,
          ["trinkets"] = {
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMM2gxMzMDz2YmxMLDLb22mtZMLAAwGAAAY2mlmZmZhhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Yulok",
          ["guild"] = "Noted",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 112639,
          ["ilvl"] = 324,
          ["crit"] = 1288,
          ["haste"] = 117,
          ["mastery"] = 698,
          ["vers"] = 885,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGPwwyM2YmZMAAAAAAALLYmYmBmhxGwMzMDz2sYGzsMssZbb2GzsAAALz20ysNzyAAAAMDbgZGw0YAAAD",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Antagon",
          ["guild"] = "Gravity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 112601,
          ["ilvl"] = 326,
          ["crit"] = 1464,
          ["haste"] = 117,
          ["mastery"] = 791,
          ["vers"] = 1392,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGDzYWmxGmZMAAAAAAALLYEzMwMM2MDmZmZY2GmxYZYZz22YGzCAAsBAAAmtZpZmZWMDLAMzw0YADAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Quintilian",
          ["guild"] = "Two Shot",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 111975,
          ["ilvl"] = 322,
          ["crit"] = 1309,
          ["haste"] = 203,
          ["mastery"] = 607,
          ["vers"] = 1124,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMM2gxMzMDz2YmxMLDLb22mtZMLAAwGAAAY2mlmZmZhhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Azerille",
          ["guild"] = "tiesto power mix",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 111928,
          ["ilvl"] = 322,
          ["crit"] = 1145,
          ["haste"] = 330,
          ["mastery"] = 748,
          ["vers"] = 745,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMMzGjxMzMDz2wMGLDLbW2GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "만둥",
          ["guild"] = "유랑단",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 111743,
          ["ilvl"] = 318,
          ["crit"] = 1042,
          ["haste"] = 417,
          ["mastery"] = 782,
          ["vers"] = 667,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2wMjBAAAAAAYZBjYmBmhxmZwMzMDz2YmxYbYZz22sNjZBAA2AAAAz2s0MzMLmhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "尼尔多龙爸",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 111558,
          ["ilvl"] = 326,
          ["crit"] = 1739,
          ["haste"] = 147,
          ["mastery"] = 417,
          ["vers"] = 789,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMYmhZ2YwMzMDz2wMGLDLb22mtZMLAAwGAAAY2mlmZmZhhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Ramen",
          ["guild"] = "Bog",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 182910,
          ["ilvl"] = 319,
          ["crit"] = 1308,
          ["haste"] = 189,
          ["mastery"] = 763,
          ["vers"] = 796,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLY0MzMwMMzGDmZmZY2GmxY5BYZz22YGzCAAsBAAAmtZpZmZWMDbAMzw0YAAAD",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Randraak",
          ["guild"] = "Unluck",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 180029,
          ["ilvl"] = 315,
          ["crit"] = 1743,
          ["haste"] = 80,
          ["mastery"] = 601,
          ["vers"] = 956,
          ["trinkets"] = {
            {
              ["id"] = 260235,
              ["name"] = "Umbral Plume",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzYWmxGmZMAAAAAAALLYEzMwMM2YwMzMDz2YmxMLDLb22GzMzCAAsBAAAmtZpZmZWYYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Fortyhands",
          ["guild"] = "Haunted by Murlocs",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 177345,
          ["ilvl"] = 326,
          ["crit"] = 1258,
          ["haste"] = 32,
          ["mastery"] = 822,
          ["vers"] = 1213,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2wMjBAAAAAAYbBzEzMwMM2YwMzMjZ2GmxYZYZz22sNjZBAA2AAAAz2s0MzMbmhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Telleria",
          ["guild"] = "Literacy Test",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 172992,
          ["ilvl"] = 320,
          ["crit"] = 1367,
          ["haste"] = 16,
          ["mastery"] = 775,
          ["vers"] = 876,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGDPwYWmxGzMjBAAAAAAYZBzEzMwMM2AmZmZMz2wMmZZYZz22YmZWAAgNAAAwsNLNzMzGDbAMzw0YAAAD",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Philouumonk",
          ["guild"] = "Reset",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 170796,
          ["ilvl"] = 326,
          ["crit"] = 1412,
          ["haste"] = 117,
          ["mastery"] = 587,
          ["vers"] = 1108,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzYWmxGmZMAAAAAAALbYEzMwMM2MMmZmZY2GzMGLDLb22mthZBAAWmlplZbmlBAAAYG2AzMgpxAAAG",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Naggentonk",
          ["guild"] = "Helden in Pyjamas",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 170023,
          ["ilvl"] = 323,
          ["crit"] = 1250,
          ["haste"] = 431,
          ["mastery"] = 594,
          ["vers"] = 876,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzYWmxGmZMAAAAAAALLYEzMwMM2YwMzMDz2YmxMLDLb22GzMzCAAsBAAAmtZpZmZWYYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Foxalo",
          ["guild"] = "Day One",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 169433,
          ["ilvl"] = 321,
          ["crit"] = 1584,
          ["haste"] = 93,
          ["mastery"] = 933,
          ["vers"] = 825,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzYWmxGmZMAAAAAAALLYEzMwMM2YwMzMjZ2wMmZZYZz22YmZWAAgNAAAwsNLNzMzCDbAMzw0YADAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Sheffym",
          ["guild"] = "Slurp Squad",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 168751,
          ["ilvl"] = 320,
          ["crit"] = 1110,
          ["haste"] = 180,
          ["mastery"] = 733,
          ["vers"] = 924,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGDzYWmxGmZMAAAAAAALLwEzMwMMYGMzMzwsNLmxMLDLb22GzMzCAAsBAAAmtZpZmZ2YYBgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "开光大师",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 168642,
          ["ilvl"] = 320,
          ["crit"] = 1334,
          ["haste"] = 229,
          ["mastery"] = 1078,
          ["vers"] = 424,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzMWmxGmZMAAAAAAALLYEzMwMM2YwMzMjZ2GmxMLDLb22GzYWAAglZZaZ2mZZAAAAmhNwMDYaMAAgB",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Paoapo",
          ["guild"] = "Nomads TM",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 165759,
          ["ilvl"] = 319,
          ["crit"] = 1368,
          ["haste"] = 110,
          ["mastery"] = 600,
          ["vers"] = 1031,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2YmZMAAAAAAALLYEzMYmhxGDmZmZY2GmxYZYZz22sNjZBAA2AAAAz2s0MzMLMswAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Philouumonk",
          ["guild"] = "Reset",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 146390,
          ["ilvl"] = 326,
          ["crit"] = 1412,
          ["haste"] = 117,
          ["mastery"] = 587,
          ["vers"] = 1108,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzYWmxGmZMAAAAAAALbYEzMwMM2MMmZmZY2GzMGLDLb22mthZBAAWmlplZbmlBAAAYG2AzMgpxAAAG",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Wakandariana",
          ["guild"] = "Nightbloom",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 146023,
          ["ilvl"] = 325,
          ["crit"] = 1358,
          ["haste"] = 119,
          ["mastery"] = 614,
          ["vers"] = 1156,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzMWmxGmZAAAAAAAYZBjYmBmhZ2MjxMzMDz2wMmZBLb22GzYWAAglZZaZ2mZZAAAAmhNwMDYaMgBAMA",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Shachi",
          ["guild"] = "Lucky Robbers",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 140854,
          ["ilvl"] = 326,
          ["crit"] = 1335,
          ["haste"] = 110,
          ["mastery"] = 654,
          ["vers"] = 1076,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzYWmxGzMjBAAAAAAYZBmwMYmB2MMmZmZMzGzMmZZYZz22YYWAAgNAAAwsNLNzMzmZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Monksea",
          ["guild"] = "냉동 피자의 삶",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 140150,
          ["ilvl"] = 322,
          ["crit"] = 1409,
          ["haste"] = 117,
          ["mastery"] = 471,
          ["vers"] = 1117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2YmZMAAAAAAALLYmYmBmhxGMmZmZY2GzMGLDLb22mtZMLAAwysMtMbzsMAAAAG2AzMgpxAAAG",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Fortyhands",
          ["guild"] = "Haunted by Murlocs",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 140105,
          ["ilvl"] = 326,
          ["crit"] = 1258,
          ["haste"] = 32,
          ["mastery"] = 822,
          ["vers"] = 1213,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2wMjBAAAAAAYbBzEzMwMM2YwMzMjZ2GmxYZYZz22sNjZBAA2AAAAz2s0MzMbmhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Bäronk",
          ["guild"] = "Flawless",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 138109,
          ["ilvl"] = 323,
          ["crit"] = 1487,
          ["haste"] = 318,
          ["mastery"] = 429,
          ["vers"] = 972,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGz4BGWmxGmZMAAAAAAALLYEmBmhxmZMmZmZMzGzMmZ5BYZz22sNjZBAA2AAAAz2s0MzMLmhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "尼尔多龙爸",
          ["guild"] = "彼岸道标12.1",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 137938,
          ["ilvl"] = 326,
          ["crit"] = 1739,
          ["haste"] = 147,
          ["mastery"] = 417,
          ["vers"] = 789,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMYmhZ2YwMzMDz2wMGLDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Jackylkeg",
          ["guild"] = "YEP",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 137059,
          ["ilvl"] = 321,
          ["crit"] = 1678,
          ["haste"] = 279,
          ["mastery"] = 646,
          ["vers"] = 650,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2YmZAAAAAAAYZBjYmBmhZ2MDmZmZY2GmxMLDLb22GzYWAAglZZaZ2mZZAAAAmhNwMDYaMAAgB",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Telleria",
          ["guild"] = "Literacy Test",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 136976,
          ["ilvl"] = 324,
          ["crit"] = 1216,
          ["haste"] = 117,
          ["mastery"] = 763,
          ["vers"] = 1059,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGz4BGWmxGzMjBAAAAAAYZBzEzMwMM2AmZmZY2mFzYmlhlNbbjZMbAAwGAAAY2mlmZmZzMsBwMDTjBAAMA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Tarlok",
          ["guild"] = "Misery",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 136301,
          ["ilvl"] = 323,
          ["crit"] = 2987,
          ["haste"] = 200,
          ["mastery"] = 629,
          ["vers"] = 802,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMM2YwMzMDzyYmxMLDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Tarlok",
          ["guild"] = "Misery",
          ["boss"] = "Sszorak",
          ["amount"] = 110689,
          ["ilvl"] = 325,
          ["crit"] = 1428,
          ["haste"] = 431,
          ["mastery"] = 530,
          ["vers"] = 893,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMM2MDmZmZYWGzMmZBLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDYAAD",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Telleria",
          ["guild"] = "Literacy Test",
          ["boss"] = "Sszorak",
          ["amount"] = 110585,
          ["ilvl"] = 324,
          ["crit"] = 1216,
          ["haste"] = 117,
          ["mastery"] = 763,
          ["vers"] = 1059,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGPwwyM2YmZMAAAAAAALbYmYmBmhxGwMzMDz2sYGzsMssZbb2GzsAAALz20ysNzyAAAAMDbgZGw0YAAAD",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Mancowhorse",
          ["guild"] = "Wing It",
          ["boss"] = "Sszorak",
          ["amount"] = 109473,
          ["ilvl"] = 324,
          ["crit"] = 1019,
          ["haste"] = 370,
          ["mastery"] = 734,
          ["vers"] = 1022,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMM2YwMzMDz2YmxMLDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Emotoo",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "Sszorak",
          ["amount"] = 107396,
          ["ilvl"] = 327,
          ["crit"] = 1157,
          ["haste"] = 217,
          ["mastery"] = 836,
          ["vers"] = 780,
          ["trinkets"] = {
            {
              ["id"] = 158374,
              ["name"] = "Tiny Electromental in a Jar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAAbLYmYmBmhZ2YwMzMDz2wMGLDLb22mtZMLAAwGAAAY2mlmZmZjhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "妈责法磕儿",
          ["guild"] = "绝世丶",
          ["boss"] = "Sszorak",
          ["amount"] = 106395,
          ["ilvl"] = 321,
          ["crit"] = 1271,
          ["haste"] = 323,
          ["mastery"] = 670,
          ["vers"] = 764,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMMzGDmZmZY2GmxMLDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Naggentonk",
          ["guild"] = "Helden in Pyjamas",
          ["boss"] = "Sszorak",
          ["amount"] = 105885,
          ["ilvl"] = 326,
          ["crit"] = 1310,
          ["haste"] = 409,
          ["mastery"] = 556,
          ["vers"] = 958,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMM2YwMzMDz2YmxMLDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Boxhandchu",
          ["guild"] = "Huskies eSports",
          ["boss"] = "Sszorak",
          ["amount"] = 104221,
          ["ilvl"] = 325,
          ["crit"] = 1502,
          ["haste"] = 318,
          ["mastery"] = 1020,
          ["vers"] = 429,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2wMjBAAAAAAYZBjYmBmhxGDmZmZY2GzMmZZYZz22sNjZBAA2AAAAz2s0MzMLmhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Jackylkeg",
          ["guild"] = "YEP",
          ["boss"] = "Sszorak",
          ["amount"] = 103303,
          ["ilvl"] = 325,
          ["crit"] = 1469,
          ["haste"] = 373,
          ["mastery"] = 749,
          ["vers"] = 707,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGPwYWmxGzMDAAAAAAALLYEzMwMM2YMmZmZY2GmxMLDLb22mthZBAA2AAAAz2s0MzMLmhNAmZYaMgBAMA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Amobrew",
          ["guild"] = "The Early Shift",
          ["boss"] = "Sszorak",
          ["amount"] = 102469,
          ["ilvl"] = 325,
          ["crit"] = 1217,
          ["haste"] = 457,
          ["mastery"] = 876,
          ["vers"] = 620,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2wMjBAAAAAAYZBjYmBmhZ2MjxMzMDzGmxYZYZ7B22mtZMLAAwGAAAY2mlmZmZhhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Bäronk",
          ["guild"] = "Flawless",
          ["boss"] = "Sszorak",
          ["amount"] = 102262,
          ["ilvl"] = 323,
          ["crit"] = 1354,
          ["haste"] = 318,
          ["mastery"] = 630,
          ["vers"] = 907,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGz4BGWmxGmZMAAAAAAALLYEmBmhxmZMmZmZMzGzMmZ5BYZz22sNmZBAA2AAAAz2s0MzMLmhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Slurpass",
          ["guild"] = "Agency",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 140270,
          ["ilvl"] = 326,
          ["crit"] = 974,
          ["haste"] = 483,
          ["mastery"] = 1061,
          ["vers"] = 575,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzwYWmxGzMjBAAAAAAYZBzEmBmhxmZwMzMDz2wMmZZYZz22sNmZBAA2AAAAz2s0MzMLMsBwMDTjBAAMA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Galunk",
          ["guild"] = "Tusk",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 140140,
          ["ilvl"] = 326,
          ["crit"] = 1537,
          ["haste"] = 318,
          ["mastery"] = 446,
          ["vers"] = 930,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGDzwyM2YmZMAAAAAAALLYEzMwMMzGDmZmZY2GmxMLDLb22mtZMLAAwGAAAY2mlmZmZjhFAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Telleria",
          ["guild"] = "Literacy Test",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 134050,
          ["ilvl"] = 324,
          ["crit"] = 1216,
          ["haste"] = 117,
          ["mastery"] = 763,
          ["vers"] = 1059,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGPwwyM2YmZMAAAAAAALbYmYmBmhxGMmZmZY2GmxMLDLb22mtxMLAAwGAAAY2mlmZmZzMsBwMDTjBAAMA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Jackylkeg",
          ["guild"] = "YEP",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 130213,
          ["ilvl"] = 325,
          ["crit"] = 1559,
          ["haste"] = 377,
          ["mastery"] = 749,
          ["vers"] = 707,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGPwYWmxGzMDAAAAAAALLYEzMwMM2YMmZmZY2GmxMLDLb22mthZBAA2AAAAz2s0MzMLmhNAmZYaMgBAMA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Tasari",
          ["guild"] = "Fluff and Blood",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 125260,
          ["ilvl"] = 327,
          ["crit"] = 1137,
          ["haste"] = 187,
          ["mastery"] = 1033,
          ["vers"] = 721,
          ["trinkets"] = {
            {
              ["id"] = 270160,
              ["name"] = "First Mate's Shellward",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbxYGGzyM2YmZMAAAAAAALLYmYmBmhxGDmZmZMzGmxMLDLbPw22sNmZDAAWmlplZbmlBAAAwwGYmBMNGAAwA",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "Notrazmig",
          ["guild"] = "Resonate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 123968,
          ["ilvl"] = 323,
          ["crit"] = 1160,
          ["haste"] = 523,
          ["mastery"] = 900,
          ["vers"] = 593,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGDzYWmxGzMjBAAAAAAYZBjYmBmhxGDmZmZY2GmxMLDLbW2GDzCAAsBAAAmtZpZmZWMDbAMzw0YADAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "乱灬窜",
          ["guild"] = "老友俱乐部",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 122811,
          ["ilvl"] = 326,
          ["crit"] = 1371,
          ["haste"] = 78,
          ["mastery"] = 713,
          ["vers"] = 952,
          ["trinkets"] = {
            {
              ["id"] = 270160,
              ["name"] = "First Mate's Shellward",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzwyM2YmZAAAAAAAYZBjYmBmhxmZwMzMDz2YmxMLDLb22mthZBAAWmlplZbmlBAAAYG2AzMgpxAAAG",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "我酒池红了灬",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 121589,
          ["ilvl"] = 323,
          ["crit"] = 1349,
          ["haste"] = 122,
          ["mastery"] = 366,
          ["vers"] = 1096,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzwYWmxGzMjBAAAAAAYZBjYmBmhZ2MDmZmZY2YmxMLPALbW2mtZMLAAwGAAAY2mlmZmZhhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "绿玩十二",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 121473,
          ["ilvl"] = 322,
          ["crit"] = 1456,
          ["haste"] = 103,
          ["mastery"] = 566,
          ["vers"] = 901,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzwYWmxGzMjBAAAAAAYZBjYmBmhZ2MDmZmZY2YmxMLPALbW2mtZMLAAwGAAAY2mlmZmZhhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Exade",
          ["guild"] = "Axon Terminal",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 119090,
          ["ilvl"] = 323,
          ["crit"] = 1257,
          ["haste"] = 175,
          ["mastery"] = 983,
          ["vers"] = 803,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGGzyM2YmZMAAAAAAALLYEzMwMMzGDmZmZY2GmxMLDLbPw22sNmZBAAWmtplZbmlBAAAwwGYmBMNGAAwA",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "尼尔多龙爸",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 120715,
          ["ilvl"] = 326,
          ["crit"] = 1739,
          ["haste"] = 147,
          ["mastery"] = 417,
          ["vers"] = 789,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMYmhZ2YwMzMDz2wMGLDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "판다리아농부",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 110443,
          ["ilvl"] = 323,
          ["crit"] = 1299,
          ["haste"] = 16,
          ["mastery"] = 1371,
          ["vers"] = 433,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMMzGDmZmZYWGmxMbDLb22GzYWAAgNAAAwsNLNzMziZYBgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Telleria",
          ["guild"] = "Literacy Test",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 109223,
          ["ilvl"] = 318,
          ["crit"] = 1207,
          ["haste"] = 16,
          ["mastery"] = 832,
          ["vers"] = 837,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGDzwyM2YmZMAAAAAAALLYmYmBmhxGwMzMjZ2GmxMLDLb22GzYWAAgNAAAwsNLNzMzmZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Bäronk",
          ["guild"] = "Flawless",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 109102,
          ["ilvl"] = 323,
          ["crit"] = 1354,
          ["haste"] = 318,
          ["mastery"] = 630,
          ["vers"] = 907,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGz4BGWmxGmZMAAAAAAALLYEmBmhxmZMmZmZMzGzMmZ5BYZz22sNjZBAA2AAAAz2s0MzMLmhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Ironbrew",
          ["guild"] = "Happy",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 107664,
          ["ilvl"] = 324,
          ["crit"] = 1407,
          ["haste"] = 114,
          ["mastery"] = 1001,
          ["vers"] = 594,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYmYmBmhZ2AmZmZY2GmxMLDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Philouumonk",
          ["guild"] = "Reset",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 106263,
          ["ilvl"] = 324,
          ["crit"] = 1426,
          ["haste"] = 117,
          ["mastery"] = 545,
          ["vers"] = 1200,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGzYWmxGmZMAAAAAAALbYEzMwMM2MMmZmZY2GzMGLDLb22mthZBAAWmlplZbmlBAAAYG2AzMgpxAAAG",
          ["hero"] = {
            ["name"] = "Master of Harmony",
            ["atlas"] = "talents-heroclass-monk-masterofharmony",
            ["icon"] = "inv_ability_masterofharmonymonk_aspectofharmony"
          }
        },
        {
          ["name"] = "만둥",
          ["guild"] = "유랑단",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 104993,
          ["ilvl"] = 318,
          ["crit"] = 1042,
          ["haste"] = 417,
          ["mastery"] = 782,
          ["vers"] = 667,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMM2MDmZmZY2GzMGbDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Chipigeon",
          ["guild"] = "Curse of Years",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 104211,
          ["ilvl"] = 324,
          ["crit"] = 1243,
          ["haste"] = 382,
          ["mastery"] = 815,
          ["vers"] = 799,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMM2YwMzMjZ2GmxMLDLb22mtZMLAAwGAAAY2mlmZmZhhNAmZYaMAAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Mancowhorse",
          ["guild"] = "Wing It",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 104091,
          ["ilvl"] = 324,
          ["crit"] = 1019,
          ["haste"] = 370,
          ["mastery"] = 734,
          ["vers"] = 1022,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMM2YwMzMDz2YmxMLDLb22GzYWAAgNAAAwsNLNzMziZYDgZGmGDAAYA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Marszen",
          ["guild"] = "Lucrum Gaudium",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 103496,
          ["ilvl"] = 325,
          ["crit"] = 1296,
          ["haste"] = 16,
          ["mastery"] = 983,
          ["vers"] = 825,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGDzwyM2wMjBAAAAAAYZBzEzMwMG2YwMzMDzGzMGLDLb22mtZMLAAwGAAAY2mlmZmZxMsBwMDTjBMAgB",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        }
      }
    },
    {
      ["spec"] = "Mistweaver",
      ["role"] = "healer",
      ["metric"] = "HPS",
      ["players"] = {
        {
          ["name"] = "二熊和吴改花",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 347302,
          ["ilvl"] = 323,
          ["crit"] = 1027,
          ["haste"] = 1636,
          ["mastery"] = 131,
          ["vers"] = 200,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWWWmZswMaGzAGMYMLzMzMMbDGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Melanthra",
          ["guild"] = "Nyx",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 342556,
          ["ilvl"] = 323,
          ["crit"] = 790,
          ["haste"] = 1648,
          ["mastery"] = 184,
          ["vers"] = 376,
          ["trinkets"] = {
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2A2sYmZmllZshZmhZW22mZswMaGzAGMYYZmZmhZbwgFTAAAAAAwilZWmlZGAAYADwMgxwYZyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Chickenarms",
          ["guild"] = "so fresh",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 337040,
          ["ilvl"] = 325,
          ["crit"] = 983,
          ["haste"] = 1717,
          ["mastery"] = 101,
          ["vers"] = 437,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCDNjZADGMYmZmhZbMGmlHYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Vìdel",
          ["guild"] = "Zanity",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 335384,
          ["ilvl"] = 324,
          ["crit"] = 1105,
          ["haste"] = 1601,
          ["mastery"] = 221,
          ["vers"] = 246,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWWWmZswMTzYGwgBDLzMzMMbwgFTAAAAAAwilZWmtZGAAYwYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Ws",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 330526,
          ["ilvl"] = 317,
          ["crit"] = 1195,
          ["haste"] = 1299,
          ["mastery"] = 265,
          ["vers"] = 121,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWWWmZswMaGzAGMYMLzMzMMbMGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Mistwraith",
          ["guild"] = "Deathstroke Division",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 329035,
          ["ilvl"] = 326,
          ["crit"] = 661,
          ["haste"] = 1767,
          ["mastery"] = 228,
          ["vers"] = 573,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxYmZmhZbMGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Nirakan",
          ["guild"] = "Wild Things",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 324678,
          ["ilvl"] = 325,
          ["crit"] = 879,
          ["haste"] = 1515,
          ["mastery"] = 279,
          ["vers"] = 419,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW22mZswMaGzAGMYYZmZmhZbwwsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "라투아",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 323916,
          ["ilvl"] = 321,
          ["crit"] = 873,
          ["haste"] = 1638,
          ["mastery"] = 101,
          ["vers"] = 531,
          ["trinkets"] = {
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswMaGzAGMYYZmZmhZbwgFTAAAAAAwilZWmtZGAAYADwMgxwYZyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Kouuaim",
          ["guild"] = "Nerlix and Chill",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 317023,
          ["ilvl"] = 319,
          ["crit"] = 1057,
          ["haste"] = 1568,
          ["mastery"] = nil,
          ["vers"] = 444,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCDNjZADGwsMzMzwsNYYWmJAAAAAAYxyMLz2MDAAMgBYGwYgFZMDA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "川尼斯功夫",
          ["guild"] = "岁岁平安",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 316930,
          ["ilvl"] = 321,
          ["crit"] = 1371,
          ["haste"] = 1336,
          ["mastery"] = 237,
          ["vers"] = 126,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgB2mZZGbWMjZWWmxGmZmtHYmlllZGLMjmxMgBzCDLzMzMMbDGsZCAAAAAAWsMzysNzAAADAwMgxwYRGzA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Ws",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 368144,
          ["ilvl"] = 323,
          ["crit"] = 1131,
          ["haste"] = 1416,
          ["mastery"] = 204,
          ["vers"] = 221,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwgxsMzYmxsZjBLmAAAAAAgFLzsMbzMAAwAGgZAjhxiMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "彡顾楠丶",
          ["guild"] = "Magic World",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 362121,
          ["ilvl"] = 325,
          ["crit"] = 964,
          ["haste"] = 1611,
          ["mastery"] = 180,
          ["vers"] = 436,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswQzYGwghZYZmZmhZbwwsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Koff",
          ["guild"] = "Morning Brew",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 360444,
          ["ilvl"] = 325,
          ["crit"] = 923,
          ["haste"] = 1508,
          ["mastery"] = 281,
          ["vers"] = 360,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWWWmZswMaGzAGMMMLzMzMMbDGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Danonk",
          ["guild"] = "Mayhem",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 359263,
          ["ilvl"] = 324,
          ["crit"] = 746,
          ["haste"] = 1498,
          ["mastery"] = 281,
          ["vers"] = 560,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 308
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxsMzMzwsxYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "汼頭人",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 358230,
          ["ilvl"] = 319,
          ["crit"] = 1066,
          ["haste"] = 1432,
          ["mastery"] = 359,
          ["vers"] = 191,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWW2mZswMaGzAGMYwMzMDz2gBLPwEAAAAAAsYZmlZbmBAAGMGgZAjhxiMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Chingmonk",
          ["guild"] = "Tauren Milfs",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 355453,
          ["ilvl"] = 325,
          ["crit"] = 980,
          ["haste"] = 1690,
          ["mastery"] = 180,
          ["vers"] = 364,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxYmZmhZbMGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "自在",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 353754,
          ["ilvl"] = 324,
          ["crit"] = 1023,
          ["haste"] = 1678,
          ["mastery"] = 242,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            },
            {
              ["id"] = 249341,
              ["name"] = "Volatile Void Suffuser",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwwMmlZmZGmtBDWMBAAAAAALWmZZ2mZAAgBMAzAGDsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Chickenarms",
          ["guild"] = "so fresh",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 353501,
          ["ilvl"] = 327,
          ["crit"] = 966,
          ["haste"] = 1744,
          ["mastery"] = 101,
          ["vers"] = 420,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCDNjZADGMYmZmhZbMGmlHYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Mistytree",
          ["guild"] = "Freaky Fellas",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 352637,
          ["ilvl"] = 324,
          ["crit"] = 922,
          ["haste"] = 1439,
          ["mastery"] = 101,
          ["vers"] = 683,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxYmZmhZbMGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Patruax",
          ["guild"] = "Ritual",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 352266,
          ["ilvl"] = 322,
          ["crit"] = 972,
          ["haste"] = 1424,
          ["mastery"] = 180,
          ["vers"] = 434,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCDNjZADGMsMzMzwsBDzyDMBAAAAAALWmZZ2mZAAgBjBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Wide",
          ["guild"] = "Mentioned",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 321358,
          ["ilvl"] = 319,
          ["crit"] = 887,
          ["haste"] = 1715,
          ["mastery"] = nil,
          ["vers"] = 461,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2A2sYmZmllZshZmhZWW2mZswMaGzAGMYYZmZmhZbwws8ATAAAAAAwilZWmtZGAAYADwMgxALyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Monkhes",
          ["guild"] = "Sketchy",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 319436,
          ["ilvl"] = 324,
          ["crit"] = 962,
          ["haste"] = 1632,
          ["mastery"] = 101,
          ["vers"] = 503,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwgxYmZmhZbMGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Serpicette",
          ["guild"] = "mythic raid guild",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 318941,
          ["ilvl"] = 321,
          ["crit"] = 807,
          ["haste"] = 1110,
          ["mastery"] = 736,
          ["vers"] = 259,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZZ2MmZ2WMghZbMb2mZswQzYGwgBMLzMzMMbDGmlZCAAAAAAWsNz2sNzAAADYAmBMwYRGzA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Disasterqt",
          ["guild"] = "Crystal Method",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 314660,
          ["ilvl"] = 321,
          ["crit"] = 1024,
          ["haste"] = 1586,
          ["mastery"] = 101,
          ["vers"] = 452,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW22mZswMaGzAGMYYZmZmhZbwgFTAAAAAAwilZWmtZGAAYADwMgxwYZyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Ws",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 313966,
          ["ilvl"] = 323,
          ["crit"] = 1131,
          ["haste"] = 1416,
          ["mastery"] = 204,
          ["vers"] = 221,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxsMzMzMmNYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Seeneenee",
          ["guild"] = "Soldiers of Elune",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 308537,
          ["ilvl"] = 326,
          ["crit"] = 848,
          ["haste"] = 1473,
          ["mastery"] = 158,
          ["vers"] = 541,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwsAzyMzMDz2gBLmAAAAAAgFLzsMbzMAAwAGgZAjhxiMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Delakeg",
          ["guild"] = "Calamity",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 308434,
          ["ilvl"] = 327,
          ["crit"] = 1122,
          ["haste"] = 1544,
          ["mastery"] = 163,
          ["vers"] = 287,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWW2mZswMaGzAGMAmZmZYWGMMLmAAAAAAgFLzsMbzMAAwgxAMDYMMWmMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Эивэн",
          ["guild"] = "Лё Резистанс",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 307308,
          ["ilvl"] = 327,
          ["crit"] = 1083,
          ["haste"] = 1674,
          ["mastery"] = 141,
          ["vers"] = 378,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWWWmZswMaGzAGMYMLzMzMMbDGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Lapöulette",
          ["guild"] = "ComeBack",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 306448,
          ["ilvl"] = 327,
          ["crit"] = 1065,
          ["haste"] = 1853,
          ["mastery"] = nil,
          ["vers"] = 329,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWW2mZswMaGzAGMYYZmZmhZZwgFTAAAAAAwilZWmtZGAAYADwMgxwYZyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "彡顾楠丶",
          ["guild"] = "Magic World",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 304471,
          ["ilvl"] = 325,
          ["crit"] = 964,
          ["haste"] = 1611,
          ["mastery"] = 180,
          ["vers"] = 436,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswQzYGwghZYZmZmhZbwwsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Midani",
          ["guild"] = "Yup",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 391148,
          ["ilvl"] = 326,
          ["crit"] = 1108,
          ["haste"] = 1848,
          ["mastery"] = nil,
          ["vers"] = 243,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MG2sYGzssMjNMmhZWW2mZswYaGzAGMYYbmZmhZbwwsYCAAAAAAWsMzysMzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Kovahm",
          ["guild"] = "smile",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 386857,
          ["ilvl"] = 327,
          ["crit"] = 851,
          ["haste"] = 1777,
          ["mastery"] = 101,
          ["vers"] = 525,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwgxsMzMzwsNYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Koff",
          ["guild"] = "Morning Brew",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 386563,
          ["ilvl"] = 324,
          ["crit"] = 922,
          ["haste"] = 1502,
          ["mastery"] = 280,
          ["vers"] = 356,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWWWmZswMaGzAGMMMLzMzMMbDGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "二熊和吴改花",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 375919,
          ["ilvl"] = 323,
          ["crit"] = 1192,
          ["haste"] = 1471,
          ["mastery"] = 131,
          ["vers"] = 200,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWWWmZswMaGzAGMYMLzMzMMbDGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Seeneenee",
          ["guild"] = "Soldiers of Elune",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 372476,
          ["ilvl"] = 321,
          ["crit"] = 1125,
          ["haste"] = 1609,
          ["mastery"] = 58,
          ["vers"] = 274,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwsAzyMzMDz2gBLmAAAAAAgFLzsMbzMAAwAGgZAjhxiMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "知趣浅薄",
          ["guild"] = "平凡的世界2",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 371121,
          ["ilvl"] = 322,
          ["crit"] = 848,
          ["haste"] = 1734,
          ["mastery"] = 159,
          ["vers"] = 350,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCDNjZADGMmlZmZGmtBDziJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Elowm",
          ["guild"] = "Revived",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 368774,
          ["ilvl"] = 326,
          ["crit"] = 990,
          ["haste"] = 1537,
          ["mastery"] = 101,
          ["vers"] = 597,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWW2mZswMaGzAGMYMLzMzMMbMGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Ws",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 368176,
          ["ilvl"] = 317,
          ["crit"] = 1195,
          ["haste"] = 1299,
          ["mastery"] = 265,
          ["vers"] = 121,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWWWmZswMaGzAGMYMLzMzMMbMGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Sharkfish",
          ["guild"] = "Erudite",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 365277,
          ["ilvl"] = 315,
          ["crit"] = 1173,
          ["haste"] = 1293,
          ["mastery"] = nil,
          ["vers"] = 375,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwAsMzMzwsNYwyMBAAAAAALWmZZ2mZAAgBMAzAGDjFZMDA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Turbokorv",
          ["guild"] = "Globallocked",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 364423,
          ["ilvl"] = 314,
          ["crit"] = 627,
          ["haste"] = 1633,
          ["mastery"] = 373,
          ["vers"] = 214,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxYmZmhZbMGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Esenin",
          ["guild"] = "Once Again",
          ["boss"] = "Sszorak",
          ["amount"] = 403827,
          ["ilvl"] = 326,
          ["crit"] = 892,
          ["haste"] = 1687,
          ["mastery"] = 184,
          ["vers"] = 480,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzMNjZADGMsMzMzwsNYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Dread",
          ["guild"] = "Synergize",
          ["boss"] = "Sszorak",
          ["amount"] = 391023,
          ["ilvl"] = 326,
          ["crit"] = 993,
          ["haste"] = 1658,
          ["mastery"] = 203,
          ["vers"] = 339,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwgxsMzMzwsNYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Puzzledmonk",
          ["guild"] = "Pathogen",
          ["boss"] = "Sszorak",
          ["amount"] = 390278,
          ["ilvl"] = 323,
          ["crit"] = 929,
          ["haste"] = 1606,
          ["mastery"] = 159,
          ["vers"] = 422,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MLDbWMmZWWG2wYGmZZZbmxCDNjZADmFYWmZmZY2ghZ5BmAAAAAAgFLzsMbzMAAwAGgZAjhxiMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Einra",
          ["guild"] = "Revolutions",
          ["boss"] = "Sszorak",
          ["amount"] = 388822,
          ["ilvl"] = 325,
          ["crit"] = 1003,
          ["haste"] = 1636,
          ["mastery"] = 101,
          ["vers"] = 368,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxsMzMzwsNYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Disasterqt",
          ["guild"] = "Crystal Method",
          ["boss"] = "Sszorak",
          ["amount"] = 386733,
          ["ilvl"] = 321,
          ["crit"] = 1024,
          ["haste"] = 1501,
          ["mastery"] = 101,
          ["vers"] = 537,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW22mZswMaGzAGMYYZmZmhZbwgFTAAAAAAwilZWmtZGAAYADwMgxwYZyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "홍차따라시",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 386447,
          ["ilvl"] = 320,
          ["crit"] = 831,
          ["haste"] = 1791,
          ["mastery"] = 277,
          ["vers"] = 264,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxsMzMzwsNYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Kovahm",
          ["guild"] = "smile",
          ["boss"] = "Sszorak",
          ["amount"] = 384986,
          ["ilvl"] = 327,
          ["crit"] = 851,
          ["haste"] = 1777,
          ["mastery"] = 101,
          ["vers"] = 525,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwgxsMzMzwsNYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Asterísk",
          ["guild"] = "Reko",
          ["boss"] = "Sszorak",
          ["amount"] = 383902,
          ["ilvl"] = 324,
          ["crit"] = 1179,
          ["haste"] = 1261,
          ["mastery"] = 157,
          ["vers"] = 453,
          ["trinkets"] = {
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwgxsMzMzwsNb8AYxEAAAAAAsYZmlZbmBAAGwAMDYMMWkxMA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Nordisk",
          ["guild"] = "No Hard Feelings",
          ["boss"] = "Sszorak",
          ["amount"] = 383870,
          ["ilvl"] = 321,
          ["crit"] = 730,
          ["haste"] = 1609,
          ["mastery"] = 94,
          ["vers"] = 564,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwghlZmZGmlBDWMBAAAAAALWmZZ2mZAAgBMAzAGDjlJjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Gkick",
          ["guild"] = "Tab Target",
          ["boss"] = "Sszorak",
          ["amount"] = 382529,
          ["ilvl"] = 325,
          ["crit"] = 848,
          ["haste"] = 1776,
          ["mastery"] = 101,
          ["vers"] = 530,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxsMzMzwsMYwyDMBAAAAAALWmZZ2mZAAgBMAzAGDsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "홍차따라시",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 404481,
          ["ilvl"] = 324,
          ["crit"] = 1009,
          ["haste"] = 1582,
          ["mastery"] = 331,
          ["vers"] = 264,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxsMzMzwsNYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Эивэн",
          ["guild"] = "Лё Резистанс",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 395362,
          ["ilvl"] = 326,
          ["crit"] = 1051,
          ["haste"] = 1866,
          ["mastery"] = 47,
          ["vers"] = 280,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWWWmZswMaGzAGMYYZmZmhZDGmlHYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Puzzledmonk",
          ["guild"] = "Pathogen",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 384723,
          ["ilvl"] = 326,
          ["crit"] = 942,
          ["haste"] = 1482,
          ["mastery"] = 159,
          ["vers"] = 438,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MLDbWMmZWWG2wYGmZZZbmxCDNjZADmFYWmZmZY2ghZ5BmAAAAAAgFLzsMbzMAAwAGgZAjhxiMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Soupherring",
          ["guild"] = "No Skill",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 384420,
          ["ilvl"] = 325,
          ["crit"] = 959,
          ["haste"] = 1632,
          ["mastery"] = 101,
          ["vers"] = 373,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxsMzMzwsNYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Incuchan",
          ["guild"] = "Booty Bay Bingo Buddies",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 382704,
          ["ilvl"] = 326,
          ["crit"] = 1061,
          ["haste"] = 1635,
          ["mastery"] = 268,
          ["vers"] = 299,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwsAzyMzMDz2gBLmAAAAAAgFLzsMbzMAAwAGgZAjhxiMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Luminesca",
          ["guild"] = "Shattrath Island",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 382135,
          ["ilvl"] = 328,
          ["crit"] = 1153,
          ["haste"] = 1572,
          ["mastery"] = 211,
          ["vers"] = 292,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwgxsMzMzwsMYwiJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Poipoipio",
          ["guild"] = "Dedicated Casuals",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 379828,
          ["ilvl"] = 325,
          ["crit"] = 822,
          ["haste"] = 1495,
          ["mastery"] = 331,
          ["vers"] = 429,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW22mZswQzYGwgBDLzMzMMbDGmFTAAAAAAwilZWmtZGAAYADwMgxwYZyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Peachpies",
          ["guild"] = "Defenestrate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 375693,
          ["ilvl"] = 327,
          ["crit"] = 989,
          ["haste"] = 1732,
          ["mastery"] = 62,
          ["vers"] = 343,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2A2sYmZmtlHYmNMzMMzyyyMjNGTzYGwghhZZMzMMbDGmlHYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Wide",
          ["guild"] = "Mentioned",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 375373,
          ["ilvl"] = 325,
          ["crit"] = 1168,
          ["haste"] = 1614,
          ["mastery"] = nil,
          ["vers"] = 354,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxGzoZMDYwAmlZmZGmtBDzyDMBAAAAAALWmZZ2mZAAgBMAzAGDsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Rinmw",
          ["guild"] = "Winters Heart",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 375291,
          ["ilvl"] = 325,
          ["crit"] = 1419,
          ["haste"] = 1505,
          ["mastery"] = 227,
          ["vers"] = 133,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswMaGzAGMYMLzMzMMbDGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Tunamonk",
          ["guild"] = "The Next Step",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 314851,
          ["ilvl"] = 325,
          ["crit"] = 468,
          ["haste"] = 715,
          ["mastery"] = 1585,
          ["vers"] = 289,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZZ2MmZ2WMghZbMbWmZswMaGzAGMbMmlZmZGmtBDWMBAAAAAAL2mZb2mZAAgBMAzAGYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Bzkmistx",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 314322,
          ["ilvl"] = 325,
          ["crit"] = 438,
          ["haste"] = 1460,
          ["mastery"] = 1150,
          ["vers"] = 146,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZZ2MmZ2WMghZbMbWmZswMaGzAGMbwsMzMzwsNYwyMBAAAAAAL2mZb2mZAAgBMAzAGgFZMDA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Alemonk",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 313197,
          ["ilvl"] = 321,
          ["crit"] = 321,
          ["haste"] = 1719,
          ["mastery"] = 980,
          ["vers"] = 245,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZxmxMz2iBMMbzMb2mZswMaGzAGMbwYmZmhZZWMDziJAAAAAAYx2Mbz2MDAAMgBYGwAsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Seeneenee",
          ["guild"] = "Soldiers of Elune",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 326944,
          ["ilvl"] = 321,
          ["crit"] = 1267,
          ["haste"] = 1377,
          ["mastery"] = 58,
          ["vers"] = 366,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwsAzyMzMDz2gBLmAAAAAAgFLzsMbzMAAwAGgZAjhxiMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Vilenja",
          ["guild"] = "Knicklicht",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 313130,
          ["ilvl"] = 322,
          ["crit"] = 1010,
          ["haste"] = 1759,
          ["mastery"] = nil,
          ["vers"] = 347,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWW2mZswMaGzAGMMDLzMzMMbDGsYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Poipoipio",
          ["guild"] = "Dedicated Casuals",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 312647,
          ["ilvl"] = 316,
          ["crit"] = 755,
          ["haste"] = 1451,
          ["mastery"] = 383,
          ["vers"] = 376,
          ["trinkets"] = {
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW22mZswMaGzAGMYYZmZmhZbwgFTAAAAAAwilZWmtZGAAYADwMgxwYZyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Эивэн",
          ["guild"] = "Лё Резистанс",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 312114,
          ["ilvl"] = 326,
          ["crit"] = 1051,
          ["haste"] = 1797,
          ["mastery"] = 47,
          ["vers"] = 320,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwgxsMzMzwsBDziJAAAAAAYxyMLz2MDAAMgBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Jadeaux",
          ["guild"] = "Meaningless Choice",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 310637,
          ["ilvl"] = 325,
          ["crit"] = 842,
          ["haste"] = 1811,
          ["mastery"] = 300,
          ["vers"] = 272,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZZmxCzoZMDYwghlZmZGmtBDWMBAAAAAALWmZZ2mZAAgBMAzAGDjlJjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "悠懒瑶瑶",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 310612,
          ["ilvl"] = 320,
          ["crit"] = 386,
          ["haste"] = 1117,
          ["mastery"] = 1057,
          ["vers"] = 527,
          ["trinkets"] = {
            {
              ["id"] = 268292,
              ["name"] = "Sporelord's Mycelial Insignia",
              ["ilvl"] = 298
            },
            {
              ["id"] = 249811,
              ["name"] = "Light of the Cosmic Crescendo",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZxmxMz2iBMMbzMbWmZswMaGzAGMgZZmZmhZbYGmlZCAAAAAAWsNz2sNzAAAADwMgBYRGzA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Wide",
          ["guild"] = "Mentioned",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 309493,
          ["ilvl"] = 325,
          ["crit"] = 1156,
          ["haste"] = 1615,
          ["mastery"] = nil,
          ["vers"] = 354,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2A2sYmZmllZshZmhZWW2mZswMaGzAGjBjxMzMDzyghZxEAAAAAAsYZmlZbmBAAGwAMDYMwiMmBA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "美团搜素烧鹅",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 308831,
          ["ilvl"] = 320,
          ["crit"] = 1079,
          ["haste"] = 1268,
          ["mastery"] = 260,
          ["vers"] = 355,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 318
            },
            {
              ["id"] = 268292,
              ["name"] = "Sporelord's Mycelial Insignia",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZWW2mZswMaGzAGMALzMzMMbDGmFTAAAAAAwilZWmtZGAAYADwMgxwYZyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Chickenarms",
          ["guild"] = "so fresh",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 308387,
          ["ilvl"] = 322,
          ["crit"] = 943,
          ["haste"] = 1616,
          ["mastery"] = 101,
          ["vers"] = 532,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCDNjZADGMYmZmhZbMGmlHYCAAAAAAWsMzysNzAAADYAmBMGGLyYGA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        },
        {
          ["name"] = "Asterísk",
          ["guild"] = "Reko",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 307886,
          ["ilvl"] = 324,
          ["crit"] = 1014,
          ["haste"] = 1426,
          ["mastery"] = 157,
          ["vers"] = 453,
          ["trinkets"] = {
            {
              ["id"] = 250248,
              ["name"] = "Mycolic Medicine",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwgxsMzMzwsBDWMBAAAAAALWmZZ2mZAAgBjBYGwYYsIjZA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "inv_ability_conduitofthecelestialsmonk_celestialconduit"
          }
        }
      }
    },
    {
      ["spec"] = "Windwalker",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "구름차의천신합일",
          ["guild"] = "Mate",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 229790,
          ["ilvl"] = 330,
          ["crit"] = 995,
          ["haste"] = 822,
          ["mastery"] = 1270,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwALzYYmZmhZbYGmFTAALmZbmZMmZGAALmZZ2GTAAAjBwMAjlBwMzs5CA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Zyntharen",
          ["guild"] = "Ring Åklagarn",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 222204,
          ["ilvl"] = 324,
          ["crit"] = 924,
          ["haste"] = 952,
          ["mastery"] = 1135,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDzGmBLzEAwiZ2mZGjZmBAwiZWmlxEAAwMDgZAGLDgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Rhaemonster",
          ["guild"] = "ToYz",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 221891,
          ["ilvl"] = 326,
          ["crit"] = 938,
          ["haste"] = 923,
          ["mastery"] = 1230,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMCzwwAmZGmZmZY2GmhZZmAAWMz2MzYMzMAAWMzysMmAAAGDgZAGLDgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Aidan",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220938,
          ["ilvl"] = 328,
          ["crit"] = 973,
          ["haste"] = 957,
          ["mastery"] = 1226,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxMmZmZY2GmBLmAAWMz2MzYMzMAAWMzysMmAAAGDgZAGLzAMzMbuA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Kitepunch",
          ["guild"] = "K L I K A",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 219835,
          ["ilvl"] = 324,
          ["crit"] = 854,
          ["haste"] = 746,
          ["mastery"] = 1258,
          ["vers"] = 344,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGGGwMGmZmZY2GmhZZmAAWMz2YGzMzMAAWMzysNmAAAGDgZAYZAMzMbeA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Raschedmonk",
          ["guild"] = "Myth",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 219214,
          ["ilvl"] = 327,
          ["crit"] = 866,
          ["haste"] = 1067,
          ["mastery"] = 1163,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAGmxMzMDz2wMYZmAAWMz2MzYMzMAAWMzysMmAAAGDgZAGLDgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Krexonaut",
          ["guild"] = "Consequence",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 218759,
          ["ilvl"] = 326,
          ["crit"] = 1002,
          ["haste"] = 801,
          ["mastery"] = 1171,
          ["vers"] = 153,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAGGmZmZY2GmhZZmAAWMz2MzYMzMAAWMzysMmAAAGDgZAGLDgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "陽光小绵羊",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217497,
          ["ilvl"] = 326,
          ["crit"] = 905,
          ["haste"] = 967,
          ["mastery"] = 1304,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMCzYbYGYGDzMzMMLYGmlZCAYxMbzMjZmZGAALmZZWGTAAAMAmBYsMAmZmNXA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Gerlox",
          ["guild"] = "Honolulu",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217302,
          ["ilvl"] = 326,
          ["crit"] = 988,
          ["haste"] = 824,
          ["mastery"] = 1260,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GmhlZmZbGAAAAAAAAAAAglhRzYGGGYZGDzMzMMbDzwsYCAYxMbzMjxMzAAYxMLzyYCAAgBwMAjlBwMzs5CA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Gweilo",
          ["guild"] = "Mean Girls",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215618,
          ["ilvl"] = 325,
          ["crit"] = 746,
          ["haste"] = 734,
          ["mastery"] = 1371,
          ["vers"] = 276,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MzYMzMAAWMzysMmAAAGDgZAYZGgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "구름차의천신합일",
          ["guild"] = "Mate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 233058,
          ["ilvl"] = 330,
          ["crit"] = 995,
          ["haste"] = 822,
          ["mastery"] = 1270,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwALzYYmZmhZbYGmFTAALmZbmZMmZGAALmZZ2GTAAAjBwMAjlBwMzs5CA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Aidan",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 225967,
          ["ilvl"] = 328,
          ["crit"] = 973,
          ["haste"] = 1122,
          ["mastery"] = 1061,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMYZmAAWMz2YGzMzMAAWMzysMmAAAYAMDwYZAMzMb+A",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Styphi",
          ["guild"] = "DMG",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 221478,
          ["ilvl"] = 327,
          ["crit"] = 889,
          ["haste"] = 854,
          ["mastery"] = 1332,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMYZmAAWMz2YGzMzMAAWMzysMmAAAYAMDwYZAMzMb+A",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Chijing",
          ["guild"] = "Slack",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 220576,
          ["ilvl"] = 327,
          ["crit"] = 1015,
          ["haste"] = 931,
          ["mastery"] = 1216,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLzEAwiZ2GzYmZmBAwiZWmlxEAAADgZAYZAMzMb+A",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Lây",
          ["guild"] = "The Next Step",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217935,
          ["ilvl"] = 324,
          ["crit"] = 1044,
          ["haste"] = 916,
          ["mastery"] = 1050,
          ["vers"] = 166,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMYZmAAWMz2YGzMzMAAWMzysMmAAAYAMDwYZAMzMb+A",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Youngonext",
          ["guild"] = "Причина Тряски",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 216659,
          ["ilvl"] = 325,
          ["crit"] = 777,
          ["haste"] = 1069,
          ["mastery"] = 1335,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMCzwwAmxwMzMDz2wMMLzEAwiZWGzYmZmBAwiZWmtxEAAADgZAGLzAMzMb+A",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Varis",
          ["guild"] = "Noni",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209983,
          ["ilvl"] = 326,
          ["crit"] = 753,
          ["haste"] = 1036,
          ["mastery"] = 1254,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLmAAWMz2MzYMzMAAWMzysMmAAAGDgZAGLzAMzMbuA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Eroo",
          ["guild"] = "Ethical",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209655,
          ["ilvl"] = 327,
          ["crit"] = 994,
          ["haste"] = 967,
          ["mastery"] = 1212,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaYGGGwMGmZmZY2GmhZZmAAWMz2MzYMzMAAWMzysMmAAAGDgZAGLDgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "濒死悟道",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209643,
          ["ilvl"] = 330,
          ["crit"] = 936,
          ["haste"] = 836,
          ["mastery"] = 1378,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAGmxMzMDz2wMMLPwEAwiZ2GzYmZmBAwiZWmlxEAAwYAMDwYZAMzMbuA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Sîp",
          ["guild"] = "Deception",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209212,
          ["ilvl"] = 326,
          ["crit"] = 655,
          ["haste"] = 1075,
          ["mastery"] = 1333,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMCzwwAmxwMzMDz2wMMLzEAwiZ2GzYmZmBAwiZWmtxEAAADgZAGLDYMzMb+A",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Juji",
          ["guild"] = "BlackCellFaction",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 386385,
          ["ilvl"] = 326,
          ["crit"] = 884,
          ["haste"] = 858,
          ["mastery"] = 1222,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmBMghZMzMzwsNMDzyDMBAsYmtxMmZmZAAsYmlZZMBAAMGAzAMWmBYmZ28B",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Pywi",
          ["guild"] = "Rat Pack",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 385266,
          ["ilvl"] = 325,
          ["crit"] = 762,
          ["haste"] = 1138,
          ["mastery"] = 1187,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMjhZmZGmthZwyMBAsYmtxMmZmZAAsYmlZbMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Dadrimmer",
          ["guild"] = "smile",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 385000,
          ["ilvl"] = 326,
          ["crit"] = 914,
          ["haste"] = 941,
          ["mastery"] = 1302,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMgBMjhZmZGmthZYWmJAgFzsNmxMzMDAgFzsMbjJAAgxAYGgx2AGzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Diehl",
          ["guild"] = "I link AOTC",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 384209,
          ["ilvl"] = 323,
          ["crit"] = 738,
          ["haste"] = 1082,
          ["mastery"] = 1123,
          ["vers"] = 152,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMWGGwMGmZmZY2GmhZZmAAWMzGzYmZmBAwiZWmlxEAAwYAMDALMgZmZzA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Scorpymonk",
          ["guild"] = "baited",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 383856,
          ["ilvl"] = 324,
          ["crit"] = 909,
          ["haste"] = 931,
          ["mastery"] = 1077,
          ["vers"] = 262,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMjhZmZGmthZYWmJAgFzsNmxMzMDAgFzsMLjJAAgxAYGAWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Gírlstreamer",
          ["guild"] = "Little Hard Feelings",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 370702,
          ["ilvl"] = 327,
          ["crit"] = 842,
          ["haste"] = 943,
          ["mastery"] = 1306,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmBMghZMzMzwsNMDzyDMBAsYmtxMmZmZAAsYmlZZMBAAwAYGgxyMAzMzmB",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Roxo",
          ["guild"] = "Da Bishes",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 369236,
          ["ilvl"] = 325,
          ["crit"] = 1004,
          ["haste"] = 955,
          ["mastery"] = 1075,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMjhZmZGmthZYWMBAsYmtxMmZmZAAsYmlZZMBAAMGAzAMWmBYmZ28B",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Macys",
          ["guild"] = "The Gauntlet",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 366674,
          ["ilvl"] = 325,
          ["crit"] = 696,
          ["haste"] = 1019,
          ["mastery"] = 1293,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMMMzMzwsxMDWmJAgFzsNmxYmZAAsYmlZbMBAAMGAzAMWmBYmZ2M",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Eroo",
          ["guild"] = "Ethical",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 366259,
          ["ilvl"] = 321,
          ["crit"] = 878,
          ["haste"] = 921,
          ["mastery"] = 1353,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDjGmhhBMjhZmZGmthZYWmJAgFmtxMmZmZAAsYmlZZMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Gerlox",
          ["guild"] = "Honolulu",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 365883,
          ["ilvl"] = 322,
          ["crit"] = 857,
          ["haste"] = 798,
          ["mastery"] = 1352,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGwAmxwMzMDz2wMMLzEAwiZ2GzYmZmBAwiZWmlxEAAwYAMDwYZAMzMbeA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Aidan",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 305389,
          ["ilvl"] = 328,
          ["crit"] = 973,
          ["haste"] = 957,
          ["mastery"] = 1226,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDjmxMMMgZMMzMzwsNMDWmJAgFmtxMmZmZAAsYmlZZMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Sîp",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 293602,
          ["ilvl"] = 326,
          ["crit"] = 655,
          ["haste"] = 1075,
          ["mastery"] = 1333,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDjmxMMMw2wwMzMDz2wMMLmAAWY2GzYmZmBAwiZWmtxEAAwYAMDwYZGgZmZzHA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Styphi",
          ["guild"] = "DMG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 290039,
          ["ilvl"] = 326,
          ["crit"] = 889,
          ["haste"] = 849,
          ["mastery"] = 1330,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDjmxMMMgZMMzMzwsNMDWmJAgFmtxMmZmZAAsYmlZZMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "迅疾閃光",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 285892,
          ["ilvl"] = 327,
          ["crit"] = 1026,
          ["haste"] = 860,
          ["mastery"] = 1272,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDjmxMMMgZMMzMzwsNMDzyMBAswsNmxMzMDAgFzsMLjJAAgxAYGAWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Eroo",
          ["guild"] = "Ethical",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 285383,
          ["ilvl"] = 327,
          ["crit"] = 994,
          ["haste"] = 967,
          ["mastery"] = 1212,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDjGmhhBMjhZmZGmthZYWmJAgFmtxMmZmZAAsYmlZZMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Paperchi",
          ["guild"] = "Medium",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 283980,
          ["ilvl"] = 326,
          ["crit"] = 1001,
          ["haste"] = 795,
          ["mastery"] = 1240,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmx2MGAAAAAAAAAAAYZY0MmhhBMjhZmZGmthZYWmJAgFzsNmxYmZAAsYmlZZMBAAMGAzAwyAYmZ2M",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Aibelf",
          ["guild"] = "Mithril Knights",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 277470,
          ["ilvl"] = 326,
          ["crit"] = 861,
          ["haste"] = 1016,
          ["mastery"] = 1194,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYbY0MmBMgZMMzMzwsNMDzyMBAsYmtxMmZmZAAsYmlZbMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Titanbelly",
          ["guild"] = "Low Expectations",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 276081,
          ["ilvl"] = 324,
          ["crit"] = 632,
          ["haste"] = 954,
          ["mastery"] = 1375,
          ["vers"] = 120,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMgZmZMzMzwshZYWmJAgFmtxMmZmZAAsYmlZbMBAAMzAYGAWAYmZ2M",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Varis",
          ["guild"] = "Noni",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 275993,
          ["ilvl"] = 326,
          ["crit"] = 753,
          ["haste"] = 1036,
          ["mastery"] = 1254,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMjhZmZGmthZYWmJAgFzsNmxYmZAAsYmlZZMBAAMGAzAwyAYmZ2M",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "완투빤찌",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 275121,
          ["ilvl"] = 326,
          ["crit"] = 717,
          ["haste"] = 1115,
          ["mastery"] = 1170,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDzEmBMgZMMzMzwsNMDzyMBAswsNmxMzMDAgFzsMLjJAAgxAYGgxyMAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Aidan",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Sszorak",
          ["amount"] = 221660,
          ["ilvl"] = 328,
          ["crit"] = 973,
          ["haste"] = 1122,
          ["mastery"] = 1061,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMYZmAAWMz2MDzMzMAA2AgZZWamZmFAMwMDAjlBwA+A",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Zyntharen",
          ["guild"] = "Ring Åklagarn",
          ["boss"] = "Sszorak",
          ["amount"] = 215980,
          ["ilvl"] = 326,
          ["crit"] = 943,
          ["haste"] = 1128,
          ["mastery"] = 957,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2sxglZCAYxMbzMMzMzAAYDAmlZpZmZWAwAzMAMWGAD4DA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "구름차의천신합일",
          ["guild"] = "Mate",
          ["boss"] = "Sszorak",
          ["amount"] = 214824,
          ["ilvl"] = 330,
          ["crit"] = 995,
          ["haste"] = 822,
          ["mastery"] = 1270,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLmAAWMz2MDzMzMAA2AgZZWamZmFAMwMDAjlZAGwHA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Styphi",
          ["guild"] = "DMG",
          ["boss"] = "Sszorak",
          ["amount"] = 211726,
          ["ilvl"] = 326,
          ["crit"] = 889,
          ["haste"] = 849,
          ["mastery"] = 1330,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMCzwwAmxwMzMDz2wMMLzEAwiZ2mZYmZmBAwGAMLzSzMzsAgBmZAYsMGwA+A",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Chezny",
          ["guild"] = "Vex Thal",
          ["boss"] = "Sszorak",
          ["amount"] = 210721,
          ["ilvl"] = 325,
          ["crit"] = 944,
          ["haste"] = 880,
          ["mastery"] = 1315,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GmhlZmZbGAAAAAAAAAAAglhRYGGGwYmxMzMDz2wMMLzEAwiZ2mZGzMzMAAWMzysMmAAAYAMDwYZAMzMbeA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Speedwalker",
          ["guild"] = "Speakeasy",
          ["boss"] = "Sszorak",
          ["amount"] = 209742,
          ["ilvl"] = 324,
          ["crit"] = 928,
          ["haste"] = 1142,
          ["mastery"] = 957,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2sxglZCAYxMbzMMzMzAAYDAmlZpZmZWAwAzMAMWGAD4DA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Juji",
          ["guild"] = "BlackCellFaction",
          ["boss"] = "Sszorak",
          ["amount"] = 208379,
          ["ilvl"] = 326,
          ["crit"] = 958,
          ["haste"] = 1023,
          ["mastery"] = 983,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMaYGGGwYGmZmZY2GmhZZmAAWMz2MDzMzMAA2AgZZWamZmFAMwMDAjlBwA+A",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Jarpamonk",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Sszorak",
          ["amount"] = 207639,
          ["ilvl"] = 326,
          ["crit"] = 1038,
          ["haste"] = 821,
          ["mastery"] = 1187,
          ["vers"] = 116,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2mxMsMzYbGAAAAAAAAAAAglhRYGGGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AgZZWamZmFAMwMDAjlxAGwFA",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Boombox",
          ["guild"] = "Shade",
          ["boss"] = "Sszorak",
          ["amount"] = 207473,
          ["ilvl"] = 321,
          ["crit"] = 1011,
          ["haste"] = 1024,
          ["mastery"] = 947,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMCzwwAmxwMzMDz2wMMLzEAwiZ2mZYmZmBAwGAMLzSzMzsAgBmZAYsMGwA+A",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Brrandonn",
          ["guild"] = "CALM DOWN",
          ["boss"] = "Sszorak",
          ["amount"] = 207081,
          ["ilvl"] = 324,
          ["crit"] = 963,
          ["haste"] = 1038,
          ["mastery"] = 994,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAGGmZmZY2GmhZZmAAWMz2MDzMzMAA2AgZZWamZmFAMwMDAjlBwA+A",
          ["hero"] = {
            ["name"] = "Shado-Pan",
            ["atlas"] = "talents-heroclass-monk-shadopan",
            ["icon"] = "inv_ability_shadopanmonk_flurrystrikes"
          }
        },
        {
          ["name"] = "Styphi",
          ["guild"] = "DMG",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 317572,
          ["ilvl"] = 327,
          ["crit"] = 889,
          ["haste"] = 854,
          ["mastery"] = 1332,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAAbDjwMMMgZMjZmZGmthZYWmJAgFmtxMmZmZAAsYmlZZMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "구름차의천신합일",
          ["guild"] = "Mate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 309484,
          ["ilvl"] = 330,
          ["crit"] = 950,
          ["haste"] = 772,
          ["mastery"] = 1372,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAAbDjmxMgBMMjZmZGmthZYWmJAgFmtxMmZmZAAsYmlZZMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Aidan",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 308346,
          ["ilvl"] = 328,
          ["crit"] = 973,
          ["haste"] = 1122,
          ["mastery"] = 1061,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAAbDjwMMMgZMjZmZGmthZYWmJAgFmtxMmZmZAAsYmlZZMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Gerlox",
          ["guild"] = "Honolulu",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 306152,
          ["ilvl"] = 326,
          ["crit"] = 988,
          ["haste"] = 824,
          ["mastery"] = 1260,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAAbDjmxMgBMjhZmZGmNmZYWmJAgFmtxMmZmZAAsYmlZbMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Sîp",
          ["guild"] = "Deception",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 297072,
          ["ilvl"] = 327,
          ["crit"] = 658,
          ["haste"] = 1083,
          ["mastery"] = 1336,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAAbDjwMMMgZMjZmZGmthZYWmJAgFmtxMmZmZAAsYmlZbMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Cleanraton",
          ["guild"] = "Offline",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 295723,
          ["ilvl"] = 326,
          ["crit"] = 935,
          ["haste"] = 997,
          ["mastery"] = 1138,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDjwMMMghZMzMzwsxMDzyMBAswsNmxMzMDAgFzsMLjJAAgxAYGgxyMAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "迅疾閃光",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 294339,
          ["ilvl"] = 327,
          ["crit"] = 1026,
          ["haste"] = 860,
          ["mastery"] = 1272,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDjmxMMMgZMMzMzwsNMDzyMBAswsNmxMzMDAgFzsMLjJAAgxAYGAWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Paperchi",
          ["guild"] = "Medium",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 293300,
          ["ilvl"] = 326,
          ["crit"] = 1003,
          ["haste"] = 796,
          ["mastery"] = 1240,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAAbDjwMMMgZMjZmZGmthZYWmJAgFmtxMmZmZAAsYmlZZMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Chezny",
          ["guild"] = "Vex Thal",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 288864,
          ["ilvl"] = 325,
          ["crit"] = 944,
          ["haste"] = 880,
          ["mastery"] = 1315,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAAbDjwMMMgZMjZmZGmthZYWmJAgFmtxMmZmZAAsYmlZZMBAAMGAzAMWGAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "완투빤찌",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 287953,
          ["ilvl"] = 326,
          ["crit"] = 717,
          ["haste"] = 1115,
          ["mastery"] = 1170,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mxAAAAAAAAAAAALDzEmBMgZMMzMzwsNMDzyMBAswsNmxMzMDAgFzsMLjJAAgxAYGgxyMAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Aidan",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 228061,
          ["ilvl"] = 328,
          ["crit"] = 945,
          ["haste"] = 941,
          ["mastery"] = 1277,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxMmZmZY2GmBLmAAWMz2MzYMzMAAWMzysMmAAAGDgZAGLzAMzMbuA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Eroo",
          ["guild"] = "Ethical",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 227026,
          ["ilvl"] = 327,
          ["crit"] = 994,
          ["haste"] = 967,
          ["mastery"] = 1213,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAbDzYmZmhZbYGsYCAYxMbzMjxMzAAYxMLzyYCAAYMAmBYsMYwMzs5CA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Gerlox",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 220533,
          ["ilvl"] = 327,
          ["crit"] = 990,
          ["haste"] = 826,
          ["mastery"] = 1262,
          ["vers"] = 116,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGGGwwMmZmZY2YmhZxEAwiZ2mZGjZmBAwiZWmtxEAAwYAMDwYZGgZmZzDA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Lulu",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 218651,
          ["ilvl"] = 328,
          ["crit"] = 1002,
          ["haste"] = 722,
          ["mastery"] = 1253,
          ["vers"] = 219,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAGzwMzMDz2wMYZmAAWMz2MzYMzMAAWMzysNmAAAGDgZAGLDgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Monkakås",
          ["guild"] = "Fragglene",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 215807,
          ["ilvl"] = 327,
          ["crit"] = 716,
          ["haste"] = 967,
          ["mastery"] = 1191,
          ["vers"] = 320,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAGmxMzMzY2GMMLmAAWMz2MzYMzMAAWMzysNmAAAGDgZAGLzAMzMbuA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "구름차의천신합일",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 215508,
          ["ilvl"] = 330,
          ["crit"] = 950,
          ["haste"] = 772,
          ["mastery"] = 1372,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwgxwMmZmZY2GMMLmAAWMz2MzYMzMAAWMzysNmAAAGDgZAGLzAMzMbuA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Styphi",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 215066,
          ["ilvl"] = 327,
          ["crit"] = 889,
          ["haste"] = 854,
          ["mastery"] = 1332,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwgxwMmZmZY2wMMLmAAWMz2MzYMzMAAWMzysNmAAAGDgZAGLzAMzMbuA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Kreemoncow",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 215034,
          ["ilvl"] = 327,
          ["crit"] = 1021,
          ["haste"] = 1000,
          ["mastery"] = 1079,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGGGwwMmZmZY2GMMLzEAwiZ2mZGjZmBAwiZWmlxEAAwYAMDwYZAMzMbeA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Voliimonk",
          ["guild"] = "Sabotage",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 212186,
          ["ilvl"] = 327,
          ["crit"] = 771,
          ["haste"] = 876,
          ["mastery"] = 1452,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaYGGGYbGzYmZmhZbYGmlZCAYxMbzMjxMzAAYxMLz2YCAAYMAmBgFAmZmNXA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "月隐晦明",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 210838,
          ["ilvl"] = 329,
          ["crit"] = 809,
          ["haste"] = 922,
          ["mastery"] = 3035,
          ["vers"] = -63,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAGzwMzMDz2wMMLmAAWMz2MzYMzMAAWMzysNmAAAGDgZAGLzAMzMbuA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "구름차의천신합일",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 459415,
          ["ilvl"] = 330,
          ["crit"] = 950,
          ["haste"] = 772,
          ["mastery"] = 1372,
          ["vers"] = 1354,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmx2MAAAAAAAAAAAALDjmxMMMghZMzMzwsMMDzyMBAswsNmxMzMDAgFzsMLjJAAwMGAzAwyAYmZWM",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Jordomonk",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 414663,
          ["ilvl"] = 327,
          ["crit"] = 887,
          ["haste"] = 998,
          ["mastery"] = 1214,
          ["vers"] = 1361,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMMjZmZGmthZYWMBAswsNmxYmZAAsYmlZZMBAAmxAYGgxyMAzMziB",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "濒死悟道",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 272357,
          ["ilvl"] = 330,
          ["crit"] = 936,
          ["haste"] = 836,
          ["mastery"] = 1378,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMMjZmZGmthZYWegJAgFzsNmxMzMDAgFzsMLjJAAgxAYGgxyAYmZ28B",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Krylest",
          ["guild"] = "Well Named guild",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 256794,
          ["ilvl"] = 324,
          ["crit"] = 826,
          ["haste"] = 960,
          ["mastery"] = 1268,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMCzwwAGzMmZmZY2GmBLzEAwiZ2mZGjZmBAwiZWmlxEAAwYAMDwYZGgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Shanyie",
          ["guild"] = "Wîpefest",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 253891,
          ["ilvl"] = 322,
          ["crit"] = 1077,
          ["haste"] = 583,
          ["mastery"] = 1257,
          ["vers"] = 194,
          ["trinkets"] = {
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAGGmZmZY2GmhZZmAAWMz2MzYMzMAAWMzysMmAAAGDgZAGLDgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Smonkio",
          ["guild"] = "No Shame",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 250958,
          ["ilvl"] = 327,
          ["crit"] = 867,
          ["haste"] = 956,
          ["mastery"] = 1282,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMCzwwAGzMmZmZY2GmBLzEAwiZ2mZGjZmBAwiZWmlxEAAwYAMDwYZGgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Bisset",
          ["guild"] = "Confluence",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 248876,
          ["ilvl"] = 324,
          ["crit"] = 978,
          ["haste"] = 554,
          ["mastery"] = 1424,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmNmZwyMBAswsxMmZmZAAsYmlZbMBAAmxAYGgxyAYmZ2M",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Chijing",
          ["guild"] = "Slack",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 247900,
          ["ilvl"] = 327,
          ["crit"] = 1015,
          ["haste"] = 931,
          ["mastery"] = 1145,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLzEAwiZ2mZGjZmBAwiZWmlxEAAwYAMDALDgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Candybrew",
          ["guild"] = "У беляша",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 244314,
          ["ilvl"] = 327,
          ["crit"] = 743,
          ["haste"] = 1161,
          ["mastery"] = 1203,
          ["vers"] = 71,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgZGLzM2mBAAAAAAAAAAAYZYEmBMgZmhZmZGmthZYWmJAgFzsNmxMzMDAgFzsMLjJAAgxAYGgxyAGzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Monkkickxz",
          ["guild"] = "Chilled",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 244192,
          ["ilvl"] = 324,
          ["crit"] = 792,
          ["haste"] = 892,
          ["mastery"] = 1373,
          ["vers"] = 188,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMgZMMzMzwsNMDzyMBAsYmtxMmZmZAAsYmlZZMBAAMGAzAwyYAzMzmPA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Norcomonk",
          ["guild"] = "Idiot",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 243776,
          ["ilvl"] = 324,
          ["crit"] = 819,
          ["haste"] = 928,
          ["mastery"] = 1374,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGjlZmZbGAAAAAAAAAAAglhRYGGGwMzwMzMDz2wMMLzEAwiZ2GzYmZmBAwiZWmtxEAAwYAMDwYZAMzMbeA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        },
        {
          ["name"] = "Sacrêd",
          ["guild"] = "is in shambles",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 243239,
          ["ilvl"] = 322,
          ["crit"] = 796,
          ["haste"] = 1061,
          ["mastery"] = 1195,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLzEAwiZ2mZGjZmBAwiZWmlxEAAwYAMDALDgZmZzFA",
          ["hero"] = {
            ["name"] = "Conduit of the Celestials",
            ["atlas"] = "talents-heroclass-monk-conduitofthecelestials",
            ["icon"] = "ability_monk_summontigerstatue"
          }
        }
      }
    }
  }
}
