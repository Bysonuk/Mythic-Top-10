MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Warrior"] = {
  ["className"] = "Warrior",
  ["specs"] = {
    {
      ["spec"] = "Arms",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Illhitu",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 238421,
          ["ilvl"] = 328,
          ["crit"] = 1386,
          ["haste"] = 1116,
          ["mastery"] = 558,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Rbwarrior",
          ["guild"] = "Never AFK",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 237357,
          ["ilvl"] = 328,
          ["crit"] = 1313,
          ["haste"] = 923,
          ["mastery"] = 767,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZbZmZmZYGzMAAAAAGLzMwEGLbDsAGwMMBmBbgZGGGMLzsNAzMAYGGA"
        },
        {
          ["name"] = "末诚",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 230137,
          ["ilvl"] = 326,
          ["crit"] = 1311,
          ["haste"] = 1014,
          ["mastery"] = 655,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZGmZbZmZmZYGzMAAAAAmZZmBmwYZZgFwAmhJwMYDMzwwALzsNAzMAYGGA"
        },
        {
          ["name"] = "Quessa",
          ["guild"] = "У беляша",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 227592,
          ["ilvl"] = 326,
          ["crit"] = 1298,
          ["haste"] = 1028,
          ["mastery"] = 590,
          ["vers"] = 166,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMz8AmZGAAAghphZGzMbLzMzMDGzMAAAAAmZZmBmwYZZgFwAmhJwMYDMzwwALzsNAzMAYGGA"
        },
        {
          ["name"] = "Бродаймонд",
          ["guild"] = "Геи Азерота",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 226705,
          ["ilvl"] = 326,
          ["crit"] = 1183,
          ["haste"] = 929,
          ["mastery"] = 780,
          ["vers"] = 137,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZgJMWWGYBMgZYCMD2AzM2GbDsMz2AMzAgZYA"
        },
        {
          ["name"] = "Pházéd",
          ["guild"] = "Deception",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 226335,
          ["ilvl"] = 325,
          ["crit"] = 1253,
          ["haste"] = 1284,
          ["mastery"] = 510,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Sniperbeer",
          ["guild"] = "Monkey Mash",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 225306,
          ["ilvl"] = 325,
          ["crit"] = 1210,
          ["haste"] = 1002,
          ["mastery"] = 706,
          ["vers"] = 88,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Dungeoning",
          ["guild"] = "HALP SHARK",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 224808,
          ["ilvl"] = 324,
          ["crit"] = 1329,
          ["haste"] = 1228,
          ["mastery"] = 476,
          ["vers"] = 72,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZGzMbLzMzMDGzMAAAAAmZZmBmwYZZgFwAmhJwMYDMzwwALzsNAzMAYGGA"
        },
        {
          ["name"] = "Warrxu",
          ["guild"] = "Blessed",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 224558,
          ["ilvl"] = 326,
          ["crit"] = 1349,
          ["haste"] = 981,
          ["mastery"] = 635,
          ["vers"] = 112,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Anekâ",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 223540,
          ["ilvl"] = 324,
          ["crit"] = 1014,
          ["haste"] = 1108,
          ["mastery"] = 794,
          ["vers"] = 184,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzMmZGAAAghphxwMbLzMzMDzYmBAAAAwMLzMgwYZZgFwAmhJwMYDMzYbYglZ2GgZGAMDDA"
        },
        {
          ["name"] = "불라방",
          ["guild"] = "Mate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 258691,
          ["ilvl"] = 332,
          ["crit"] = 1461,
          ["haste"] = 1097,
          ["mastery"] = 532,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMz8AmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Cloudwarrior",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 228833,
          ["ilvl"] = 327,
          ["crit"] = 1261,
          ["haste"] = 1009,
          ["mastery"] = 593,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Plkawar",
          ["guild"] = "Nascent",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 225989,
          ["ilvl"] = 327,
          ["crit"] = 1420,
          ["haste"] = 1072,
          ["mastery"] = 413,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Sotaxwar",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 225661,
          ["ilvl"] = 327,
          ["crit"] = 1419,
          ["haste"] = 739,
          ["mastery"] = 766,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMz8AmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Eroka",
          ["guild"] = "Honestly",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 225217,
          ["ilvl"] = 326,
          ["crit"] = 1459,
          ["haste"] = 1064,
          ["mastery"] = 548,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphBzMLLzMzMMzYmBAAAAwMLzMwEGLbDsAGwMMBmBbgZGGbDsMz2AMzAgZYA"
        },
        {
          ["name"] = "Rosswarrior",
          ["guild"] = "Rhythm",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224502,
          ["ilvl"] = 326,
          ["crit"] = 1286,
          ["haste"] = 935,
          ["mastery"] = 580,
          ["vers"] = 255,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMz8AmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZgJMWWGYBMgZYCMD2AzM2GbDsMz2AMzAgZYA"
        },
        {
          ["name"] = "四包烟",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224410,
          ["ilvl"] = 321,
          ["crit"] = 1352,
          ["haste"] = 1120,
          ["mastery"] = 483,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 318
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmxyYbglZ2GgZGAYYA"
        },
        {
          ["name"] = "巃丶",
          ["guild"] = "Scary maze",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224287,
          ["ilvl"] = 330,
          ["crit"] = 1314,
          ["haste"] = 1017,
          ["mastery"] = 608,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Farover",
          ["guild"] = "Northstar",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 223648,
          ["ilvl"] = 326,
          ["crit"] = 1187,
          ["haste"] = 1149,
          ["mastery"] = 592,
          ["vers"] = 258,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Niahx",
          ["guild"] = "Прок Гейминг",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 222932,
          ["ilvl"] = 325,
          ["crit"] = 1495,
          ["haste"] = 887,
          ["mastery"] = 523,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Zitee",
          ["guild"] = "Raze",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 353324,
          ["ilvl"] = 326,
          ["crit"] = 1274,
          ["haste"] = 982,
          ["mastery"] = 783,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZGzMWmZmZGMmZAAAAAMWmZgJMW2GYBMgZYCMD2AzMM2GMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Pát",
          ["guild"] = "Valhalla NZ",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 338869,
          ["ilvl"] = 327,
          ["crit"] = 1329,
          ["haste"] = 1023,
          ["mastery"] = 692,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZZZmZmZYGzMAAAAAGLzMwEGLbDsAGwMMBmBbgZGGGMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Olarto",
          ["guild"] = "undecided",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 336346,
          ["ilvl"] = 327,
          ["crit"] = 1363,
          ["haste"] = 1041,
          ["mastery"] = 587,
          ["vers"] = 184,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZZZmZmZYGzMAAAAAGLzMwEGLbDsAGwMMBmBbgZGGGMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Sniperbeer",
          ["guild"] = "Monkey Mash",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 328980,
          ["ilvl"] = 325,
          ["crit"] = 1214,
          ["haste"] = 1018,
          ["mastery"] = 669,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZGzMWmZmZGMmZAAAAAMWmZgJMW2GYBMgZYCMD2AzMM2GMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Scolpi",
          ["guild"] = "Tempo",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 325496,
          ["ilvl"] = 319,
          ["crit"] = 1244,
          ["haste"] = 1091,
          ["mastery"] = 681,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZGmZbZmZmZYGzMAAAAAGLzMwEGLbDsAGwMMBmBbgZGGGMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Evandar",
          ["guild"] = "Friendly Friends",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 324265,
          ["ilvl"] = 326,
          ["crit"] = 1351,
          ["haste"] = 1185,
          ["mastery"] = 603,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZYmZbZmZmZwYmBAAAAwYZmBmwYZbgFwAmhJwMYDMzYbYwsMz2AMzAgZYA"
        },
        {
          ["name"] = "執迷不悟丶",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 324176,
          ["ilvl"] = 320,
          ["crit"] = 1433,
          ["haste"] = 972,
          ["mastery"] = 576,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZYmZZZmZmZYGzMAAAAAGLzMwEGLbDsAGwMMBmBbgZGGGMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Azogal",
          ["guild"] = "Proper Guild Name",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323152,
          ["ilvl"] = 325,
          ["crit"] = 1232,
          ["haste"] = 1051,
          ["mastery"] = 748,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZGzMWmZmZGMmZAAAAAMWmZgJMW2GYBMgZYCMD2AzMM2GMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Retreatless",
          ["guild"] = "Mercy Killers",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323088,
          ["ilvl"] = 326,
          ["crit"] = 1262,
          ["haste"] = 1046,
          ["mastery"] = 730,
          ["vers"] = 163,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZbZmZmZwYmBAAAAwYZmBmwYZbgFwAmhJwMYDMzYZYwsMz2AMzAgZYA"
        },
        {
          ["name"] = "Nlw",
          ["guild"] = "Nineteen Reasons Why",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 322679,
          ["ilvl"] = 325,
          ["crit"] = 1358,
          ["haste"] = 1267,
          ["mastery"] = 459,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZzMzMzwMmZAAAAAMWmZgJMW2GYBMgZYCMD2AzMM2GMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Cringewar",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 376131,
          ["ilvl"] = 331,
          ["crit"] = 1286,
          ["haste"] = 1016,
          ["mastery"] = 646,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "불라방",
          ["guild"] = "Mate",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 351641,
          ["ilvl"] = 333,
          ["crit"] = 1325,
          ["haste"] = 1097,
          ["mastery"] = 532,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Pházéd",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 338621,
          ["ilvl"] = 325,
          ["crit"] = 1253,
          ["haste"] = 1284,
          ["mastery"] = 510,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Illhitu",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 333368,
          ["ilvl"] = 328,
          ["crit"] = 1386,
          ["haste"] = 1116,
          ["mastery"] = 558,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGmxMDAAAAgZWmZgJMW2GYBMgZYCMwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Sotaxwar",
          ["guild"] = "Husk at Crit",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 332244,
          ["ilvl"] = 327,
          ["crit"] = 1419,
          ["haste"] = 739,
          ["mastery"] = 766,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Executemcgee",
          ["guild"] = "Mythicc",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 329329,
          ["ilvl"] = 326,
          ["crit"] = 1277,
          ["haste"] = 1268,
          ["mastery"] = 573,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmZzMzMzgxMDAAAAgZWmZgJMW2GYBMgZYCMD2AzMWGbDsMz2AMzAgZYA"
        },
        {
          ["name"] = "Jaés",
          ["guild"] = "Revoke",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 327466,
          ["ilvl"] = 327,
          ["crit"] = 1391,
          ["haste"] = 1054,
          ["mastery"] = 626,
          ["vers"] = 106,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhxyALzsNAzMAYGGA"
        },
        {
          ["name"] = "Shadovworrio",
          ["guild"] = "Revoke",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 327396,
          ["ilvl"] = 325,
          ["crit"] = 1204,
          ["haste"] = 1073,
          ["mastery"] = 615,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphBzMLLzMzMDzYmBAAAAwMLzMwEGLbDsAGwMMBmBbgZGGbDsMz2AMzAgZYA"
        },
        {
          ["name"] = "Белегард",
          ["guild"] = "У беляша",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 327095,
          ["ilvl"] = 327,
          ["crit"] = 1247,
          ["haste"] = 1222,
          ["mastery"] = 606,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGmZbZmZmZYGzMAAAAAmZZmBmwYZbgFwAmhJwMYDMzwwALzsNAzMAYGGA"
        },
        {
          ["name"] = "Venzèr",
          ["guild"] = "Save The Wife",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 322875,
          ["ilvl"] = 324,
          ["crit"] = 1562,
          ["haste"] = 1259,
          ["mastery"] = 390,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMbmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmx2YZglZ2GgZGAYYA"
        },
        {
          ["name"] = "불라방",
          ["guild"] = "Mate",
          ["boss"] = "Sszorak",
          ["amount"] = 246061,
          ["ilvl"] = 333,
          ["crit"] = 1325,
          ["haste"] = 1097,
          ["mastery"] = 532,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYBMgZYCMD2AzMM2GYZmlBYmBAzwA"
        },
        {
          ["name"] = "Cringewar",
          ["guild"] = "Northern Sky",
          ["boss"] = "Sszorak",
          ["amount"] = 237849,
          ["ilvl"] = 331,
          ["crit"] = 1286,
          ["haste"] = 1016,
          ["mastery"] = 646,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZAhxyyALgBMDTgZwGYmx2YbglZWGgZGAMDDA"
        },
        {
          ["name"] = "Cellezug",
          ["guild"] = "Competence Optional",
          ["boss"] = "Sszorak",
          ["amount"] = 227703,
          ["ilvl"] = 322,
          ["crit"] = 1352,
          ["haste"] = 1209,
          ["mastery"] = 472,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYBMgZYCMD2AzMM2GYZmlBYmBAzwA"
        },
        {
          ["name"] = "Khawarr",
          ["guild"] = "vodka",
          ["boss"] = "Sszorak",
          ["amount"] = 227211,
          ["ilvl"] = 325,
          ["crit"] = 1247,
          ["haste"] = 1130,
          ["mastery"] = 691,
          ["vers"] = 173,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZAhxyyALgBMDTgZwGYmx2YbglZWGgZGAMDDA"
        },
        {
          ["name"] = "Rbwarrior",
          ["guild"] = "Never AFK",
          ["boss"] = "Sszorak",
          ["amount"] = 226946,
          ["ilvl"] = 326,
          ["crit"] = 1302,
          ["haste"] = 1085,
          ["mastery"] = 551,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYBMgZYCMD2AzMM2GYZmlBYmBAzwA"
        },
        {
          ["name"] = "Rauschzip",
          ["guild"] = "Easy Katka",
          ["boss"] = "Sszorak",
          ["amount"] = 226366,
          ["ilvl"] = 326,
          ["crit"] = 1274,
          ["haste"] = 1086,
          ["mastery"] = 724,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZAhxyyAbgBMDTgZwGYmx2YbglZWGgZGAMDDA"
        },
        {
          ["name"] = "Ahrylia",
          ["guild"] = "Reunion",
          ["boss"] = "Sszorak",
          ["amount"] = 225661,
          ["ilvl"] = 326,
          ["crit"] = 1376,
          ["haste"] = 1219,
          ["mastery"] = 537,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZAhxyyALgBMDTgZwGYmx2YbglZWGgZGAMDDA"
        },
        {
          ["name"] = "Furybringer",
          ["guild"] = "Grim",
          ["boss"] = "Sszorak",
          ["amount"] = 224827,
          ["ilvl"] = 326,
          ["crit"] = 1164,
          ["haste"] = 1163,
          ["mastery"] = 728,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYBMgZYCMD2AzMM2GYZmlBYmBAzwA"
        },
        {
          ["name"] = "Recklust",
          ["guild"] = "Cutting Bread",
          ["boss"] = "Sszorak",
          ["amount"] = 224813,
          ["ilvl"] = 326,
          ["crit"] = 1240,
          ["haste"] = 1214,
          ["mastery"] = 601,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYDMgZYCMD2AzMM2GYZmlBYmBAzwA"
        },
        {
          ["name"] = "巃丶",
          ["guild"] = "Scary maze",
          ["boss"] = "Sszorak",
          ["amount"] = 223356,
          ["ilvl"] = 330,
          ["crit"] = 1296,
          ["haste"] = 1017,
          ["mastery"] = 628,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYBMgZYCMD2AzMM2GYZmlBYmBAzwA"
        },
        {
          ["name"] = "Quenellemafé",
          ["guild"] = "Above Average",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 347490,
          ["ilvl"] = 326,
          ["crit"] = 1415,
          ["haste"] = 892,
          ["mastery"] = 608,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Teemù",
          ["guild"] = "Slack",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 344282,
          ["ilvl"] = 325,
          ["crit"] = 1536,
          ["haste"] = 1128,
          ["mastery"] = 443,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Eroka",
          ["guild"] = "Honestly",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 341047,
          ["ilvl"] = 326,
          ["crit"] = 1317,
          ["haste"] = 1229,
          ["mastery"] = 527,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphBzMLLzMzMMzYmBAAAAwMLzMwEGLbDsAGwMMBmBbgZGGLDsMz2AMzAgZYA"
        },
        {
          ["name"] = "Jaés",
          ["guild"] = "Revoke",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 339566,
          ["ilvl"] = 327,
          ["crit"] = 1326,
          ["haste"] = 1173,
          ["mastery"] = 559,
          ["vers"] = 106,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhxyALzsNAzMAYGGA"
        },
        {
          ["name"] = "Illhitu",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 339385,
          ["ilvl"] = 328,
          ["crit"] = 1386,
          ["haste"] = 1116,
          ["mastery"] = 558,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGmxMDAAAAgZWmZgJMW2GYBMgZYCMwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Doomcro",
          ["guild"] = "CMT",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 335933,
          ["ilvl"] = 325,
          ["crit"] = 1423,
          ["haste"] = 1115,
          ["mastery"] = 528,
          ["vers"] = 204,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGmxyMzMzYmxMDAAAAgZWmZgJMW2GYBMgZYCMwGYmhxyALzsNAzMAYGGA"
        },
        {
          ["name"] = "Execussy",
          ["guild"] = "Reckoning",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 333204,
          ["ilvl"] = 326,
          ["crit"] = 1325,
          ["haste"] = 1179,
          ["mastery"] = 555,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmZzMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhxyALzsNAzMAYGGA"
        },
        {
          ["name"] = "巃丶",
          ["guild"] = "Scary maze",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 331338,
          ["ilvl"] = 330,
          ["crit"] = 1296,
          ["haste"] = 1017,
          ["mastery"] = 628,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhxyALzsNAzMAYGGA"
        },
        {
          ["name"] = "Beànz",
          ["guild"] = "Mid Team",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 330420,
          ["ilvl"] = 327,
          ["crit"] = 1294,
          ["haste"] = 1032,
          ["mastery"] = 560,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "雷德尔",
          ["guild"] = "颠倒梦想",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 330333,
          ["ilvl"] = 325,
          ["crit"] = 1330,
          ["haste"] = 990,
          ["mastery"] = 571,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzYmxMDAAAAgZWmZgJMW2GYBMgZYCMwGYmhxyALzsNAzMAYGGA"
        },
        {
          ["name"] = "Cringewar",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 273286,
          ["ilvl"] = 331,
          ["crit"] = 1286,
          ["haste"] = 1016,
          ["mastery"] = 646,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "巃丶",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 254715,
          ["ilvl"] = 331,
          ["crit"] = 1495,
          ["haste"] = 958,
          ["mastery"] = 510,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzwMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Apook",
          ["guild"] = "Infinity",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 250948,
          ["ilvl"] = 327,
          ["crit"] = 1272,
          ["haste"] = 1180,
          ["mastery"] = 657,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphBzMWmZmZGzMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Peraa",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 247643,
          ["ilvl"] = 327,
          ["crit"] = 1322,
          ["haste"] = 1165,
          ["mastery"] = 594,
          ["vers"] = 192,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphBzMLLzMzMjZGzMAAAAAmZZmBmwYZbgFwAmhJwMYDMzwYbglZ2GgZGAYYA"
        },
        {
          ["name"] = "Ptz",
          ["guild"] = "Ethical",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 245411,
          ["ilvl"] = 327,
          ["crit"] = 1258,
          ["haste"] = 1016,
          ["mastery"] = 852,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphBzMLLzMzMDzYmBAAAAwMLzMwEGLbDsAGwMMBmBbgZGGbDsMz2AMzAgZYA"
        },
        {
          ["name"] = "Sêvj",
          ["guild"] = "Quichons",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 243446,
          ["ilvl"] = 327,
          ["crit"] = 1430,
          ["haste"] = 1171,
          ["mastery"] = 506,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMz8AmZGAAAghphZYmxyMzMzwMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Alorani",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 241339,
          ["ilvl"] = 327,
          ["crit"] = 1421,
          ["haste"] = 1256,
          ["mastery"] = 458,
          ["vers"] = 16,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMz8AmZGAAAghphBzMWmZmZGzMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Shamiwarr",
          ["guild"] = "Fragglene",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 237220,
          ["ilvl"] = 327,
          ["crit"] = 1237,
          ["haste"] = 1109,
          ["mastery"] = 550,
          ["vers"] = 135,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFz8AmZGAAAghphBzMbLzMzMjZGzMAAAAAmZZmBmwYZZgFwAmhJwMYDMzwwALzsNAzMAYGGA"
        },
        {
          ["name"] = "Eroka",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 236868,
          ["ilvl"] = 326,
          ["crit"] = 1317,
          ["haste"] = 1229,
          ["mastery"] = 527,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphBzMLLzMzMMzYmBAAAAwMLzMwEGLbDsAGwMMBmBbgZGGbDsMz2AMzAgZYA"
        },
        {
          ["name"] = "Illhitu",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 235591,
          ["ilvl"] = 326,
          ["crit"] = 1375,
          ["haste"] = 1180,
          ["mastery"] = 497,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphBzMLLzMzMDzYmBAAAAwMLzMwEGLbDsAGwMMBmBbgZGGbDsMz2AMzAgZYA"
        },
        {
          ["name"] = "Eroka",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 420707,
          ["ilvl"] = 331,
          ["crit"] = 1403,
          ["haste"] = 1252,
          ["mastery"] = 532,
          ["vers"] = 1370,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZYmZbZmZmZwYmBAAAAwYZmBmwYZbgFwAmhJwMYDMzwYbwsMz2AMzAgZYA"
        },
        {
          ["name"] = "Karash",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 333625,
          ["ilvl"] = 327,
          ["crit"] = 1311,
          ["haste"] = 1175,
          ["mastery"] = 622,
          ["vers"] = 1390,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZYmxyMzMzwMmZAAAAAMWmZgJMW2GYBMgZYCMD2AzMM2GMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Rylon",
          ["guild"] = "Average Pillagers",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 251491,
          ["ilvl"] = 324,
          ["crit"] = 1288,
          ["haste"] = 1049,
          ["mastery"] = 553,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMbLzMzMDGzMAAAAAmZZmBmwYbZgFwAmhJwMYDMzwwALzsNAzMAYGGA"
        },
        {
          ["name"] = "불라방",
          ["guild"] = "Mate",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 250609,
          ["ilvl"] = 332,
          ["crit"] = 1461,
          ["haste"] = 1097,
          ["mastery"] = 532,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZYmZbZmZmZwYmBAAAAwMLzMwEGLLDsAGwMMBmBbgZGGbDsMz2AMzAgZYA"
        },
        {
          ["name"] = "Eroka",
          ["guild"] = "Honestly",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 245762,
          ["ilvl"] = 331,
          ["crit"] = 1403,
          ["haste"] = 1252,
          ["mastery"] = 532,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZYmZbZmZmZwYmBAAAAwYZmBmwYZbgFwAmhJwMYDMzwYbwsMz2AMzAgZYA"
        },
        {
          ["name"] = "希仑",
          ["guild"] = "炉火糖粥",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 243481,
          ["ilvl"] = 327,
          ["crit"] = 1437,
          ["haste"] = 912,
          ["mastery"] = 677,
          ["vers"] = 167,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMz8AmZGAAAghphZYmxyMzMzwMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Illhitu",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 243450,
          ["ilvl"] = 328,
          ["crit"] = 1386,
          ["haste"] = 1116,
          ["mastery"] = 558,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Jimboslicee",
          ["guild"] = "Idiot",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 241803,
          ["ilvl"] = 320,
          ["crit"] = 1309,
          ["haste"] = 1096,
          ["mastery"] = 529,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFz8AmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxyyALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Jamesw",
          ["guild"] = "Yseras Dream",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 240794,
          ["ilvl"] = 322,
          ["crit"] = 1324,
          ["haste"] = 901,
          ["mastery"] = 633,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFz8AmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "Chuprage",
          ["guild"] = "Literacy Test",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 237150,
          ["ilvl"] = 325,
          ["crit"] = 1229,
          ["haste"] = 1166,
          ["mastery"] = 497,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphZYmxyMzMzwMmZAAAAAMWmZgJMW2GYBMgZYCMD2AzMM2GMLzsNAzMAYGGA"
        },
        {
          ["name"] = "Zisseria",
          ["guild"] = "Diabolica",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 236395,
          ["ilvl"] = 320,
          ["crit"] = 1222,
          ["haste"] = 1084,
          ["mastery"] = 656,
          ["vers"] = 108,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTgZwGYmhx2ALzsNAzMAYGGA"
        },
        {
          ["name"] = "골딱",
          ["guild"] = "구 데 기",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 235195,
          ["ilvl"] = 322,
          ["crit"] = 1299,
          ["haste"] = 964,
          ["mastery"] = 597,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFz8AmZGAAAghphxYmZbZmZmZYGzMAAAAAmZZmBmwYZZgFwAmhJwMYDMzwwALzsNAzMAYGGA"
        }
      }
    },
    {
      ["spec"] = "Fury",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Sotaxwar",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 240576,
          ["ilvl"] = 321,
          ["crit"] = 1042,
          ["haste"] = 1282,
          ["mastery"] = 888,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMzMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Ménelia",
          ["guild"] = "OKIDOR",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 218195,
          ["ilvl"] = 325,
          ["crit"] = 1096,
          ["haste"] = 1233,
          ["mastery"] = 727,
          ["vers"] = 293,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZYMzMzMzYmlZMmZmZzMzMAAQMW2GYBMgZYCMDbAzMbGbAAwMDjxwYwYA"
        },
        {
          ["name"] = "Dedidetwo",
          ["guild"] = "Somali Yacht Club",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 214285,
          ["ilvl"] = 324,
          ["crit"] = 950,
          ["haste"] = 1046,
          ["mastery"] = 954,
          ["vers"] = 359,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMzMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Baldloser",
          ["guild"] = "Calamity",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 212931,
          ["ilvl"] = 313,
          ["crit"] = 701,
          ["haste"] = 1205,
          ["mastery"] = 1201,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 249342,
              ["name"] = "Heart of Ancient Hunger",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmxYmxsZmZGAAIGLbDsAGwMMBmhNgZGGAAgZGGzywYwYA"
        },
        {
          ["name"] = "Bigbowwl",
          ["guild"] = "Afro Ninjas",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 212873,
          ["ilvl"] = 323,
          ["crit"] = 898,
          ["haste"] = 922,
          ["mastery"] = 1183,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Rampagebonk",
          ["guild"] = "Ascendance",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 212010,
          ["ilvl"] = 327,
          ["crit"] = 851,
          ["haste"] = 1142,
          ["mastery"] = 1240,
          ["vers"] = 51,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZmZmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Ентил",
          ["guild"] = "Фрактал",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 211315,
          ["ilvl"] = 323,
          ["crit"] = 1009,
          ["haste"] = 1021,
          ["mastery"] = 1115,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMzMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Dripzi",
          ["guild"] = "really bro",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 209873,
          ["ilvl"] = 325,
          ["crit"] = 1031,
          ["haste"] = 857,
          ["mastery"] = 1035,
          ["vers"] = 285,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmxYmZmNzMzAAAxYZbgFwAmhJwMsBMzwAAAMzwYMMGMG"
        },
        {
          ["name"] = "Riggs",
          ["guild"] = "A Little Bit Sweaty",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 209349,
          ["ilvl"] = 326,
          ["crit"] = 994,
          ["haste"] = 1146,
          ["mastery"] = 1163,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmxYmxsZmZGAAIGLbDsAGwMMBmhNgZGGAAgZGGzywYwYA"
        },
        {
          ["name"] = "Dasherz",
          ["guild"] = "Bog",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 208593,
          ["ilvl"] = 325,
          ["crit"] = 1334,
          ["haste"] = 1012,
          ["mastery"] = 835,
          ["vers"] = 175,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmxYmxsZmZGAAIGLbDsAGwMMBmhNgZGGAAgZGGzywYwYA"
        },
        {
          ["name"] = "Vvizion",
          ["guild"] = "Mean Girls",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 207217,
          ["ilvl"] = 325,
          ["crit"] = 849,
          ["haste"] = 1224,
          ["mastery"] = 1226,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMz2yMzMzMzMmZmZmZMzyMGzMmNzMzAAAxYZbgFwAmhJwMsBMzwAAAMzwYWGYwYA"
        },
        {
          ["name"] = "Nísso",
          ["guild"] = "Gibb",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 202731,
          ["ilvl"] = 323,
          ["crit"] = 825,
          ["haste"] = 1215,
          ["mastery"] = 1220,
          ["vers"] = 42,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZYMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmZzYDAAmZYMLDjBjB"
        },
        {
          ["name"] = "Bráveheart",
          ["guild"] = "Odyns Chosen",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198004,
          ["ilvl"] = 323,
          ["crit"] = 524,
          ["haste"] = 1308,
          ["mastery"] = 1354,
          ["vers"] = 221,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMgZYCMDbAzMM2AAgZGGzywYwYA"
        },
        {
          ["name"] = "Dripzi",
          ["guild"] = "really bro",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 196946,
          ["ilvl"] = 325,
          ["crit"] = 1031,
          ["haste"] = 857,
          ["mastery"] = 1035,
          ["vers"] = 285,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZmZmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Josephjs",
          ["guild"] = "Awakeníng",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 194498,
          ["ilvl"] = 326,
          ["crit"] = 1178,
          ["haste"] = 1068,
          ["mastery"] = 1057,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZWWmZmZmxMmZmZmZmZWmxYmxsZmZGAAIGLbDsAGwMMBmhNgZGGAAgZGGjBGMG"
        },
        {
          ["name"] = "Kratos",
          ["guild"] = "Noctis",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 193916,
          ["ilvl"] = 326,
          ["crit"] = 901,
          ["haste"] = 1069,
          ["mastery"] = 1283,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZmZmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Zuo",
          ["guild"] = "Odyssey",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 193835,
          ["ilvl"] = 324,
          ["crit"] = 678,
          ["haste"] = 1103,
          ["mastery"] = 1222,
          ["vers"] = 212,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZYMzMzMzYmlZMmZmZzMzMAAQMW2GYDMgZYCMDbAzMbGbAAwMDjxwYwYA"
        },
        {
          ["name"] = "Baldloser",
          ["guild"] = "Calamity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 191920,
          ["ilvl"] = 324,
          ["crit"] = 916,
          ["haste"] = 1329,
          ["mastery"] = 969,
          ["vers"] = 256,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMjZMzMzMzYmlZmxMjZzMzMAAQMW2GYDMgZYCMDbAzMMAAAzMMGDjBjB"
        },
        {
          ["name"] = "Justlovers",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 191910,
          ["ilvl"] = 321,
          ["crit"] = 821,
          ["haste"] = 1027,
          ["mastery"] = 1229,
          ["vers"] = 210,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzwMjlZmZmZYMzMzMzYmlZmxMjZzMzMAAQMW2GYBMgZYCMDbAzMLGbAAwMDjxwYwYA"
        },
        {
          ["name"] = "Cosaint",
          ["guild"] = "Ethereal",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 188596,
          ["ilvl"] = 323,
          ["crit"] = 644,
          ["haste"] = 1189,
          ["mastery"] = 1442,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmxYmZmNzMzAAAxYZbgFwAmhJwMsBMzwAAAMzwYMMGMG"
        },
        {
          ["name"] = "Anwaban",
          ["guild"] = "Two Day Raiding Guild",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 347109,
          ["ilvl"] = 324,
          ["crit"] = 1035,
          ["haste"] = 1042,
          ["mastery"] = 928,
          ["vers"] = 394,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYDMgZYCMDbAzMM2AAgZGGzywYwYA"
        },
        {
          ["name"] = "Executemcgee",
          ["guild"] = "Mythicc",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 346718,
          ["ilvl"] = 326,
          ["crit"] = 1405,
          ["haste"] = 1133,
          ["mastery"] = 738,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmhBAAYmhxsMMGMG"
        },
        {
          ["name"] = "Josephjs",
          ["guild"] = "Awakeníng",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 346115,
          ["ilvl"] = 326,
          ["crit"] = 1098,
          ["haste"] = 1025,
          ["mastery"] = 1127,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZWWmZmZmxMmZmZmZmZWmxYmxsZmZGAAIGLbDsAGwMMBmhNgZGGAAgZGGjBGMG"
        },
        {
          ["name"] = "山野望月丶",
          ["guild"] = "时间",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 330254,
          ["ilvl"] = 325,
          ["crit"] = 1134,
          ["haste"] = 1254,
          ["mastery"] = 696,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmxYmxsZmZGAAIGLbDsAGwMMBmhNgZGGAAgZGGzywYwYA"
        },
        {
          ["name"] = "Cosaint",
          ["guild"] = "Ethereal",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 329007,
          ["ilvl"] = 323,
          ["crit"] = 644,
          ["haste"] = 1189,
          ["mastery"] = 1442,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmxYmxsZmZGAAIGLbDsAGwMMBmhNgZGGAAgZGGzywYwYA"
        },
        {
          ["name"] = "Dripzi",
          ["guild"] = "really bro",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327728,
          ["ilvl"] = 325,
          ["crit"] = 1031,
          ["haste"] = 857,
          ["mastery"] = 1035,
          ["vers"] = 285,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZmZmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Fredone",
          ["guild"] = "Kirkland Signature",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327723,
          ["ilvl"] = 325,
          ["crit"] = 772,
          ["haste"] = 1227,
          ["mastery"] = 1245,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmxYmxsZmZGAAIGLbDsAGwMMBmhNgZGGAAgZGGzywYwYA"
        },
        {
          ["name"] = "将王丶将至",
          ["guild"] = "Knowledge is Power",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327676,
          ["ilvl"] = 321,
          ["crit"] = 687,
          ["haste"] = 1120,
          ["mastery"] = 1233,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMgZYCMDbAzMM2AAgZGGzywYwYA"
        },
        {
          ["name"] = "Zemial",
          ["guild"] = "Handle It",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 324751,
          ["ilvl"] = 323,
          ["crit"] = 649,
          ["haste"] = 1129,
          ["mastery"] = 1283,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMjlZmZmZMzMzMzMzYmlZMmZMbmZmBAAixy2AbgBMDTgZYDwMM2AAgZGGzywYwYA"
        },
        {
          ["name"] = "Faris",
          ["guild"] = "Odyssey",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 324550,
          ["ilvl"] = 318,
          ["crit"] = 1024,
          ["haste"] = 1425,
          ["mastery"] = 851,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzwMz2yMzMzMMmZmZmZMzyMGzMmNzMzAAAxYZbgFwAmhJwMsBMzwYDAAmZYMLDjBjB"
        },
        {
          ["name"] = "Kratos",
          ["guild"] = "Noctis",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 262362,
          ["ilvl"] = 325,
          ["crit"] = 900,
          ["haste"] = 1069,
          ["mastery"] = 1346,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZmZmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Dripzi",
          ["guild"] = "really bro",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 252354,
          ["ilvl"] = 327,
          ["crit"] = 1034,
          ["haste"] = 857,
          ["mastery"] = 1047,
          ["vers"] = 291,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZmZmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Baldloser",
          ["guild"] = "Calamity",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 249568,
          ["ilvl"] = 324,
          ["crit"] = 916,
          ["haste"] = 1329,
          ["mastery"] = 969,
          ["vers"] = 256,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMjZMzMzMzYmlZmxMjZzMzMAAQMW2GYDMgZYCMDbAzMMAAAzMMGDjBjB"
        },
        {
          ["name"] = "Faris",
          ["guild"] = "Odyssey",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 248894,
          ["ilvl"] = 326,
          ["crit"] = 1130,
          ["haste"] = 1342,
          ["mastery"] = 692,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzwMz2yMzMzMMmZmZmZMzyMGzMzsZmZGAAIGLbDsAGwMMBmhNgZGGbAAwMDjxwYwYA"
        },
        {
          ["name"] = "Ентил",
          ["guild"] = "Фрактал",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 246027,
          ["ilvl"] = 324,
          ["crit"] = 1136,
          ["haste"] = 984,
          ["mastery"] = 1194,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMzMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Krenna",
          ["guild"] = "Women of Azeroth",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 244951,
          ["ilvl"] = 321,
          ["crit"] = 810,
          ["haste"] = 1087,
          ["mastery"] = 1223,
          ["vers"] = 199,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMz2yMzMzMzMmZmZmZMzyMGzMmNzMzAAAxYZbgFwAmhJwMsBMzwAAAMzwYWGYwYA"
        },
        {
          ["name"] = "Lexaeus",
          ["guild"] = "Mid Tier Crisis",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 238850,
          ["ilvl"] = 324,
          ["crit"] = 681,
          ["haste"] = 955,
          ["mastery"] = 1240,
          ["vers"] = 354,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Nekowarr",
          ["guild"] = "Justify",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 238514,
          ["ilvl"] = 325,
          ["crit"] = 712,
          ["haste"] = 1193,
          ["mastery"] = 1316,
          ["vers"] = 225,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzwMzyyMzMzMmxMzMzMjZWmxYmZmNzMzAAAxYZbgFwAmhJwMsBMzwAAAMzwYMMGMG"
        },
        {
          ["name"] = "Cosaint",
          ["guild"] = "Ethereal",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 236833,
          ["ilvl"] = 323,
          ["crit"] = 644,
          ["haste"] = 1189,
          ["mastery"] = 1442,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmxYmZmNzMzAAAxYZbgFwAmhJwMsBMzwAAAMzwYMMGMG"
        },
        {
          ["name"] = "Vvizion",
          ["guild"] = "Mean Girls",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 236586,
          ["ilvl"] = 325,
          ["crit"] = 747,
          ["haste"] = 1180,
          ["mastery"] = 1277,
          ["vers"] = 296,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMz2yMzMzMzMmZmZmZMzyMGzMmNzMzAAAxYZbgFwAmhJwMsBMzwAAAMzwYWGYwYA"
        },
        {
          ["name"] = "Sotaxwar",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Sszorak",
          ["amount"] = 231467,
          ["ilvl"] = 327,
          ["crit"] = 1105,
          ["haste"] = 1223,
          ["mastery"] = 964,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Womitx",
          ["guild"] = "Ad Elysium",
          ["boss"] = "Sszorak",
          ["amount"] = 217857,
          ["ilvl"] = 327,
          ["crit"] = 1185,
          ["haste"] = 1191,
          ["mastery"] = 777,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Kratos",
          ["guild"] = "Noctis",
          ["boss"] = "Sszorak",
          ["amount"] = 217300,
          ["ilvl"] = 326,
          ["crit"] = 901,
          ["haste"] = 1069,
          ["mastery"] = 1283,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Warriorvel",
          ["guild"] = "Unrivaled",
          ["boss"] = "Sszorak",
          ["amount"] = 215559,
          ["ilvl"] = 324,
          ["crit"] = 1263,
          ["haste"] = 1035,
          ["mastery"] = 814,
          ["vers"] = 217,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Faris",
          ["guild"] = "Odyssey",
          ["boss"] = "Sszorak",
          ["amount"] = 214295,
          ["ilvl"] = 326,
          ["crit"] = 1130,
          ["haste"] = 1342,
          ["mastery"] = 692,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzwMz2yMzMzMMmZmZMzMzyMzYmZmNjZGAAIGLbDsAGwMMBmhNgZGGbAAwMDjxwYwYA"
        },
        {
          ["name"] = "Bigbowwl",
          ["guild"] = "Afro Ninjas",
          ["boss"] = "Sszorak",
          ["amount"] = 213808,
          ["ilvl"] = 326,
          ["crit"] = 833,
          ["haste"] = 991,
          ["mastery"] = 1363,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgBMDTgZYDYmZzAAAMzwYMMGMG"
        },
        {
          ["name"] = "Rosswarrior",
          ["guild"] = "Rhythm",
          ["boss"] = "Sszorak",
          ["amount"] = 213146,
          ["ilvl"] = 327,
          ["crit"] = 1114,
          ["haste"] = 1305,
          ["mastery"] = 629,
          ["vers"] = 255,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "오크전사가짱이지",
          ["guild"] = "Ori",
          ["boss"] = "Sszorak",
          ["amount"] = 213120,
          ["ilvl"] = 323,
          ["crit"] = 1221,
          ["haste"] = 1214,
          ["mastery"] = 846,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Давунша",
          ["guild"] = "Скагглсок",
          ["boss"] = "Sszorak",
          ["amount"] = 212917,
          ["ilvl"] = 322,
          ["crit"] = 969,
          ["haste"] = 988,
          ["mastery"] = 2820,
          ["vers"] = -13,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Ovenproof",
          ["guild"] = "Functional",
          ["boss"] = "Sszorak",
          ["amount"] = 212247,
          ["ilvl"] = 324,
          ["crit"] = 1040,
          ["haste"] = 1306,
          ["mastery"] = 910,
          ["vers"] = 148,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgBMDTgZYDYmZzAAAMzwYMMGMG"
        },
        {
          ["name"] = "Kratos",
          ["guild"] = "Noctis",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 268370,
          ["ilvl"] = 326,
          ["crit"] = 901,
          ["haste"] = 1069,
          ["mastery"] = 1283,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMjZMzMzMzMzsMjxMjZzMzMAAQMW2GYBMgZYCMYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Sotaxwar",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 264755,
          ["ilvl"] = 327,
          ["crit"] = 1009,
          ["haste"] = 1285,
          ["mastery"] = 862,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMz2yMzMzMmxMzMzMjZWmxYmZmNzMzAAAxYZbgFwAmhJwMsBMzsZAAAmZYMGYwYA"
        },
        {
          ["name"] = "Dripzi",
          ["guild"] = "really bro",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 239048,
          ["ilvl"] = 325,
          ["crit"] = 1031,
          ["haste"] = 857,
          ["mastery"] = 1035,
          ["vers"] = 285,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMz2yMzMzMmxMzMzMjZWmxYmZmNzMzAAAxYZbgFwAmhJwMsBMzsZAAAmZYMGYwYA"
        },
        {
          ["name"] = "Sweetwarr",
          ["guild"] = "Энивей",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 235595,
          ["ilvl"] = 323,
          ["crit"] = 1115,
          ["haste"] = 1164,
          ["mastery"] = 945,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzMzsMjxMjZzMzMAAQMW2GYBMgZYCMDbAzMbGAAgZGGjBGMG"
        },
        {
          ["name"] = "Kratos",
          ["guild"] = "Noctis",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 234791,
          ["ilvl"] = 325,
          ["crit"] = 900,
          ["haste"] = 1069,
          ["mastery"] = 1280,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZmZmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Nekowarr",
          ["guild"] = "Justify",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 229090,
          ["ilvl"] = 320,
          ["crit"] = 712,
          ["haste"] = 1144,
          ["mastery"] = 1217,
          ["vers"] = 293,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzyyMzMzMmxMzMzMjZWmxYmZmNzMzAAAxYZbgFwAmhJwMsBMzwAAAMzwYMMGMG"
        },
        {
          ["name"] = "Ентил",
          ["guild"] = "Фрактал",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 227747,
          ["ilvl"] = 324,
          ["crit"] = 1136,
          ["haste"] = 984,
          ["mastery"] = 1194,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMzMmZMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Amp",
          ["guild"] = "Cursed",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 227654,
          ["ilvl"] = 325,
          ["crit"] = 1100,
          ["haste"] = 1007,
          ["mastery"] = 2887,
          ["vers"] = -121,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZYMzMzMzYmlZMmZmZzMzMAAQMW2GYBMgZYCMDbAzMbGbAAwMDjxwYwYA"
        },
        {
          ["name"] = "Aräthor",
          ["guild"] = "Ritual",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 227624,
          ["ilvl"] = 322,
          ["crit"] = 685,
          ["haste"] = 989,
          ["mastery"] = 1207,
          ["vers"] = 469,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMgZYCMDbAzMM2AAgZGGzywYwYA"
        },
        {
          ["name"] = "Rampagebonk",
          ["guild"] = "Ascendance",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 227323,
          ["ilvl"] = 327,
          ["crit"] = 851,
          ["haste"] = 1142,
          ["mastery"] = 1240,
          ["vers"] = 51,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZsMzMzMDjZmZmZmZmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
        },
        {
          ["name"] = "Baldloser",
          ["guild"] = "Calamity",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 226871,
          ["ilvl"] = 321,
          ["crit"] = 809,
          ["haste"] = 1356,
          ["mastery"] = 1043,
          ["vers"] = 256,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2WmZmZmhxMzMzMjZWmZGzMmNzMzAAAxYZbgNwAmhJwMsBMzwAAAMzwYMMGMG"
        }
      }
    },
    {
      ["spec"] = "Protection",
      ["role"] = "tank",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Scv",
          ["guild"] = "Midgard",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 129514,
          ["ilvl"] = 324,
          ["crit"] = 1317,
          ["haste"] = 1142,
          ["mastery"] = 427,
          ["vers"] = 71,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMmZ2mxsMMGz0wYGLzMzMDGzMAAAAYZAYGDAsZGDbwAzwCNmZhxMMDzsBAYmBAYgxA"
        },
        {
          ["name"] = "Adian",
          ["guild"] = "Tempest",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 126385,
          ["ilvl"] = 324,
          ["crit"] = 1214,
          ["haste"] = 1052,
          ["mastery"] = 501,
          ["vers"] = 362,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMjxYmGGDLzMzMDGzMAAAAYZAYGDAsZGDbwAzwCNmZBmxMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Lehdan",
          ["guild"] = "The Cold North",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 125828,
          ["ilvl"] = 321,
          ["crit"] = 882,
          ["haste"] = 1115,
          ["mastery"] = 435,
          ["vers"] = 624,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGz0wMzYZmZmZAzMAAAAYZAYGDAsYGDbwAzwCNmZhxMMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Kirros",
          ["guild"] = "Group Finders Guide",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 123258,
          ["ilvl"] = 322,
          ["crit"] = 737,
          ["haste"] = 1038,
          ["mastery"] = 943,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMjZmZmZGz2MGDjxMNMmxyYmZGzMmZAAAAwyAwMGgB2glFjGzAYWwMbMmhZYmNAYmBAAgxA"
        },
        {
          ["name"] = "Boblecoque",
          ["guild"] = "OBSCURE REFERENCE",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 122389,
          ["ilvl"] = 322,
          ["crit"] = 1457,
          ["haste"] = 651,
          ["mastery"] = 842,
          ["vers"] = 204,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGzMz2MmlhxYmmxYmtlZmZmBMzAAAAglBgZMAwiZMsBDMDL0YmFYGzgZAAYmBAYgxA"
        },
        {
          ["name"] = "韩青山",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 120239,
          ["ilvl"] = 324,
          ["crit"] = 1097,
          ["haste"] = 1392,
          ["mastery"] = 553,
          ["vers"] = 43,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGzY2MmlZMGjGmZstMzMzMYMzAAAAglxAMjBYgNYZxoxMAmNMzGMjZGMAgZGAAmBGD"
        },
        {
          ["name"] = "Enàver",
          ["guild"] = "Nilumi",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 120226,
          ["ilvl"] = 322,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["potion"] = nil,
          ["talents"] = ""
        },
        {
          ["name"] = "Invictusrage",
          ["guild"] = "Honorbound",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 119260,
          ["ilvl"] = 320,
          ["crit"] = 1120,
          ["haste"] = 1337,
          ["mastery"] = 329,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGmZ2mxsMMGjGmZstMzMzMYMzAAAAglBgZMAwiZMsBDMDL0YmFGzYmBDAAzMAgZgxA"
        },
        {
          ["name"] = "Vildie",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 118909,
          ["ilvl"] = 325,
          ["crit"] = 1093,
          ["haste"] = 1309,
          ["mastery"] = 172,
          ["vers"] = 595,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzMzmxsMMGz0wMDLzMzMDYmBAAAALDAzYAGYD2WMaMDgZDzsxYGzMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Zê",
          ["guild"] = "Swamp Animals",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 118771,
          ["ilvl"] = 322,
          ["crit"] = 1081,
          ["haste"] = 887,
          ["mastery"] = 708,
          ["vers"] = 390,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzMz2MmlhxYmGmZstMzMzMgZGAAAAsMAMjBA2MjhNYgZYhGzswwYmBzGAgZGAwAGD"
        },
        {
          ["name"] = "Zê",
          ["guild"] = "Swamp Animals",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 138088,
          ["ilvl"] = 322,
          ["crit"] = 1081,
          ["haste"] = 887,
          ["mastery"] = 708,
          ["vers"] = 390,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzMz2MmlhxYmGmZmtlZmZmBMzAAAAglBgZMAwmZMsBDMDL0YmFGGmhZ2AAMzAAAGD"
        },
        {
          ["name"] = "Adian",
          ["guild"] = "Tempest",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 120729,
          ["ilvl"] = 324,
          ["crit"] = 1214,
          ["haste"] = 1052,
          ["mastery"] = 501,
          ["vers"] = 362,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMjxYmGGDLzMzMDGzMAAAAYZAYGDAsZGDbwAzwCNmZBmxMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Spanra",
          ["guild"] = "Raize",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 120283,
          ["ilvl"] = 323,
          ["crit"] = 1205,
          ["haste"] = 1069,
          ["mastery"] = 311,
          ["vers"] = 417,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMz2MmlhxY0wMjtlZmZmBjZGAAAAsMAMjBA2MjhNYgZYhGzsAzYmBDAAzMAgZgxA"
        },
        {
          ["name"] = "Aycé",
          ["guild"] = "Distorted",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 118707,
          ["ilvl"] = 325,
          ["crit"] = 950,
          ["haste"] = 1724,
          ["mastery"] = 293,
          ["vers"] = 218,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGmZ2mxsMMGjGmZmtlZmZmBjZGAAAAsNAMjBA2MjhNYgZYhGzswYGmBDAAzMAgZgxA"
        },
        {
          ["name"] = "Stamba",
          ["guild"] = "ÆVUM",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 112300,
          ["ilvl"] = 323,
          ["crit"] = 768,
          ["haste"] = 1375,
          ["mastery"] = 336,
          ["vers"] = 514,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MzsMMGjGmZYZmZmZwYmBAAAALjBYGDwAbwyiRjZAMbYmNYGzMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Havì",
          ["guild"] = "Ashen",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 110489,
          ["ilvl"] = 322,
          ["crit"] = 1119,
          ["haste"] = 1017,
          ["mastery"] = 432,
          ["vers"] = 516,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGzY2MmlhxY0MGzYZmZmZwYmBAAAALjBYGDAsZGDLwAzwCNmZBzMmZYsBAYmBAYgxA"
        },
        {
          ["name"] = "Sesame",
          ["guild"] = "BGW",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 108543,
          ["ilvl"] = 324,
          ["crit"] = 1250,
          ["haste"] = 1177,
          ["mastery"] = 454,
          ["vers"] = 253,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGzMzmxsMMGz0wMDLzMzMDGzMAAAAYZAYGDAsYGDbwAzwCNmZhxMmZwsBAYmBAMgxA"
        },
        {
          ["name"] = "Guthezzo",
          ["guild"] = "Dsylxeic",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 108531,
          ["ilvl"] = 323,
          ["crit"] = 871,
          ["haste"] = 1250,
          ["mastery"] = 515,
          ["vers"] = 333,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MmlZMGjGmZYZmZmZwYmBAAAALjBYGDwAbwyiRjZAMbYmNYGzMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Vildie",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 107199,
          ["ilvl"] = 325,
          ["crit"] = 1093,
          ["haste"] = 1309,
          ["mastery"] = 172,
          ["vers"] = 595,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzMzmxsMMGz0wMDLzMzMDYmBAAAALDAzYAGYD2WMaMDgZDzsxYGzMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Simres",
          ["guild"] = "Epilogue",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 106649,
          ["ilvl"] = 324,
          ["crit"] = 977,
          ["haste"] = 1512,
          ["mastery"] = 283,
          ["vers"] = 296,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZmxMzMmxsZmZZGjxohZGWmZmZGMmZAAAAwyMDwMGgB2glFjGzAYWwMbwwMDmNAYmBAgZgxA"
        },
        {
          ["name"] = "Havì",
          ["guild"] = "Ashen",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 185509,
          ["ilvl"] = 319,
          ["crit"] = 954,
          ["haste"] = 1167,
          ["mastery"] = 338,
          ["vers"] = 420,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMz2MGDjxoZMmxyMzMzgxMDAAAAWGDwMGAYzMGWgBmhFaMzCMjZGGbAAmZAAGYMA"
        },
        {
          ["name"] = "Boblecoque",
          ["guild"] = "OBSCURE REFERENCE",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 183921,
          ["ilvl"] = 324,
          ["crit"] = 1195,
          ["haste"] = 849,
          ["mastery"] = 745,
          ["vers"] = 402,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1234969,
            ["name"] = "Ethereal Augmentation"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MzsMMGjGmZmtlZmZmBjZGAAAAsMGgZMADsBbLGNmBwshZ2gZYGmBAMzAAgBGD"
        },
        {
          ["name"] = "Nonskillwar",
          ["guild"] = "Вечный Сон \"Ловец Снов\"",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 174644,
          ["ilvl"] = 324,
          ["crit"] = 867,
          ["haste"] = 1180,
          ["mastery"] = 772,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MmlhxY0YmZYZmZmZYYmBAAAALjBYGDwAbwyiRjZAMbYmNYmZmBzCAMzAAwAGD"
        },
        {
          ["name"] = "Vercetorix",
          ["guild"] = "Saddle Club",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 174573,
          ["ilvl"] = 322,
          ["crit"] = 1148,
          ["haste"] = 992,
          ["mastery"] = 660,
          ["vers"] = 285,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MzsMjxY0wMDLzMzMDGzMAAAAYZAYGDwAbw2iRjZAMbYmNYGzMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Emwar",
          ["guild"] = "Cosmik",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 174559,
          ["ilvl"] = 322,
          ["crit"] = 716,
          ["haste"] = 1520,
          ["mastery"] = 523,
          ["vers"] = 173,
          ["trinkets"] = {
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzY2MmlZMGjGmZsZmZmZYGzMAAAAYZMAzYAGYDWWMaMDgZBzsBzYmBzGAMzAAwAGD"
        },
        {
          ["name"] = "Dimarco",
          ["guild"] = "Cognizant",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 170817,
          ["ilvl"] = 321,
          ["crit"] = 1029,
          ["haste"] = 1152,
          ["mastery"] = 876,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MmlZMGjmxYYZmZmZwYmBAAAALjBYGDwAbwyiRjZAMLYmNYGzMY2AgZGAAmBGD"
        },
        {
          ["name"] = "규딘",
          ["guild"] = "유랑단",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 170653,
          ["ilvl"] = 321,
          ["crit"] = 1343,
          ["haste"] = 1326,
          ["mastery"] = 293,
          ["vers"] = 130,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzY2MmlZMGjGmZGLzMzMDGzMAAAAYZMAzYAGYD2WMaMDgZDzsBzwMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Argo",
          ["guild"] = "Decidedly Uncouth",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 169673,
          ["ilvl"] = 322,
          ["crit"] = 940,
          ["haste"] = 1376,
          ["mastery"] = 399,
          ["vers"] = 371,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MmlZMGjGmZstMzMzMMMzAAAAglxAMjBYgNYbxoxMAmNMzGMjZGMAgZGAAmBGD"
        },
        {
          ["name"] = "Sense",
          ["guild"] = "Nurfed",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 169179,
          ["ilvl"] = 324,
          ["crit"] = 866,
          ["haste"] = 1091,
          ["mastery"] = 837,
          ["vers"] = 355,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MmlZMGjGmZstMzMzMMMzAAAAglxAMjBYgNYbxoxMAmNMzGMjZGMAgZGAAmBGD"
        },
        {
          ["name"] = "Spanra",
          ["guild"] = "Raize",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 167959,
          ["ilvl"] = 321,
          ["crit"] = 1196,
          ["haste"] = 958,
          ["mastery"] = 337,
          ["vers"] = 432,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGjGmZstMzMzMYMzAAAAglBgZMAwmZMsBDMDL0YmFGzYmBDAAzMAgZgxA"
        },
        {
          ["name"] = "Spanra",
          ["guild"] = "Raize",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 149332,
          ["ilvl"] = 323,
          ["crit"] = 1040,
          ["haste"] = 1234,
          ["mastery"] = 311,
          ["vers"] = 417,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1234969,
            ["name"] = "Ethereal Augmentation"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzMz2MmlhxYmGGjtlZmZmBjZGAAAAsMAMjBYgNYZxoxMAmNMzGMjZGMAgZGAAmBGD"
        },
        {
          ["name"] = "Adian",
          ["guild"] = "Tempest",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 147656,
          ["ilvl"] = 321,
          ["crit"] = 1122,
          ["haste"] = 945,
          ["mastery"] = 411,
          ["vers"] = 467,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMz2MmlhxY0wMzYZmZmZwYmBAAAALDAzYAgNzYYDGYGWoxMLMMMDzsBAYmBAYgxA"
        },
        {
          ["name"] = "Aycé",
          ["guild"] = "Distorted",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 147555,
          ["ilvl"] = 325,
          ["crit"] = 1276,
          ["haste"] = 1189,
          ["mastery"] = 495,
          ["vers"] = 218,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGmZ2mxsMMGjGmZmtlZmZmBjZGAAAAsNAMjBA2MjhNYgZYhGzswYGmBDAAzMAgZgxA"
        },
        {
          ["name"] = "Zê",
          ["guild"] = "Swamp Animals",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 144035,
          ["ilvl"] = 321,
          ["crit"] = 1070,
          ["haste"] = 887,
          ["mastery"] = 708,
          ["vers"] = 390,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzMz2MmlhxYmGmZmtlZmZmBMzAAAAglBgZMAwmZMsBDMDL0YmFGGmBzGAgZGAwAGD"
        },
        {
          ["name"] = "Xyrdam",
          ["guild"] = "New Reunion",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 139353,
          ["ilvl"] = 322,
          ["crit"] = 804,
          ["haste"] = 1373,
          ["mastery"] = 571,
          ["vers"] = 315,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMjxYmGmZstMmZmhZMzAAAAglBgZMADsBLLGNmBwshZ2gZMzgBAMzAAwAGD"
        },
        {
          ["name"] = "Hersin",
          ["guild"] = "Rolling For Blame",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 138509,
          ["ilvl"] = 322,
          ["crit"] = 1042,
          ["haste"] = 1307,
          ["mastery"] = 611,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMjZmZmZGz2MmlhxY0MzYmFzMzMDDzMAAAAYZAYGDwAbwyiRjZAMLYmNYGzMMAAzMAAYgxA"
        },
        {
          ["name"] = "Vildie",
          ["guild"] = "Husk at Crit",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 137636,
          ["ilvl"] = 319,
          ["crit"] = 671,
          ["haste"] = 1462,
          ["mastery"] = 429,
          ["vers"] = 423,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMjZmZmZGzmxsMjxY0wMzYZmZmZwYmBAAAALDAzYAGYD2WMaMDgZDzsBzwMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Sesame",
          ["guild"] = "BGW",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 136736,
          ["ilvl"] = 322,
          ["crit"] = 1242,
          ["haste"] = 1170,
          ["mastery"] = 453,
          ["vers"] = 253,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGzMzmxsMMGz0wMDLzMzMDGzMAAAAYZAYGDAsYGDbwAzwCNmZhxMmZwsBAYmBAMgxA"
        },
        {
          ["name"] = "不吃螺蛳粉",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 136661,
          ["ilvl"] = 319,
          ["crit"] = 810,
          ["haste"] = 1194,
          ["mastery"] = 859,
          ["vers"] = 37,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270160,
              ["name"] = "First Mate's Shellward",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMjZmZmZGzmxsMjxY0wMzYZmZmZwYmBAAAALDAzYAGYDWWMaMDgZDzsBzwMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Stamba",
          ["guild"] = "ÆVUM",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 136323,
          ["ilvl"] = 323,
          ["crit"] = 735,
          ["haste"] = 1431,
          ["mastery"] = 336,
          ["vers"] = 514,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MzsMMGjGmZYZmZmZwYmBAAAALjBYGDwAbwyiRjZAMbYmNYGzMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Vildie",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Sszorak",
          ["amount"] = 129065,
          ["ilvl"] = 326,
          ["crit"] = 1093,
          ["haste"] = 1311,
          ["mastery"] = 172,
          ["vers"] = 598,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMmZ2MmlhxY0MmZYZmZmZAzMAAAAYZMAzYAgFzYYDGYGWoxMLMmxMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Spanra",
          ["guild"] = "Raize",
          ["boss"] = "Sszorak",
          ["amount"] = 121212,
          ["ilvl"] = 323,
          ["crit"] = 1205,
          ["haste"] = 1069,
          ["mastery"] = 311,
          ["vers"] = 417,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGjGmZstMzMzMYMzAAAAglBgZMAwmZMsBDMDL0YmFGzYmBDAAzMAgZgxA"
        },
        {
          ["name"] = "Cranksmith",
          ["guild"] = "Pathogen",
          ["boss"] = "Sszorak",
          ["amount"] = 117228,
          ["ilvl"] = 320,
          ["crit"] = 1210,
          ["haste"] = 1076,
          ["mastery"] = 441,
          ["vers"] = 199,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGmZ2MmlhxY0wMDLzMzMDzYmBAAAALjBYGDAsZGDbwAzwCNGLMmxMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Kyrts",
          ["guild"] = "Imparity",
          ["boss"] = "Sszorak",
          ["amount"] = 116643,
          ["ilvl"] = 323,
          ["crit"] = 1330,
          ["haste"] = 1254,
          ["mastery"] = 410,
          ["vers"] = 124,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGzMzmxsMMGjmxMDLzMzMDGzMAAAAYZAYGDAsYGDbwAzwCNGLMmxMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Gistwar",
          ["guild"] = "BlackCellFaction",
          ["boss"] = "Sszorak",
          ["amount"] = 115844,
          ["ilvl"] = 324,
          ["crit"] = 938,
          ["haste"] = 1245,
          ["mastery"] = 672,
          ["vers"] = 246,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGz0wMjtlZmZmBjZGAAAAsMAMjBAWMjhNYgZYhGjFGzYmBDAAzMAgZgxA"
        },
        {
          ["name"] = "Zwr",
          ["guild"] = "Infinity",
          ["boss"] = "Sszorak",
          ["amount"] = 115427,
          ["ilvl"] = 323,
          ["crit"] = 984,
          ["haste"] = 1117,
          ["mastery"] = 465,
          ["vers"] = 481,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGjGmZYZmZmhZGzMAAAAYZMAzYAgNzYYDGYGWoxMLMMmZwsBAYmBAMgxA"
        },
        {
          ["name"] = "Bus",
          ["guild"] = "Vindicatum",
          ["boss"] = "Sszorak",
          ["amount"] = 115106,
          ["ilvl"] = 317,
          ["crit"] = 927,
          ["haste"] = 1072,
          ["mastery"] = 806,
          ["vers"] = 50,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGz0wMDLjZmZYGzMAAAAYZAYGDAsYGDbwAzwCNmZhxMmZwsBAYmBAMgxA"
        },
        {
          ["name"] = "Alexwarr",
          ["guild"] = "Low Expectations",
          ["boss"] = "Sszorak",
          ["amount"] = 114117,
          ["ilvl"] = 323,
          ["crit"] = 1191,
          ["haste"] = 1350,
          ["mastery"] = 513,
          ["vers"] = 53,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMmZ2MmlhxY0wYstMzMzMMjZGAAAAsMGgZMAwiZMsBDMDL0YmFGzYmBDAAzMAgZgxA"
        },
        {
          ["name"] = "Guthezzo",
          ["guild"] = "Dsylxeic",
          ["boss"] = "Sszorak",
          ["amount"] = 114072,
          ["ilvl"] = 320,
          ["crit"] = 838,
          ["haste"] = 1294,
          ["mastery"] = 451,
          ["vers"] = 328,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGz0wMDLzMzMDYmBAAAALjBYGDAsYGDbwAzwCNmZhhxMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Sense",
          ["guild"] = "Nurfed",
          ["boss"] = "Sszorak",
          ["amount"] = 114020,
          ["ilvl"] = 323,
          ["crit"] = 820,
          ["haste"] = 1180,
          ["mastery"] = 769,
          ["vers"] = 348,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMzYmZGmZ2MmlhxY0MmZYZmZmZAzMAAAAYZMAzYAgFzYYDGYGWoxMLMmxMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Aédric",
          ["guild"] = "Ascendancy",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 155843,
          ["ilvl"] = 323,
          ["crit"] = 3075,
          ["haste"] = 1219,
          ["mastery"] = 505,
          ["vers"] = -175,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzY2MmlhxY0wMDLzMzMDDzMAAAAYZMAzYAGYDWWMaMDgZDzsBzMzMYWAgZGAAmBGD"
        },
        {
          ["name"] = "Gradde",
          ["guild"] = "Without Limits",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 155751,
          ["ilvl"] = 323,
          ["crit"] = 761,
          ["haste"] = 1494,
          ["mastery"] = 300,
          ["vers"] = 564,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzY2MmlhxY0wYstMzMzMMMzAAAAglxAMjBYgNYZxoxMAmNMzGMzMzgZDAmZAAYGYMA"
        },
        {
          ["name"] = "Sense",
          ["guild"] = "Nurfed",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 146895,
          ["ilvl"] = 324,
          ["crit"] = 866,
          ["haste"] = 1309,
          ["mastery"] = 585,
          ["vers"] = 390,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MmlZMGjGmZstMzMzMMMzAAAAglxAMjBYgNYbxoxMAmNMzGMjZGMAgZGAAmBGD"
        },
        {
          ["name"] = "Lalasama",
          ["guild"] = "Nascent",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 146266,
          ["ilvl"] = 327,
          ["crit"] = 683,
          ["haste"] = 1543,
          ["mastery"] = 458,
          ["vers"] = 302,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzY2MmlhxYmGGDLzMzMjZGjBAAAALjBYmtBYgNYZxoxMAmNMzGMjZGMAgZGAAmBGD"
        },
        {
          ["name"] = "Zwr",
          ["guild"] = "Infinity",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 145336,
          ["ilvl"] = 323,
          ["crit"] = 984,
          ["haste"] = 1117,
          ["mastery"] = 465,
          ["vers"] = 481,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzY2MzsMMGjGmZGLzYmZYGzMAAAAYZMAzYAGYDWWMaMDgZBzsBmxMYWAgZGAAmBGD"
        },
        {
          ["name"] = "Dinglederper",
          ["guild"] = "Scuffed",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 143595,
          ["ilvl"] = 324,
          ["crit"] = 991,
          ["haste"] = 1439,
          ["mastery"] = 384,
          ["vers"] = 129,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzY2MmlhxY0wMjNzMzMjZYmBAAAALjBYGDwAbwyiRjZAMbwsBzMzMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Anathdra",
          ["guild"] = "Schwingen des Phoenix",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 131650,
          ["ilvl"] = 324,
          ["crit"] = 932,
          ["haste"] = 1182,
          ["mastery"] = 517,
          ["vers"] = 460,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZmxMzMzMmFzMLDjxMNMGWmZmZGmxMDAAAAWmZAmxAMwGssY0YGAzGmZDGMDmNAYmBAgZgxA"
        },
        {
          ["name"] = "Ignorebull",
          ["guild"] = "Echoes",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 118775,
          ["ilvl"] = 322,
          ["crit"] = 1479,
          ["haste"] = 1243,
          ["mastery"] = 159,
          ["vers"] = 330,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzYWMzsMMGjGmZYZmZmZYGzMAAAAYZmBYGDwAbwyiRjZAMbYmNgZmBzCAMzAAwAGD"
        },
        {
          ["name"] = "Worldguard",
          ["guild"] = "The Reckless",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 117348,
          ["ilvl"] = 321,
          ["crit"] = 773,
          ["haste"] = 1637,
          ["mastery"] = 277,
          ["vers"] = 421,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 311
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MzsMMGz0wMDLjZmZYGzMAAAAYbMAzYAGYBWWMaMDgZDzsBmZmBzGAMzAAwAGD"
        },
        {
          ["name"] = "Losticlap",
          ["guild"] = "Booty Bay Bingo Buddies",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 117175,
          ["ilvl"] = 322,
          ["crit"] = 330,
          ["haste"] = 1228,
          ["mastery"] = 593,
          ["vers"] = 762,
          ["trinkets"] = {
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 315
            }
          },
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzYWMmlZMGjGmZstMzMzMMMzAAAAglxAMjBYgNYbxoxMAmNMzGMjZGMAgZGAAmBGD"
        },
        {
          ["name"] = "Vercetorix",
          ["guild"] = "Saddle Club",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 128875,
          ["ilvl"] = 321,
          ["crit"] = 1005,
          ["haste"] = 991,
          ["mastery"] = 660,
          ["vers"] = 285,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273795,
              ["name"] = "Coiled Fangstone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzMzmxsMMGjGmZGLzMzMDGzMAAAAYZAYGDwAbw2iRjZAMbYmNGzwMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Adian",
          ["guild"] = "Tempest",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 122607,
          ["ilvl"] = 324,
          ["crit"] = 1214,
          ["haste"] = 1052,
          ["mastery"] = 501,
          ["vers"] = 362,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMjxYmGGDLzMzMDGzMAAAAYZAYGDAsZGDbwAzwCNmZBmxMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Vildie",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 122187,
          ["ilvl"] = 325,
          ["crit"] = 1093,
          ["haste"] = 1309,
          ["mastery"] = 172,
          ["vers"] = 595,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzMzMzYGzmxsMMGjGmZGLzMzMDDzMAAAAYZAYGDwAbw2iRjZAMbYmNGzwMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Xyrdam",
          ["guild"] = "New Reunion",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 121064,
          ["ilvl"] = 322,
          ["crit"] = 804,
          ["haste"] = 1444,
          ["mastery"] = 571,
          ["vers"] = 315,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MmlZMGz0wMzstMmZmhZMzAAAAglxAMjBYgNYZxoxMAmNMzGMDzgBAMzAAwAGD"
        },
        {
          ["name"] = "Shawestruck",
          ["guild"] = "proud to be hated",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 119170,
          ["ilvl"] = 320,
          ["crit"] = 912,
          ["haste"] = 1151,
          ["mastery"] = 509,
          ["vers"] = 447,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MzsMjxYmGmZstMmZmhZMzAAAAglBgZMADsBbLGNmBwshZ2gZMzgBAMzAAwAGD"
        },
        {
          ["name"] = "Vialtos",
          ["guild"] = "Milk",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 117975,
          ["ilvl"] = 321,
          ["crit"] = 1292,
          ["haste"] = 1298,
          ["mastery"] = 179,
          ["vers"] = 225,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzMzMzYmZ2MmlhxY0wMzYZmZmZYYmBAAAALDAzYAGYD2WMaMDgZDzsBzwMY2AgZGAAmBGD"
        },
        {
          ["name"] = "Spanra",
          ["guild"] = "Raize",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 117381,
          ["ilvl"] = 323,
          ["crit"] = 1024,
          ["haste"] = 1218,
          ["mastery"] = 311,
          ["vers"] = 417,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMzMzmxsMjxYmGGjtlZmZmBjZGAAAAsMAMjBYgNYZxoxMAmNMzGMjZGMAgZGAAmBGD"
        },
        {
          ["name"] = "Thunderbrave",
          ["guild"] = "Nordavind",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 116604,
          ["ilvl"] = 325,
          ["crit"] = 1328,
          ["haste"] = 1408,
          ["mastery"] = 332,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMDzMzMmZ2mxsMMGz0wYmNzYmZYGzMAAAAYZAYGDAsZGDbwAzwCNmZhxMMDmNAAzMAgZgxA"
        },
        {
          ["name"] = "Muffinwarri",
          ["guild"] = "Until The End",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 116274,
          ["ilvl"] = 325,
          ["crit"] = 1111,
          ["haste"] = 1048,
          ["mastery"] = 637,
          ["vers"] = 222,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MzsMMGz0wMDLjZmZYGzMAAAAYZMAzYAGYD2WMaMDgZDzsBzYmBzGAMzAAwAGD"
        },
        {
          ["name"] = "Stamba",
          ["guild"] = "ÆVUM",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 115737,
          ["ilvl"] = 323,
          ["crit"] = 768,
          ["haste"] = 1375,
          ["mastery"] = 336,
          ["vers"] = 514,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzYmZGzY2MzsMMGjGmZYZmZmZwYmBAAAALjBYGDwAbwyiRjZAMbYmNYGzMY2AgZGAAmBGD"
        }
      }
    }
  }
}
