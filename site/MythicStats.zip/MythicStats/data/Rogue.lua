MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Rogue"] = {
  ["className"] = "Rogue",
  ["specs"] = {
    {
      ["spec"] = "Assassination",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Shinyruo",
          ["guild"] = "拂晓",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 230252,
          ["ilvl"] = 323,
          ["crit"] = 1414,
          ["haste"] = 1043,
          ["mastery"] = 584,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "취호",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 225064,
          ["ilvl"] = 321,
          ["crit"] = 1324,
          ["haste"] = 942,
          ["mastery"] = 756,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "烧鹅腿",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 224379,
          ["ilvl"] = 322,
          ["crit"] = 1382,
          ["haste"] = 948,
          ["mastery"] = 666,
          ["vers"] = 84,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZM2mZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Impyr",
          ["guild"] = "Northern Sky",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 221280,
          ["ilvl"] = 327,
          ["crit"] = 1332,
          ["haste"] = 1023,
          ["mastery"] = 661,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYAAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmZMmZMGzMjxAYgFYGjGzGgtBsBAmZmZMA"
        },
        {
          ["name"] = "Kpb",
          ["guild"] = "Ascendance",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220370,
          ["ilvl"] = 325,
          ["crit"] = 1403,
          ["haste"] = 921,
          ["mastery"] = 799,
          ["vers"] = 45,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Asighineu",
          ["guild"] = "Pirates of Scarlet Moon",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220324,
          ["ilvl"] = 324,
          ["crit"] = 1269,
          ["haste"] = 1196,
          ["mastery"] = 654,
          ["vers"] = 186,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYmxYMmZYMAGYBmxoxsAYbAbGAMzMDD"
        },
        {
          ["name"] = "Shester",
          ["guild"] = "Embers",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220068,
          ["ilvl"] = 320,
          ["crit"] = 1358,
          ["haste"] = 915,
          ["mastery"] = 817,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMzMjxMjxYmZMGADsAzY0Y2AsNgNDAmZGMA"
        },
        {
          ["name"] = "Mortíz",
          ["guild"] = "guppy pond",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 219355,
          ["ilvl"] = 324,
          ["crit"] = 1379,
          ["haste"] = 1039,
          ["mastery"] = 601,
          ["vers"] = 109,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAttNzMzMzMGbzMzsNzyMzMjxMjxYmZMGADsAzY0Y2AsNgNDAmZGMA"
        },
        {
          ["name"] = "Kenney",
          ["guild"] = "Equity",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 219219,
          ["ilvl"] = 326,
          ["crit"] = 1437,
          ["haste"] = 922,
          ["mastery"] = 749,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMDD"
        },
        {
          ["name"] = "Chainbleed",
          ["guild"] = "YEP",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217548,
          ["ilvl"] = 325,
          ["crit"] = 1485,
          ["haste"] = 928,
          ["mastery"] = 525,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZM2mZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Gabilemou",
          ["guild"] = "Just dont die",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217874,
          ["ilvl"] = 320,
          ["crit"] = 1254,
          ["haste"] = 1249,
          ["mastery"] = 344,
          ["vers"] = 180,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 315
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYmxYMmZYMAGYBmxoxsBYZAbGAMzMGD"
        },
        {
          ["name"] = "Akali",
          ["guild"] = "Potato Corner",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217443,
          ["ilvl"] = 325,
          ["crit"] = 1476,
          ["haste"] = 1028,
          ["mastery"] = 779,
          ["vers"] = 119,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAZbmZmZmZM2mZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Kerelinn",
          ["guild"] = "ohno",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217015,
          ["ilvl"] = 326,
          ["crit"] = 1351,
          ["haste"] = 1188,
          ["mastery"] = 453,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAttNzMzMzMGbzMzsNzyMzMjxMjxYmxMGADsAzY0Y2AsNgNDAmZGMA"
        },
        {
          ["name"] = "Preparedr",
          ["guild"] = "velocity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 215816,
          ["ilvl"] = 327,
          ["crit"] = 1403,
          ["haste"] = 1158,
          ["mastery"] = 555,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYAAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYMzYMmZMjBwALwMGNmNAbDYzAgZmZGD"
        },
        {
          ["name"] = "Zeross",
          ["guild"] = "Aurora",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 215144,
          ["ilvl"] = 326,
          ["crit"] = 1543,
          ["haste"] = 1094,
          ["mastery"] = 513,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZAAAAAAYWGsNDAAAAAottxMzMzMGbzMzsNzyMzMjxMjxYmZMGADsAzY0YWAsNgNDAmZmZMA"
        },
        {
          ["name"] = "Killars",
          ["guild"] = "Stormbound",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 213339,
          ["ilvl"] = 325,
          ["crit"] = 1419,
          ["haste"] = 711,
          ["mastery"] = 965,
          ["vers"] = 50,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGzMzYMmZYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Magthïe",
          ["guild"] = "Wasted Talent",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 211200,
          ["ilvl"] = 321,
          ["crit"] = 1514,
          ["haste"] = 924,
          ["mastery"] = 481,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Miamiganster",
          ["guild"] = "Vindicatum",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 211141,
          ["ilvl"] = 325,
          ["crit"] = 1466,
          ["haste"] = 985,
          ["mastery"] = 615,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "抠脚贼",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 210867,
          ["ilvl"] = 325,
          ["crit"] = 1326,
          ["haste"] = 1041,
          ["mastery"] = 726,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMDD"
        },
        {
          ["name"] = "Lolaè",
          ["guild"] = "Quichons",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209785,
          ["ilvl"] = 324,
          ["crit"] = 1413,
          ["haste"] = 1160,
          ["mastery"] = 501,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZZmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Lassitude",
          ["guild"] = "YEP",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 331721,
          ["ilvl"] = 324,
          ["crit"] = 1272,
          ["haste"] = 1079,
          ["mastery"] = 681,
          ["vers"] = 135,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmHYegxMjxwMjxAYgFYGjGzGgtBsBAmZGjB"
        },
        {
          ["name"] = "Vexxlorx",
          ["guild"] = "Ashen",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 324561,
          ["ilvl"] = 322,
          ["crit"] = 1320,
          ["haste"] = 1150,
          ["mastery"] = 658,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AzDMmZMGmZMGADsAzY0Y2AsNgNAwMzMjB"
        },
        {
          ["name"] = "Ellwaron",
          ["guild"] = "Hostile",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323453,
          ["ilvl"] = 322,
          ["crit"] = 1513,
          ["haste"] = 989,
          ["mastery"] = 399,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AzDMmZMGmZMGADsAzY0Y2AsNgNAwMzMjB"
        },
        {
          ["name"] = "Blindvanish",
          ["guild"] = "Frog Gang",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 321844,
          ["ilvl"] = 319,
          ["crit"] = 1149,
          ["haste"] = 1078,
          ["mastery"] = 678,
          ["vers"] = 184,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAZZmZmZmZMWmZmZbmlZm5BmHYMzYMMzYMAGYBmxoxsAYbAbGAMzMGjB"
        },
        {
          ["name"] = "抠脚贼",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 321472,
          ["ilvl"] = 322,
          ["crit"] = 1293,
          ["haste"] = 1079,
          ["mastery"] = 808,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmHYegxMjxwMjxAYgFYGjGzGgtBsZAwMzgB"
        },
        {
          ["name"] = "Iamdog",
          ["guild"] = "Welcome",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 320409,
          ["ilvl"] = 318,
          ["crit"] = 1142,
          ["haste"] = 1260,
          ["mastery"] = 476,
          ["vers"] = 172,
          ["trinkets"] = {
            {
              ["id"] = 159617,
              ["name"] = "Lustrous Golden Plumage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AzDMmZMGmZMGADsAzY0Y2AsNgNAwMzMjB"
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 318685,
          ["ilvl"] = 320,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["potion"] = nil,
          ["talents"] = ""
        },
        {
          ["name"] = "Zerøcool",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 318652,
          ["ilvl"] = 324,
          ["crit"] = 1466,
          ["haste"] = 969,
          ["mastery"] = 759,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYbmZmtZWmZmHYegxMjxwMjxAYgFYGjGzGgtBsZAwMzgB"
        },
        {
          ["name"] = "소매치기",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 318359,
          ["ilvl"] = 314,
          ["crit"] = 1366,
          ["haste"] = 810,
          ["mastery"] = 882,
          ["vers"] = 119,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["potion"] = nil,
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPw8AjZGjhZGjBwALwMGNmNAbDYzAgZmxYA"
        },
        {
          ["name"] = "Uwucutegirl",
          ["guild"] = "Reko",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 317339,
          ["ilvl"] = 322,
          ["crit"] = 1288,
          ["haste"] = 1101,
          ["mastery"] = 746,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmHYegxMjxwMjxAYgFYGjGzGgtBsZAwMDjB"
        },
        {
          ["name"] = "Nemethis",
          ["guild"] = "Zeal",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 271685,
          ["ilvl"] = 323,
          ["crit"] = 1237,
          ["haste"] = 1259,
          ["mastery"] = 487,
          ["vers"] = 204,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzGgtBsZAwMzYMA"
        },
        {
          ["name"] = "Mongis",
          ["guild"] = "Effective Chaos",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 266005,
          ["ilvl"] = 323,
          ["crit"] = 1299,
          ["haste"] = 814,
          ["mastery"] = 852,
          ["vers"] = 219,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAwygtZAAAAAAZbmZmZmZMWmZmZbmlZm5BMjZGjhZGzMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Lolaè",
          ["guild"] = "Quichons",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 264488,
          ["ilvl"] = 324,
          ["crit"] = 1318,
          ["haste"] = 1189,
          ["mastery"] = 568,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "乌呀噫哈",
          ["guild"] = "颠倒梦想",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 263182,
          ["ilvl"] = 324,
          ["crit"] = 1523,
          ["haste"] = 1246,
          ["mastery"] = 413,
          ["vers"] = 138,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGbzMzsNzyMzMjxMjxYmhxAsZWGYALglhJwwiBzMAjxA"
        },
        {
          ["name"] = "Impyr",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 262745,
          ["ilvl"] = 327,
          ["crit"] = 1332,
          ["haste"] = 1023,
          ["mastery"] = 661,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzGgtBsBAmZmZMA"
        },
        {
          ["name"] = "Kenney",
          ["guild"] = "Equity",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 262709,
          ["ilvl"] = 326,
          ["crit"] = 1467,
          ["haste"] = 795,
          ["mastery"] = 846,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmHwMmZMGmZMGADsAzY0YWAsNgNDAmZGMA"
        },
        {
          ["name"] = "抠脚贼",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 262570,
          ["ilvl"] = 326,
          ["crit"] = 1326,
          ["haste"] = 1041,
          ["mastery"] = 668,
          ["vers"] = 170,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmHYegxMjxwMjxAYgFYGjGzGgtBsZAwMzgB"
        },
        {
          ["name"] = "抖音老妖魔獣",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 261233,
          ["ilvl"] = 327,
          ["crit"] = 1363,
          ["haste"] = 1050,
          ["mastery"] = 792,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGbzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzYMA"
        },
        {
          ["name"] = "Atrocite",
          ["guild"] = "undecided",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 261101,
          ["ilvl"] = 324,
          ["crit"] = 1116,
          ["haste"] = 1013,
          ["mastery"] = 679,
          ["vers"] = 340,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmHYegxMjxwMjxAYgFYGjGzCgtBsZAwMzgB"
        },
        {
          ["name"] = "Kerelinn",
          ["guild"] = "ohno",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 259991,
          ["ilvl"] = 326,
          ["crit"] = 1350,
          ["haste"] = 1187,
          ["mastery"] = 452,
          ["vers"] = 167,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGbzMzsNzyMz8AmxMjxwMjxAYgFYGjGzGgtBsZAwMzYMA"
        },
        {
          ["name"] = "Donnyxd",
          ["guild"] = "Reckoning",
          ["boss"] = "Sszorak",
          ["amount"] = 231459,
          ["ilvl"] = 325,
          ["crit"] = 1451,
          ["haste"] = 991,
          ["mastery"] = 528,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAMzsMmtZAAAAAAYWGsMDAAAAAottxMzMzMGbzMzsNzyMzMMjZMGzMGGADsAzY0YWAsNgNDAmZmZMA"
        },
        {
          ["name"] = "Zeross",
          ["guild"] = "Aurora",
          ["boss"] = "Sszorak",
          ["amount"] = 230710,
          ["ilvl"] = 324,
          ["crit"] = 1546,
          ["haste"] = 1048,
          ["mastery"] = 486,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAMzsMmtZAAAAAAYWGsMDAAAAAottxMzMzMGbzMzsNzyMzMMjZMGzMGGADsAzY0YWAsNgNDAmZmZMA"
        },
        {
          ["name"] = "Hrasha",
          ["guild"] = "Silenced",
          ["boss"] = "Sszorak",
          ["amount"] = 228099,
          ["ilvl"] = 323,
          ["crit"] = 1329,
          ["haste"] = 936,
          ["mastery"] = 790,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYGzYMmZMMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Nolarz",
          ["guild"] = "Noted",
          ["boss"] = "Sszorak",
          ["amount"] = 227452,
          ["ilvl"] = 320,
          ["crit"] = 1391,
          ["haste"] = 818,
          ["mastery"] = 639,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsMDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYGzYMmZMMAGYBmxoxsBYbAbGAMzMDD"
        },
        {
          ["name"] = "Uwucutegirl",
          ["guild"] = "Reko",
          ["boss"] = "Sszorak",
          ["amount"] = 227434,
          ["ilvl"] = 323,
          ["crit"] = 1376,
          ["haste"] = 1146,
          ["mastery"] = 666,
          ["vers"] = 184,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmZMjZMGzMGGADsAzY0Y2AsNgNDAmZYMA"
        },
        {
          ["name"] = "抠脚贼",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 225197,
          ["ilvl"] = 323,
          ["crit"] = 1306,
          ["haste"] = 1027,
          ["mastery"] = 725,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAMzsMmtZwAAAAAAzyglZAAAAAAZbmZmZmZMWmZmZbmlZmZYGzYMmZMMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Rjæ",
          ["guild"] = "Medium",
          ["boss"] = "Sszorak",
          ["amount"] = 223444,
          ["ilvl"] = 326,
          ["crit"] = 1503,
          ["haste"] = 1153,
          ["mastery"] = 601,
          ["vers"] = 65,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsMDAAAAAAzygtZAAAAAAttNzMzMzMGbzMzsNzyMzMjZMjxYmxwAYgFYGjGzGgtBsBAmZmZMA"
        },
        {
          ["name"] = "Pimschanse",
          ["guild"] = "Arbeitsamt Orgrimmar",
          ["boss"] = "Sszorak",
          ["amount"] = 223140,
          ["ilvl"] = 323,
          ["crit"] = 1249,
          ["haste"] = 717,
          ["mastery"] = 803,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsMDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmZMjZMGzMGGADsAzY0Y2AsNgNDAmZGMA"
        },
        {
          ["name"] = "Hollab",
          ["guild"] = "Ultra Instinct",
          ["boss"] = "Sszorak",
          ["amount"] = 222169,
          ["ilvl"] = 324,
          ["crit"] = 1300,
          ["haste"] = 1081,
          ["mastery"] = 366,
          ["vers"] = 375,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsMDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYGzYMmZMMAGYBmxoxsAYbAbGAMzMGD"
        },
        {
          ["name"] = "Atrocite",
          ["guild"] = "undecided",
          ["boss"] = "Sszorak",
          ["amount"] = 221715,
          ["ilvl"] = 324,
          ["crit"] = 1116,
          ["haste"] = 1013,
          ["mastery"] = 679,
          ["vers"] = 340,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsMDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmZMjZMGzMGGADsAzY0YWAsNgNAwMzYMA"
        },
        {
          ["name"] = "Zolbar",
          ["guild"] = "CMT",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 292636,
          ["ilvl"] = 325,
          ["crit"] = 1436,
          ["haste"] = 1011,
          ["mastery"] = 617,
          ["vers"] = 163,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAGYBmxoxsBYbAbGAMzMDD"
        },
        {
          ["name"] = "Gwozr",
          ["guild"] = "Tempo",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 288322,
          ["ilvl"] = 327,
          ["crit"] = 1235,
          ["haste"] = 1090,
          ["mastery"] = 949,
          ["vers"] = 77,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzYMA"
        },
        {
          ["name"] = "抠脚贼",
          ["guild"] = "老友俱乐部",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 287933,
          ["ilvl"] = 323,
          ["crit"] = 1394,
          ["haste"] = 952,
          ["mastery"] = 711,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AzDMmZMGmZMGgNzyADYBsMMBGWMYmBYGGA"
        },
        {
          ["name"] = "Kenney",
          ["guild"] = "Equity",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 281288,
          ["ilvl"] = 325,
          ["crit"] = 1298,
          ["haste"] = 920,
          ["mastery"] = 937,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmHwMmZMGmZMGADsAzY0YWAsNgNDAmZGMA"
        },
        {
          ["name"] = "Nickledon",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 280480,
          ["ilvl"] = 326,
          ["crit"] = 1251,
          ["haste"] = 1118,
          ["mastery"] = 758,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAGYBmxoxsAYbAbGAMzMGD"
        },
        {
          ["name"] = "Chainbleed",
          ["guild"] = "YEP",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 280174,
          ["ilvl"] = 326,
          ["crit"] = 1420,
          ["haste"] = 890,
          ["mastery"] = 742,
          ["vers"] = 133,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYbmZmtZWmZmHwMmZMGmZMGADsAzY0Y2AsNgNDAmZGMA"
        },
        {
          ["name"] = "Donnyxd",
          ["guild"] = "Reckoning",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 278671,
          ["ilvl"] = 325,
          ["crit"] = 1467,
          ["haste"] = 784,
          ["mastery"] = 857,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGbzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzYMA"
        },
        {
          ["name"] = "Shdwphnx",
          ["guild"] = "Rewind",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 276928,
          ["ilvl"] = 324,
          ["crit"] = 1457,
          ["haste"] = 956,
          ["mastery"] = 762,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "秋挽",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 276565,
          ["ilvl"] = 325,
          ["crit"] = 1450,
          ["haste"] = 1059,
          ["mastery"] = 613,
          ["vers"] = 170,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAottZmZmZmxYbmZmtZWmZmHwMmZMGmZMGgNzyADYBsMMBGWAzMAjxA"
        },
        {
          ["name"] = "Preparedr",
          ["guild"] = "velocity",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 273705,
          ["ilvl"] = 327,
          ["crit"] = 1403,
          ["haste"] = 1158,
          ["mastery"] = 555,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzYMA"
        },
        {
          ["name"] = "Lolaè",
          ["guild"] = "Quichons",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 248977,
          ["ilvl"] = 324,
          ["crit"] = 1413,
          ["haste"] = 1160,
          ["mastery"] = 501,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZZmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Auxeus",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 242599,
          ["ilvl"] = 327,
          ["crit"] = 1397,
          ["haste"] = 908,
          ["mastery"] = 837,
          ["vers"] = 245,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPwYMzYMmZGjBYzsMwAWALDTghFDmZAGjB"
        },
        {
          ["name"] = "Tomelvis",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 222832,
          ["ilvl"] = 327,
          ["crit"] = 1454,
          ["haste"] = 1062,
          ["mastery"] = 744,
          ["vers"] = 128,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPwYMzYMmZGjBYzsMwAWALDTghFDmZAGjB"
        },
        {
          ["name"] = "Avasa",
          ["guild"] = "Sabotage",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 222762,
          ["ilvl"] = 326,
          ["crit"] = 1508,
          ["haste"] = 895,
          ["mastery"] = 819,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYAAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmZMmZMGzMjxAYgFYGjGzGgtBsZAwMzYMA"
        },
        {
          ["name"] = "Esra",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 452547,
          ["ilvl"] = 327,
          ["crit"] = 1286,
          ["haste"] = 1127,
          ["mastery"] = 902,
          ["vers"] = 1347,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMPgZMz4BMjZGjBYzsMwAWALDTghFDmZAGjB"
        },
        {
          ["name"] = "판다만두왕",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 445264,
          ["ilvl"] = 328,
          ["crit"] = 1264,
          ["haste"] = 781,
          ["mastery"] = 1047,
          ["vers"] = 1384,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMPgZMzYMMzYMALmlBGwCYZYCMsYwMDwYMA"
        },
        {
          ["name"] = "왕도둑민우",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 426431,
          ["ilvl"] = 328,
          ["crit"] = 3060,
          ["haste"] = 967,
          ["mastery"] = 830,
          ["vers"] = -34,
          ["trinkets"] = {
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYmBYxsMwAWALDTghFDmZAGMA"
        },
        {
          ["name"] = "Mutilatee",
          ["guild"] = "Vindicatum",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 243970,
          ["ilvl"] = 325,
          ["crit"] = 1388,
          ["haste"] = 1177,
          ["mastery"] = 620,
          ["vers"] = 175,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZM2mZmZbmlZmZmHYMzYMMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Klópfér",
          ["guild"] = "forever the sickest kids",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 239453,
          ["ilvl"] = 324,
          ["crit"] = 1180,
          ["haste"] = 1024,
          ["mastery"] = 815,
          ["vers"] = 298,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAz2gtZAAAAAAttNzMzMzMGLzMzsNzyMzMzDMmZMGmZMGADsAzY0Y2AsNgNDAmZGMA"
        },
        {
          ["name"] = "Gwozr",
          ["guild"] = "Tempo",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 235605,
          ["ilvl"] = 327,
          ["crit"] = 1235,
          ["haste"] = 1090,
          ["mastery"] = 949,
          ["vers"] = 77,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsAYbAbGAMzMGD"
        },
        {
          ["name"] = "Preparedr",
          ["guild"] = "velocity",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 234386,
          ["ilvl"] = 326,
          ["crit"] = 1403,
          ["haste"] = 1158,
          ["mastery"] = 548,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYAAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPwYMzYMmZmZMAGYBmxoxsBYbAbGAMzMzYA"
        },
        {
          ["name"] = "Sneakyrhino",
          ["guild"] = "SCH",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 233999,
          ["ilvl"] = 317,
          ["crit"] = 1043,
          ["haste"] = 1036,
          ["mastery"] = 427,
          ["vers"] = 470,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 285
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Puds",
          ["guild"] = "Deadly Damage",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 231102,
          ["ilvl"] = 319,
          ["crit"] = 1377,
          ["haste"] = 1102,
          ["mastery"] = 438,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZmHYMzYMMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Иниквитти",
          ["guild"] = "Лучший Рейд",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 230382,
          ["ilvl"] = 323,
          ["crit"] = 1316,
          ["haste"] = 887,
          ["mastery"] = 802,
          ["vers"] = 273,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYAAAAAAYWGsNDAAAAAottZmZmZmxYZmZmtZWmZmZMmZMGzMjxAYgFYGjGzGgtBsBAmZmZMA"
        },
        {
          ["name"] = "Ærri",
          ["guild"] = "Wisp",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 230192,
          ["ilvl"] = 321,
          ["crit"] = 1493,
          ["haste"] = 1003,
          ["mastery"] = 487,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbAgZmZGD"
        },
        {
          ["name"] = "Pumpmenace",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 227315,
          ["ilvl"] = 323,
          ["crit"] = 1284,
          ["haste"] = 1064,
          ["mastery"] = 801,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZmHYMzYMMzYMAGYBmxoxsBYbAbGAMzMGD"
        },
        {
          ["name"] = "Magthïe",
          ["guild"] = "Wasted Talent",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 225610,
          ["ilvl"] = 319,
          ["crit"] = 1435,
          ["haste"] = 984,
          ["mastery"] = 477,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZGjZGjxMzYMAGYBmxoxsBYbAbGAMzMGD"
        }
      }
    },
    {
      ["spec"] = "Subtlety",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Parse",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 250244,
          ["ilvl"] = 327,
          ["crit"] = 539,
          ["haste"] = 826,
          ["mastery"] = 1386,
          ["vers"] = 459,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Xelion",
          ["guild"] = "Echoes",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 249557,
          ["ilvl"] = 327,
          ["crit"] = 599,
          ["haste"] = 735,
          ["mastery"] = 1326,
          ["vers"] = 565,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Lloxyurns",
          ["guild"] = "繁华落尽",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 237647,
          ["ilvl"] = 322,
          ["crit"] = 527,
          ["haste"] = 669,
          ["mastery"] = 1166,
          ["vers"] = 736,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Wot",
          ["guild"] = "Cutting Bread",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 234824,
          ["ilvl"] = 327,
          ["crit"] = 494,
          ["haste"] = 721,
          ["mastery"] = 1254,
          ["vers"] = 717,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "阿桃",
          ["guild"] = "雷霆咆哮",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 234805,
          ["ilvl"] = 323,
          ["crit"] = 632,
          ["haste"] = 531,
          ["mastery"] = 1328,
          ["vers"] = 730,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgZ2mBAAAAAmlxYZiZbbMmZYYmZmZGmHYbGzYbbMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Rennqt",
          ["guild"] = "Just Woke Up",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 234360,
          ["ilvl"] = 323,
          ["crit"] = 646,
          ["haste"] = 779,
          ["mastery"] = 1236,
          ["vers"] = 518,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Skullysneak",
          ["guild"] = "Somali Yacht Club",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 234253,
          ["ilvl"] = 325,
          ["crit"] = 590,
          ["haste"] = 1197,
          ["mastery"] = 901,
          ["vers"] = 496,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "轻浮的弟弟",
          ["guild"] = "Again",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 233555,
          ["ilvl"] = 322,
          ["crit"] = 572,
          ["haste"] = 759,
          ["mastery"] = 1270,
          ["vers"] = 516,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYG2mZmZmZGDGzsNAAAAmBjZzsMwAWALDTgZBzwMDwMGA"
        },
        {
          ["name"] = "Monkeysiu",
          ["guild"] = "Revoke",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 233503,
          ["ilvl"] = 325,
          ["crit"] = 414,
          ["haste"] = 773,
          ["mastery"] = 1287,
          ["vers"] = 745,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "彗声彗色",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 232435,
          ["ilvl"] = 318,
          ["crit"] = 767,
          ["haste"] = 702,
          ["mastery"] = 1222,
          ["vers"] = 389,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbLzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Wot",
          ["guild"] = "Cutting Bread",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 232361,
          ["ilvl"] = 327,
          ["crit"] = 494,
          ["haste"] = 721,
          ["mastery"] = 1254,
          ["vers"] = 717,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Slasharama",
          ["guild"] = "vodka",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 223224,
          ["ilvl"] = 325,
          ["crit"] = 579,
          ["haste"] = 708,
          ["mastery"] = 1216,
          ["vers"] = 679,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYG2mZmZmZGDGzsNAAAAmBjZzsMwAWALDTgZBzwMDwMGA"
        },
        {
          ["name"] = "小红手墨客丶",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 222417,
          ["ilvl"] = 326,
          ["crit"] = 732,
          ["haste"] = 744,
          ["mastery"] = 1227,
          ["vers"] = 429,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "鱼鱼十一号",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 221710,
          ["ilvl"] = 327,
          ["crit"] = 686,
          ["haste"] = 764,
          ["mastery"] = 1270,
          ["vers"] = 445,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Skullysneak",
          ["guild"] = "Somali Yacht Club",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 220475,
          ["ilvl"] = 325,
          ["crit"] = 590,
          ["haste"] = 1197,
          ["mastery"] = 901,
          ["vers"] = 497,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Zhynz",
          ["guild"] = "Ascendancy",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 220149,
          ["ilvl"] = 323,
          ["crit"] = 545,
          ["haste"] = 624,
          ["mastery"] = 1229,
          ["vers"] = 742,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Raidlogger",
          ["guild"] = "Dsylxeic",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 219612,
          ["ilvl"] = 324,
          ["crit"] = 744,
          ["haste"] = 980,
          ["mastery"] = 919,
          ["vers"] = 508,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Euronics",
          ["guild"] = "Reflection",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 219313,
          ["ilvl"] = 325,
          ["crit"] = 369,
          ["haste"] = 569,
          ["mastery"] = 1262,
          ["vers"] = 966,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbLzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Cerok",
          ["guild"] = "Frenzied Apes",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217266,
          ["ilvl"] = 324,
          ["crit"] = 671,
          ["haste"] = 701,
          ["mastery"] = 1217,
          ["vers"] = 602,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Evilraîn",
          ["guild"] = "Below Average",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 216552,
          ["ilvl"] = 326,
          ["crit"] = 598,
          ["haste"] = 709,
          ["mastery"] = 1271,
          ["vers"] = 672,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Leaffallew",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 350007,
          ["ilvl"] = 323,
          ["crit"] = 787,
          ["haste"] = 817,
          ["mastery"] = 1260,
          ["vers"] = 332,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Therope",
          ["guild"] = "WatchYourFeet",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 347379,
          ["ilvl"] = 325,
          ["crit"] = 434,
          ["haste"] = 1095,
          ["mastery"] = 1148,
          ["vers"] = 530,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAzgxsYWGYALglhJwsADzMAzYA"
        },
        {
          ["name"] = "Monsterabuse",
          ["guild"] = "Proxy",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 345723,
          ["ilvl"] = 322,
          ["crit"] = 477,
          ["haste"] = 686,
          ["mastery"] = 1211,
          ["vers"] = 744,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYmZbZmZmZmZMYMz2AAAAwgxsZWGYALglhJwsgZYmBYYA"
        },
        {
          ["name"] = "Cheapshotx",
          ["guild"] = "Инвинсибл",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 342159,
          ["ilvl"] = 319,
          ["crit"] = 517,
          ["haste"] = 773,
          ["mastery"] = 1141,
          ["vers"] = 713,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "秋挽",
          ["guild"] = "Modern",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 341936,
          ["ilvl"] = 325,
          ["crit"] = 630,
          ["haste"] = 682,
          ["mastery"] = 1161,
          ["vers"] = 690,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Suite",
          ["guild"] = "Wrong Tactics Folks",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 340417,
          ["ilvl"] = 322,
          ["crit"] = 376,
          ["haste"] = 680,
          ["mastery"] = 1364,
          ["vers"] = 748,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYG2mZmZmZGDGzsNAAAAmBjZxsMwAWALDTgZBzwMDwMGA"
        },
        {
          ["name"] = "Subti",
          ["guild"] = "Twitch Prime",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 340130,
          ["ilvl"] = 324,
          ["crit"] = 961,
          ["haste"] = 740,
          ["mastery"] = 1141,
          ["vers"] = 331,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Dukatron",
          ["guild"] = "Huhuholics",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 339284,
          ["ilvl"] = 320,
          ["crit"] = 508,
          ["haste"] = 706,
          ["mastery"] = 1275,
          ["vers"] = 556,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Anythng",
          ["guild"] = "baited",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 339212,
          ["ilvl"] = 326,
          ["crit"] = 625,
          ["haste"] = 860,
          ["mastery"] = 1190,
          ["vers"] = 537,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Anelace",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 339104,
          ["ilvl"] = 322,
          ["crit"] = 517,
          ["haste"] = 707,
          ["mastery"] = 1337,
          ["vers"] = 542,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTjx2YMzwwMzMzMMPw2MmhtZmZmZmxgxMbDAAAgZwYWMLDMgFwywEYWwMMzAMjB"
        },
        {
          ["name"] = "秋挽",
          ["guild"] = "Modern",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 246730,
          ["ilvl"] = 325,
          ["crit"] = 630,
          ["haste"] = 682,
          ["mastery"] = 1161,
          ["vers"] = 690,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Shameonus",
          ["guild"] = "Oblivion",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 245496,
          ["ilvl"] = 325,
          ["crit"] = 391,
          ["haste"] = 690,
          ["mastery"] = 1445,
          ["vers"] = 681,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Magicterran",
          ["guild"] = "老友俱乐部后起之秀团_",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 244196,
          ["ilvl"] = 324,
          ["crit"] = 684,
          ["haste"] = 650,
          ["mastery"] = 1253,
          ["vers"] = 598,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "숏묵",
          ["guild"] = "조류학회",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 242859,
          ["ilvl"] = 325,
          ["crit"] = 749,
          ["haste"] = 693,
          ["mastery"] = 1196,
          ["vers"] = 528,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYG2mZmZmZGDGzsNAAAAmBjZzsMwAWALDTgZBzwMDwMGA"
        },
        {
          ["name"] = "Insulinx",
          ["guild"] = "Кайзер",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 241826,
          ["ilvl"] = 323,
          ["crit"] = 668,
          ["haste"] = 719,
          ["mastery"] = 1147,
          ["vers"] = 619,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYmx2MzMzMzYwYmtBAAAgBjZxsMwAWALDTgZBzwMDwMGA"
        },
        {
          ["name"] = "綾瀬沙季",
          ["guild"] = "炉火糖粥",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 241680,
          ["ilvl"] = 326,
          ["crit"] = 876,
          ["haste"] = 705,
          ["mastery"] = 1191,
          ["vers"] = 420,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYG2mZmZmZGDGzsNAAAAmBjZzsMwAWALDTgZBzwMDwMGA"
        },
        {
          ["name"] = "Navorishalar",
          ["guild"] = "Adapt",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 241590,
          ["ilvl"] = 324,
          ["crit"] = 364,
          ["haste"] = 808,
          ["mastery"] = 1326,
          ["vers"] = 704,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Esra",
          ["guild"] = "Honestly",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 240854,
          ["ilvl"] = 325,
          ["crit"] = 450,
          ["haste"] = 731,
          ["mastery"] = 1364,
          ["vers"] = 633,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Monkeysiu",
          ["guild"] = "Revoke",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 239732,
          ["ilvl"] = 325,
          ["crit"] = 414,
          ["haste"] = 773,
          ["mastery"] = 1287,
          ["vers"] = 745,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Jonewrld",
          ["guild"] = "Northstar",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 239081,
          ["ilvl"] = 326,
          ["crit"] = 696,
          ["haste"] = 719,
          ["mastery"] = 1257,
          ["vers"] = 529,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Euronics",
          ["guild"] = "Reflection",
          ["boss"] = "Sszorak",
          ["amount"] = 243578,
          ["ilvl"] = 325,
          ["crit"] = 369,
          ["haste"] = 569,
          ["mastery"] = 1262,
          ["vers"] = 966,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbLzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Keshdl",
          ["guild"] = "R e t i r e d",
          ["boss"] = "Sszorak",
          ["amount"] = 243192,
          ["ilvl"] = 324,
          ["crit"] = 340,
          ["haste"] = 708,
          ["mastery"] = 1319,
          ["vers"] = 818,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Wot",
          ["guild"] = "Cutting Bread",
          ["boss"] = "Sszorak",
          ["amount"] = 242077,
          ["ilvl"] = 327,
          ["crit"] = 494,
          ["haste"] = 622,
          ["mastery"] = 1353,
          ["vers"] = 717,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Flamë",
          ["guild"] = "Clarity",
          ["boss"] = "Sszorak",
          ["amount"] = 241967,
          ["ilvl"] = 325,
          ["crit"] = 672,
          ["haste"] = 788,
          ["mastery"] = 1239,
          ["vers"] = 461,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Lassitude",
          ["guild"] = "YEP",
          ["boss"] = "Sszorak",
          ["amount"] = 241636,
          ["ilvl"] = 325,
          ["crit"] = 571,
          ["haste"] = 620,
          ["mastery"] = 1259,
          ["vers"] = 728,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Anonymzr",
          ["guild"] = "Easy Katka",
          ["boss"] = "Sszorak",
          ["amount"] = 240159,
          ["ilvl"] = 325,
          ["crit"] = 557,
          ["haste"] = 1027,
          ["mastery"] = 1143,
          ["vers"] = 480,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Bew",
          ["guild"] = "Myth",
          ["boss"] = "Sszorak",
          ["amount"] = 238676,
          ["ilvl"] = 325,
          ["crit"] = 688,
          ["haste"] = 809,
          ["mastery"] = 1398,
          ["vers"] = 293,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Antok",
          ["guild"] = "Offline",
          ["boss"] = "Sszorak",
          ["amount"] = 238420,
          ["ilvl"] = 325,
          ["crit"] = 232,
          ["haste"] = 896,
          ["mastery"] = 1242,
          ["vers"] = 660,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273797,
              ["name"] = "Tattered Amani War Banner",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Zhynz",
          ["guild"] = "Ascendancy",
          ["boss"] = "Sszorak",
          ["amount"] = 237534,
          ["ilvl"] = 323,
          ["crit"] = 546,
          ["haste"] = 624,
          ["mastery"] = 1229,
          ["vers"] = 742,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Skullysneak",
          ["guild"] = "Somali Yacht Club",
          ["boss"] = "Sszorak",
          ["amount"] = 237533,
          ["ilvl"] = 325,
          ["crit"] = 590,
          ["haste"] = 1197,
          ["mastery"] = 901,
          ["vers"] = 496,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Wot",
          ["guild"] = "Cutting Bread",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 265491,
          ["ilvl"] = 327,
          ["crit"] = 494,
          ["haste"] = 622,
          ["mastery"] = 1353,
          ["vers"] = 717,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Xelion",
          ["guild"] = "Echoes",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 263171,
          ["ilvl"] = 325,
          ["crit"] = 599,
          ["haste"] = 733,
          ["mastery"] = 1324,
          ["vers"] = 561,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Anythng",
          ["guild"] = "baited",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 262588,
          ["ilvl"] = 326,
          ["crit"] = 625,
          ["haste"] = 860,
          ["mastery"] = 1190,
          ["vers"] = 537,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Anonymzr",
          ["guild"] = "Easy Katka",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 262308,
          ["ilvl"] = 326,
          ["crit"] = 557,
          ["haste"] = 1029,
          ["mastery"] = 1143,
          ["vers"] = 480,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Treez",
          ["guild"] = "aespa",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 259738,
          ["ilvl"] = 325,
          ["crit"] = 634,
          ["haste"] = 817,
          ["mastery"] = 1328,
          ["vers"] = 451,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "浑浑噩噩楠楠",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 257857,
          ["ilvl"] = 325,
          ["crit"] = 600,
          ["haste"] = 727,
          ["mastery"] = 1267,
          ["vers"] = 623,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAzgxsYWGYALglhJwsgZYmBYYA"
        },
        {
          ["name"] = "Antok",
          ["guild"] = "Offline",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 256810,
          ["ilvl"] = 326,
          ["crit"] = 233,
          ["haste"] = 901,
          ["mastery"] = 1243,
          ["vers"] = 662,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273797,
              ["name"] = "Tattered Amani War Banner",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Shameonus",
          ["guild"] = "Oblivion",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 256366,
          ["ilvl"] = 325,
          ["crit"] = 391,
          ["haste"] = 750,
          ["mastery"] = 1325,
          ["vers"] = 743,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Møgzu",
          ["guild"] = "miscalculated",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 255914,
          ["ilvl"] = 325,
          ["crit"] = 542,
          ["haste"] = 705,
          ["mastery"] = 1097,
          ["vers"] = 814,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Përkz",
          ["guild"] = "Honolulu",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 255699,
          ["ilvl"] = 325,
          ["crit"] = 544,
          ["haste"] = 753,
          ["mastery"] = 1231,
          ["vers"] = 680,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "丶吮指原味鸡",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 234814,
          ["ilvl"] = 326,
          ["crit"] = 730,
          ["haste"] = 699,
          ["mastery"] = 1281,
          ["vers"] = 518,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYmZbbMzMzMjBMz2AAAAwgxsZWGYALglhJwsgZYmBYmZA"
        },
        {
          ["name"] = "Anythng",
          ["guild"] = "baited",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 232428,
          ["ilvl"] = 326,
          ["crit"] = 555,
          ["haste"] = 861,
          ["mastery"] = 1209,
          ["vers"] = 594,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Parse",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 231420,
          ["ilvl"] = 328,
          ["crit"] = 539,
          ["haste"] = 828,
          ["mastery"] = 1386,
          ["vers"] = 463,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Wreckids",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 230948,
          ["ilvl"] = 325,
          ["crit"] = 421,
          ["haste"] = 772,
          ["mastery"] = 1369,
          ["vers"] = 659,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Përkz",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 227855,
          ["ilvl"] = 326,
          ["crit"] = 549,
          ["haste"] = 753,
          ["mastery"] = 1234,
          ["vers"] = 680,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Esra",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 226201,
          ["ilvl"] = 325,
          ["crit"] = 450,
          ["haste"] = 731,
          ["mastery"] = 1364,
          ["vers"] = 633,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Nibren",
          ["guild"] = "Ethical",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 225774,
          ["ilvl"] = 325,
          ["crit"] = 511,
          ["haste"] = 1062,
          ["mastery"] = 1297,
          ["vers"] = 281,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Impyr",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 221720,
          ["ilvl"] = 327,
          ["crit"] = 646,
          ["haste"] = 781,
          ["mastery"] = 1225,
          ["vers"] = 533,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Symmyellow",
          ["guild"] = "Infinity",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 214627,
          ["ilvl"] = 324,
          ["crit"] = 603,
          ["haste"] = 746,
          ["mastery"] = 1373,
          ["vers"] = 604,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYmZbbmZmZmZMYMz2AAAAwgxsZWGYALglhJwsgZYmBYYA"
        },
        {
          ["name"] = "Mobbdeep",
          ["guild"] = "Quichons",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 214001,
          ["ilvl"] = 322,
          ["crit"] = 716,
          ["haste"] = 703,
          ["mastery"] = 1114,
          ["vers"] = 580,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Reptyler",
          ["guild"] = "Thirteen Orphans",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 247234,
          ["ilvl"] = 321,
          ["crit"] = 396,
          ["haste"] = 813,
          ["mastery"] = 1355,
          ["vers"] = 421,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 311
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Møgzu",
          ["guild"] = "miscalculated",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 241944,
          ["ilvl"] = 325,
          ["crit"] = 540,
          ["haste"] = 705,
          ["mastery"] = 1097,
          ["vers"] = 814,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Anythng",
          ["guild"] = "baited",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 241204,
          ["ilvl"] = 326,
          ["crit"] = 625,
          ["haste"] = 860,
          ["mastery"] = 1190,
          ["vers"] = 537,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Sharpeyez",
          ["guild"] = "Retired Extremely Bad",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 241009,
          ["ilvl"] = 322,
          ["crit"] = 444,
          ["haste"] = 668,
          ["mastery"] = 1292,
          ["vers"] = 756,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "静森",
          ["guild"] = "Starry Night",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 240817,
          ["ilvl"] = 326,
          ["crit"] = 429,
          ["haste"] = 722,
          ["mastery"] = 1394,
          ["vers"] = 720,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAglxYZiZbbMmZYYmZmZGmHYbGzM2mZmZmZGDGzsNAAAAmBjZxsMwAWALDTgZBzwMDwMGA"
        },
        {
          ["name"] = "Antok",
          ["guild"] = "Offline",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 239919,
          ["ilvl"] = 325,
          ["crit"] = 232,
          ["haste"] = 894,
          ["mastery"] = 1242,
          ["vers"] = 660,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273797,
              ["name"] = "Tattered Amani War Banner",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Kleftisrouge",
          ["guild"] = "Literacy Test",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 238450,
          ["ilvl"] = 324,
          ["crit"] = 594,
          ["haste"] = 1032,
          ["mastery"] = 1128,
          ["vers"] = 417,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYG2mZmZmZGDGzsNAAAAmBjZzsMwAWALDTgZBzwMDwMGA"
        },
        {
          ["name"] = "Oofyy",
          ["guild"] = "Kingsman",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 237985,
          ["ilvl"] = 322,
          ["crit"] = 455,
          ["haste"] = 725,
          ["mastery"] = 1343,
          ["vers"] = 665,
          ["trinkets"] = {
            {
              ["id"] = 273797,
              ["name"] = "Tattered Amani War Banner",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "귀천마객",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 237724,
          ["ilvl"] = 322,
          ["crit"] = 704,
          ["haste"] = 770,
          ["mastery"] = 1271,
          ["vers"] = 384,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
        },
        {
          ["name"] = "Xelion",
          ["guild"] = "Echoes",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 237193,
          ["ilvl"] = 326,
          ["crit"] = 764,
          ["haste"] = 735,
          ["mastery"] = 1161,
          ["vers"] = 565,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMBmFMDzMAzYA"
        }
      }
    },
    {
      ["spec"] = "Outlaw",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Static",
          ["guild"] = "Cult of Morgoth",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 234357,
          ["ilvl"] = 321,
          ["crit"] = 1294,
          ["haste"] = 1122,
          ["mastery"] = 173,
          ["vers"] = 514,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Mistarogue",
          ["guild"] = "Sustained",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 230525,
          ["ilvl"] = 324,
          ["crit"] = 1285,
          ["haste"] = 1137,
          ["mastery"] = 117,
          ["vers"] = 607,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZMzMmF4BmZZaZw2MAAAAAALbjZGmZmZWMzMbDAAAAzMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Awangawangaw",
          ["guild"] = "Stand Unshaken",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 230147,
          ["ilvl"] = 325,
          ["crit"] = 1317,
          ["haste"] = 1140,
          ["mastery"] = 171,
          ["vers"] = 535,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZMzMmF4BmZbaZw2MAAAAAA2mZmhZmZmFzMz2AAAAYGDAGzihBGYWYhWYjBYmBzgB"
        },
        {
          ["name"] = "Клемск",
          ["guild"] = "Расхитители",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 229455,
          ["ilvl"] = 311,
          ["crit"] = 1472,
          ["haste"] = 986,
          ["mastery"] = 154,
          ["vers"] = 369,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAgx2MzMMzMzsYmZ2GAAAAzYAwYWMMwAzCL0CbMAzMYgB"
        },
        {
          ["name"] = "Capstab",
          ["guild"] = "Intensity",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 227123,
          ["ilvl"] = 320,
          ["crit"] = 1130,
          ["haste"] = 990,
          ["mastery"] = 363,
          ["vers"] = 621,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmxMzsNzMjZmxsAPwMmWGsNDAAAAAglZmZYmZmZxMzsNAAAAmxAgxsYYgBmFWoF2YAmZwMYA"
        },
        {
          ["name"] = "Scoreboard",
          ["guild"] = "Three Die Six",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 225261,
          ["ilvl"] = 321,
          ["crit"] = 1321,
          ["haste"] = 1174,
          ["mastery"] = 156,
          ["vers"] = 318,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmxMzsNzMjZmxsAPwMmWGsNDAAAAAglZmZYmZmZxMzsNAAAAmxAgxsYYgBmFWoF2YAmZwMYA"
        },
        {
          ["name"] = "Callmesmithy",
          ["guild"] = "Failsafe",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 224856,
          ["ilvl"] = 315,
          ["crit"] = 1483,
          ["haste"] = 961,
          ["mastery"] = 115,
          ["vers"] = 260,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 159617,
              ["name"] = "Lustrous Golden Plumage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmZmZmtZmZMzMmFwMmWGsNDAAAAAgtZmZYmZmZxMzsNAAAAmxAgxsYYgBmFWoN2YAmZwAzA"
        },
        {
          ["name"] = "Steezy",
          ["guild"] = "Tide",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 224567,
          ["ilvl"] = 323,
          ["crit"] = 1129,
          ["haste"] = 1229,
          ["mastery"] = 395,
          ["vers"] = 382,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZMzMmF4BmZZaZw2MAAAAAALbjZGmZmZWMzMbDAAAAzMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Diddyborne",
          ["guild"] = "Púlse",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 222283,
          ["ilvl"] = 322,
          ["crit"] = 1300,
          ["haste"] = 966,
          ["mastery"] = 98,
          ["vers"] = 764,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbbzMzwMzMziZmZZAAAAYmBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "星隐丶",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220175,
          ["ilvl"] = 321,
          ["crit"] = 1148,
          ["haste"] = 1067,
          ["mastery"] = 184,
          ["vers"] = 667,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMzMzMmFGmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDeA"
        },
        {
          ["name"] = "Kéraz",
          ["guild"] = "Ritual",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 204212,
          ["ilvl"] = 324,
          ["crit"] = 1299,
          ["haste"] = 1133,
          ["mastery"] = 201,
          ["vers"] = 523,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMjxMzsNzMzMjxssgHYmtplBbzAAAAAAstNzMDzMzMLmZmtBAAAgxAgxsYYgBmFWoF2YAmZwAzA"
        },
        {
          ["name"] = "Kameloz",
          ["guild"] = "Spiral Out",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 203795,
          ["ilvl"] = 323,
          ["crit"] = 1433,
          ["haste"] = 1058,
          ["mastery"] = 98,
          ["vers"] = 553,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "로셀리니",
          ["guild"] = "포장마차",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 203313,
          ["ilvl"] = 322,
          ["crit"] = 1084,
          ["haste"] = 1248,
          ["mastery"] = 161,
          ["vers"] = 685,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 318
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Slythr",
          ["guild"] = "Eboncrest",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 201364,
          ["ilvl"] = 319,
          ["crit"] = 1141,
          ["haste"] = 980,
          ["mastery"] = 170,
          ["vers"] = 630,
          ["trinkets"] = {
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAMjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Loktark",
          ["guild"] = "Rain",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 200784,
          ["ilvl"] = 326,
          ["crit"] = 1305,
          ["haste"] = 1095,
          ["mastery"] = 125,
          ["vers"] = 671,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMwM"
        },
        {
          ["name"] = "Mistarogue",
          ["guild"] = "Sustained",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 200749,
          ["ilvl"] = 324,
          ["crit"] = 1285,
          ["haste"] = 1137,
          ["mastery"] = 117,
          ["vers"] = 607,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZZaZw2MAAAAAALbjZGmZmZWMzMbDAAAAzMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Mershvanish",
          ["guild"] = "Bingohallen",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198819,
          ["ilvl"] = 326,
          ["crit"] = 1380,
          ["haste"] = 1167,
          ["mastery"] = 168,
          ["vers"] = 465,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMbsQLsxAMzgBG"
        },
        {
          ["name"] = "Cummingham",
          ["guild"] = "Zanity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198335,
          ["ilvl"] = 321,
          ["crit"] = 1232,
          ["haste"] = 1111,
          ["mastery"] = 161,
          ["vers"] = 623,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAMjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Jeepseerogue",
          ["guild"] = "Jurassic Raiders",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198178,
          ["ilvl"] = 321,
          ["crit"] = 1292,
          ["haste"] = 1009,
          ["mastery"] = 318,
          ["vers"] = 474,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbLzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Stabzemq",
          ["guild"] = "Axon Terminal",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 197260,
          ["ilvl"] = 323,
          ["crit"] = 1384,
          ["haste"] = 1030,
          ["mastery"] = 70,
          ["vers"] = 612,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "边缘之锋",
          ["guild"] = "西内呦",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 336819,
          ["ilvl"] = 322,
          ["crit"] = 1269,
          ["haste"] = 1102,
          ["mastery"] = 107,
          ["vers"] = 662,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAw22MzMMzMzsYmZ2GAAAAzYAwYWMMwAzCL0CbMAzMYgB"
        },
        {
          ["name"] = "雪色",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 329931,
          ["ilvl"] = 321,
          ["crit"] = 1351,
          ["haste"] = 1111,
          ["mastery"] = 132,
          ["vers"] = 513,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Pasquale",
          ["guild"] = "Mid Team",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 313771,
          ["ilvl"] = 320,
          ["crit"] = 968,
          ["haste"] = 1145,
          ["mastery"] = 167,
          ["vers"] = 760,
          ["trinkets"] = {
            {
              ["id"] = 250259,
              ["name"] = "Sapling of the Dawnroot",
              ["ilvl"] = 315
            },
            {
              ["id"] = 250225,
              ["name"] = "Void Execution Mandate",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Neecryna",
          ["guild"] = "Aprèm",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 313433,
          ["ilvl"] = 325,
          ["crit"] = 1802,
          ["haste"] = 898,
          ["mastery"] = 127,
          ["vers"] = 385,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAMjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Silz",
          ["guild"] = "Epilogue",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 312281,
          ["ilvl"] = 318,
          ["crit"] = 1254,
          ["haste"] = 1108,
          ["mastery"] = 252,
          ["vers"] = 529,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmxMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMwAzCL0CbMAzMYgB"
        },
        {
          ["name"] = "Mistarogue",
          ["guild"] = "Sustained",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 311438,
          ["ilvl"] = 322,
          ["crit"] = 1607,
          ["haste"] = 903,
          ["mastery"] = 153,
          ["vers"] = 490,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAALbjZGmZmZWMzMbDAAAAzMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Метабрэйкер",
          ["guild"] = "Дворфийский Ковен",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 306544,
          ["ilvl"] = 323,
          ["crit"] = 1236,
          ["haste"] = 830,
          ["mastery"] = 232,
          ["vers"] = 687,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY2WmZmhZmZmFzMz2AAAAwYAwYWMMwAzCL0CbMAzMYgB"
        },
        {
          ["name"] = "Turbochud",
          ["guild"] = "Send Crests",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 305128,
          ["ilvl"] = 321,
          ["crit"] = 1199,
          ["haste"] = 1232,
          ["mastery"] = 246,
          ["vers"] = 464,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAw22MzMMzMzsYmZ2GAAAAzYAwYWMMwAzCL0CbMAzMYgB"
        },
        {
          ["name"] = "一呀呀",
          ["guild"] = "黎明之翼",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 303224,
          ["ilvl"] = 322,
          ["crit"] = 1344,
          ["haste"] = 1021,
          ["mastery"] = 113,
          ["vers"] = 467,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAw2yMzMMzMzsYmZ2GAAAAGDAGzihBGYWYhWYjBYmBzgB"
        },
        {
          ["name"] = "苏格呢",
          ["guild"] = "神殇",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 303166,
          ["ilvl"] = 323,
          ["crit"] = 1344,
          ["haste"] = 989,
          ["mastery"] = 117,
          ["vers"] = 732,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYbbmZGmZMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDeA"
        },
        {
          ["name"] = "Tomelvis",
          ["guild"] = "Wave",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 278309,
          ["ilvl"] = 322,
          ["crit"] = 1477,
          ["haste"] = 961,
          ["mastery"] = 318,
          ["vers"] = 422,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMzMzMmFGmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDeA"
        },
        {
          ["name"] = "Roguald",
          ["guild"] = "CK",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 258849,
          ["ilvl"] = 321,
          ["crit"] = 1330,
          ["haste"] = 933,
          ["mastery"] = 205,
          ["vers"] = 557,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmZmZmtZmZMzMmFwMmWGsNDAAAAAw22MzMMzMzsYmZ2GAAAAGDAGzihBGYWYhWYjBYmBzgB"
        },
        {
          ["name"] = "Zeviis",
          ["guild"] = "Carnage Inc",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 254212,
          ["ilvl"] = 323,
          ["crit"] = 1340,
          ["haste"] = 894,
          ["mastery"] = 170,
          ["vers"] = 750,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMzMzMmFGmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwADMLsQLsxAMzgBeA"
        },
        {
          ["name"] = "Jeepseerogue",
          ["guild"] = "Jurassic Raiders",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 253557,
          ["ilvl"] = 321,
          ["crit"] = 1292,
          ["haste"] = 1009,
          ["mastery"] = 318,
          ["vers"] = 474,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbLzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Jibarogue",
          ["guild"] = "Clown Return",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 253127,
          ["ilvl"] = 325,
          ["crit"] = 1513,
          ["haste"] = 996,
          ["mastery"] = 134,
          ["vers"] = 545,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmZmZmtZmZMzMmFwMmWGsNDAAAAAw22MzMMzMzsYmZ2GAAAAzYAwYWMMwAzCL0CbMAzMYgB"
        },
        {
          ["name"] = "Slythr",
          ["guild"] = "Eboncrest",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 246866,
          ["ilvl"] = 320,
          ["crit"] = 1179,
          ["haste"] = 991,
          ["mastery"] = 135,
          ["vers"] = 630,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAMjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Kevsyndrome",
          ["guild"] = "Clown Fiesta",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 246034,
          ["ilvl"] = 323,
          ["crit"] = 1208,
          ["haste"] = 1027,
          ["mastery"] = 408,
          ["vers"] = 340,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "雪色",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 245858,
          ["ilvl"] = 321,
          ["crit"] = 1351,
          ["haste"] = 1111,
          ["mastery"] = 132,
          ["vers"] = 513,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Ristarte",
          ["guild"] = "Wesley CRUSHERs",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 245064,
          ["ilvl"] = 320,
          ["crit"] = 1598,
          ["haste"] = 951,
          ["mastery"] = 255,
          ["vers"] = 262,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMzMzMmFGmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMbsQLsxAMzgBeA"
        },
        {
          ["name"] = "Måc",
          ["guild"] = "CALM DOWN",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 245053,
          ["ilvl"] = 321,
          ["crit"] = 1424,
          ["haste"] = 1145,
          ["mastery"] = 161,
          ["vers"] = 389,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbLzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Jibarogue",
          ["guild"] = "Clown Return",
          ["boss"] = "Sszorak",
          ["amount"] = 236731,
          ["ilvl"] = 325,
          ["crit"] = 1348,
          ["haste"] = 1161,
          ["mastery"] = 134,
          ["vers"] = 545,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMjxMzsNzMzMjxssgHYmlplBbzAAAAAAstNzMDzMzMLmZmtBAAAwMGAMmFDDMwswCtwGDwMDGYA"
        },
        {
          ["name"] = "Cummingham",
          ["guild"] = "Zanity",
          ["boss"] = "Sszorak",
          ["amount"] = 233024,
          ["ilvl"] = 321,
          ["crit"] = 1233,
          ["haste"] = 1112,
          ["mastery"] = 161,
          ["vers"] = 623,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Tiibi",
          ["guild"] = "Revolutions",
          ["boss"] = "Sszorak",
          ["amount"] = 231465,
          ["ilvl"] = 325,
          ["crit"] = 1127,
          ["haste"] = 1190,
          ["mastery"] = 342,
          ["vers"] = 591,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Måc",
          ["guild"] = "CALM DOWN",
          ["boss"] = "Sszorak",
          ["amount"] = 221903,
          ["ilvl"] = 322,
          ["crit"] = 1436,
          ["haste"] = 1159,
          ["mastery"] = 161,
          ["vers"] = 394,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Neecryna",
          ["guild"] = "Aprèm",
          ["boss"] = "Sszorak",
          ["amount"] = 221387,
          ["ilvl"] = 326,
          ["crit"] = 1746,
          ["haste"] = 910,
          ["mastery"] = 127,
          ["vers"] = 388,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMjxMzsNzMzMjxssgHYmtplBbzAAAAAAstNzMDzMzMLmZmtBAAAgxAgxsYYgBmFWoF2YAmZwMYA"
        },
        {
          ["name"] = "Шевч",
          ["guild"] = "Стигма",
          ["boss"] = "Sszorak",
          ["amount"] = 219633,
          ["ilvl"] = 324,
          ["crit"] = 1309,
          ["haste"] = 1257,
          ["mastery"] = nil,
          ["vers"] = 531,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMjxMzsNzMzMjxssgHYmlplBbzAAAAAAstNzMDzMzMLmZmtBAAAwMGAMmFDDMwswCtwGDwMDGYA"
        },
        {
          ["name"] = "Yohanz",
          ["guild"] = "Super Adventure Pals",
          ["boss"] = "Sszorak",
          ["amount"] = 219259,
          ["ilvl"] = 322,
          ["crit"] = 1426,
          ["haste"] = 1001,
          ["mastery"] = 322,
          ["vers"] = 355,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZZaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Rnglól",
          ["guild"] = "Salty Tears",
          ["boss"] = "Sszorak",
          ["amount"] = 218528,
          ["ilvl"] = 325,
          ["crit"] = 1372,
          ["haste"] = 920,
          ["mastery"] = 254,
          ["vers"] = 545,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMjZmZmtZmZmZMmlFYmtplBbzAAAAAAstNzMDzMzMLmZmtBAAAgxAgxsYYgBmFWoF2YAmZwMYA"
        },
        {
          ["name"] = "Tauxy",
          ["guild"] = "The Ministry",
          ["boss"] = "Sszorak",
          ["amount"] = 218169,
          ["ilvl"] = 321,
          ["crit"] = 1254,
          ["haste"] = 1161,
          ["mastery"] = 128,
          ["vers"] = 590,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmxMzsNzMzMjxsAPwMmWGsNDAAAAAw22MzMMzMzsYmZ2GAAAAGDAGzihBGYWYhWYjBYmBzgB"
        },
        {
          ["name"] = "Stabzemq",
          ["guild"] = "Axon Terminal",
          ["boss"] = "Sszorak",
          ["amount"] = 217373,
          ["ilvl"] = 323,
          ["crit"] = 1284,
          ["haste"] = 1080,
          ["mastery"] = 70,
          ["vers"] = 661,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Tomelvis",
          ["guild"] = "Wave",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 269249,
          ["ilvl"] = 324,
          ["crit"] = 1359,
          ["haste"] = 974,
          ["mastery"] = 445,
          ["vers"] = 425,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMzMzMmFGmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDeA"
        },
        {
          ["name"] = "Stabzemq",
          ["guild"] = "Axon Terminal",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 260122,
          ["ilvl"] = 325,
          ["crit"] = 1398,
          ["haste"] = 1052,
          ["mastery"] = 70,
          ["vers"] = 613,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "花匠丶",
          ["guild"] = "Telekinesis",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 249550,
          ["ilvl"] = 322,
          ["crit"] = 1280,
          ["haste"] = 962,
          ["mastery"] = 280,
          ["vers"] = 463,
          ["trinkets"] = {
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Acertrick",
          ["guild"] = "Fluff and Blood",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 248682,
          ["ilvl"] = 325,
          ["crit"] = 1189,
          ["haste"] = 1237,
          ["mastery"] = 171,
          ["vers"] = 484,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmZmZmtZmZmZmxswwMmWGsNDAAAAAw22MzMMzMzsYmZ2GAAAAzYAwYWMMwAzCL0CbMAzMYgHA"
        },
        {
          ["name"] = "Rnglól",
          ["guild"] = "Salty Tears",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 244872,
          ["ilvl"] = 325,
          ["crit"] = 1372,
          ["haste"] = 920,
          ["mastery"] = 254,
          ["vers"] = 545,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMzMzMmFGmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAMjBAjZxwADMLsQLsxAMzgBeA"
        },
        {
          ["name"] = "Loktark",
          ["guild"] = "Rain",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 243034,
          ["ilvl"] = 326,
          ["crit"] = 1305,
          ["haste"] = 1095,
          ["mastery"] = 125,
          ["vers"] = 671,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMjxMzsNzMzMzMmlNjHYmtplBbzAAAAAAstNzMDzMzMLmZmtBAAAgxAgxsYYgBmFWoF2YAmZwAPwA"
        },
        {
          ["name"] = "Kéraz",
          ["guild"] = "Ritual",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 239156,
          ["ilvl"] = 324,
          ["crit"] = 1499,
          ["haste"] = 894,
          ["mastery"] = 337,
          ["vers"] = 583,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMwM"
        },
        {
          ["name"] = "Pasquale",
          ["guild"] = "Mid Team",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 224011,
          ["ilvl"] = 324,
          ["crit"] = 978,
          ["haste"] = 1175,
          ["mastery"] = 174,
          ["vers"] = 774,
          ["trinkets"] = {
            {
              ["id"] = 250259,
              ["name"] = "Sapling of the Dawnroot",
              ["ilvl"] = 315
            },
            {
              ["id"] = 250225,
              ["name"] = "Void Execution Mandate",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Ortyy",
          ["guild"] = "Spirits Rising",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 219321,
          ["ilvl"] = 325,
          ["crit"] = 1343,
          ["haste"] = 1002,
          ["mastery"] = 267,
          ["vers"] = 598,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Måc",
          ["guild"] = "CALM DOWN",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 251552,
          ["ilvl"] = 321,
          ["crit"] = 1424,
          ["haste"] = 1151,
          ["mastery"] = 161,
          ["vers"] = 389,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZMzMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Maxíí",
          ["guild"] = "Comet",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 243934,
          ["ilvl"] = 321,
          ["crit"] = 1148,
          ["haste"] = 1263,
          ["mastery"] = 126,
          ["vers"] = 377,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "Scoreboard",
          ["guild"] = "Three Die Six",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 242917,
          ["ilvl"] = 324,
          ["crit"] = 1536,
          ["haste"] = 1145,
          ["mastery"] = 177,
          ["vers"] = 305,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmxMzsNzMjZmxsAPwMmWGsNDAAAAAglZmZYmZmZxMzsNAAAAmxAgxsYYgBmFWoF2YAmZwMYA"
        },
        {
          ["name"] = "Tomelvis",
          ["guild"] = "Wave",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 239438,
          ["ilvl"] = 324,
          ["crit"] = 1359,
          ["haste"] = 974,
          ["mastery"] = 445,
          ["vers"] = 425,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Nøwyouseemee",
          ["guild"] = "Nox Venari",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 234959,
          ["ilvl"] = 322,
          ["crit"] = 1355,
          ["haste"] = 904,
          ["mastery"] = 222,
          ["vers"] = 583,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
        },
        {
          ["name"] = "부산인",
          ["guild"] = "나의 와저씨들",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 231374,
          ["ilvl"] = 323,
          ["crit"] = 1128,
          ["haste"] = 1157,
          ["mastery"] = nil,
          ["vers"] = 651,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MmZmxMzsNzMzMjxsAPwMmWGsNDAAAAAw22MzMMzMzsYmZ2GAAAAGDAGzihBGYWYhWYjBYmBzgB"
        },
        {
          ["name"] = "Kameloz",
          ["guild"] = "Spiral Out",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 230901,
          ["ilvl"] = 322,
          ["crit"] = 1248,
          ["haste"] = 1203,
          ["mastery"] = 94,
          ["vers"] = 549,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMjZmxsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDG"
        },
        {
          ["name"] = "Mershvanish",
          ["guild"] = "Bingohallen",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 228838,
          ["ilvl"] = 326,
          ["crit"] = 1380,
          ["haste"] = 1165,
          ["mastery"] = 168,
          ["vers"] = 464,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZMzMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwADMbsQLsxAMzgBG"
        },
        {
          ["name"] = "Woldorogue",
          ["guild"] = "Commit",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 227919,
          ["ilvl"] = 324,
          ["crit"] = 1359,
          ["haste"] = 918,
          ["mastery"] = 98,
          ["vers"] = 613,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 159617,
              ["name"] = "Lustrous Golden Plumage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1234969,
            ["name"] = "Ethereal Augmentation"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZZaZw2MAAAAAAbbzMzwMzMziZmZbAAAAMjBAjZxwADMbsQLsxAMzgBG"
        },
        {
          ["name"] = "苏格呢",
          ["guild"] = "神殇",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 225679,
          ["ilvl"] = 323,
          ["crit"] = 1379,
          ["haste"] = 914,
          ["mastery"] = 161,
          ["vers"] = 729,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMzMzsNzMzMjxsw4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGYgZhFahNGgZGMDeA"
        }
      }
    }
  }
}
