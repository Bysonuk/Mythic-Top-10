MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Priest"] = {
  ["className"] = "Priest",
  ["specs"] = {
    {
      ["spec"] = "Discipline",
      ["role"] = "healer",
      ["metric"] = "HPS",
      ["players"] = {
        {
          ["name"] = "Procture",
          ["guild"] = "Epoch",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 356062,
          ["ilvl"] = 310,
          ["crit"] = 349,
          ["haste"] = 1955,
          ["mastery"] = 664,
          ["vers"] = 88,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDMTzEDmZAAAmtZbBM2MAAMmZmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Sushe",
          ["guild"] = "Opposite",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 351306,
          ["ilvl"] = 323,
          ["crit"] = 360,
          ["haste"] = 1999,
          ["mastery"] = 648,
          ["vers"] = 275,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtNwYzAAwYMzYwMYmBmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "马玲",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 349791,
          ["ilvl"] = 322,
          ["crit"] = 701,
          ["haste"] = 1767,
          ["mastery"] = 683,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYmHwgZbmZmZmZAAAAAAAAAAYGWmBzMzgxMDYamYwMDAAwsNbbgxmBAgxMzMGmZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Drtowati",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 346267,
          ["ilvl"] = 323,
          ["crit"] = 592,
          ["haste"] = 1634,
          ["mastery"] = 783,
          ["vers"] = 200,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDYammZwMDAAwsNbLgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Justpg",
          ["guild"] = "NonSense",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 345300,
          ["ilvl"] = 325,
          ["crit"] = 403,
          ["haste"] = 1787,
          ["mastery"] = 831,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMjBTzEDmZAAAmtZbDM2MAAMmZmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Sunri",
          ["guild"] = "K E K L E O",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 339722,
          ["ilvl"] = 319,
          ["crit"] = 602,
          ["haste"] = 1748,
          ["mastery"] = 623,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 268292,
              ["name"] = "Sporelord's Mycelial Insignia",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzMGMbzMzMzMDAAAAAAAAAAzwyMYmZGmxMjBamYwMDAAwsNbbgxmBAgxMzMGmZwMDGBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Niofea",
          ["guild"] = "Ascendance",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 339194,
          ["ilvl"] = 323,
          ["crit"] = 558,
          ["haste"] = 1831,
          ["mastery"] = 623,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzwMwMNTMYmBAAY2mtNwYzAAwYmZGDmBzMYmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Looqp",
          ["guild"] = "The Next Step",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 335262,
          ["ilvl"] = 325,
          ["crit"] = 403,
          ["haste"] = 1885,
          ["mastery"] = 701,
          ["vers"] = 304,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMPAzwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMMjBTz0YwMDAAwsNbbgxmBAgxMzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Mercy",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 331201,
          ["ilvl"] = 318,
          ["crit"] = 625,
          ["haste"] = 2064,
          ["mastery"] = 325,
          ["vers"] = 56,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtFwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Convertedx",
          ["guild"] = "the long nap",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 329543,
          ["ilvl"] = 319,
          ["crit"] = 454,
          ["haste"] = 1693,
          ["mastery"] = 813,
          ["vers"] = 157,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzMwMbzMzMzMDAAAAAAAAAAzYWmZMDzwMMDMTz0YwMDAAwsNbLgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Brownpriest",
          ["guild"] = "Tokidoki",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 418001,
          ["ilvl"] = 326,
          ["crit"] = 623,
          ["haste"] = 1902,
          ["mastery"] = 557,
          ["vers"] = 228,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYmHwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "马玲",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 390193,
          ["ilvl"] = 318,
          ["crit"] = 668,
          ["haste"] = 1654,
          ["mastery"] = 695,
          ["vers"] = 41,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzMGMbzMzMzMDAAAAAAAAAAzwyMYmZGMMjBTzEDmZAAAmtZbDM2MAAMmZmxwMDmZwMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Ilovedragon",
          ["guild"] = "Do Over",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 384585,
          ["ilvl"] = 320,
          ["crit"] = 521,
          ["haste"] = 1735,
          ["mastery"] = 776,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 289
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmxYGGmZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Perttiina",
          ["guild"] = "Noni",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 382051,
          ["ilvl"] = 326,
          ["crit"] = 646,
          ["haste"] = 1857,
          ["mastery"] = 597,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTjBzMAAAz2stBGbGAAGjZGDmBzMYmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Looqp",
          ["guild"] = "The Next Step",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 381181,
          ["ilvl"] = 325,
          ["crit"] = 403,
          ["haste"] = 1885,
          ["mastery"] = 701,
          ["vers"] = 304,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMPAzwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMMjBTz0YwMDAAwsNbbgxmBAgxMzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Plapla",
          ["guild"] = "ToYz",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 380683,
          ["ilvl"] = 325,
          ["crit"] = 540,
          ["haste"] = 1867,
          ["mastery"] = 699,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AmhZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0YwMDAAwsNbbgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Atrocity",
          ["guild"] = "Lucid",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 380395,
          ["ilvl"] = 322,
          ["crit"] = 437,
          ["haste"] = 1695,
          ["mastery"] = 763,
          ["vers"] = 215,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmxYGMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "여우신선",
          ["guild"] = "Main Tank Heal",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 380236,
          ["ilvl"] = 320,
          ["crit"] = 484,
          ["haste"] = 1876,
          ["mastery"] = 715,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AGmZbmZmZmZAAAAAAAAAAYGWmBzMzghZATz0MDmZAAAmtZbDM2MAAMmZmxwMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Mercy",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 379156,
          ["ilvl"] = 324,
          ["crit"] = 527,
          ["haste"] = 1864,
          ["mastery"] = 646,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtFwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Stopthecount",
          ["guild"] = "Speakeasy",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 377320,
          ["ilvl"] = 322,
          ["crit"] = 685,
          ["haste"] = 1679,
          ["mastery"] = 655,
          ["vers"] = 281,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYGMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDMTz0MDmZAAAmtZbBM2MAAMGzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Brownpriest",
          ["guild"] = "Tokidoki",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 358646,
          ["ilvl"] = 326,
          ["crit"] = 623,
          ["haste"] = 1837,
          ["mastery"] = 557,
          ["vers"] = 228,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYmHwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Szatkø",
          ["guild"] = "Apathy",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 341434,
          ["ilvl"] = 321,
          ["crit"] = 794,
          ["haste"] = 1634,
          ["mastery"] = 646,
          ["vers"] = 55,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 295
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDYammZwMDAAwsNbbgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Jcbami",
          ["guild"] = "Stellar",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 336816,
          ["ilvl"] = 323,
          ["crit"] = 742,
          ["haste"] = 1889,
          ["mastery"] = 691,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYGMmZbmZmZmZAAAAAAAAAAYmZWmBzMzgxMDYamYwMDAAwsNbbgxmBAgxMmxwMDmZwMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Plapla",
          ["guild"] = "ToYz",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 330892,
          ["ilvl"] = 319,
          ["crit"] = 604,
          ["haste"] = 1685,
          ["mastery"] = 728,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AmhZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0YwMDAAwsNbbgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Jakbcastin",
          ["guild"] = "Incarnate",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 329068,
          ["ilvl"] = 325,
          ["crit"] = 474,
          ["haste"] = 1801,
          ["mastery"] = 802,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtNwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Beefchanga",
          ["guild"] = "Void",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 325548,
          ["ilvl"] = 323,
          ["crit"] = 611,
          ["haste"] = 1834,
          ["mastery"] = 688,
          ["vers"] = 182,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmxYGMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Mercy",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 324055,
          ["ilvl"] = 324,
          ["crit"] = 530,
          ["haste"] = 1867,
          ["mastery"] = 646,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtFwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Drtowati",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323523,
          ["ilvl"] = 323,
          ["crit"] = 592,
          ["haste"] = 1634,
          ["mastery"] = 783,
          ["vers"] = 200,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDYammZwMDAAwsNbLgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "티에카",
          ["guild"] = "신기하게 생겼어",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323214,
          ["ilvl"] = 320,
          ["crit"] = 701,
          ["haste"] = 1494,
          ["mastery"] = 829,
          ["vers"] = 53,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmx2YmBzMGMbzMzMzMDAAAAAAAAAAzYWmZMDzgxMDMTzEDmZAAAmtZbDM2MAAMmZmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Dgxx",
          ["guild"] = "Friendly Friends",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323099,
          ["ilvl"] = 323,
          ["crit"] = 548,
          ["haste"] = 1495,
          ["mastery"] = 891,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYGMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDYammZwMDAAwsNbLgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Brownpriest",
          ["guild"] = "Tokidoki",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 395097,
          ["ilvl"] = 326,
          ["crit"] = 623,
          ["haste"] = 1837,
          ["mastery"] = 557,
          ["vers"] = 228,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYmHwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Lynmd",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 394097,
          ["ilvl"] = 325,
          ["crit"] = 439,
          ["haste"] = 1809,
          ["mastery"] = 753,
          ["vers"] = 99,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmxYGmhZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbDM2MAAMGzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Niofea",
          ["guild"] = "Ascendance",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 386388,
          ["ilvl"] = 318,
          ["crit"] = 721,
          ["haste"] = 1734,
          ["mastery"] = 633,
          ["vers"] = 141,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbmtZmZmZmBAAAAAAAAAgZYZGMzMDmxMwMNTMYmBAAY2mtNwYzAAwYmZGDmBzMYmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Assicu",
          ["guild"] = "Ascended",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 384123,
          ["ilvl"] = 325,
          ["crit"] = 531,
          ["haste"] = 1810,
          ["mastery"] = 759,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzMGMbzMzMzMDAAAAAAAAAAzwyMYmZGmxMDMTz0YwMDAAwsNbLgxmBAgxYmxgZwMDMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Aski",
          ["guild"] = "Myth",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 381031,
          ["ilvl"] = 322,
          ["crit"] = 741,
          ["haste"] = 1886,
          ["mastery"] = 561,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AmhZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDMTzEDmZAAAmtZbDM2MAAMmZmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "티에카",
          ["guild"] = "신기하게 생겼어",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 378991,
          ["ilvl"] = 325,
          ["crit"] = 1031,
          ["haste"] = 1417,
          ["mastery"] = 771,
          ["vers"] = 53,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMGzwgZbmZmZmZAAAAAAAAAAYGzyMjZYGMmZgZamYwMDAAwsNbbgxmBAgxMzMGMDmZwMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Arrei",
          ["guild"] = "All Good",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 377496,
          ["ilvl"] = 321,
          ["crit"] = 681,
          ["haste"] = 1669,
          ["mastery"] = 558,
          ["vers"] = 274,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250256,
              ["name"] = "Heart of Wind",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtFwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Malløw",
          ["guild"] = "Amazing Stories",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 376984,
          ["ilvl"] = 321,
          ["crit"] = 539,
          ["haste"] = 1758,
          ["mastery"] = 749,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmxYmHghZbmZmZmZAAAAAAAAAAYGWmBzMzwMMjBTz0YwMDAAwsNbbgxmBAgxMzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Pastóoh",
          ["guild"] = "Cutting Bread",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 375572,
          ["ilvl"] = 321,
          ["crit"] = 620,
          ["haste"] = 1431,
          ["mastery"] = 900,
          ["vers"] = 149,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmxYGmhZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "马玲",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 372812,
          ["ilvl"] = 318,
          ["crit"] = 668,
          ["haste"] = 1654,
          ["mastery"] = 695,
          ["vers"] = 41,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmxYmHwgZbmZmZmZAAAAAAAAAAYGWmBzMzghZMYamYwMDAAwsNbbgxmBAgxMzMGmZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Looqp",
          ["guild"] = "The Next Step",
          ["boss"] = "Sszorak",
          ["amount"] = 439597,
          ["ilvl"] = 325,
          ["crit"] = 403,
          ["haste"] = 1885,
          ["mastery"] = 701,
          ["vers"] = 304,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMPAzwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMMjBTz0YwMDAAwsNbbgxmBAgxMzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Brownpriest",
          ["guild"] = "Tokidoki",
          ["boss"] = "Sszorak",
          ["amount"] = 424981,
          ["ilvl"] = 326,
          ["crit"] = 623,
          ["haste"] = 1837,
          ["mastery"] = 557,
          ["vers"] = 228,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYmHwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Perttiina",
          ["guild"] = "Noni",
          ["boss"] = "Sszorak",
          ["amount"] = 421459,
          ["ilvl"] = 325,
          ["crit"] = 653,
          ["haste"] = 1861,
          ["mastery"] = 601,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTjBzMAAAz2stBGbGAAGjZGDmBzMYmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "茭白萌萌哒",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 410313,
          ["ilvl"] = 320,
          ["crit"] = 678,
          ["haste"] = 1565,
          ["mastery"] = 881,
          ["vers"] = 44,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMjZgZamGDmZAAAmtZbDM2MAAMGzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Jakbcastin",
          ["guild"] = "Incarnate",
          ["boss"] = "Sszorak",
          ["amount"] = 408159,
          ["ilvl"] = 326,
          ["crit"] = 339,
          ["haste"] = 1811,
          ["mastery"] = 802,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtNwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "티에카",
          ["guild"] = "신기하게 생겼어",
          ["boss"] = "Sszorak",
          ["amount"] = 404138,
          ["ilvl"] = 320,
          ["crit"] = 701,
          ["haste"] = 1494,
          ["mastery"] = 829,
          ["vers"] = 53,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYmHwgZbmZmZmZAAAAAAAAAAYGzyMjZYGMmZgZamYwMDAAwsNbbgxmBAgxMzMGMDmZwMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Koronoo",
          ["guild"] = "The Reckless",
          ["boss"] = "Sszorak",
          ["amount"] = 400774,
          ["ilvl"] = 325,
          ["crit"] = 196,
          ["haste"] = 1734,
          ["mastery"] = 889,
          ["vers"] = 424,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzMwMbzMzMzMDAAAAAAAAAAzwyMYmZGmhZgZamGDmZAAAmtZbBM2MAAMGzMGMDmZwMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Clandon",
          ["guild"] = "Vindicatum",
          ["boss"] = "Sszorak",
          ["amount"] = 395779,
          ["ilvl"] = 322,
          ["crit"] = 534,
          ["haste"] = 1802,
          ["mastery"] = 659,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtFwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "马玲",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 394756,
          ["ilvl"] = 322,
          ["crit"] = 536,
          ["haste"] = 1931,
          ["mastery"] = 683,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AmhZbmZmZmZAAAAAAAAAAYGWmBzMzghZMYamYwMDAAwsNbbgxmBAgxMzMGmZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Assicu",
          ["guild"] = "Ascended",
          ["boss"] = "Sszorak",
          ["amount"] = 385164,
          ["ilvl"] = 325,
          ["crit"] = 531,
          ["haste"] = 1810,
          ["mastery"] = 759,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzMGMbzMzMzMDAAAAAAAAAAzwyMYmZGmxMDMTz0YwMDAAwsNbLgxmBAgxYmxgZwMDMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Looqp",
          ["guild"] = "The Next Step",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 436625,
          ["ilvl"] = 325,
          ["crit"] = 403,
          ["haste"] = 1885,
          ["mastery"] = 701,
          ["vers"] = 304,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMGzwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMMjBTz0YwMDAAwsNbbgxmBAgxMzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Sushe",
          ["guild"] = "Opposite",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 426787,
          ["ilvl"] = 323,
          ["crit"] = 360,
          ["haste"] = 1999,
          ["mastery"] = 648,
          ["vers"] = 275,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMGzwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbDM2MAAMGzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Plapla",
          ["guild"] = "ToYz",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 424315,
          ["ilvl"] = 325,
          ["crit"] = 540,
          ["haste"] = 1802,
          ["mastery"] = 699,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmxYGmhZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0YwMDAAwsNbbgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "티에카",
          ["guild"] = "신기하게 생겼어",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 421033,
          ["ilvl"] = 325,
          ["crit"] = 1031,
          ["haste"] = 1417,
          ["mastery"] = 771,
          ["vers"] = 53,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMGzwgZbmZmZmZAAAAAAAAAAYGzyMjZYGMmZgZamYwMDAAwsNbbgxmBAgxMzMGMDmZwMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Stopthecount",
          ["guild"] = "Speakeasy",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 418286,
          ["ilvl"] = 323,
          ["crit"] = 523,
          ["haste"] = 1849,
          ["mastery"] = 655,
          ["vers"] = 281,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYGMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDMTz0MDmZAAAmtZbBM2MAAMGzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Atrocity",
          ["guild"] = "Lucid",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 417164,
          ["ilvl"] = 322,
          ["crit"] = 437,
          ["haste"] = 1567,
          ["mastery"] = 763,
          ["vers"] = 215,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmxYGMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Perttiina",
          ["guild"] = "Noni",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 415878,
          ["ilvl"] = 326,
          ["crit"] = 646,
          ["haste"] = 1857,
          ["mastery"] = 597,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTjBzMAAAz2stBGbGAAGjZGDmBzMYmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Mheeveon",
          ["guild"] = "Availed",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 412240,
          ["ilvl"] = 322,
          ["crit"] = 626,
          ["haste"] = 1842,
          ["mastery"] = 608,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZwmpZaMYmBAAY2mtFwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Lightsh",
          ["guild"] = "Slurp Squad",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 412135,
          ["ilvl"] = 326,
          ["crit"] = 764,
          ["haste"] = 1775,
          ["mastery"] = 585,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzMGMbzMzMzMDAAAAAAAAAAzwyMYmZGmxMDYamYwMDAAwsNbbgxmBAgxMzMGMDmZwMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Jakbcastin",
          ["guild"] = "Incarnate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 412014,
          ["ilvl"] = 326,
          ["crit"] = 270,
          ["haste"] = 1844,
          ["mastery"] = 802,
          ["vers"] = 273,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtNwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Jakbcastin",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 433743,
          ["ilvl"] = 326,
          ["crit"] = 270,
          ["haste"] = 1844,
          ["mastery"] = 802,
          ["vers"] = 273,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtNwYzAAwYMzYwMYmBjgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Pharapriest",
          ["guild"] = "Quichons",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 432990,
          ["ilvl"] = 323,
          ["crit"] = 561,
          ["haste"] = 1778,
          ["mastery"] = 518,
          ["vers"] = 308,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzMMMbzMzMzMDAAAAAAAAAAzwyMYmZGmxMDYammZwMDAAwsNbbgxmBAgxYmxgZwMDMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Lynmd",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 431617,
          ["ilvl"] = 327,
          ["crit"] = 442,
          ["haste"] = 1943,
          ["mastery"] = 570,
          ["vers"] = 99,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtNwYzAAwYMzYwMYmBmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Looqp",
          ["guild"] = "The Next Step",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 431182,
          ["ilvl"] = 325,
          ["crit"] = 404,
          ["haste"] = 1887,
          ["mastery"] = 701,
          ["vers"] = 304,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzwMGMNTjBzMAAAz2stBGbGAAGzMzYwMYmBmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Liebrepriest",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 423447,
          ["ilvl"] = 326,
          ["crit"] = 471,
          ["haste"] = 1703,
          ["mastery"] = 949,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMzMDYamGDmZAAAmtZbBM2MAAMGzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Aski",
          ["guild"] = "Myth",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 419049,
          ["ilvl"] = 324,
          ["crit"] = 702,
          ["haste"] = 1917,
          ["mastery"] = 609,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMjZgZamYwMDAAwsNbbgxmBAgxMzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Keenpr",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 417731,
          ["ilvl"] = 327,
          ["crit"] = 231,
          ["haste"] = 1713,
          ["mastery"] = 898,
          ["vers"] = 274,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMjZATz0MDmZAAAmtZbDM2MAAMGzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Fistofpell",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 406148,
          ["ilvl"] = 325,
          ["crit"] = 670,
          ["haste"] = 1672,
          ["mastery"] = 943,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMbzsNzMzMzAAAAAAAAAAgZYZGMzMDzYmBMNTjBzMAAAz2stBGbGAAGzMzYwMYmBmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Dokwhite",
          ["guild"] = "baited",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 399906,
          ["ilvl"] = 326,
          ["crit"] = 891,
          ["haste"] = 1341,
          ["mastery"] = 870,
          ["vers"] = 203,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtNwYzAAwYMzYwMYmBmgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Elaka",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 398076,
          ["ilvl"] = 325,
          ["crit"] = 474,
          ["haste"] = 1981,
          ["mastery"] = 698,
          ["vers"] = 225,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzwMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZgJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Jcbami",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 328121,
          ["ilvl"] = 324,
          ["crit"] = 695,
          ["haste"] = 1948,
          ["mastery"] = 691,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYGMmZbmZmZmZAAAAAAAAAAYmZWmBzMzgxMDYamYwMDAAwsNbbgxmBAgxMmxwMDmZwMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "马玲",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 322395,
          ["ilvl"] = 319,
          ["crit"] = 676,
          ["haste"] = 1781,
          ["mastery"] = 581,
          ["vers"] = 41,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AGmZbmZmZmZAAAAAAAAAAYGWmBzMzghZMYamYwMDAAwsNbbgxmBAgxMzMGmZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Procture",
          ["guild"] = "Epoch",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 322390,
          ["ilvl"] = 315,
          ["crit"] = 328,
          ["haste"] = 1798,
          ["mastery"] = 776,
          ["vers"] = 42,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AGmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDMTzEDmZAAAmtZbBM2MAAMmZmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Sephiroze",
          ["guild"] = "순 삭",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 318840,
          ["ilvl"] = 323,
          ["crit"] = 316,
          ["haste"] = 1846,
          ["mastery"] = 915,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMmZbmZmZmZAAAAAAAAAAYGWmBzMzgxMDYammZwMDAAwsNbbgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Sepi",
          ["guild"] = "Notion",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 318708,
          ["ilvl"] = 322,
          ["crit"] = 585,
          ["haste"] = 1792,
          ["mastery"] = 704,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDMTz0YwMDAAwsNbLgxmBAgxYmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "티에카",
          ["guild"] = "신기하게 생겼어",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 314113,
          ["ilvl"] = 320,
          ["crit"] = 701,
          ["haste"] = 1494,
          ["mastery"] = 829,
          ["vers"] = 53,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYmHwgZbmZmZmZAAAAAAAAAAYGzyMjZYGMmZgZamYwMDAAwsNbbgxmBAgxMzMGMDmZwMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Hunttay",
          ["guild"] = "vodka",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 313211,
          ["ilvl"] = 320,
          ["crit"] = 701,
          ["haste"] = 1744,
          ["mastery"] = 750,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzMMMbzMzMzMDAAAAAAAAAAzwyMYmZGmxMDYammZwMDAAwsNbbgxmBAgxYmxgZwMDMBD",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Brownpriest",
          ["guild"] = "Tokidoki",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 312467,
          ["ilvl"] = 324,
          ["crit"] = 696,
          ["haste"] = 1697,
          ["mastery"] = 609,
          ["vers"] = 228,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyMzMYmHwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATz0MDmZAAAmtZbBM2MAAMGzMGMDmZwIYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Celestix",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 308291,
          ["ilvl"] = 322,
          ["crit"] = 414,
          ["haste"] = 3557,
          ["mastery"] = 902,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AMmZbmZmZmZAAAAAAAAAAYGWmBzMzghZATz0MDmZAAAmtZbBM2MAAMGzMGmZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        },
        {
          ["name"] = "Aleks",
          ["guild"] = "Toy Bagels",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 305828,
          ["ilvl"] = 322,
          ["crit"] = 386,
          ["haste"] = 1957,
          ["mastery"] = 816,
          ["vers"] = 222,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBz8AmhZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATzEDmZAAAmtZbDM2MAAMmZmxgZwMDmJYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "inv_ability_voidweaverpriest_entropicrift"
          }
        }
      }
    },
    {
      ["spec"] = "Holy",
      ["role"] = "healer",
      ["metric"] = "HPS",
      ["players"] = {
        {
          ["name"] = "Sunri",
          ["guild"] = "K E K L E O",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 418491,
          ["ilvl"] = 318,
          ["crit"] = 1151,
          ["haste"] = 489,
          ["mastery"] = 1010,
          ["vers"] = 296,
          ["trinkets"] = {
            {
              ["id"] = 264507,
              ["name"] = "Crucible of Erratic Energies",
              ["ilvl"] = 295
            },
            {
              ["id"] = 268292,
              ["name"] = "Sporelord's Mycelial Insignia",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZKAmZBDhxsMAjBWMzMLAMjZGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Tobii",
          ["guild"] = "aware",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 416377,
          ["ilvl"] = 319,
          ["crit"] = 1181,
          ["haste"] = 645,
          ["mastery"] = 1100,
          ["vers"] = 39,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmZMDzwMjZMgZqBwMLYIMmtBYMwiZmZBAjZGDMzAMzMDMA",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "一可樂一",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 413215,
          ["ilvl"] = 324,
          ["crit"] = 1381,
          ["haste"] = 516,
          ["mastery"] = 1085,
          ["vers"] = 99,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMzYmlZYGAAAAzYWmBzMzwMjZAMTNAmZBDhxsMAjBWMzMLAYMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Smìte",
          ["guild"] = "forever the sickest kids",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 410056,
          ["ilvl"] = 325,
          ["crit"] = 1031,
          ["haste"] = 466,
          ["mastery"] = 1388,
          ["vers"] = 327,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTNAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "脆皮糖",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 408630,
          ["ilvl"] = 322,
          ["crit"] = 1367,
          ["haste"] = 543,
          ["mastery"] = 1173,
          ["vers"] = 58,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "힐마에",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 404578,
          ["ilvl"] = 319,
          ["crit"] = 1246,
          ["haste"] = 563,
          ["mastery"] = 918,
          ["vers"] = 209,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZmhZmhlZYGAAAAzwyMYmZGmxMDgZKAmZDDhxsMAjBWMzMLAMjxMjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "暮予",
          ["guild"] = "剑心犹在",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 401500,
          ["ilvl"] = 323,
          ["crit"] = 1332,
          ["haste"] = 593,
          ["mastery"] = 1033,
          ["vers"] = 59,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 268292,
              ["name"] = "Sporelord's Mycelial Insignia",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMzYmlZYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Massdispel",
          ["guild"] = "Die Schattenwölfe",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 401074,
          ["ilvl"] = 320,
          ["crit"] = 1212,
          ["haste"] = 651,
          ["mastery"] = 878,
          ["vers"] = 124,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzwyMYmZGmZMDgZqBwMLYIMmlBYMwiZmZBgZYGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Saberinad",
          ["guild"] = "B L C",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 399890,
          ["ilvl"] = 320,
          ["crit"] = 1114,
          ["haste"] = 861,
          ["mastery"] = 828,
          ["vers"] = 139,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmZMjHYGmZMDgZqBwMLYIMmtBYMwiZmZBADzYMMzAMzMDMA",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "豆仔丶",
          ["guild"] = "清  辰",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 397924,
          ["ilvl"] = 326,
          ["crit"] = 1145,
          ["haste"] = 601,
          ["mastery"] = 1210,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmZMjHYGmZMDgZqBwMLYIMmlBYMwiZmZBgZwYMMzAMzMDMA",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Fizzyowo",
          ["guild"] = "Something Clever",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 476539,
          ["ilvl"] = 320,
          ["crit"] = 1290,
          ["haste"] = 590,
          ["mastery"] = 928,
          ["vers"] = 144,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTBwMbYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "一个人灬流浪",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 471869,
          ["ilvl"] = 320,
          ["crit"] = 1020,
          ["haste"] = 1034,
          ["mastery"] = 580,
          ["vers"] = 286,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMzYmlZYGAAAAzYWmBzMzgxMjBMTBwMLYIMmlBYMwiZmZBgZYGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "乔八牧",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 470419,
          ["ilvl"] = 319,
          ["crit"] = 1328,
          ["haste"] = 637,
          ["mastery"] = 703,
          ["vers"] = 302,
          ["trinkets"] = {
            {
              ["id"] = 156245,
              ["name"] = "Show of Faith",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTNAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Aylinpriest",
          ["guild"] = "Hostile",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 469721,
          ["ilvl"] = 320,
          ["crit"] = 887,
          ["haste"] = 459,
          ["mastery"] = 942,
          ["vers"] = 738,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMbYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "暮予",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 468901,
          ["ilvl"] = 327,
          ["crit"] = 1179,
          ["haste"] = 568,
          ["mastery"] = 1088,
          ["vers"] = 219,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMzYmlZYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "哎呀奶不到",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 468445,
          ["ilvl"] = 324,
          ["crit"] = 1357,
          ["haste"] = 298,
          ["mastery"] = 1173,
          ["vers"] = 181,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMzYmlZYGAAAAzYWmBzMzwMMjBMTNAmZBDhxsMAjBWMzMLAYYGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "沐沐喵",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 466736,
          ["ilvl"] = 322,
          ["crit"] = 811,
          ["haste"] = 827,
          ["mastery"] = 1270,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMjZwGmpAYmFMEGzyAMGYxMzsAwMGjxgZAmZmBGA",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "魔法少女咸鱼",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 463884,
          ["ilvl"] = 322,
          ["crit"] = 1237,
          ["haste"] = 864,
          ["mastery"] = 579,
          ["vers"] = 236,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZKAmZBDhxsMAjBWMzMLAMjZGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "허연쥐",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 462217,
          ["ilvl"] = 323,
          ["crit"] = 1238,
          ["haste"] = 328,
          ["mastery"] = 1113,
          ["vers"] = 281,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzMWmBzMzwMmZAMTNAmZDDhxsMAjBWMzMLAMjxYMMzAMzMgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "星丨与海",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 456786,
          ["ilvl"] = 321,
          ["crit"] = 1183,
          ["haste"] = 552,
          ["mastery"] = 1110,
          ["vers"] = 91,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTNAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 421790,
          ["ilvl"] = 320,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "野原炘之助",
          ["guild"] = "繁梦之末",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 419681,
          ["ilvl"] = 321,
          ["crit"] = 1136,
          ["haste"] = 830,
          ["mastery"] = 587,
          ["vers"] = 335,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMD2wM1AYmFMEGz2AMGYxMzsAwMzYMGMDwMjBGA",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "暮予",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 412678,
          ["ilvl"] = 327,
          ["crit"] = 1226,
          ["haste"] = 596,
          ["mastery"] = 1085,
          ["vers"] = 123,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMzYmlZYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Sinikettu",
          ["guild"] = "Muisted",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 407505,
          ["ilvl"] = 326,
          ["crit"] = 968,
          ["haste"] = 802,
          ["mastery"] = 1160,
          ["vers"] = 302,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "冰心时雨",
          ["guild"] = "圣糖刺客",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 407158,
          ["ilvl"] = 325,
          ["crit"] = 1296,
          ["haste"] = 659,
          ["mastery"] = 947,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBgZMzYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Chai",
          ["guild"] = "No Skill",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 401303,
          ["ilvl"] = 324,
          ["crit"] = 1292,
          ["haste"] = 698,
          ["mastery"] = 992,
          ["vers"] = 180,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMzYmlZYGAAAAzYWmBzMzYbGzMsAzUAMzCGCjZbAGDsYmZWAYGjxYwMAzMGYA",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Likenarisa",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 399324,
          ["ilvl"] = 324,
          ["crit"] = 1274,
          ["haste"] = 923,
          ["mastery"] = 583,
          ["vers"] = 356,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzwyMMzMzwMjZAMTNAmZBDhxsNAjBWMzMLAYYGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Frutzipray",
          ["guild"] = "Wipe Fest",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 397470,
          ["ilvl"] = 319,
          ["crit"] = 1218,
          ["haste"] = 258,
          ["mastery"] = 1018,
          ["vers"] = 436,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBgZYGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Huninn",
          ["guild"] = "mythic raid guild",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 397381,
          ["ilvl"] = 320,
          ["crit"] = 1168,
          ["haste"] = 532,
          ["mastery"] = 868,
          ["vers"] = 366,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzMziZMzMzwMjZAMTNAmZBDhxsMAjBWMzMLAMjBjBzAMzMDMA",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "在家也挺好",
          ["guild"] = "Somnium",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 396973,
          ["ilvl"] = 322,
          ["crit"] = 998,
          ["haste"] = 728,
          ["mastery"] = 1118,
          ["vers"] = 154,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMzYmlZYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBgZYGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Tobii",
          ["guild"] = "aware",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 469106,
          ["ilvl"] = 319,
          ["crit"] = 1181,
          ["haste"] = 645,
          ["mastery"] = 1100,
          ["vers"] = 39,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmZMDzwMjZMgZqBwMLYIMmtBYMwiZmZBAjZGDMzAMzMDMA",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Likenarisa",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 463205,
          ["ilvl"] = 324,
          ["crit"] = 1274,
          ["haste"] = 923,
          ["mastery"] = 583,
          ["vers"] = 356,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzwyMMzMzwMjZAMTNAmZBDhxsNAjBWMzMLAYYGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "蒼月銀雪",
          ["guild"] = "罗德岛骑士团",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 457243,
          ["ilvl"] = 324,
          ["crit"] = 1395,
          ["haste"] = 546,
          ["mastery"] = 1043,
          ["vers"] = 31,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWmZmxMjhZYmlZGzAAAAYGzyMYmZGmZMDgZqBwMLYIMmlBYMwiZmBAzYMGDmBYmZGYA",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "玹丶牧",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 455684,
          ["ilvl"] = 323,
          ["crit"] = 1184,
          ["haste"] = 574,
          ["mastery"] = 974,
          ["vers"] = 284,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTNAmZBDhxsMAjBWMzMLAMDzYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "譕丶痕",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 454280,
          ["ilvl"] = 326,
          ["crit"] = 1240,
          ["haste"] = 511,
          ["mastery"] = 1201,
          ["vers"] = 64,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzgZMDgZqBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "丷可爱多丷",
          ["guild"] = "弯仔码头",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 448354,
          ["ilvl"] = 319,
          ["crit"] = 1176,
          ["haste"] = 512,
          ["mastery"] = 1179,
          ["vers"] = 58,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMLYIMmtBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "怜爱",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 447890,
          ["ilvl"] = 321,
          ["crit"] = 1151,
          ["haste"] = 530,
          ["mastery"] = 1424,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTNAmZBDhxsMAjBWMzMLAYMzYMMzAMzMgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "硌手的小善子",
          ["guild"] = "Septem Peccata Mortalia",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 445836,
          ["ilvl"] = 317,
          ["crit"] = 1264,
          ["haste"] = 812,
          ["mastery"] = 818,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMzYmlZYGAAAAzYWmBzMzwMjZAMTNAmZBDhxsMAjBWMzMLAYMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Curelight",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 445690,
          ["ilvl"] = 321,
          ["crit"] = 1256,
          ["haste"] = 480,
          ["mastery"] = 1211,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTNAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "晒太阳好舒服",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 445630,
          ["ilvl"] = 323,
          ["crit"] = 1295,
          ["haste"] = 520,
          ["mastery"] = 1271,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Deoxx",
          ["guild"] = "Advent",
          ["boss"] = "Sszorak",
          ["amount"] = 476943,
          ["ilvl"] = 324,
          ["crit"] = 1229,
          ["haste"] = 795,
          ["mastery"] = 943,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTBwMLYIMmtBYMwiZmZBgZMzYMMzAMzMgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Hólymòly",
          ["guild"] = "rotten apples",
          ["boss"] = "Sszorak",
          ["amount"] = 470285,
          ["ilvl"] = 323,
          ["crit"] = 1137,
          ["haste"] = 710,
          ["mastery"] = 974,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzMWmBzMzwMzMDgZqBwMLYIMmlBYMwiZmZBgZMGjBzAMzYgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "天使晚晚",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 467626,
          ["ilvl"] = 324,
          ["crit"] = 1174,
          ["haste"] = 806,
          ["mastery"] = 921,
          ["vers"] = 208,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMzMDgZKAmZBDhxsMAjBWMzMLAMDGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Wujuz",
          ["guild"] = "No Shame",
          ["boss"] = "Sszorak",
          ["amount"] = 466050,
          ["ilvl"] = 321,
          ["crit"] = 1577,
          ["haste"] = 363,
          ["mastery"] = 1019,
          ["vers"] = 219,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Stopthecount",
          ["guild"] = "Speakeasy",
          ["boss"] = "Sszorak",
          ["amount"] = 464770,
          ["ilvl"] = 323,
          ["crit"] = 1329,
          ["haste"] = 865,
          ["mastery"] = 631,
          ["vers"] = 331,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "凌乱丶华丽",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 461561,
          ["ilvl"] = 327,
          ["crit"] = 1240,
          ["haste"] = 607,
          ["mastery"] = 1128,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTNAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Smìte",
          ["guild"] = "forever the sickest kids",
          ["boss"] = "Sszorak",
          ["amount"] = 458828,
          ["ilvl"] = 323,
          ["crit"] = 893,
          ["haste"] = 742,
          ["mastery"] = 1184,
          ["vers"] = 327,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "冰心时雨",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 457300,
          ["ilvl"] = 323,
          ["crit"] = 1296,
          ["haste"] = 649,
          ["mastery"] = 925,
          ["vers"] = 181,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTBwMLYIMmlBYMwiZmZBgZMzYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Seventeen",
          ["guild"] = "Reunion",
          ["boss"] = "Sszorak",
          ["amount"] = 453732,
          ["ilvl"] = 325,
          ["crit"] = 1128,
          ["haste"] = 688,
          ["mastery"] = 1092,
          ["vers"] = 228,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Sàssy",
          ["guild"] = "Banelings",
          ["boss"] = "Sszorak",
          ["amount"] = 452278,
          ["ilvl"] = 322,
          ["crit"] = 1443,
          ["haste"] = 365,
          ["mastery"] = 1069,
          ["vers"] = 162,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzMWmBzMzwMjZAMTNAmZBDhxsMAjBWMzMLAMDGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "等一场落雨",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 489615,
          ["ilvl"] = 324,
          ["crit"] = 1283,
          ["haste"] = 557,
          ["mastery"] = 997,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTNAmZBDhxsMAjBWMzMLAMDGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Oqur",
          ["guild"] = "Blur",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 477016,
          ["ilvl"] = 325,
          ["crit"] = 1054,
          ["haste"] = 423,
          ["mastery"] = 1124,
          ["vers"] = 394,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMzMDgZKAmZBDhxsNAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Convess",
          ["guild"] = "Innervision",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 460284,
          ["ilvl"] = 323,
          ["crit"] = 1053,
          ["haste"] = 574,
          ["mastery"] = 1230,
          ["vers"] = 116,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMzMDgZqBwMLYIMmlBYMwiZmZBgZMGjBzAMzYgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Sgtcookiez",
          ["guild"] = "Fierce",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 457270,
          ["ilvl"] = 328,
          ["crit"] = 1097,
          ["haste"] = 718,
          ["mastery"] = 1075,
          ["vers"] = 131,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMzMDgZKAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "凌乱丶华丽",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 456379,
          ["ilvl"] = 327,
          ["crit"] = 1272,
          ["haste"] = 589,
          ["mastery"] = 1114,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTNAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Hyta",
          ["guild"] = "Divinum",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 456063,
          ["ilvl"] = 322,
          ["crit"] = 1203,
          ["haste"] = 797,
          ["mastery"] = 1155,
          ["vers"] = 14,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Sellingpi",
          ["guild"] = "Nerd Rage",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 455383,
          ["ilvl"] = 323,
          ["crit"] = 1176,
          ["haste"] = 745,
          ["mastery"] = 1164,
          ["vers"] = 178,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMzMDgZKAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "마주넹",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 455363,
          ["ilvl"] = 323,
          ["crit"] = 904,
          ["haste"] = 693,
          ["mastery"] = 1253,
          ["vers"] = 296,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Hannavi",
          ["guild"] = "Rewind",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 454706,
          ["ilvl"] = 324,
          ["crit"] = 1086,
          ["haste"] = 556,
          ["mastery"] = 1040,
          ["vers"] = 286,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzMzyMMzMzYbGzMsAzUDgZWwQYMLDwYgFzMzCAzAGDmBYmxAD",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "白白的小月亮",
          ["guild"] = "Dim Moon",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 452170,
          ["ilvl"] = 326,
          ["crit"] = 1258,
          ["haste"] = 567,
          ["mastery"] = 1228,
          ["vers"] = 141,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMzMDgZqBwMLYIMmlBYMwiZmZBgZwYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 439959,
          ["ilvl"] = 332,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Yup",
          ["guild"] = "Ethical",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 388829,
          ["ilvl"] = 324,
          ["crit"] = 1366,
          ["haste"] = 488,
          ["mastery"] = 1067,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Ula'tek",
          ["amount"] = 461807,
          ["ilvl"] = 331,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Fistofpell",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 456841,
          ["ilvl"] = 329,
          ["crit"] = 1356,
          ["haste"] = 665,
          ["mastery"] = 976,
          ["vers"] = 224,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Niyas",
          ["guild"] = "Salt Mines",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 397051,
          ["ilvl"] = 321,
          ["crit"] = 1115,
          ["haste"] = 629,
          ["mastery"] = 878,
          ["vers"] = 306,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTBwMbYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "爆炒茄子",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 396577,
          ["ilvl"] = 319,
          ["crit"] = 787,
          ["haste"] = 1227,
          ["mastery"] = 1028,
          ["vers"] = 52,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzMzyMYGzwMMDYMTNAmZBDhxsMAjBWMzMLAMjxDMzMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Ihwimsm",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 393775,
          ["ilvl"] = 318,
          ["crit"] = 969,
          ["haste"] = 941,
          ["mastery"] = 965,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 268292,
              ["name"] = "Sporelord's Mycelial Insignia",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMjZAMTNAmZBDhxsMAjBWMzMLAYYGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Jibrael",
          ["guild"] = "Sustained",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 392823,
          ["ilvl"] = 323,
          ["crit"] = 1128,
          ["haste"] = 742,
          ["mastery"] = 954,
          ["vers"] = 163,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMbYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Davepls",
          ["guild"] = "Competence Optional",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 390328,
          ["ilvl"] = 322,
          ["crit"] = 1154,
          ["haste"] = 798,
          ["mastery"] = 821,
          ["vers"] = 222,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMzMDgZKAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "南澄",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 388716,
          ["ilvl"] = 322,
          ["crit"] = 1026,
          ["haste"] = 598,
          ["mastery"] = 1317,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "凌乱丶华丽",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 386886,
          ["ilvl"] = 327,
          ["crit"] = 1240,
          ["haste"] = 607,
          ["mastery"] = 1128,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTNAmZBDhxsMAjBWMzMLAMjxYMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "泪眼忆小伦",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 386618,
          ["ilvl"] = 320,
          ["crit"] = 772,
          ["haste"] = 871,
          ["mastery"] = 1113,
          ["vers"] = 249,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250256,
              ["name"] = "Heart of Wind",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzMzyMYGzwMMDYMTNAmZBDhxsNAjBWMzMLAMjxDMzMYGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Desinanisea",
          ["guild"] = "Voljin and Tonic",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 386491,
          ["ilvl"] = 321,
          ["crit"] = 1220,
          ["haste"] = 792,
          ["mastery"] = 505,
          ["vers"] = 521,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBgZMGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        },
        {
          ["name"] = "Meiriona",
          ["guild"] = "Dragons",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 386257,
          ["ilvl"] = 322,
          ["crit"] = 1202,
          ["haste"] = 753,
          ["mastery"] = 1058,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZKAmZBDhxsMAjBWMzMLAMjZGjhZGgZmZgB",
          ["hero"] = {
            ["name"] = "Oracle",
            ["atlas"] = "talents-heroclass-priest-oracle",
            ["icon"] = "ability_priest_holywordlife"
          }
        }
      }
    },
    {
      ["spec"] = "Shadow",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "桃桃呜龙",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 223534,
          ["ilvl"] = 315,
          ["crit"] = 647,
          ["haste"] = 1187,
          ["mastery"] = 1064,
          ["vers"] = 60,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzY2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Adeliya",
          ["guild"] = "Burden",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 222541,
          ["ilvl"] = 325,
          ["crit"] = 660,
          ["haste"] = 976,
          ["mastery"] = 1308,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Umbrasp",
          ["guild"] = "Jade Falcons",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 218749,
          ["ilvl"] = 322,
          ["crit"] = 748,
          ["haste"] = 978,
          ["mastery"] = 1288,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Vil",
          ["guild"] = "Denial of Service",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 216711,
          ["ilvl"] = 326,
          ["crit"] = 764,
          ["haste"] = 986,
          ["mastery"] = 1281,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "瓜皮辣鸡",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 216295,
          ["ilvl"] = 326,
          ["crit"] = 700,
          ["haste"] = 1024,
          ["mastery"] = 1181,
          ["vers"] = 954,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzM2MzYmZGGTGYmGDMDwMbmhZxAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "虚空齐射",
          ["guild"] = "旧雨",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215060,
          ["ilvl"] = 324,
          ["crit"] = 893,
          ["haste"] = 926,
          ["mastery"] = 1067,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzY2MzYmZmZDZYzMNAzAMzmZYWMAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Shinsha",
          ["guild"] = "Landslide",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215002,
          ["ilvl"] = 324,
          ["crit"] = 1005,
          ["haste"] = 812,
          ["mastery"] = 1123,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Xvoidgazs",
          ["guild"] = "Rage Against the Meta",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 214526,
          ["ilvl"] = 321,
          ["crit"] = 799,
          ["haste"] = 959,
          ["mastery"] = 1194,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGQGYmmZgZAmZzMMbGAyYsAgZGwYmZGzmZmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Gigamehh",
          ["guild"] = "Wave",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 213078,
          ["ilvl"] = 324,
          ["crit"] = 1015,
          ["haste"] = 870,
          ["mastery"] = 1199,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzM2mxYmZGbIDLbz0AMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Rea",
          ["guild"] = "Edict",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 212813,
          ["ilvl"] = 320,
          ["crit"] = 652,
          ["haste"] = 748,
          ["mastery"] = 1354,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 156288,
              ["name"] = "Elemental Focus Stone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGYyMYmGDMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Grendini",
          ["guild"] = "Fragglene",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 249041,
          ["ilvl"] = 324,
          ["crit"] = 944,
          ["haste"] = 798,
          ["mastery"] = 1288,
          ["vers"] = 138,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 156021,
              ["name"] = "Energy Siphon",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPwAAAAAAAAAAAAMMLmxMbzMmZ2mxYG2GzYmZGbjJDMTjBmBYmNzwsZAIjxCAGjBjZmZMbMz2yAMDGA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Burritok",
          ["guild"] = "Might",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 248091,
          ["ilvl"] = 324,
          ["crit"] = 872,
          ["haste"] = 946,
          ["mastery"] = 1196,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPwAAAAAAAAAAAAMMLmxMbzMmZ2mxYG2GzYmZGbjJDMTjBmBYmNzwsZAIjxCAGjBjZmZMbMz2yAMDGA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Oblivionis",
          ["guild"] = "醉星辰",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 246932,
          ["ilvl"] = 325,
          ["crit"] = 750,
          ["haste"] = 997,
          ["mastery"] = 1136,
          ["vers"] = 152,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYGzmZGzMzATmBz0YgZAmZzMMbGAyYsAgZGDGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Salmer",
          ["guild"] = "Consequence",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 244643,
          ["ilvl"] = 326,
          ["crit"] = 1014,
          ["haste"] = 822,
          ["mastery"] = 1072,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYmxgxMzMmFmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "박근수",
          ["guild"] = "Mate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 244002,
          ["ilvl"] = 327,
          ["crit"] = 884,
          ["haste"] = 824,
          ["mastery"] = 1183,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPwAAAAAAAAAAAAMMLmxMbzMmZ2mxYG2mZGzMzwQzAz0MDMDwMbmhZzAQGjFAMGDGzMzY2YmtlBwgB",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Truckdog",
          ["guild"] = "Pig Pen",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 240725,
          ["ilvl"] = 326,
          ["crit"] = 748,
          ["haste"] = 1010,
          ["mastery"] = 1291,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzwQzAz0MDMDwMbmhZzAQGjFAMzYwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Snowgigarat",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 240455,
          ["ilvl"] = 327,
          ["crit"] = 714,
          ["haste"] = 1157,
          ["mastery"] = 1105,
          ["vers"] = 187,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzwQzAz0MDMDwMbmhZzAQGjFAMzYwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Ristarte",
          ["guild"] = "Doomed",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 240189,
          ["ilvl"] = 326,
          ["crit"] = 733,
          ["haste"] = 978,
          ["mastery"] = 1210,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYmxgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Warklaw",
          ["guild"] = "Honestly",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 239025,
          ["ilvl"] = 329,
          ["crit"] = 741,
          ["haste"] = 1011,
          ["mastery"] = 1420,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 344
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIDMTjBmBYmNzwsYAIjxCAmZAjZmZMbmZ2WGgZwA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Atemix",
          ["guild"] = "WICKED",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 238425,
          ["ilvl"] = 325,
          ["crit"] = 991,
          ["haste"] = 759,
          ["mastery"] = 1207,
          ["vers"] = 44,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzATGYmmZgZAmZzMMbGAyYsAgZGDGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Odman",
          ["guild"] = "Tauren Milfs",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 308537,
          ["ilvl"] = 325,
          ["crit"] = 782,
          ["haste"] = 990,
          ["mastery"] = 1075,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbMZGMTDwMAzsZGmNDAZMWAwMDYMzMjZjZ2WGgZwA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "风度丶",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 303475,
          ["ilvl"] = 326,
          ["crit"] = 1019,
          ["haste"] = 899,
          ["mastery"] = 1167,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzY2MzYmZGbMZYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 289216,
          ["ilvl"] = 322,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "月萌萌",
          ["guild"] = "MR",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 288417,
          ["ilvl"] = 318,
          ["crit"] = 986,
          ["haste"] = 912,
          ["mastery"] = 1078,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzM2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Faintpriest",
          ["guild"] = "constant",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 285659,
          ["ilvl"] = 324,
          ["crit"] = 1047,
          ["haste"] = 798,
          ["mastery"] = 1255,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Grendini",
          ["guild"] = "Fragglene",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 284945,
          ["ilvl"] = 321,
          ["crit"] = 926,
          ["haste"] = 881,
          ["mastery"] = 1226,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 156021,
              ["name"] = "Energy Siphon",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "隠杏珠",
          ["guild"] = "BabyMonster",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 284340,
          ["ilvl"] = 324,
          ["crit"] = 982,
          ["haste"] = 848,
          ["mastery"] = 1063,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MGzMzYBNzYxMNDYGgZ2MDzmBgMGLAYmBMmZmxsxMbLDgBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Oblivionis",
          ["guild"] = "醉星辰",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 284069,
          ["ilvl"] = 327,
          ["crit"] = 740,
          ["haste"] = 928,
          ["mastery"] = 1240,
          ["vers"] = 152,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzY2MzYmZGYyMYmGDMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Rvivr",
          ["guild"] = "K L I K A",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 283916,
          ["ilvl"] = 323,
          ["crit"] = 871,
          ["haste"] = 981,
          ["mastery"] = 1135,
          ["vers"] = 153,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Snowgigarat",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 283204,
          ["ilvl"] = 327,
          ["crit"] = 714,
          ["haste"] = 1157,
          ["mastery"] = 1105,
          ["vers"] = 187,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2YGzMzwYyAz0MDMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Roccorpii",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 325149,
          ["ilvl"] = 324,
          ["crit"] = 645,
          ["haste"] = 1053,
          ["mastery"] = 1126,
          ["vers"] = 380,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYmxgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Snowgigarat",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 316474,
          ["ilvl"] = 327,
          ["crit"] = 714,
          ["haste"] = 1157,
          ["mastery"] = 1105,
          ["vers"] = 187,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzwQzAz0MDMDwMbmhZzAQGjFAMzYwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Elise",
          ["guild"] = "Just Woke Up",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 312588,
          ["ilvl"] = 326,
          ["crit"] = 905,
          ["haste"] = 749,
          ["mastery"] = 1239,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzATGYmmZgZAmZzMMbGAyYsAgZGDGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Parsetumor",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 309337,
          ["ilvl"] = 326,
          ["crit"] = 845,
          ["haste"] = 906,
          ["mastery"] = 1181,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzYjJDLmpBYGgZ2MDzmBgMGLAYmxgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Atemix",
          ["guild"] = "WICKED",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 308191,
          ["ilvl"] = 325,
          ["crit"] = 991,
          ["haste"] = 759,
          ["mastery"] = 1207,
          ["vers"] = 44,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzATGYmmZgZAmZzMMbGAyYsAgZGDGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Coffeep",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 308032,
          ["ilvl"] = 325,
          ["crit"] = 928,
          ["haste"] = 891,
          ["mastery"] = 1136,
          ["vers"] = 183,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzwQzAz0MDMDwMbmhZzAQGjFAMzYwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Adeliya",
          ["guild"] = "Burden",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 307396,
          ["ilvl"] = 325,
          ["crit"] = 660,
          ["haste"] = 976,
          ["mastery"] = 1308,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPAAAAAAAAAAAAghZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMGMmZmxsxMbLDwMYA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Pandesall",
          ["guild"] = "Salty Tears",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 306077,
          ["ilvl"] = 326,
          ["crit"] = 865,
          ["haste"] = 767,
          ["mastery"] = 1298,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAghZxMGbzMmZ2mxYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYmxgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Clâms",
          ["guild"] = "Efficient",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 304294,
          ["ilvl"] = 323,
          ["crit"] = 790,
          ["haste"] = 802,
          ["mastery"] = 1287,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPAAAAAAAAAAAAghZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMGMmZmxsxMbLDwMYA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Loyalxdice",
          ["guild"] = "Reforged",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 304010,
          ["ilvl"] = 325,
          ["crit"] = 703,
          ["haste"] = 965,
          ["mastery"] = 1229,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzYjJDMTjBmBYmNzwsZAIjxCAmZMYMzMjZjZ2WGgZwA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Clarity",
          ["guild"] = "Mental Apocalypse",
          ["boss"] = "Sszorak",
          ["amount"] = 186935,
          ["ilvl"] = 326,
          ["crit"] = 785,
          ["haste"] = 965,
          ["mastery"] = 1177,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMGz2MGzw2MzYmZGGTzAz0MgZAmZzMMbGAyYsAgZGwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Tempr",
          ["guild"] = "guppy pond",
          ["boss"] = "Sszorak",
          ["amount"] = 184935,
          ["ilvl"] = 323,
          ["crit"] = 961,
          ["haste"] = 1077,
          ["mastery"] = 1026,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMDz2MzYGzmZGzMzYjJDLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "spell_priest_voidsear"
          }
        },
        {
          ["name"] = "Ravxd",
          ["guild"] = "velocity",
          ["boss"] = "Sszorak",
          ["amount"] = 184137,
          ["ilvl"] = 326,
          ["crit"] = 1063,
          ["haste"] = 715,
          ["mastery"] = 1248,
          ["vers"] = 147,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMDz2MzYGzmZGzMzYjJDLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "spell_priest_voidsear"
          }
        },
        {
          ["name"] = "Kimpräst",
          ["guild"] = "Reko",
          ["boss"] = "Sszorak",
          ["amount"] = 184063,
          ["ilvl"] = 326,
          ["crit"] = 763,
          ["haste"] = 890,
          ["mastery"] = 1246,
          ["vers"] = 240,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMDz2MzYGzmZGzMzYjJDLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "spell_priest_voidsear"
          }
        },
        {
          ["name"] = "Faintpriest",
          ["guild"] = "constant",
          ["boss"] = "Sszorak",
          ["amount"] = 183277,
          ["ilvl"] = 324,
          ["crit"] = 1047,
          ["haste"] = 798,
          ["mastery"] = 1255,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMDz2MzYGzmZGzMzYjJDLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "spell_priest_voidsear"
          }
        },
        {
          ["name"] = "Бантаростта",
          ["guild"] = "Нулевая видимость",
          ["boss"] = "Sszorak",
          ["amount"] = 183238,
          ["ilvl"] = 326,
          ["crit"] = 593,
          ["haste"] = 947,
          ["mastery"] = 1461,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMDz2MzYGzmZGzMzYjJDMTjBmZmBACwsNbLgZjBAGMmZmxsxMYmBzgB",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "spell_priest_voidsear"
          }
        },
        {
          ["name"] = "鈴科百合子",
          ["guild"] = "靈魂归宿",
          ["boss"] = "Sszorak",
          ["amount"] = 183169,
          ["ilvl"] = 325,
          ["crit"] = 976,
          ["haste"] = 1006,
          ["mastery"] = 1250,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMDz2MzYGzGzYmZGGTzAz0MDMzMDAEgZb2WAzGDAMYMzMjZjZwMDMYA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "spell_priest_voidsear"
          }
        },
        {
          ["name"] = "Umbrasp",
          ["guild"] = "Jade Falcons",
          ["boss"] = "Sszorak",
          ["amount"] = 182530,
          ["ilvl"] = 326,
          ["crit"] = 721,
          ["haste"] = 922,
          ["mastery"] = 1365,
          ["vers"] = 170,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMDz2MzYGzmZGzMzYjJDLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "spell_priest_voidsear"
          }
        },
        {
          ["name"] = "Grendini",
          ["guild"] = "Fragglene",
          ["boss"] = "Sszorak",
          ["amount"] = 182373,
          ["ilvl"] = 325,
          ["crit"] = 944,
          ["haste"] = 798,
          ["mastery"] = 1288,
          ["vers"] = 138,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMDz2MzYGzmZGzMzYjJDLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "spell_priest_voidsear"
          }
        },
        {
          ["name"] = "Kaleido",
          ["guild"] = "BlackCellFaction",
          ["boss"] = "Sszorak",
          ["amount"] = 182349,
          ["ilvl"] = 325,
          ["crit"] = 785,
          ["haste"] = 937,
          ["mastery"] = 1321,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMDz2MzYG2mZGzMzYjJDLmpBYmZGAIAz2stBmNGAYwYmZGzGzgZGMDGA",
          ["hero"] = {
            ["name"] = "Voidweaver",
            ["atlas"] = "talents-heroclass-priest-voidweaver",
            ["icon"] = "spell_priest_voidsear"
          }
        },
        {
          ["name"] = "Burritok",
          ["guild"] = "Might",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 284203,
          ["ilvl"] = 324,
          ["crit"] = 872,
          ["haste"] = 946,
          ["mastery"] = 1196,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPwAAAAAAAAAAAAMMLmxMbzMmZ2mxYG2GzYmZGbjJDMTjBmBYmNzwsZAIjxCAGjBjZmZMbMz2yAMDGA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Buffpriest",
          ["guild"] = "Fun with Friends",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 277694,
          ["ilvl"] = 327,
          ["crit"] = 923,
          ["haste"] = 896,
          ["mastery"] = 1253,
          ["vers"] = 137,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPwAAAAAAAAAAAAMMLmxMbzMmZ2mxYGzmZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYMGMmZmxsxMbLDwMYA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Oblivionis",
          ["guild"] = "醉星辰",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 273444,
          ["ilvl"] = 327,
          ["crit"] = 740,
          ["haste"] = 928,
          ["mastery"] = 1240,
          ["vers"] = 152,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPwAAAAAAAAAAAAMMLmxMbzMmZ2mxYGzmZGzMzATmBz0YgZAmZzMMbGAyYsAgxYwYmZGzGzstMAzgB",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Snowgigarat",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 273368,
          ["ilvl"] = 327,
          ["crit"] = 879,
          ["haste"] = 992,
          ["mastery"] = 1105,
          ["vers"] = 187,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2YGzMzYZoZYxMNDYGgZ2MDzmBgMGLAYmBMmZmxsxMbLDgBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Indigoth",
          ["guild"] = "Reflection",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 272049,
          ["ilvl"] = 323,
          ["crit"] = 881,
          ["haste"] = 901,
          ["mastery"] = 1254,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzY2MzYmZGbMZYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Faintpriest",
          ["guild"] = "constant",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 272017,
          ["ilvl"] = 326,
          ["crit"] = 880,
          ["haste"] = 902,
          ["mastery"] = 1353,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Clarity",
          ["guild"] = "Mental Apocalypse",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 270803,
          ["ilvl"] = 327,
          ["crit"] = 789,
          ["haste"] = 967,
          ["mastery"] = 1177,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGYaGYmmBMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Arino",
          ["guild"] = "Origin",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 270799,
          ["ilvl"] = 326,
          ["crit"] = 1072,
          ["haste"] = 840,
          ["mastery"] = 990,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Grendini",
          ["guild"] = "Fragglene",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 270142,
          ["ilvl"] = 324,
          ["crit"] = 944,
          ["haste"] = 798,
          ["mastery"] = 1288,
          ["vers"] = 138,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 156021,
              ["name"] = "Energy Siphon",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzM2mxYmZGYaGYmmZgZAmZzMMbGAyYsAgZGwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Snadepræst",
          ["guild"] = "Revoke",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 268924,
          ["ilvl"] = 323,
          ["crit"] = 1021,
          ["haste"] = 927,
          ["mastery"] = 1130,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzY2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Poipoi",
          ["guild"] = "Myth",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 236841,
          ["ilvl"] = 327,
          ["crit"] = 803,
          ["haste"] = 974,
          ["mastery"] = 1300,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbMNDMTzAmBYmNzwsZAIjxCAmZAjZmZMbMz2yAYwA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "圆敏丶",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 232261,
          ["ilvl"] = 329,
          ["crit"] = 955,
          ["haste"] = 899,
          ["mastery"] = 1152,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzM2mxYmZGbIDLmpZAzAMzmZY2MAkxYBAzMgxMzMmFmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Gigamehh",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 231329,
          ["ilvl"] = 326,
          ["crit"] = 1016,
          ["haste"] = 881,
          ["mastery"] = 1195,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzY2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmFmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Kaldemic",
          ["guild"] = "Ethical",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 230315,
          ["ilvl"] = 326,
          ["crit"] = 1000,
          ["haste"] = 924,
          ["mastery"] = 1272,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzM2mxYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Snowgigarat",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 229094,
          ["ilvl"] = 325,
          ["crit"] = 762,
          ["haste"] = 887,
          ["mastery"] = 1313,
          ["vers"] = 187,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzM2mxYmZGGaGYmmZgZAmZzMMbGAyYsAgZGwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Grendini",
          ["guild"] = "Fragglene",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 223206,
          ["ilvl"] = 327,
          ["crit"] = 944,
          ["haste"] = 807,
          ["mastery"] = 1297,
          ["vers"] = 138,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 156021,
              ["name"] = "Energy Siphon",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzM2mxYmZGYaGYmmZgZAmZzMMbGAyYsAgZGwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "박근수",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 215344,
          ["ilvl"] = 327,
          ["crit"] = 884,
          ["haste"] = 989,
          ["mastery"] = 1018,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGGaGYmmZgZAmZzMMbGAyYsAgZGwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Trakoray",
          ["guild"] = "The Next Step",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 215301,
          ["ilvl"] = 326,
          ["crit"] = 901,
          ["haste"] = 1039,
          ["mastery"] = 1088,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGQzMYmmBMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Crzyp",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 212407,
          ["ilvl"] = 327,
          ["crit"] = 701,
          ["haste"] = 950,
          ["mastery"] = 1291,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbMZgZaMwMAzsZGmNDAZMWAwMDYMzMjZjZ2WGgZwA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Warklaw",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 208269,
          ["ilvl"] = 329,
          ["crit"] = 741,
          ["haste"] = 1011,
          ["mastery"] = 1349,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 344
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIDMTjBmBYmNzwsYAIjxCAmZAjZmZMbmZ2WGgZwA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "박근수",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 423018,
          ["ilvl"] = 328,
          ["crit"] = 782,
          ["haste"] = 929,
          ["mastery"] = 1193,
          ["vers"] = 1425,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGGaGYmmZgZAmZzMMbGAyYsAgZGwYmZGzGzstMAGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Warklaw",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 403665,
          ["ilvl"] = 332,
          ["crit"] = 938,
          ["haste"] = 1001,
          ["mastery"] = 1419,
          ["vers"] = 1377,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIDMTjBmBYmNzwsYAIjxCAmZAjZmZMbmZ2WGgZwA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Tempr",
          ["guild"] = "guppy pond",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 380775,
          ["ilvl"] = 322,
          ["crit"] = 948,
          ["haste"] = 1071,
          ["mastery"] = 1017,
          ["vers"] = 102,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIDLbz0AMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Salmer",
          ["guild"] = "Consequence",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 378290,
          ["ilvl"] = 324,
          ["crit"] = 996,
          ["haste"] = 817,
          ["mastery"] = 1059,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIDLbz0AMDwMbmhZzAQGjFAMzAGzMzYWYmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Atemix",
          ["guild"] = "WICKED",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 375855,
          ["ilvl"] = 324,
          ["crit"] = 929,
          ["haste"] = 880,
          ["mastery"] = 1093,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGYyAz0MDMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Deceiviate",
          ["guild"] = "Raid Awareness",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 372677,
          ["ilvl"] = 322,
          ["crit"] = 733,
          ["haste"] = 910,
          ["mastery"] = 1224,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzM2mZGjZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Gigamehh",
          ["guild"] = "Wave",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 365036,
          ["ilvl"] = 324,
          ["crit"] = 1015,
          ["haste"] = 870,
          ["mastery"] = 1199,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzM2mxYmZGbIDLbz0AMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Precade",
          ["guild"] = "ComeBack",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 357139,
          ["ilvl"] = 321,
          ["crit"] = 713,
          ["haste"] = 867,
          ["mastery"] = 1371,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbMZGMTDwMAzsZGmNDAZMWAwMDYMzMjZjZ2WGgZwA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Eleiviatism",
          ["guild"] = "Biggie Chief and da Boys",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 349410,
          ["ilvl"] = 322,
          ["crit"] = 818,
          ["haste"] = 1139,
          ["mastery"] = 1158,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Vøid",
          ["guild"] = "R e t i r e d",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 345425,
          ["ilvl"] = 325,
          ["crit"] = 907,
          ["haste"] = 940,
          ["mastery"] = 1219,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzY2MzYmZGYyMYmGDMDwMbmhZzAQGjFAMzAGzMzY2YmtlBYGMA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "猪心",
          ["guild"] = "仲夏之魂",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 343264,
          ["ilvl"] = 319,
          ["crit"] = 516,
          ["haste"] = 1186,
          ["mastery"] = 1271,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzY2MzYmZGbIDbmpxAzAMzmZYWMAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        },
        {
          ["name"] = "Umbrasp",
          ["guild"] = "Jade Falcons",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 342786,
          ["ilvl"] = 318,
          ["crit"] = 743,
          ["haste"] = 946,
          ["mastery"] = 1314,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA",
          ["hero"] = {
            ["name"] = "Archon",
            ["atlas"] = "talents-heroclass-priest-archon",
            ["icon"] = "ability_priest_halo_shadow"
          }
        }
      }
    }
  }
}
