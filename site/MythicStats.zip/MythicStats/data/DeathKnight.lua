MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["DeathKnight"] = {
  ["className"] = "Death Knight",
  ["specs"] = {
    {
      ["spec"] = "Blood",
      ["role"] = "tank",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Jeyle",
          ["guild"] = "Above Average",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 129285,
          ["ilvl"] = 325,
          ["crit"] = 1150,
          ["haste"] = 1407,
          ["mastery"] = 515,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMjhZbmZmmZzMjZmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Fallenme",
          ["guild"] = "行走的鱼",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 127525,
          ["ilvl"] = 322,
          ["crit"] = 1200,
          ["haste"] = 1022,
          ["mastery"] = 414,
          ["vers"] = 439,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwY2GzwMmZmhZbmZmmZZGzMMGAAAAwMzMzYmZYGDAYmZmZGAAADMwMW0YZDw2A2AMjZGAAYmBjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Yomblibimo",
          ["guild"] = "The History",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 115470,
          ["ilvl"] = 326,
          ["crit"] = 1069,
          ["haste"] = 1313,
          ["mastery"] = 582,
          ["vers"] = 258,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZZmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMgxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "호꾸에욤",
          ["guild"] = "인앤아웃",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 115078,
          ["ilvl"] = 321,
          ["crit"] = 907,
          ["haste"] = 1464,
          ["mastery"] = 111,
          ["vers"] = 610,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMYwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Hermitpuppet",
          ["guild"] = "도원",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 114793,
          ["ilvl"] = 325,
          ["crit"] = 1324,
          ["haste"] = 1295,
          ["mastery"] = 157,
          ["vers"] = 411,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MbGzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwM20YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Vicdktwo",
          ["guild"] = "Enclave",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 113098,
          ["ilvl"] = 325,
          ["crit"] = 1079,
          ["haste"] = 1053,
          ["mastery"] = 390,
          ["vers"] = 638,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZzYmxMGAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Romberfisch",
          ["guild"] = "Amazing Stories",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 111789,
          ["ilvl"] = 321,
          ["crit"] = 1123,
          ["haste"] = 1145,
          ["mastery"] = 469,
          ["vers"] = 1620,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMjhZbmZmmZxYMzMmBAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Froezy",
          ["guild"] = "Zwei Kölsch bitte",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 111188,
          ["ilvl"] = 323,
          ["crit"] = 1224,
          ["haste"] = 1043,
          ["mastery"] = 728,
          ["vers"] = 41,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLGzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Dekayblind",
          ["guild"] = "BigBrain",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 110682,
          ["ilvl"] = 322,
          ["crit"] = 1308,
          ["haste"] = 1093,
          ["mastery"] = 461,
          ["vers"] = 301,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxMjhxMAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Pathogeny",
          ["guild"] = "tre dagar",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 109851,
          ["ilvl"] = 324,
          ["crit"] = 1153,
          ["haste"] = 1143,
          ["mastery"] = 464,
          ["vers"] = 360,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZmhZbmZmmZzYMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZBw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "호꾸에욤",
          ["guild"] = "인앤아웃",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 127630,
          ["ilvl"] = 324,
          ["crit"] = 917,
          ["haste"] = 1520,
          ["mastery"] = 111,
          ["vers"] = 624,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMYwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Yomblibimo",
          ["guild"] = "The History",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 127147,
          ["ilvl"] = 326,
          ["crit"] = 1069,
          ["haste"] = 1313,
          ["mastery"] = 582,
          ["vers"] = 258,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZZmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMgxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Redpaprika",
          ["guild"] = "Mate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 126939,
          ["ilvl"] = 327,
          ["crit"] = 857,
          ["haste"] = 1271,
          ["mastery"] = 427,
          ["vers"] = 615,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxMjxMGAAAAwMzMzMzMDzYAAzMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Cybeeqt",
          ["guild"] = "Ethical",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 123930,
          ["ilvl"] = 325,
          ["crit"] = 1181,
          ["haste"] = 1254,
          ["mastery"] = 114,
          ["vers"] = 571,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMbzMz0MLGjxMmBAAAAmZmZmZmZYGDAYmZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "不屈之傲",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 123492,
          ["ilvl"] = 324,
          ["crit"] = 1246,
          ["haste"] = 1264,
          ["mastery"] = 272,
          ["vers"] = 390,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwY2GzMMmZMMbzMz0MLzMjhxMAAAAwMzMzMzMDzYAAzMzMzAAAYgBmxmGbLA2GwGgZMDAAYmBmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Joeyuwu",
          ["guild"] = "mythic raid guild",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 122483,
          ["ilvl"] = 326,
          ["crit"] = 1225,
          ["haste"] = 1267,
          ["mastery"] = 503,
          ["vers"] = 213,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMbzMz0MbGjxMGAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbAWGwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Deneroc",
          ["guild"] = "The Next Step",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 121578,
          ["ilvl"] = 322,
          ["crit"] = 1040,
          ["haste"] = 1167,
          ["mastery"] = 431,
          ["vers"] = 389,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYMmZMjZGDz2MzMNzyMzYYMAAAAgZmZmZmZGmxMDAGzMzMAAAGYgZsoxyGgtBsBYGzAAAmZwMMA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Trigdk",
          ["guild"] = "Medium",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 120233,
          ["ilvl"] = 324,
          ["crit"] = 2851,
          ["haste"] = 1067,
          ["mastery"] = 477,
          ["vers"] = 238,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLGzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Moormt",
          ["guild"] = "The Vindicated",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 118467,
          ["ilvl"] = 326,
          ["crit"] = 1257,
          ["haste"] = 1259,
          ["mastery"] = 362,
          ["vers"] = 300,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZmhZbmZmmZxMjxMGAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLLA2GwGgZMDAAYmBwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Rivendellol",
          ["guild"] = "咏冻黎明12.0",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 118367,
          ["ilvl"] = 327,
          ["crit"] = 1260,
          ["haste"] = 989,
          ["mastery"] = 466,
          ["vers"] = 481,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMbzMz0MLmZmxMAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "古手川千纱丶",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 208044,
          ["ilvl"] = 322,
          ["crit"] = 979,
          ["haste"] = 1309,
          ["mastery"] = 398,
          ["vers"] = 377,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzwMmZmhZbmZmmZxMzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Aythia",
          ["guild"] = "No Drama Llama",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 202704,
          ["ilvl"] = 326,
          ["crit"] = 1258,
          ["haste"] = 853,
          ["mastery"] = 348,
          ["vers"] = 788,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmZmxgZbmZmmZbmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDwyA2AMjZAAAzMgxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Daesease",
          ["guild"] = "Odyssey",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 198454,
          ["ilvl"] = 326,
          ["crit"] = 1399,
          ["haste"] = 1034,
          ["mastery"] = 536,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MbmZMmxMAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Stearawid",
          ["guild"] = "Dumbrava Minunata",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 195564,
          ["ilvl"] = 324,
          ["crit"] = 952,
          ["haste"] = 1339,
          ["mastery"] = 365,
          ["vers"] = 568,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZmhZbmZmmZxMjxMAAAAAmZmZmZmZYGjZAYMzMzAAAYgBmxiGLbA2GwGgZYAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Lierua",
          ["guild"] = "Fragments",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 190223,
          ["ilvl"] = 325,
          ["crit"] = 880,
          ["haste"] = 1393,
          ["mastery"] = 502,
          ["vers"] = 431,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1234969,
            ["name"] = "Ethereal Augmentation"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MbmZMmxAAAAAmZmZGzMDzYMDAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Wazocutie",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 187828,
          ["ilvl"] = 327,
          ["crit"] = 1024,
          ["haste"] = 1196,
          ["mastery"] = 473,
          ["vers"] = 478,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMbzMz0MLmZmZmBAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Dziutodk",
          ["guild"] = "Tak o Gosciu",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 186865,
          ["ilvl"] = 326,
          ["crit"] = 1336,
          ["haste"] = 1136,
          ["mastery"] = 353,
          ["vers"] = 347,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMYwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Fstozempic",
          ["guild"] = "R A D",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 182908,
          ["ilvl"] = 324,
          ["crit"] = 1243,
          ["haste"] = 955,
          ["mastery"] = 623,
          ["vers"] = 319,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Gigachadapo",
          ["guild"] = "K L I K A",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 182439,
          ["ilvl"] = 323,
          ["crit"] = 908,
          ["haste"] = 1330,
          ["mastery"] = 493,
          ["vers"] = 438,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MbmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YbDw2A2AMjZAAAzMYwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Froezy",
          ["guild"] = "Zwei Kölsch bitte",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 181287,
          ["ilvl"] = 320,
          ["crit"] = 1193,
          ["haste"] = 1115,
          ["mastery"] = 668,
          ["vers"] = 41,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLGzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Jeyle",
          ["guild"] = "Above Average",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 167079,
          ["ilvl"] = 325,
          ["crit"] = 1150,
          ["haste"] = 1407,
          ["mastery"] = 515,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMjhZbmZmmZzMjZmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Innocence",
          ["guild"] = "For the Glory of JO JO",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 166267,
          ["ilvl"] = 326,
          ["crit"] = 1137,
          ["haste"] = 1257,
          ["mastery"] = 350,
          ["vers"] = 386,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLGjxMGAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Relod",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 164083,
          ["ilvl"] = 330,
          ["crit"] = 1113,
          ["haste"] = 1398,
          ["mastery"] = 429,
          ["vers"] = 263,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxMjZmxAAAAAmZmZmZmZYGjBAzMzMzAAAYgBmxiGLbA2GwGgZYAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "古手川千纱丶",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 160642,
          ["ilvl"] = 320,
          ["crit"] = 1031,
          ["haste"] = 1201,
          ["mastery"] = 376,
          ["vers"] = 442,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzwMmZMMbzMz0MLmZmxMGAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Solâyaya",
          ["guild"] = "Dedicated Casuals",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 158292,
          ["ilvl"] = 327,
          ["crit"] = 1339,
          ["haste"] = 1217,
          ["mastery"] = 494,
          ["vers"] = 190,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMbzMz0MbmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Cybeeqt",
          ["guild"] = "Ethical",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 158049,
          ["ilvl"] = 325,
          ["crit"] = 1181,
          ["haste"] = 1254,
          ["mastery"] = 114,
          ["vers"] = 571,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMbzMz0MLGjxMmBAAAAmZmZmZmZYGDAYmZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "海肆梦沉",
          ["guild"] = "冷涩",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 157444,
          ["ilvl"] = 328,
          ["crit"] = 1156,
          ["haste"] = 1169,
          ["mastery"] = 588,
          ["vers"] = 282,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLmZMmBAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Nanona",
          ["guild"] = "Van",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 156969,
          ["ilvl"] = 326,
          ["crit"] = 990,
          ["haste"] = 1163,
          ["mastery"] = 327,
          ["vers"] = 686,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwY2GzMmxMmhZbmZmmZbmZMmxAAAAAmZmZmZmZ8AzYAAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Mickdk",
          ["guild"] = "Iglo Rådet",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 155617,
          ["ilvl"] = 323,
          ["crit"] = 1290,
          ["haste"] = 1127,
          ["mastery"] = 152,
          ["vers"] = 524,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMYwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Damoritwo",
          ["guild"] = "MythicDungeonFools",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 154285,
          ["ilvl"] = 325,
          ["crit"] = 928,
          ["haste"] = 1255,
          ["mastery"] = 276,
          ["vers"] = 680,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMbzMz0MbmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Trigdk",
          ["guild"] = "Medium",
          ["boss"] = "Sszorak",
          ["amount"] = 109192,
          ["ilvl"] = 325,
          ["crit"] = 1085,
          ["haste"] = 1020,
          ["mastery"] = 574,
          ["vers"] = 470,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLGzMmxAAAAAmZmZmZmZYGjZAgZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Kaldeera",
          ["guild"] = "Swamp Animals",
          ["boss"] = "Sszorak",
          ["amount"] = 108326,
          ["ilvl"] = 324,
          ["crit"] = 878,
          ["haste"] = 1483,
          ["mastery"] = 442,
          ["vers"] = 318,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxYmxMGAAAAwMzMzMzMDzYMDAMzMzAAAYgBmxiGLLAWGwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Ravendár",
          ["guild"] = "Epoch",
          ["boss"] = "Sszorak",
          ["amount"] = 108048,
          ["ilvl"] = 324,
          ["crit"] = 1129,
          ["haste"] = 1206,
          ["mastery"] = 535,
          ["vers"] = 256,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZzYMzMGAAAAwMzMzMzMDzYMDAMzMzAAAYgBmxmGLbA2GwGgZYGAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "阿露伊",
          ["guild"] = "覺 醒",
          ["boss"] = "Sszorak",
          ["amount"] = 107993,
          ["ilvl"] = 325,
          ["crit"] = 903,
          ["haste"] = 1188,
          ["mastery"] = 866,
          ["vers"] = 271,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZmhZbmZmmZxMzMmBAAAAwMzMzMzMzYmZAAjZmZGAAADMwM20YZBw2A2AMDDAAYmBwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Deneroc",
          ["guild"] = "The Next Step",
          ["boss"] = "Sszorak",
          ["amount"] = 106764,
          ["ilvl"] = 323,
          ["crit"] = 1040,
          ["haste"] = 1141,
          ["mastery"] = 531,
          ["vers"] = 324,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYMmhZMzYY2mZmpZWmZGDjZAAAAgZmZmZmZGmxMDAMzMzMAAAGYgZsoxyGgtBsBYGzAAAmZwMMA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Relod",
          ["guild"] = "Northern Sky",
          ["boss"] = "Sszorak",
          ["amount"] = 106107,
          ["ilvl"] = 330,
          ["crit"] = 1113,
          ["haste"] = 1398,
          ["mastery"] = 429,
          ["vers"] = 263,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxMjZmxAAAAAmZmZmZmZYGjBAzMzMzAAAYgBmxiGLbA2GwGgZYAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Troyy",
          ["guild"] = "Mate",
          ["boss"] = "Sszorak",
          ["amount"] = 105838,
          ["ilvl"] = 329,
          ["crit"] = 887,
          ["haste"] = 1471,
          ["mastery"] = 341,
          ["vers"] = 508,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxMjxMmBAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Teickila",
          ["guild"] = "Hatewatching",
          ["boss"] = "Sszorak",
          ["amount"] = 105629,
          ["ilvl"] = 323,
          ["crit"] = 964,
          ["haste"] = 1319,
          ["mastery"] = 503,
          ["vers"] = 339,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYMmZMjZGDz2MzMNzmZGDjZAAAAgZmZmZmZGmxMzAAzMzMAAAGYgZsoxyGglBsBYGzAAAmZwMMA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Kürâs",
          ["guild"] = "Flawless",
          ["boss"] = "Sszorak",
          ["amount"] = 105586,
          ["ilvl"] = 327,
          ["crit"] = 1132,
          ["haste"] = 1695,
          ["mastery"] = 315,
          ["vers"] = 42,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMbzMz0MLGjxMmBAAAAmZmZmZmZYmZMDAMzMzAAAYgBmxiGLbA2GwGgZYAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Kaeltrix",
          ["guild"] = "Huhuholics",
          ["boss"] = "Sszorak",
          ["amount"] = 105423,
          ["ilvl"] = 327,
          ["crit"] = 1329,
          ["haste"] = 1226,
          ["mastery"] = 569,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMLzMz0MLGzMmxAAAAAmZmZmZmZYGjZAgZmZGAAADMwMW0YZBw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Jeyle",
          ["guild"] = "Above Average",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 191200,
          ["ilvl"] = 325,
          ["crit"] = 1150,
          ["haste"] = 1407,
          ["mastery"] = 515,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMjhZbmZmmZzMjZmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Solâyaya",
          ["guild"] = "Dedicated Casuals",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 182586,
          ["ilvl"] = 327,
          ["crit"] = 1336,
          ["haste"] = 1214,
          ["mastery"] = 494,
          ["vers"] = 190,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMLzMz0MbmZMmxMAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Kaomswhey",
          ["guild"] = "Comfy",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 180916,
          ["ilvl"] = 326,
          ["crit"] = 911,
          ["haste"] = 844,
          ["mastery"] = 746,
          ["vers"] = 719,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMLzMz0MLmZMzMGAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbAWGwGgZMDAAYmBwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Sðwen",
          ["guild"] = "Waít for it",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 176736,
          ["ilvl"] = 326,
          ["crit"] = 1267,
          ["haste"] = 1172,
          ["mastery"] = 428,
          ["vers"] = 307,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxYmxMGAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Deneroc",
          ["guild"] = "The Next Step",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 175730,
          ["ilvl"] = 323,
          ["crit"] = 1040,
          ["haste"] = 1141,
          ["mastery"] = 531,
          ["vers"] = 324,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYMmhZMzYYWmZmpZ2mZGzMjBAAAAMzMzMzMzwMmZAwYmZmBAAwADMjFNW2AsNgNAzYGAAwMDGMA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Calmidk",
          ["guild"] = "Offline",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 174741,
          ["ilvl"] = 326,
          ["crit"] = 1271,
          ["haste"] = 1176,
          ["mastery"] = 554,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMLzMz0MLmZMmBAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Blutiklix",
          ["guild"] = "Unic",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 172795,
          ["ilvl"] = 325,
          ["crit"] = 1047,
          ["haste"] = 1156,
          ["mastery"] = 593,
          ["vers"] = 311,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 331
            },
            {
              ["id"] = 249344,
              ["name"] = "Light Company Guidon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMLzMz0MLmZMmxAAAAAmZmZmZmZYGjZAYMzMzAAAYgBmxiGLbAWGwGgZYAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Schokoeik",
          ["guild"] = "Jade Falcons",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 172393,
          ["ilvl"] = 327,
          ["crit"] = 976,
          ["haste"] = 1314,
          ["mastery"] = 672,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMLzMz0MbmZmZmBAAAAYmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMDDAAYmBwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Chämstër",
          ["guild"] = "Skill Issue",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 171723,
          ["ilvl"] = 326,
          ["crit"] = 1218,
          ["haste"] = 1125,
          ["mastery"] = 648,
          ["vers"] = 184,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMLzMz0MbGzMmxAAAAAzMzMzMzMDzYMAYMzMzAAAYgBmxmGLbA2GwGgZYAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Teickila",
          ["guild"] = "Hatewatching",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 170541,
          ["ilvl"] = 326,
          ["crit"] = 891,
          ["haste"] = 1352,
          ["mastery"] = 535,
          ["vers"] = 408,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMjhZxMz0MbmZMzMmBAAAAmZmZGzMDzYMDAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Cybeeqt",
          ["guild"] = "Ethical",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 129470,
          ["ilvl"] = 327,
          ["crit"] = 1151,
          ["haste"] = 1278,
          ["mastery"] = 114,
          ["vers"] = 614,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMbzMz0MLGjxMmBAAAAmZmZmZmZYGDAYmZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Darkyoung",
          ["guild"] = "Myth",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 127927,
          ["ilvl"] = 324,
          ["crit"] = 781,
          ["haste"] = 1312,
          ["mastery"] = 321,
          ["vers"] = 752,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxYMmxMAAAAwMzMzMzMDzYMAYmZmZGAAADMwMW0YZDw2A2AMDDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Relod",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 127160,
          ["ilvl"] = 330,
          ["crit"] = 1013,
          ["haste"] = 1433,
          ["mastery"] = 311,
          ["vers"] = 447,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxMjZmxAAAAAmZmZmZmZYGjBAzMzMzAAAYgBmxiGLbA2GwGgZYAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Zeforusdk",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 119590,
          ["ilvl"] = 324,
          ["crit"] = 1050,
          ["haste"] = 1216,
          ["mastery"] = 381,
          ["vers"] = 636,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZZGjxMGAAAAYmhZmZmZ8AzMjBAzMzMzAAAYgBmxiGLLA2GwGgZAAAYmBmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Clowndekay",
          ["guild"] = "Fragglene",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 119014,
          ["ilvl"] = 326,
          ["crit"] = 1123,
          ["haste"] = 1355,
          ["mastery"] = 488,
          ["vers"] = 179,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxMjxMGAAAAwMzMzMzMDzYMAYmZmZGAAADMwMW0YZDw2A2AMDDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Vipsxo",
          ["guild"] = "Infinity",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 118583,
          ["ilvl"] = 326,
          ["crit"] = 976,
          ["haste"] = 1309,
          ["mastery"] = 580,
          ["vers"] = 256,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxMjZmxAAAAAmZmZmZmZYGjBAzMzMzAAAYgBmxiGLbA2GwGgZYAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Troyy",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 116235,
          ["ilvl"] = 330,
          ["crit"] = 890,
          ["haste"] = 1474,
          ["mastery"] = 341,
          ["vers"] = 512,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyYmxMmZMMbzMz0MbmZMmxMAAAAwMMzMzMjZGDAYmZmZGAAADMwMW0YZDw2A2AMDDAAYmBGGA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Acedk",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 114931,
          ["ilvl"] = 325,
          ["crit"] = 928,
          ["haste"] = 3037,
          ["mastery"] = 251,
          ["vers"] = 656,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxYMmxMAAAAwMzMzMjZGzMDAYmZmZGAAADMwMW0YZDw2A2AMDDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Thaiax",
          ["guild"] = "Sabotage",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 112191,
          ["ilvl"] = 324,
          ["crit"] = 1277,
          ["haste"] = 1349,
          ["mastery"] = 371,
          ["vers"] = 112,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMjhZbmZmmZxMjxMGAAAAwMmZGzMDzMjBAzMzMzAAAYgBmxiGLbAWGwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Packnight",
          ["guild"] = "Quichons",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 110692,
          ["ilvl"] = 325,
          ["crit"] = 980,
          ["haste"] = 1314,
          ["mastery"] = 349,
          ["vers"] = 498,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZMMbzMz0MbGjxMmBAAAAmhZmZMjZGjBAzMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBGGA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Sunnyvi",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 203896,
          ["ilvl"] = 327,
          ["crit"] = 913,
          ["haste"] = 1263,
          ["mastery"] = 617,
          ["vers"] = 418,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyYmxMmZMMbzMz0MbzYMmxAAAAAGMzMzMjZmZMAYmZmZmBAAYgBmxiGLbA2GwGgZAAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Troyy",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 194074,
          ["ilvl"] = 332,
          ["crit"] = 1038,
          ["haste"] = 1341,
          ["mastery"] = 335,
          ["vers"] = 1772,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwMzCzMmxMjhZbmZmmZzMjxMGAAAAwMMzMzMjZmZAAzMzMzMAAADMwMW0YZDw2A2AMDAAAzMYGGA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Redpaprika",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 192800,
          ["ilvl"] = 327,
          ["crit"] = 857,
          ["haste"] = 1273,
          ["mastery"] = 427,
          ["vers"] = 1876,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyYmxMmZMMbzMz0MLmZMmxMAAAAwgZmZmZMzMjBAzMzMzMAAADMwMW0YZDw2A2AMDAAAzMYwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Zeforusdk",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 167704,
          ["ilvl"] = 326,
          ["crit"] = 1091,
          ["haste"] = 1196,
          ["mastery"] = 314,
          ["vers"] = 1932,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyYmxMmZMMbzMz0MbzMjxMGAAAAwgZmZmZMzMjBAzMzMzMAAADMwMW0YZDw2A2AMDAAAzMgxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Wbattle",
          ["guild"] = "利刃",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 134595,
          ["ilvl"] = 322,
          ["crit"] = 1278,
          ["haste"] = 1112,
          ["mastery"] = 507,
          ["vers"] = 269,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLmZMmxMAAAAwMzMzMzMDzYMDAjZmZGAAADMwMW0YZDw2A2AMDDAAYmBwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Fallenme",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 130500,
          ["ilvl"] = 324,
          ["crit"] = 1222,
          ["haste"] = 883,
          ["mastery"] = 430,
          ["vers"] = 608,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMbzMz0MLzYmhxAAAAAmZmZGzMjHYGDAYMzMzAAAYgBmxiGLbA2GwGgZMzAAAzMgxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "影心风行者",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 126956,
          ["ilvl"] = 325,
          ["crit"] = 814,
          ["haste"] = 1202,
          ["mastery"] = 101,
          ["vers"] = 1013,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLmZMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Calmrdk",
          ["guild"] = "Profanities",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 118501,
          ["ilvl"] = 317,
          ["crit"] = 1005,
          ["haste"] = 1056,
          ["mastery"] = 605,
          ["vers"] = 344,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMGMbzMz0MbzMjZmBAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "古手川千纱丶",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 115236,
          ["ilvl"] = 322,
          ["crit"] = 979,
          ["haste"] = 1309,
          ["mastery"] = 398,
          ["vers"] = 377,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzwMmZmhZbmZmmZxMzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDw2A2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Hiroideath",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 114780,
          ["ilvl"] = 323,
          ["crit"] = 965,
          ["haste"] = 1275,
          ["mastery"] = 294,
          ["vers"] = 590,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzwMmZmhZzMz0MLmZMmxMAAAAwMzMzMzMjHYGDAYmZmZGAAADMwMW0YZDw2A2AMDDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "掠影示现",
          ["guild"] = "环形废墟",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 114202,
          ["ilvl"] = 323,
          ["crit"] = 1235,
          ["haste"] = 800,
          ["mastery"] = 578,
          ["vers"] = 448,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwY2mZGmxMzMMbzMz0MLmZMmBAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2Gw2AMjZAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Nixgrip",
          ["guild"] = "Frequencies",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 113381,
          ["ilvl"] = 322,
          ["crit"] = 913,
          ["haste"] = 945,
          ["mastery"] = 794,
          ["vers"] = 366,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZmxMmZmhZZmZmmZxYMmxAAAAAmZmZmZmZYGjZAYMzMzAAAYgBmxiGLLAWGwGgZYAAAzMwwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Innocence",
          ["guild"] = "For the Glory of JO JO",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 112942,
          ["ilvl"] = 326,
          ["crit"] = 1100,
          ["haste"] = 1228,
          ["mastery"] = 414,
          ["vers"] = 386,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MLGjxMGAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Взрыватикус",
          ["guild"] = "Лучший Рейд",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 111016,
          ["ilvl"] = 325,
          ["crit"] = 1280,
          ["haste"] = 969,
          ["mastery"] = 487,
          ["vers"] = 447,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWGzMmxMzMMbzMz0MbmZMmBAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbA2GwGgZMDAAYmBzwA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        }
      }
    },
    {
      ["spec"] = "Frost",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Ripx",
          ["guild"] = "Ascendance",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 238384,
          ["ilvl"] = 324,
          ["crit"] = 1278,
          ["haste"] = 480,
          ["mastery"] = 1278,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMzMGDz2MzMzMLmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Tinzza",
          ["guild"] = "IHAN SAMA",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 225727,
          ["ilvl"] = 323,
          ["crit"] = 1453,
          ["haste"] = 576,
          ["mastery"] = 1142,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "六如丶",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220428,
          ["ilvl"] = 324,
          ["crit"] = 1273,
          ["haste"] = 547,
          ["mastery"] = 1200,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZYMGDz2MzMzMLzMjMjZGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Heran",
          ["guild"] = "B L C",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 220337,
          ["ilvl"] = 324,
          ["crit"] = 1320,
          ["haste"] = 499,
          ["mastery"] = 1171,
          ["vers"] = 191,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZxMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Dkice",
          ["guild"] = "SaveCowEatPanda",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 219149,
          ["ilvl"] = 322,
          ["crit"] = 1342,
          ["haste"] = 369,
          ["mastery"] = 1345,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMzMDY2mZmZmZxMjMjZGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "丶残丨阳",
          ["guild"] = "异酱的wcl",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 218497,
          ["ilvl"] = 325,
          ["crit"] = 1403,
          ["haste"] = 350,
          ["mastery"] = 1319,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMYMGDz2MzMzMbzMjmZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAwgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "九九捌小魔王",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217673,
          ["ilvl"] = 324,
          ["crit"] = 1492,
          ["haste"] = 333,
          ["mastery"] = 1288,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZGDz2MzMzMbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Kagesendo",
          ["guild"] = "Resonate",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 216093,
          ["ilvl"] = 321,
          ["crit"] = 1231,
          ["haste"] = 560,
          ["mastery"] = 1123,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 249344,
              ["name"] = "Light Company Guidon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Ilusiodeath",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 216052,
          ["ilvl"] = 324,
          ["crit"] = 1413,
          ["haste"] = 612,
          ["mastery"] = 1108,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Gripshaker",
          ["guild"] = "Shattrath Island",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 213501,
          ["ilvl"] = 325,
          ["crit"] = 1444,
          ["haste"] = 413,
          ["mastery"] = 1217,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAzyMzMzMLzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Snowso",
          ["guild"] = "Kiwi Company",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224721,
          ["ilvl"] = 326,
          ["crit"] = 1322,
          ["haste"] = 593,
          ["mastery"] = 1236,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMGDzyMzMzMbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Vildk",
          ["guild"] = "Infinity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 215463,
          ["ilvl"] = 326,
          ["crit"] = 1387,
          ["haste"] = 635,
          ["mastery"] = 1125,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZZmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "쿠와아아앙",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 214888,
          ["ilvl"] = 324,
          ["crit"] = 1396,
          ["haste"] = 640,
          ["mastery"] = 1060,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMbzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Kagan",
          ["guild"] = "Vortex",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 212417,
          ["ilvl"] = 325,
          ["crit"] = 1255,
          ["haste"] = 775,
          ["mastery"] = 1138,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZGDz2MzMzMLmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "九九捌小魔王",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 210654,
          ["ilvl"] = 326,
          ["crit"] = 3228,
          ["haste"] = 328,
          ["mastery"] = 1312,
          ["vers"] = -131,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZGDz2MzMzMbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Heran",
          ["guild"] = "B L C",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 210438,
          ["ilvl"] = 324,
          ["crit"] = 1320,
          ["haste"] = 499,
          ["mastery"] = 1171,
          ["vers"] = 191,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZxMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "셀리에",
          ["guild"] = "인앤아웃",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209662,
          ["ilvl"] = 325,
          ["crit"] = 1363,
          ["haste"] = 432,
          ["mastery"] = 1311,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Agrael",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 208699,
          ["ilvl"] = 325,
          ["crit"] = 1410,
          ["haste"] = 617,
          ["mastery"] = 1203,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAz2MzMzMbzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "花蝶风月",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 205748,
          ["ilvl"] = 322,
          ["crit"] = 1628,
          ["haste"] = 339,
          ["mastery"] = 1079,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMzYY2mZmZmZzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Glipbobotank",
          ["guild"] = "Reforged",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 205281,
          ["ilvl"] = 323,
          ["crit"] = 1501,
          ["haste"] = 442,
          ["mastery"] = 1096,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMGDz2MzMzMLmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Ardbert",
          ["guild"] = "Mocus",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 352294,
          ["ilvl"] = 324,
          ["crit"] = 1166,
          ["haste"] = 705,
          ["mastery"] = 1213,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjxYY2mZmZmZZmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAwgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Heran",
          ["guild"] = "B L C",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 343684,
          ["ilvl"] = 324,
          ["crit"] = 1320,
          ["haste"] = 499,
          ["mastery"] = 1171,
          ["vers"] = 191,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZxMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Joepun",
          ["guild"] = "Dont Release",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 340981,
          ["ilvl"] = 322,
          ["crit"] = 1342,
          ["haste"] = 644,
          ["mastery"] = 1064,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmxMzIzYMGmZMYmZmZmZmZGAAAAAAAAAGz2ADYBsMMBGLYmxMzADADzMAzMYA",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Deathzdemize",
          ["guild"] = "Tabbed Out",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 338278,
          ["ilvl"] = 326,
          ["crit"] = 1306,
          ["haste"] = 526,
          ["mastery"] = 1228,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAz2MzMzMbzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Braidyndk",
          ["guild"] = "nVus",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 336769,
          ["ilvl"] = 322,
          ["crit"] = 1345,
          ["haste"] = 501,
          ["mastery"] = 1227,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmhZMzYY2mZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "최졍우",
          ["guild"] = "비 상",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 330262,
          ["ilvl"] = 322,
          ["crit"] = 1413,
          ["haste"] = 642,
          ["mastery"] = 1071,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZYY2mZmZmZZmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "丶奶糖丶",
          ["guild"] = "國士無雙",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 328657,
          ["ilvl"] = 323,
          ["crit"] = 1512,
          ["haste"] = 417,
          ["mastery"] = 1022,
          ["vers"] = 250,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Hastrupdk",
          ["guild"] = "Sabotage",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327640,
          ["ilvl"] = 323,
          ["crit"] = 1454,
          ["haste"] = 379,
          ["mastery"] = 1214,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZmZAz2MzMzMbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Xarua",
          ["guild"] = "RAVAGE",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327151,
          ["ilvl"] = 320,
          ["crit"] = 1399,
          ["haste"] = 666,
          ["mastery"] = 1035,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMmZY2mZmZmZzMjmZwYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Pågsson",
          ["guild"] = "Bog",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 326730,
          ["ilvl"] = 321,
          ["crit"] = 1291,
          ["haste"] = 627,
          ["mastery"] = 1197,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmxMzIzYMGmZMYmZmZmZmZGAAAAAAAAAGz2ADYBsMMBGLYmxMzADADzMAzMYA",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "风灬焰",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 293385,
          ["ilvl"] = 325,
          ["crit"] = 1219,
          ["haste"] = 662,
          ["mastery"] = 1223,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmhZMGDz2MzMzMLzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Asxa",
          ["guild"] = "Lucid",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 288317,
          ["ilvl"] = 326,
          ["crit"] = 1354,
          ["haste"] = 542,
          ["mastery"] = 1182,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMDY2mZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Niakín",
          ["guild"] = "ÆVUM",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 287409,
          ["ilvl"] = 326,
          ["crit"] = 1400,
          ["haste"] = 473,
          ["mastery"] = 1308,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMbzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Skolrak",
          ["guild"] = "Wisp",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 286356,
          ["ilvl"] = 324,
          ["crit"] = 1262,
          ["haste"] = 491,
          ["mastery"] = 1292,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmhZMzYYWmZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "쿠와아아앙",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 284246,
          ["ilvl"] = 326,
          ["crit"] = 1328,
          ["haste"] = 693,
          ["mastery"] = 1087,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMbzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Vildk",
          ["guild"] = "Infinity",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 283990,
          ["ilvl"] = 326,
          ["crit"] = 1387,
          ["haste"] = 635,
          ["mastery"] = 1125,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZZmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 280924,
          ["ilvl"] = 326,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "忙碌的海狸",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 279630,
          ["ilvl"] = 326,
          ["crit"] = 1185,
          ["haste"] = 406,
          ["mastery"] = 1382,
          ["vers"] = 200,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjxYY2mZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Festerbloom",
          ["guild"] = "No Hard Feelings",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 279320,
          ["ilvl"] = 325,
          ["crit"] = 1126,
          ["haste"] = 831,
          ["mastery"] = 1143,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMDYWmZmZmZxMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Heran",
          ["guild"] = "B L C",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 278895,
          ["ilvl"] = 324,
          ["crit"] = 1325,
          ["haste"] = 499,
          ["mastery"] = 1173,
          ["vers"] = 191,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZxMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Shinidk",
          ["guild"] = "Лё Резистанс",
          ["boss"] = "Sszorak",
          ["amount"] = 227976,
          ["ilvl"] = 323,
          ["crit"] = 1308,
          ["haste"] = 549,
          ["mastery"] = 1262,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZYY2mZmZmZZmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Lq",
          ["guild"] = "Fraudes",
          ["boss"] = "Sszorak",
          ["amount"] = 220973,
          ["ilvl"] = 325,
          ["crit"] = 1370,
          ["haste"] = 621,
          ["mastery"] = 1156,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZmxYY2mZmZmZzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAYgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "태연이",
          ["guild"] = "Mate",
          ["boss"] = "Sszorak",
          ["amount"] = 219906,
          ["ilvl"] = 325,
          ["crit"] = 1336,
          ["haste"] = 515,
          ["mastery"] = 1235,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZbGjmZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAYgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Heran",
          ["guild"] = "B L C",
          ["boss"] = "Sszorak",
          ["amount"] = 219270,
          ["ilvl"] = 324,
          ["crit"] = 1325,
          ["haste"] = 499,
          ["mastery"] = 1173,
          ["vers"] = 191,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZxMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Xarua",
          ["guild"] = "RAVAGE",
          ["boss"] = "Sszorak",
          ["amount"] = 218779,
          ["ilvl"] = 324,
          ["crit"] = 1400,
          ["haste"] = 584,
          ["mastery"] = 1104,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMmZY2mZmZmZzMjmZwYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Vhoke",
          ["guild"] = "Super Adventure Pals",
          ["boss"] = "Sszorak",
          ["amount"] = 218383,
          ["ilvl"] = 325,
          ["crit"] = 1372,
          ["haste"] = 529,
          ["mastery"] = 1295,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmhZMzYY2mZmZmZbmZEjZGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Noviko",
          ["guild"] = "Mean Girls",
          ["boss"] = "Sszorak",
          ["amount"] = 218137,
          ["ilvl"] = 325,
          ["crit"] = 1382,
          ["haste"] = 560,
          ["mastery"] = 1152,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAz2MzMzMbzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Festerbloom",
          ["guild"] = "No Hard Feelings",
          ["boss"] = "Sszorak",
          ["amount"] = 217641,
          ["ilvl"] = 323,
          ["crit"] = 1259,
          ["haste"] = 733,
          ["mastery"] = 1142,
          ["vers"] = 180,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 156234,
              ["name"] = "Blood of the Old God",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMDYWmZmZmZxMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Leedlle",
          ["guild"] = "Winters Heart",
          ["boss"] = "Sszorak",
          ["amount"] = 216936,
          ["ilvl"] = 325,
          ["crit"] = 1433,
          ["haste"] = 538,
          ["mastery"] = 1208,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZmZGDz2MzMzMbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Asxa",
          ["guild"] = "Lucid",
          ["boss"] = "Sszorak",
          ["amount"] = 216879,
          ["ilvl"] = 322,
          ["crit"] = 1358,
          ["haste"] = 471,
          ["mastery"] = 1214,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMbzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Neerö",
          ["guild"] = "Skill Issue",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 311219,
          ["ilvl"] = 326,
          ["crit"] = 1389,
          ["haste"] = 697,
          ["mastery"] = 1094,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMDYWmZmZmZZmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAwgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "쿠와아아앙",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 304516,
          ["ilvl"] = 325,
          ["crit"] = 1396,
          ["haste"] = 643,
          ["mastery"] = 1063,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAzyMzMzMbzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Leedlle",
          ["guild"] = "Winters Heart",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 304055,
          ["ilvl"] = 324,
          ["crit"] = 1497,
          ["haste"] = 502,
          ["mastery"] = 1172,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZmZGDz2MzMzMbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Asxa",
          ["guild"] = "Lucid",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 303572,
          ["ilvl"] = 327,
          ["crit"] = 1351,
          ["haste"] = 513,
          ["mastery"] = 1237,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMDY2mZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Shinidk",
          ["guild"] = "Лё Резистанс",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 302676,
          ["ilvl"] = 324,
          ["crit"] = 1355,
          ["haste"] = 597,
          ["mastery"] = 1168,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMLzMzkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Callmetog",
          ["guild"] = "Tempo",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 301268,
          ["ilvl"] = 324,
          ["crit"] = 1533,
          ["haste"] = 249,
          ["mastery"] = 1351,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZGDz2MzMzMLmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "태연이",
          ["guild"] = "Mate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 300085,
          ["ilvl"] = 325,
          ["crit"] = 1336,
          ["haste"] = 515,
          ["mastery"] = 1235,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMGDz2MzMzMbzYkZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAYgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Deshgloomer",
          ["guild"] = "YEP",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 298595,
          ["ilvl"] = 324,
          ["crit"] = 1348,
          ["haste"] = 583,
          ["mastery"] = 1232,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMDYWmZmZmZbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAYgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Goosedekay",
          ["guild"] = "Idiot",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 297076,
          ["ilvl"] = 326,
          ["crit"] = 1573,
          ["haste"] = 270,
          ["mastery"] = 1326,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMDY2mZmZmZbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAwgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Festerbloom",
          ["guild"] = "No Hard Feelings",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 292008,
          ["ilvl"] = 323,
          ["crit"] = 1259,
          ["haste"] = 826,
          ["mastery"] = 1141,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 156234,
              ["name"] = "Blood of the Old God",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMDYWmZmZmZxMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Vildk",
          ["guild"] = "Infinity",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 232765,
          ["ilvl"] = 327,
          ["crit"] = 1411,
          ["haste"] = 588,
          ["mastery"] = 1170,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZZmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "태연이",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 225725,
          ["ilvl"] = 325,
          ["crit"] = 1399,
          ["haste"] = 515,
          ["mastery"] = 1174,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZbGjmZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAYgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "태연이",
          ["guild"] = "Mate",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 226594,
          ["ilvl"] = 325,
          ["crit"] = 1336,
          ["haste"] = 515,
          ["mastery"] = 1235,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjxYY2mZmZmZbGjmZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAYgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Asxa",
          ["guild"] = "Lucid",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 223989,
          ["ilvl"] = 322,
          ["crit"] = 1307,
          ["haste"] = 471,
          ["mastery"] = 1260,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMbzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Tíghtan",
          ["guild"] = "Easy Katka",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 220464,
          ["ilvl"] = 320,
          ["crit"] = 1510,
          ["haste"] = 338,
          ["mastery"] = 1251,
          ["vers"] = 218,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjxMDz2MzMzMbGjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgZgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "셀리에",
          ["guild"] = "인앤아웃",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 219859,
          ["ilvl"] = 325,
          ["crit"] = 1366,
          ["haste"] = 594,
          ["mastery"] = 1146,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMGDzyMzMzMbzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAYgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "九九捌小魔王",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 219662,
          ["ilvl"] = 325,
          ["crit"] = 1504,
          ["haste"] = 328,
          ["mastery"] = 1312,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZGDz2MzMzMbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "风灬焰",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 219400,
          ["ilvl"] = 324,
          ["crit"] = 1209,
          ["haste"] = 659,
          ["mastery"] = 1223,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMGDz2MzMzMLzMjYMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Ilusiodeath",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 218873,
          ["ilvl"] = 322,
          ["crit"] = 1392,
          ["haste"] = 609,
          ["mastery"] = 1107,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAz2MzMzMbzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGgxgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Shrekson",
          ["guild"] = "Banda Spelli",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 217640,
          ["ilvl"] = 324,
          ["crit"] = 1409,
          ["haste"] = 521,
          ["mastery"] = 1122,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMbzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Sízzi",
          ["guild"] = "RR inc",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 217638,
          ["ilvl"] = 325,
          ["crit"] = 1298,
          ["haste"] = 544,
          ["mastery"] = 1244,
          ["vers"] = 144,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZGDz2MzMzMLmZkZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        },
        {
          ["name"] = "Kirito",
          ["guild"] = "Top melon",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 217355,
          ["ilvl"] = 320,
          ["crit"] = 1401,
          ["haste"] = 449,
          ["mastery"] = 1148,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMjZMDY2mZmZmZZmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAYgB",
          ["hero"] = {
            ["name"] = "Deathbringer",
            ["atlas"] = "talents-heroclass-deathknight-deathbringer",
            ["icon"] = "inv_ability_deathbringerdeathknight_reapersmark"
          }
        }
      }
    },
    {
      ["spec"] = "Unholy",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Animalgoat",
          ["guild"] = "BGW",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217426,
          ["ilvl"] = 324,
          ["crit"] = 1327,
          ["haste"] = 608,
          ["mastery"] = 1095,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZa2MzYmZMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassAYZwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Mograinez",
          ["guild"] = "Shots Fired",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215660,
          ["ilvl"] = 325,
          ["crit"] = 1320,
          ["haste"] = 483,
          ["mastery"] = 1234,
          ["vers"] = 137,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMMjZMDz2MzMTz2MzYmZMAAAAAAAAMzwYAwyMmZ2MzYmZMwAzYRjlFAbD2wAmBgxMzYGMzAjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "David",
          ["guild"] = "Eternal",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 214083,
          ["ilvl"] = 325,
          ["crit"] = 1185,
          ["haste"] = 698,
          ["mastery"] = 1230,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjZGjZ2mZmZa2MzYMjZAAAAAAAAMzwYAwyMmZ2MzYmZMwAzYTjlFAbD2wAmBgxMzYGMzghxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "滄夢馭曜",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 211585,
          ["ilvl"] = 324,
          ["crit"] = 1344,
          ["haste"] = 422,
          ["mastery"] = 1284,
          ["vers"] = 116,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjZGjZ2mZmZa2MzYYMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Hondodk",
          ["guild"] = "The Vindicated",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 210192,
          ["ilvl"] = 326,
          ["crit"] = 1378,
          ["haste"] = 547,
          ["mastery"] = 1264,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mZmZaWMzYMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "紅袖添香灬",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 209633,
          ["ilvl"] = 327,
          ["crit"] = 1378,
          ["haste"] = 451,
          ["mastery"] = 1294,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjZmZY2mZmZaWMzYYMDAAAAAAAgZGmZAwyMmZ2MzYMjBGYGbassBYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Netanyaflu",
          ["guild"] = "Pool Noodle Pirates",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 208901,
          ["ilvl"] = 325,
          ["crit"] = 1443,
          ["haste"] = 371,
          ["mastery"] = 1260,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmZMjZYY2mZmZaWmZGjZMAAAAAAAAMzwYAwyMmZ2mZGjZMwAzYTjlFAbD2wAmBgxMzYGMzAmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Gkurfvrst",
          ["guild"] = "仰望星空",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 207938,
          ["ilvl"] = 313,
          ["crit"] = 1276,
          ["haste"] = 472,
          ["mastery"] = 1076,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 249344,
              ["name"] = "Light Company Guidon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTz2MzYMjBAAAAAAAg5BGGDAWmBzmZGzMjBGYGbassBYbwGGwMAmZmZGzgZGMmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Raskanera",
          ["guild"] = "Doomed",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 207228,
          ["ilvl"] = 324,
          ["crit"] = 1331,
          ["haste"] = 545,
          ["mastery"] = 1192,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMMjZMDz2MzMTz2MzYmZMAAAAAAAAMzwYAwyMmZ2MzYmZMwAzYRjlFAbD2wAmBgxMzYGMzAjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "還我寂寞盛夏",
          ["guild"] = "SnowElysium",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 206931,
          ["ilvl"] = 319,
          ["crit"] = 1443,
          ["haste"] = 396,
          ["mastery"] = 1095,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMMjxMDz2MzMTz2MzYMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Trogagodk",
          ["guild"] = "Пять Бутылок Водки",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 205915,
          ["ilvl"] = 323,
          ["crit"] = 1239,
          ["haste"] = 727,
          ["mastery"] = 1046,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZmZGDz2MzMTz2MzYYMDAAAAAAAgZGmZAw2MmZ2mZGjZMwAzYTjlFAbD2AwMAMmZGzgZGgxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Daìsukeew",
          ["guild"] = "Aeternum",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 205143,
          ["ilvl"] = 325,
          ["crit"] = 1457,
          ["haste"] = 278,
          ["mastery"] = 1295,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mZmZa2MzYMjBAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Flameroll",
          ["guild"] = "Anime Thighs",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 204642,
          ["ilvl"] = 324,
          ["crit"] = 1380,
          ["haste"] = 526,
          ["mastery"] = 1201,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTzmZGzMjBAAAAAAAgZGmZAwyMmZ2mZGjZALmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Shenroh",
          ["guild"] = "Might",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 203968,
          ["ilvl"] = 326,
          ["crit"] = 1493,
          ["haste"] = 345,
          ["mastery"] = 1300,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTz2MzYMjBAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Mograinez",
          ["guild"] = "Shots Fired",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 201326,
          ["ilvl"] = 325,
          ["crit"] = 1320,
          ["haste"] = 483,
          ["mastery"] = 1234,
          ["vers"] = 137,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMMjZGDz2MzMTz2MzYmZMAAAAAAAAMzwMDAWmxMz2MzYMDYxsYYgBmNGasAgZAYMzMmBYmxYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Kratosor",
          ["guild"] = "SaveCowEatPanda",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 201144,
          ["ilvl"] = 325,
          ["crit"] = 1422,
          ["haste"] = 207,
          ["mastery"] = 1406,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZmZGDz2MzMTzmZGjZMAAAAAAAAMzwMDAWmxMz2MzYMDYzsYYgBmNGaswAMDAjZmxMAzMYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "紅袖添香灬",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 200877,
          ["ilvl"] = 327,
          ["crit"] = 1378,
          ["haste"] = 451,
          ["mastery"] = 1294,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjZmZY2mZmZaWMzYYMDAAAAAAAgZGmZAwyMmZ2mZGjZMwAzYTjlNAbD2AwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "笹百合",
          ["guild"] = "People In Love",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 199807,
          ["ilvl"] = 323,
          ["crit"] = 1372,
          ["haste"] = 378,
          ["mastery"] = 1214,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDzMzMDz2MzMTz2MzYYMDAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Drixul",
          ["guild"] = "K E K L E O",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 199501,
          ["ilvl"] = 324,
          ["crit"] = 1452,
          ["haste"] = 368,
          ["mastery"] = 1198,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTz2MzYMjBAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Finesthour",
          ["guild"] = "Vindicatum",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198760,
          ["ilvl"] = 324,
          ["crit"] = 1436,
          ["haste"] = 342,
          ["mastery"] = 1290,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZa2MzYmZMDAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Finesthour",
          ["guild"] = "Vindicatum",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 383083,
          ["ilvl"] = 320,
          ["crit"] = 1307,
          ["haste"] = 444,
          ["mastery"] = 1242,
          ["vers"] = 139,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZaWMzYmZMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "滄夢馭曜",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 381901,
          ["ilvl"] = 324,
          ["crit"] = 1347,
          ["haste"] = 422,
          ["mastery"] = 1284,
          ["vers"] = 116,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjZGjZ2mZmZa2MzYYMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "韭菜炒鸡蛋",
          ["guild"] = "风炎",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 379340,
          ["ilvl"] = 321,
          ["crit"] = 1290,
          ["haste"] = 422,
          ["mastery"] = 1329,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2GzMTzyMzYmZMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Zakrian",
          ["guild"] = "All into Boss",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 375493,
          ["ilvl"] = 321,
          ["crit"] = 1439,
          ["haste"] = 538,
          ["mastery"] = 1209,
          ["vers"] = 93,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTz2MGjZMAAAAAAAAMzwYAwyMmZ2MzYmZMwAzYRjlFAbD2wAmBgxMzYGMzgZmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Rangedbad",
          ["guild"] = "Twitch Prime",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 373707,
          ["ilvl"] = 324,
          ["crit"] = 1536,
          ["haste"] = 281,
          ["mastery"] = 1244,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZaWMzYmZMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Rammoskebab",
          ["guild"] = "neverlucky",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 368234,
          ["ilvl"] = 320,
          ["crit"] = 1570,
          ["haste"] = 258,
          ["mastery"] = 1409,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250229,
              ["name"] = "Idol of the War Loa",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mZmZaWmZGDjZAAAAAAAAMzwYAwyMmZ2MzYmZMwAzYTjlNAbD2wAmBgxMzYGMzAmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Cottonsocks",
          ["guild"] = "Raid From Home",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 366702,
          ["ilvl"] = 324,
          ["crit"] = 1515,
          ["haste"] = 485,
          ["mastery"] = 1015,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZaWMzYmZMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Winjoo",
          ["guild"] = "Traube Minze",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 363426,
          ["ilvl"] = 326,
          ["crit"] = 1425,
          ["haste"] = 505,
          ["mastery"] = 1197,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTzmZmZMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Animalgoat",
          ["guild"] = "BGW",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 363332,
          ["ilvl"] = 323,
          ["crit"] = 1318,
          ["haste"] = 607,
          ["mastery"] = 1093,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZa2MzYmZMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassAYZwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Nmmdecay",
          ["guild"] = "undecided",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 362463,
          ["ilvl"] = 326,
          ["crit"] = 1633,
          ["haste"] = 203,
          ["mastery"] = 1235,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTzyMzYMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Раммштайнн",
          ["guild"] = "Кайзер",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 274596,
          ["ilvl"] = 325,
          ["crit"] = 1439,
          ["haste"] = 507,
          ["mastery"] = 1228,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mZmZaWmxYMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Ripx",
          ["guild"] = "Ascendance",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 270129,
          ["ilvl"] = 322,
          ["crit"] = 1314,
          ["haste"] = 500,
          ["mastery"] = 1180,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZmZGDz2MzMTziZGDjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Zzdk",
          ["guild"] = "마취괍니다",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 267532,
          ["ilvl"] = 323,
          ["crit"] = 1411,
          ["haste"] = 586,
          ["mastery"] = 1024,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2YmZaWmZGzMjZAAAAAAAAMzwYAwyMmZ2MzYmZMwAzYRjlFAbD2wAmBgxMzYGMzghxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Kleaver",
          ["guild"] = "value",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 266972,
          ["ilvl"] = 323,
          ["crit"] = 1462,
          ["haste"] = 336,
          ["mastery"] = 1189,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTz2MzYMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Znoo",
          ["guild"] = "value",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 265218,
          ["ilvl"] = 326,
          ["crit"] = 1292,
          ["haste"] = 582,
          ["mastery"] = 1185,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTziZmZMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassBYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Epyct",
          ["guild"] = "Apathy",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 264657,
          ["ilvl"] = 324,
          ["crit"] = 1291,
          ["haste"] = 769,
          ["mastery"] = 859,
          ["vers"] = 236,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZmZGDz2MzMTziZGDjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Lethkar",
          ["guild"] = "comma",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 264483,
          ["ilvl"] = 325,
          ["crit"] = 1564,
          ["haste"] = 160,
          ["mastery"] = 1312,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTz2MGDzMAAAAAAAAMzwYAwyMmZ2MzYmZMwAzYTjlFAbD2YGwMAMmZGzgZGYmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Nixmortem",
          ["guild"] = "Milkin Time",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 261589,
          ["ilvl"] = 325,
          ["crit"] = 1487,
          ["haste"] = 458,
          ["mastery"] = 1109,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTz2MzYYMAAAAAAAAMzwYAwyMmZ2MzYmZMwAzYRjlNAbD2wAmBgxMzYGMzgZmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Mograinez",
          ["guild"] = "Shots Fired",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 260626,
          ["ilvl"] = 325,
          ["crit"] = 1320,
          ["haste"] = 483,
          ["mastery"] = 1234,
          ["vers"] = 137,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMMjZYY2mZmZa2mZGzMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Animalgoat",
          ["guild"] = "BGW",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 259559,
          ["ilvl"] = 324,
          ["crit"] = 1327,
          ["haste"] = 608,
          ["mastery"] = 1095,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZa2MzYmZMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassAYZwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "有咩",
          ["guild"] = "靈魂归宿",
          ["boss"] = "Sszorak",
          ["amount"] = 223035,
          ["ilvl"] = 325,
          ["crit"] = 1379,
          ["haste"] = 453,
          ["mastery"] = 1204,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMMjxYY2mZmZaWmZGjZMAAAAAAAAMzwMDAWmxMz2MzYMDYzsYYgBmNGasAgZAYMzMmBYmZmZMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Swoleman",
          ["guild"] = "Merely A Setback",
          ["boss"] = "Sszorak",
          ["amount"] = 223016,
          ["ilvl"] = 325,
          ["crit"] = 1532,
          ["haste"] = 407,
          ["mastery"] = 1153,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTz2MzYYMAAAAAAAAMzwMDAWmxMz2MzYMDYzsYYgBmNGasAgZAYMzMmBYmZmZMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Виндми",
          ["guild"] = "Нет пути назад",
          ["boss"] = "Sszorak",
          ["amount"] = 222367,
          ["ilvl"] = 326,
          ["crit"] = 1382,
          ["haste"] = 463,
          ["mastery"] = 1246,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTzmZmZMjBAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Grimorn",
          ["guild"] = "Afro Ninjas",
          ["boss"] = "Sszorak",
          ["amount"] = 219400,
          ["ilvl"] = 325,
          ["crit"] = 1392,
          ["haste"] = 521,
          ["mastery"] = 1170,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTzmZmZMjBAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Snowso",
          ["guild"] = "Kiwi Company",
          ["boss"] = "Sszorak",
          ["amount"] = 219105,
          ["ilvl"] = 322,
          ["crit"] = 1562,
          ["haste"] = 211,
          ["mastery"] = 1272,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjZGDz2MzMTzmZGjZMDAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Smolbreather",
          ["guild"] = "From Ashes",
          ["boss"] = "Sszorak",
          ["amount"] = 218722,
          ["ilvl"] = 326,
          ["crit"] = 1403,
          ["haste"] = 485,
          ["mastery"] = 1179,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTzmZmZMjBAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "忙碌的海狸",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "Sszorak",
          ["amount"] = 217804,
          ["ilvl"] = 328,
          ["crit"] = 1306,
          ["haste"] = 330,
          ["mastery"] = 1315,
          ["vers"] = 200,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTjZmxYGDAAAAAAAAzMMzAglZMzsNzMGzAWMLGGYgZjhGLAYGAGzMjZAmZmZGD",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Ripz",
          ["guild"] = "TRK",
          ["boss"] = "Sszorak",
          ["amount"] = 217456,
          ["ilvl"] = 323,
          ["crit"] = 1460,
          ["haste"] = 412,
          ["mastery"] = 1356,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTzyMzYMjBAAAAAAAgZGmZAwyMmZ2mZGjZALmFDDMwsxQjFAMDAjZmxMAzMjZMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Drogdealer",
          ["guild"] = "Aotic",
          ["boss"] = "Sszorak",
          ["amount"] = 217014,
          ["ilvl"] = 327,
          ["crit"] = 1344,
          ["haste"] = 576,
          ["mastery"] = 1124,
          ["vers"] = 157,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMMjxYY2mZmZaWmZGjZMAAAAAAAAMzwMDAWmxMz2MzYMDYzsYYgBmNGasAgZAYMzMmBYmZmZMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Ðeförz",
          ["guild"] = "Projet Nameless",
          ["boss"] = "Sszorak",
          ["amount"] = 216666,
          ["ilvl"] = 324,
          ["crit"] = 1292,
          ["haste"] = 690,
          ["mastery"] = 1031,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZmZGDz2MzMTzmZGjZMAAAAAAAAMzwMDAWmxMz2MzYMDYzsYYgBmNGasAgZAYMzMmBYmZYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Zarmakai",
          ["guild"] = "Rain",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 251784,
          ["ilvl"] = 324,
          ["crit"] = 1390,
          ["haste"] = 578,
          ["mastery"] = 1166,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMDDz2MzMTzmZmZmZMAAAAAAAAMzwYAwyMmZ2mZGzMjBGYGLassBYbwGAmBgxMzYGMzghxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Obl",
          ["guild"] = "Competence Optional",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 249678,
          ["ilvl"] = 326,
          ["crit"] = 1187,
          ["haste"] = 461,
          ["mastery"] = 1314,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMGDz2MzMTz2MzYMjBAAAAAAAgZGGDAWmxMz2MzYmZMwAzYTjlFAbD2AwMAMmZGzgZGMmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Nadriethiël",
          ["guild"] = "Salty Tears",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 245582,
          ["ilvl"] = 327,
          ["crit"] = 1379,
          ["haste"] = 339,
          ["mastery"] = 1366,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmZMjZYY2mZmZaWMzYMjBAAAAAAAgZGGDAWmxMz2MzYmZMwAzYTjlNAbD2AwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "紅袖添香灬",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 245138,
          ["ilvl"] = 327,
          ["crit"] = 1381,
          ["haste"] = 455,
          ["mastery"] = 1299,
          ["vers"] = 154,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZaWMzYmZMDAAAAAAAgZGmZAwyMmZ2MzYMjBGYGbassBYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Gaelama",
          ["guild"] = "Pig Pen",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 241719,
          ["ilvl"] = 324,
          ["crit"] = 1197,
          ["haste"] = 695,
          ["mastery"] = 1213,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmZMjZYYWmZmZa2MzMjZMAAAAAAAAMzwMDAWmxMz2MzYmZMwAzYRjlFAbD2AwMAwMzYGMzghxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "篠绮",
          ["guild"] = "Dim Moon",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 236370,
          ["ilvl"] = 328,
          ["crit"] = 1440,
          ["haste"] = 342,
          ["mastery"] = 1340,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmBjxYY2mZmZa2mZGjZMDAAAAAAAgZGGDAWmxMz2MzYmZMwAzYTjlNAbD2AwMAMmZGzgZGYmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Finesthour",
          ["guild"] = "Vindicatum",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 231477,
          ["ilvl"] = 326,
          ["crit"] = 1424,
          ["haste"] = 302,
          ["mastery"] = 1385,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmZYMGDz2MzMTziZGzMjZAAAAAAAAMzwYAwyMmZ2mZGzMjBGYGbassAYbwGAmBgxMzYGMzghxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Zimengdk",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 217133,
          ["ilvl"] = 325,
          ["crit"] = 1037,
          ["haste"] = 480,
          ["mastery"] = 1209,
          ["vers"] = 396,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmBjxYYWmZmZaWmZGjZMDAAAAAAAgZGmZAwyMmZ2mZGjZAbmFDDMwsxQjFAMDAjZmxMAzMjZMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Anthaniadk",
          ["guild"] = "Blinded",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 197354,
          ["ilvl"] = 323,
          ["crit"] = 1203,
          ["haste"] = 522,
          ["mastery"] = 1270,
          ["vers"] = 144,
          ["trinkets"] = {
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmZMjZMDz2MzMTDzMGzYAAAAAAAAYmhxAglZMzsNzMmZGDMwMW0YZDw2gNAMDAjZmxMYmBzYMA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Gdubs",
          ["guild"] = "Comfy",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 186865,
          ["ilvl"] = 325,
          ["crit"] = 1464,
          ["haste"] = 540,
          ["mastery"] = 1135,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTzyMzYMjBAAAAAAAgZGmZAwyMmZ2mZGjZALmFDDMwsxQjFAMDAjZmxMAzMzYMA",
          ["hero"] = {
            ["name"] = "Rider of the Apocalypse",
            ["atlas"] = "talents-heroclass-deathknight-rideroftheapocalypse",
            ["icon"] = "achievement_zone_icecrown_01"
          }
        },
        {
          ["name"] = "Smolbreather",
          ["guild"] = "From Ashes",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 223231,
          ["ilvl"] = 320,
          ["crit"] = 1220,
          ["haste"] = 591,
          ["mastery"] = 1282,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzMDz2MzMTzmZGDjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassBYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Animalgoat",
          ["guild"] = "BGW",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 219113,
          ["ilvl"] = 321,
          ["crit"] = 1273,
          ["haste"] = 588,
          ["mastery"] = 1138,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZa2MzYmZMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassAYZwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "David",
          ["guild"] = "Eternal",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 218788,
          ["ilvl"] = 322,
          ["crit"] = 1379,
          ["haste"] = 502,
          ["mastery"] = 1139,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzMDz2MzMTzmZGDjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassBYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "丶欧皇骑",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 216317,
          ["ilvl"] = 324,
          ["crit"] = 1302,
          ["haste"] = 531,
          ["mastery"] = 1207,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMMjZGDz2MzMTzyMzYMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "꿀꿀멍멍꿀꿀멍멍",
          ["guild"] = "마취괍니다",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 215990,
          ["ilvl"] = 319,
          ["crit"] = 1238,
          ["haste"] = 516,
          ["mastery"] = 1265,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMGDz2MzMTzyMGzMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassBYbwGGwMAMmZGzgZGYmxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Rangedbad",
          ["guild"] = "Twitch Prime",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 215203,
          ["ilvl"] = 322,
          ["crit"] = 1421,
          ["haste"] = 338,
          ["mastery"] = 1262,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmZMjxYY2mZmZa2MzYmZMAAAAAAAAMzwMDAWmxMzmZGzMjBGYGbassAYbwGAmBgxMzYGMzAjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Dkflawkins",
          ["guild"] = "Divide",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 215144,
          ["ilvl"] = 324,
          ["crit"] = 1496,
          ["haste"] = 212,
          ["mastery"] = 1323,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTzmZmZMjBAAAAAAAgZGGDAWmxMzmZGzMjBGYGLassBYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Willybwankin",
          ["guild"] = "The Vindicated",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 214905,
          ["ilvl"] = 322,
          ["crit"] = 1274,
          ["haste"] = 384,
          ["mastery"] = 1348,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mZmZaMjxYGDAAAAAAAAzMMGAsMjZmNzMmZGDMwMW0YZDw2gNMgZAYMzMmBzMYmZMA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Líùdk",
          ["guild"] = "Anime Thighs",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 214893,
          ["ilvl"] = 324,
          ["crit"] = 1229,
          ["haste"] = 495,
          ["mastery"] = 1343,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mxMTjZmxYGzAAAAAAAAYmhxAglZMzsZmxMzYgBmxmGLbA2GshBMDAjZmxMYmBjZMA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        },
        {
          ["name"] = "Adeeoz",
          ["guild"] = "Gray Parses Only",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 214280,
          ["ilvl"] = 325,
          ["crit"] = 1353,
          ["haste"] = 338,
          ["mastery"] = 1373,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMDjxYY2mZmZa2MzYmZMDAAAAAAAgZGGDAWmxMzmZGzMjBGYGbassAYbwGGwMAMmZGzgZGMjxA",
          ["hero"] = {
            ["name"] = "San'layn",
            ["atlas"] = "talents-heroclass-deathknight-sanlayn",
            ["icon"] = "inv_ability_sanlayndeathknight_vampiricstrike"
          }
        }
      }
    }
  }
}
