MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Shaman"] = {
  ["className"] = "Shaman",
  ["specs"] = {
    {
      ["spec"] = "Elemental",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Dwarfun",
          ["guild"] = "Wisp",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 255589,
          ["ilvl"] = 325,
          ["crit"] = 1211,
          ["haste"] = 687,
          ["mastery"] = 989,
          ["vers"] = 157,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMzM2WMtxMjxyMzMjhFLzYxMDzsMAgBAmZMMMA"
        },
        {
          ["name"] = "Филдан",
          ["guild"] = "Зов Саргераса",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 243544,
          ["ilvl"] = 323,
          ["crit"] = 929,
          ["haste"] = 868,
          ["mastery"] = 1038,
          ["vers"] = 146,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2ipFmZ2GLzMzMGWsMsYmhZWGAwwAYmxwwA"
        },
        {
          ["name"] = "딸딸맨",
          ["guild"] = "Mess",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 242892,
          ["ilvl"] = 321,
          ["crit"] = 865,
          ["haste"] = 995,
          ["mastery"] = 963,
          ["vers"] = 224,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsMzMjx2ipNmZWGLzMzMGWmlhFzMMzyAAGAYmxwwA"
        },
        {
          ["name"] = "Màndow",
          ["guild"] = "Offline",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 239659,
          ["ilvl"] = 326,
          ["crit"] = 1146,
          ["haste"] = 988,
          ["mastery"] = 849,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsMzMjx2ipFmZWGLmZmxwysMjFzMMzyAAGAYmxwwA"
        },
        {
          ["name"] = "Torbentosse",
          ["guild"] = "Pure",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 239383,
          ["ilvl"] = 326,
          ["crit"] = 1253,
          ["haste"] = 688,
          ["mastery"] = 943,
          ["vers"] = 112,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsMzMjx2ipNmZWGLzMzMGWsMjFzMMzyAAGAYmxwwA"
        },
        {
          ["name"] = "Fauni",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 238887,
          ["ilvl"] = 321,
          ["crit"] = 808,
          ["haste"] = 901,
          ["mastery"] = 1129,
          ["vers"] = 213,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmlZmZM2WMtxMjxyMzMjhlZZmZZYMzsAAMAwMjhhB"
        },
        {
          ["name"] = "Futter",
          ["guild"] = "macht DRUCK",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 238678,
          ["ilvl"] = 323,
          ["crit"] = 1085,
          ["haste"] = 822,
          ["mastery"] = 1063,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjZAAAAgFzsBDYAzGTgZBAmtZmZM2WmJMzswiZmZMDzyMWMGmZZAADDgZGDDD"
        },
        {
          ["name"] = "Zedbeastly",
          ["guild"] = "Regular Average Gamers",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 236976,
          ["ilvl"] = 325,
          ["crit"] = 1005,
          ["haste"] = 674,
          ["mastery"] = 1188,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsMzMjx2ipNmZ2GLzMzMGWsMjFzMMzyAAGAYmxwwA"
        },
        {
          ["name"] = "산업통상자원부",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 236396,
          ["ilvl"] = 322,
          ["crit"] = 796,
          ["haste"] = 936,
          ["mastery"] = 986,
          ["vers"] = 229,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2ipFmZ2GLz8AzMGWmlhFzMMzyAAGGAzMGGGA"
        },
        {
          ["name"] = "聚光灯往这打",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 236132,
          ["ilvl"] = 321,
          ["crit"] = 995,
          ["haste"] = 693,
          ["mastery"] = 1029,
          ["vers"] = 194,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2yMtxMzGLzMzMmBLDLmZYmlBAMMAmZMMMA"
        },
        {
          ["name"] = "花花十二",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 220876,
          ["ilvl"] = 323,
          ["crit"] = 912,
          ["haste"] = 748,
          ["mastery"] = 948,
          ["vers"] = 306,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMzM2WMtxMzyYZmZmxwilhFzMMz2AAGAYmxwwA"
        },
        {
          ["name"] = "呱呱萨",
          ["guild"] = "共踏人生漫长路",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 215816,
          ["ilvl"] = 326,
          ["crit"] = 1111,
          ["haste"] = 844,
          ["mastery"] = 921,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2ipNmZMWmZmZMsMLDLmZYmtBAMMAmZMMMA"
        },
        {
          ["name"] = "今晚吃什么呢",
          ["guild"] = "门徒",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 215482,
          ["ilvl"] = 323,
          ["crit"] = 1138,
          ["haste"] = 592,
          ["mastery"] = 1048,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsMzMjx2ipNmZMWm5BmZMsMLzYxMDzsNAghBwMjhhB"
        },
        {
          ["name"] = "Tokeros",
          ["guild"] = "The Amazing Zoo",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 213948,
          ["ilvl"] = 327,
          ["crit"] = 1036,
          ["haste"] = 787,
          ["mastery"] = 1105,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2ipFmZWGLz8AzMGWmlZsYmhZWGAwAAzMGGGA"
        },
        {
          ["name"] = "Letalgenital",
          ["guild"] = "Jet Set Club",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 213225,
          ["ilvl"] = 324,
          ["crit"] = 1076,
          ["haste"] = 764,
          ["mastery"] = 1010,
          ["vers"] = 245,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsMWmZmZMsMLzYxMDzsNAgBAmZMMMA"
        },
        {
          ["name"] = "알트갤러리",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 212957,
          ["ilvl"] = 326,
          ["crit"] = 972,
          ["haste"] = 817,
          ["mastery"] = 1025,
          ["vers"] = 181,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMzM2WMtxMzyYZmZmxwilhFzMMz2AAGAYmxwwA"
        },
        {
          ["name"] = "Torbentosse",
          ["guild"] = "Pure",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 211467,
          ["ilvl"] = 327,
          ["crit"] = 1257,
          ["haste"] = 692,
          ["mastery"] = 947,
          ["vers"] = 116,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsMzMjx2ipNmZWGLzMzMGWsMjFzMMzyAAGAYmxwwA"
        },
        {
          ["name"] = "Moneyshaman",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 210204,
          ["ilvl"] = 327,
          ["crit"] = 1138,
          ["haste"] = 881,
          ["mastery"] = 836,
          ["vers"] = 199,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2ipNmZMWmZmZMsMLzYxMDzsMAgBAmZMMMA"
        },
        {
          ["name"] = "Zedbeastly",
          ["guild"] = "Regular Average Gamers",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209736,
          ["ilvl"] = 325,
          ["crit"] = 1005,
          ["haste"] = 674,
          ["mastery"] = 1188,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsMzMjx2ipNmZ2GLzMzMGWsMjFzMMzyAAGAYmxwwA"
        },
        {
          ["name"] = "Ygrit",
          ["guild"] = "Equity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209368,
          ["ilvl"] = 327,
          ["crit"] = 1062,
          ["haste"] = 702,
          ["mastery"] = 1151,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2ipNmZMWmZmZeghFLDLmZYmlBAMMAmZMMMA"
        },
        {
          ["name"] = "小奈电下",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 336422,
          ["ilvl"] = 324,
          ["crit"] = 1235,
          ["haste"] = 704,
          ["mastery"] = 849,
          ["vers"] = 137,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZMWWmpNmZwyMzMjZwyMzywYmZBAYGAMzYYYA"
        },
        {
          ["name"] = "Divezyy",
          ["guild"] = "Vestige",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 333554,
          ["ilvl"] = 321,
          ["crit"] = 885,
          ["haste"] = 563,
          ["mastery"] = 1139,
          ["vers"] = 315,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMtxMjxyMzMjZsYZmZZYMzsAAMAwMjhhB"
        },
        {
          ["name"] = "橘芋子",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327166,
          ["ilvl"] = 323,
          ["crit"] = 948,
          ["haste"] = 851,
          ["mastery"] = 1176,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAsMzMjZ2WmJmZmFzyMmZMGzyMzywYmZBAYAgZGDDD"
        },
        {
          ["name"] = "Fellorc",
          ["guild"] = "Main Tank Heal",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 325060,
          ["ilvl"] = 323,
          ["crit"] = 1100,
          ["haste"] = 782,
          ["mastery"] = 857,
          ["vers"] = 193,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMhZmtxyMzMjhlZZYZGjZmFAghBwMjhhB"
        },
        {
          ["name"] = "Hesitant",
          ["guild"] = "Solid Lads",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 324331,
          ["ilvl"] = 323,
          ["crit"] = 955,
          ["haste"] = 726,
          ["mastery"] = 1153,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMtxMjxyMzMjhFLmZZYMzsAAMjBwMjhhB"
        },
        {
          ["name"] = "Torbentosse",
          ["guild"] = "Pure",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323726,
          ["ilvl"] = 324,
          ["crit"] = 1084,
          ["haste"] = 847,
          ["mastery"] = 941,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMhZGjlZmZmHYYZWmZWGGzMLAADAMzYYYA"
        },
        {
          ["name"] = "Thundershøck",
          ["guild"] = "Shattered",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323190,
          ["ilvl"] = 326,
          ["crit"] = 818,
          ["haste"] = 961,
          ["mastery"] = 1102,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMtxMjxyMzMjhlZZMLDjZmFAghBwMjhhB"
        },
        {
          ["name"] = "今晚吃什么呢",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 322969,
          ["ilvl"] = 323,
          ["crit"] = 1181,
          ["haste"] = 531,
          ["mastery"] = 1068,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmlZmZM2WMtxMjxyMjZMjlZZMLDjZmNAghBwMjhhB"
        },
        {
          ["name"] = "Dwarfun",
          ["guild"] = "Wisp",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 321423,
          ["ilvl"] = 322,
          ["crit"] = 917,
          ["haste"] = 539,
          ["mastery"] = 1228,
          ["vers"] = 274,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZmx2ipNmZMWmZmZMsYZmZZYMzsAAMAwMjhhB"
        },
        {
          ["name"] = "Frisky",
          ["guild"] = "Arcane Energies",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 318747,
          ["ilvl"] = 322,
          ["crit"] = 946,
          ["haste"] = 729,
          ["mastery"] = 1083,
          ["vers"] = 190,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2ipNmZ2GLmZmxwmlhlZmxMzCAwMGAzMGGGA"
        },
        {
          ["name"] = "Glaern",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 299937,
          ["ilvl"] = 326,
          ["crit"] = 930,
          ["haste"] = 813,
          ["mastery"] = 828,
          ["vers"] = 427,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsMWmZmZMsYZmZZYMzsMAghBwMjhZ8BA"
        },
        {
          ["name"] = "Dwarfun",
          ["guild"] = "Wisp",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 283863,
          ["ilvl"] = 325,
          ["crit"] = 1211,
          ["haste"] = 687,
          ["mastery"] = 989,
          ["vers"] = 157,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMzM2WMhZmtxyMzMjhFLzMLDjZmlBAMAwMjhZ8BA"
        },
        {
          ["name"] = "Catfishcraig",
          ["guild"] = "Pathogen",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 278804,
          ["ilvl"] = 325,
          ["crit"] = 1110,
          ["haste"] = 855,
          ["mastery"] = 1098,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2yMhZGsMzMzYGmlZmlhxMzyAAGGAzMGmxHA"
        },
        {
          ["name"] = "Nicktotem",
          ["guild"] = "Revoke",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 275738,
          ["ilvl"] = 325,
          ["crit"] = 826,
          ["haste"] = 847,
          ["mastery"] = 1193,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzYsMzMzYGLzyMzywYmZZAADAMzYYGfA"
        },
        {
          ["name"] = "Moneyshaman",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 274877,
          ["ilvl"] = 327,
          ["crit"] = 1138,
          ["haste"] = 881,
          ["mastery"] = 836,
          ["vers"] = 199,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2ipNmZMWmZmZMsMLzMLDjZmlBAMAwMjhZ8BA"
        },
        {
          ["name"] = "堇色蛋糕",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 274193,
          ["ilvl"] = 328,
          ["crit"] = 1121,
          ["haste"] = 792,
          ["mastery"] = 928,
          ["vers"] = 131,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsNWmZmZMsMLzMLDjZmlBAMAwMjhZ8BA"
        },
        {
          ["name"] = "Tokeros",
          ["guild"] = "The Amazing Zoo",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 272213,
          ["ilvl"] = 324,
          ["crit"] = 1048,
          ["haste"] = 916,
          ["mastery"] = 1067,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzYsMzMz8ADLzyMzywYmZZAADAMzYYGfA"
        },
        {
          ["name"] = "污橙萨",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 272108,
          ["ilvl"] = 327,
          ["crit"] = 1086,
          ["haste"] = 795,
          ["mastery"] = 974,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsMWmZmZMsMLzMLDjZmlBAMAwMjhZ8BA"
        },
        {
          ["name"] = "Лёхапират",
          ["guild"] = "Лё Резистанс",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 270998,
          ["ilvl"] = 322,
          ["crit"] = 877,
          ["haste"] = 858,
          ["mastery"] = 1084,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZZZMmhBAAAAsYmNYADY2YCMLAglZmZmZ2WmJmZmNWmZmZMwyMzywYmZZAADAMzYYGfA"
        },
        {
          ["name"] = "可爱心",
          ["guild"] = "B L C",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 270382,
          ["ilvl"] = 326,
          ["crit"] = 1016,
          ["haste"] = 667,
          ["mastery"] = 1039,
          ["vers"] = 292,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZw2CthZMzyMzMzDMsMLzMLDjZmFAgZAwMjhhB"
        },
        {
          ["name"] = "今晚吃什么呢",
          ["guild"] = "门徒",
          ["boss"] = "Sszorak",
          ["amount"] = 241576,
          ["ilvl"] = 327,
          ["crit"] = 1041,
          ["haste"] = 718,
          ["mastery"] = 1012,
          ["vers"] = 254,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsMzMjx2ipNmZMWmZmZMsMLDLmZYmtBAMMAmZMMMA"
        },
        {
          ["name"] = "Tunaken",
          ["guild"] = "Vibrant",
          ["boss"] = "Sszorak",
          ["amount"] = 236788,
          ["ilvl"] = 325,
          ["crit"] = 1243,
          ["haste"] = 574,
          ["mastery"] = 1094,
          ["vers"] = 60,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2ipNmZ2GLzMzMG2sMsYmhZ2GAwwAYmxwwA"
        },
        {
          ["name"] = "Филдан",
          ["guild"] = "Зов Саргераса",
          ["boss"] = "Sszorak",
          ["amount"] = 235243,
          ["ilvl"] = 326,
          ["crit"] = 1034,
          ["haste"] = 864,
          ["mastery"] = 967,
          ["vers"] = 146,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2ipNmZ2GLzMzMGWsMsYmhZWGAwwAYmxwwA"
        },
        {
          ["name"] = "알트갤러리",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 229679,
          ["ilvl"] = 326,
          ["crit"] = 972,
          ["haste"] = 817,
          ["mastery"] = 1025,
          ["vers"] = 181,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMzM2WMtxMzyYZmZmxwilhFzMMz2AAGAYmxwwA"
        },
        {
          ["name"] = "Лёхапират",
          ["guild"] = "Лё Резистанс",
          ["boss"] = "Sszorak",
          ["amount"] = 229187,
          ["ilvl"] = 325,
          ["crit"] = 891,
          ["haste"] = 861,
          ["mastery"] = 1092,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMzM2WMtxMzyYZmxMGWsMsYmhZWGAwMAYmxwwA"
        },
        {
          ["name"] = "呱呱萨",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 227658,
          ["ilvl"] = 326,
          ["crit"] = 2008,
          ["haste"] = 837,
          ["mastery"] = 944,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjx2ipNmZMWmZmZMsMLDLmZYmtBAMMAmZMMMA"
        },
        {
          ["name"] = "Highvöltagë",
          ["guild"] = "Проксима",
          ["boss"] = "Sszorak",
          ["amount"] = 227529,
          ["ilvl"] = 323,
          ["crit"] = 1228,
          ["haste"] = 705,
          ["mastery"] = 1015,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMmZmZZbZMMMDAAAAsYmNYADY2YCMLAwsMzMjx2yMtxMzCLzMzMmhZZYxMzYmFAgBAmZMMMA"
        },
        {
          ["name"] = "Letalgenital",
          ["guild"] = "Jet Set Club",
          ["boss"] = "Sszorak",
          ["amount"] = 226430,
          ["ilvl"] = 326,
          ["crit"] = 1096,
          ["haste"] = 821,
          ["mastery"] = 989,
          ["vers"] = 246,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAgtZmZMz2yMtZmZwyMzMjBzyMWMzwMbDAYAgZGDDD"
        },
        {
          ["name"] = "Kaellach",
          ["guild"] = "Interstellar Bum Orcs",
          ["boss"] = "Sszorak",
          ["amount"] = 225751,
          ["ilvl"] = 319,
          ["crit"] = 1036,
          ["haste"] = 844,
          ["mastery"] = 989,
          ["vers"] = 194,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAgtZmZMz2yMtZmZwyMzMjBzyMWMzwMLDAYAgZGDDD"
        },
        {
          ["name"] = "Futter",
          ["guild"] = "macht DRUCK",
          ["boss"] = "Sszorak",
          ["amount"] = 222608,
          ["ilvl"] = 326,
          ["crit"] = 1106,
          ["haste"] = 816,
          ["mastery"] = 946,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjZAAAAgFzsBDYAzGTgZBAmtZGjx2yMtxMzCLmZmxMMLzYxYYmlBAMMAmZMMMA"
        },
        {
          ["name"] = "Dwarfun",
          ["guild"] = "Wisp",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 286247,
          ["ilvl"] = 323,
          ["crit"] = 925,
          ["haste"] = 545,
          ["mastery"] = 1232,
          ["vers"] = 278,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMzM2WMhZmtxyMzMjhFLzMLDjZmtBAMAwMjhZ8BA"
        },
        {
          ["name"] = "Bondd",
          ["guild"] = "Rain",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 282044,
          ["ilvl"] = 323,
          ["crit"] = 1221,
          ["haste"] = 587,
          ["mastery"] = 1051,
          ["vers"] = 112,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2yMhZmNWmZmZMDzyMzyMGzMbAADAMzYYYA"
        },
        {
          ["name"] = "Tunaken",
          ["guild"] = "Vibrant",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 281920,
          ["ilvl"] = 327,
          ["crit"] = 1246,
          ["haste"] = 576,
          ["mastery"] = 1102,
          ["vers"] = 61,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJmZGjlZmZGDsMzsMMmZ2GAwAAzMGmxHA"
        },
        {
          ["name"] = "小奈电下",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 281687,
          ["ilvl"] = 327,
          ["crit"] = 1029,
          ["haste"] = 690,
          ["mastery"] = 1147,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjxyyMtxMDWmZmZMDWmZWGGzMbDAYGAMzYYGfA"
        },
        {
          ["name"] = "Tokeros",
          ["guild"] = "The Amazing Zoo",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 278325,
          ["ilvl"] = 327,
          ["crit"] = 1036,
          ["haste"] = 790,
          ["mastery"] = 1109,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzYsMzMz8ADLzyMzywYmZbAADAMzYYGfA"
        },
        {
          ["name"] = "Sheffy",
          ["guild"] = "Oblivion",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 276767,
          ["ilvl"] = 328,
          ["crit"] = 1061,
          ["haste"] = 903,
          ["mastery"] = 1036,
          ["vers"] = 16,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJmZGsMzMzYwsMmlhxMz2AAGGAzMGmxHA"
        },
        {
          ["name"] = "花花十三",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 276202,
          ["ilvl"] = 325,
          ["crit"] = 1022,
          ["haste"] = 734,
          ["mastery"] = 1043,
          ["vers"] = 121,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2ipNmZMWmZmZMjFLzMLDjZmtBAMAwMjhZ8BA"
        },
        {
          ["name"] = "느긋한쿠키",
          ["guild"] = "아으 진짜 뭐해요",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 274940,
          ["ilvl"] = 325,
          ["crit"] = 1078,
          ["haste"] = 1044,
          ["mastery"] = 982,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJmZmFWmxMjBzyMzywYmZbAAzAgZGDz4DA"
        },
        {
          ["name"] = "Highvöltagë",
          ["guild"] = "Проксима",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 274687,
          ["ilvl"] = 325,
          ["crit"] = 1343,
          ["haste"] = 769,
          ["mastery"] = 887,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsMzMjx2yMhZmFWmZmZMDzyMzywYmZbAADAMzYYGfA"
        },
        {
          ["name"] = "Catfishcraig",
          ["guild"] = "Pathogen",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 274496,
          ["ilvl"] = 326,
          ["crit"] = 1113,
          ["haste"] = 855,
          ["mastery"] = 1103,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2yMhZGsMzMz8AzwsMzsMMmZ2GAwAAzMGmxHA"
        },
        {
          ["name"] = "Bayazi",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 232977,
          ["ilvl"] = 327,
          ["crit"] = 1127,
          ["haste"] = 765,
          ["mastery"] = 1001,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMtwMjxyMzMjhlZZmZZYMzsBAMAwMjhhB"
        },
        {
          ["name"] = "Nickshockz",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 226099,
          ["ilvl"] = 326,
          ["crit"] = 986,
          ["haste"] = 776,
          ["mastery"] = 1115,
          ["vers"] = 1007,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAglZmZMz2yMtYmZWYZmZmxgZZYxMDzsNAgBAmZMMMA"
        },
        {
          ["name"] = "Zorthar",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 205512,
          ["ilvl"] = 325,
          ["crit"] = 1011,
          ["haste"] = 843,
          ["mastery"] = 1021,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAsMzMzMWWmpFmZWYZmZmxMMLjZZYMzsBAMAwMjhhB"
        },
        {
          ["name"] = "Zorthar",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 329988,
          ["ilvl"] = 331,
          ["crit"] = 1097,
          ["haste"] = 963,
          ["mastery"] = 1058,
          ["vers"] = 1354,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 344
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAsMzMjx2yMtxMzCLzMzMmhZZYZGjZmFAgZAwMjhhB"
        },
        {
          ["name"] = "青鹜狂想曲",
          ["guild"] = "Top melon",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 325666,
          ["ilvl"] = 322,
          ["crit"] = 1155,
          ["haste"] = 731,
          ["mastery"] = 1057,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZZZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WmJMzglZGzMzwsMmlhxMzCAwMAYmxwwA"
        },
        {
          ["name"] = "呱呱萨",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 316072,
          ["ilvl"] = 325,
          ["crit"] = 1302,
          ["haste"] = 787,
          ["mastery"] = 921,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMtxMz2YZmZmxwilxsMMmZWAAmBAzMGGGA"
        },
        {
          ["name"] = "Bondd",
          ["guild"] = "Rain",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 312921,
          ["ilvl"] = 321,
          ["crit"] = 1298,
          ["haste"] = 712,
          ["mastery"] = 805,
          ["vers"] = 112,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmlZmZM2WmpNmZ2YZmZmxMYZmZZYMzsAAMAwMjhhB"
        },
        {
          ["name"] = "Castershaman",
          ["guild"] = "Perdition",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 302748,
          ["ilvl"] = 326,
          ["crit"] = 1155,
          ["haste"] = 987,
          ["mastery"] = 921,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMtwMz2YZmZmxwilZmlhxMzCAwAAzMGGGA"
        },
        {
          ["name"] = "鲜榨小白兔",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 302172,
          ["ilvl"] = 326,
          ["crit"] = 1086,
          ["haste"] = 767,
          ["mastery"] = 1032,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMtxMzyYZmZmxwilxsMMmZWAAmBAzMGGGA"
        },
        {
          ["name"] = "Sheitanaxo",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 297737,
          ["ilvl"] = 321,
          ["crit"] = 1311,
          ["haste"] = 549,
          ["mastery"] = 1021,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsMzMjZ2WmpFzMzGLzYmxALzMLDzMzsAAmBAmZMMMA"
        },
        {
          ["name"] = "Алкхемист",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 294869,
          ["ilvl"] = 320,
          ["crit"] = 819,
          ["haste"] = 923,
          ["mastery"] = 1083,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMtxMjxyMzMjhFLmZZYMzsAAMjBwMjhhB"
        },
        {
          ["name"] = "Nerdshockz",
          ["guild"] = "Northern Sky",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 293446,
          ["ilvl"] = 321,
          ["crit"] = 968,
          ["haste"] = 951,
          ["mastery"] = 776,
          ["vers"] = 276,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WMtxMjxyMzMjZsYZmZZYMzsAAMAwMjhhB"
        },
        {
          ["name"] = "Acelol",
          ["guild"] = "Retired Extremely Bad",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 293368,
          ["ilvl"] = 325,
          ["crit"] = 1117,
          ["haste"] = 800,
          ["mastery"] = 942,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZM2WmJMzswyMjZegZYWGzywYmZBAYYAMzYYYA"
        },
        {
          ["name"] = "Dwarfun",
          ["guild"] = "Wisp",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 293308,
          ["ilvl"] = 323,
          ["crit"] = 920,
          ["haste"] = 540,
          ["mastery"] = 1228,
          ["vers"] = 274,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTgZBAmtZmZmx2ipNmZMWmZmZMsYZmZZYMzsAAMAwMjhhB"
        }
      }
    },
    {
      ["spec"] = "Enhancement",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Totemtickler",
          ["guild"] = "Without Limits",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 228761,
          ["ilvl"] = 325,
          ["crit"] = 793,
          ["haste"] = 998,
          ["mastery"] = 1218,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZsxMDWmZmZGDjZAAmhxMDjAzMYwYA"
        },
        {
          ["name"] = "Myn",
          ["guild"] = "Wild Things",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 227296,
          ["ilvl"] = 326,
          ["crit"] = 1087,
          ["haste"] = 1061,
          ["mastery"] = 975,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYstMjNmZ2YZmZmZMMmBAYGGzMMCMzgBjB"
        },
        {
          ["name"] = "疯乄怒",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 224531,
          ["ilvl"] = 323,
          ["crit"] = 627,
          ["haste"] = 1098,
          ["mastery"] = 1158,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZbGzMjtlZsxMz2YZmZmhBmBAYGGzMmRgZGMYMA"
        },
        {
          ["name"] = "羊宫妃那丶",
          ["guild"] = "Tale of the Past",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 219705,
          ["ilvl"] = 323,
          ["crit"] = 869,
          ["haste"] = 972,
          ["mastery"] = 1182,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBALzMzMjllZgZmNzyMzMDDzyAAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "Werdup",
          ["guild"] = "Echoes",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215183,
          ["ilvl"] = 319,
          ["crit"] = 1121,
          ["haste"] = 835,
          ["mastery"] = 981,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmHYmZwyYGAgZYMzwMBmZwgxA"
        },
        {
          ["name"] = "Rajaion",
          ["guild"] = "Myths",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 214680,
          ["ilvl"] = 321,
          ["crit"] = 760,
          ["haste"] = 821,
          ["mastery"] = 1395,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssMjNmZ2YZmZm5BMMmBAYGGzMmRgZGMYMA"
        },
        {
          ["name"] = "Darlbo",
          ["guild"] = "Nightshade",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 213889,
          ["ilvl"] = 322,
          ["crit"] = 987,
          ["haste"] = 909,
          ["mastery"] = 1076,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzYssYsxMzGLzMzMDMmBAYGGzMmZCMzgBjB"
        },
        {
          ["name"] = "Goblincel",
          ["guild"] = "Insomnîa",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 212657,
          ["ilvl"] = 320,
          ["crit"] = 447,
          ["haste"] = 959,
          ["mastery"] = 1198,
          ["vers"] = 209,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 311
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
        },
        {
          ["name"] = "Mnomquah",
          ["guild"] = "MIAMI",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 211296,
          ["ilvl"] = 321,
          ["crit"] = 743,
          ["haste"] = 860,
          ["mastery"] = 1238,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYmllZsxMz2YZGzMMWGzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Lemonelement",
          ["guild"] = "Trivial",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 209704,
          ["ilvl"] = 323,
          ["crit"] = 726,
          ["haste"] = 955,
          ["mastery"] = 1296,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZbGzYssMjNmZMWmZmZGjFmBAYGGzMMCMzgBjB"
        },
        {
          ["name"] = "Shamyrage",
          ["guild"] = "mythic raid guild",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198311,
          ["ilvl"] = 324,
          ["crit"] = 2771,
          ["haste"] = 994,
          ["mastery"] = 971,
          ["vers"] = -114,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYssMjNmZ2GLzMzMMMmBAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "Groundbeéf",
          ["guild"] = "Pull on Two",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 197120,
          ["ilvl"] = 322,
          ["crit"] = 847,
          ["haste"] = 1055,
          ["mastery"] = 2831,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZmZGjllZsxMzGLzMzMMMLDAgZYMzwMBmZwgxA"
        },
        {
          ["name"] = "Eluvah",
          ["guild"] = "Sordid",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 195531,
          ["ilvl"] = 325,
          ["crit"] = 1111,
          ["haste"] = 928,
          ["mastery"] = 988,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzMjllZswMzGLzMzMMMmBAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "푸른쿠마",
          ["guild"] = "썩은굴",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 194948,
          ["ilvl"] = 322,
          ["crit"] = 1136,
          ["haste"] = 1002,
          ["mastery"] = 785,
          ["vers"] = 147,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYstYsxMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Totemtickler",
          ["guild"] = "Without Limits",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 192851,
          ["ilvl"] = 325,
          ["crit"] = 793,
          ["haste"] = 998,
          ["mastery"] = 1218,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZsxMDWmZmZGDjZAAmhxMDjAzMYwYA"
        },
        {
          ["name"] = "Dejavushka",
          ["guild"] = "Вечный Сон \"Дремлющий\"",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 191846,
          ["ilvl"] = 321,
          ["crit"] = 1035,
          ["haste"] = 961,
          ["mastery"] = 945,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZbGzYssMjNmZ2YZmZmZMMmBAYGGzMMCMzgBjB"
        },
        {
          ["name"] = "호박머가리",
          ["guild"] = "전국동물애호협회",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 191609,
          ["ilvl"] = 317,
          ["crit"] = 798,
          ["haste"] = 843,
          ["mastery"] = 983,
          ["vers"] = 270,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMzyYZmZmBWGzAAMDjZGzMBmZwgxA"
        },
        {
          ["name"] = "Tervatoteemi",
          ["guild"] = "TURBO SAAB",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 191182,
          ["ilvl"] = 325,
          ["crit"] = 962,
          ["haste"] = 907,
          ["mastery"] = 1122,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
        },
        {
          ["name"] = "Nesse",
          ["guild"] = "Dawn",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 191118,
          ["ilvl"] = 324,
          ["crit"] = 980,
          ["haste"] = 592,
          ["mastery"] = 1156,
          ["vers"] = 220,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
        },
        {
          ["name"] = "Reebolt",
          ["guild"] = "Efficient",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 187040,
          ["ilvl"] = 323,
          ["crit"] = 929,
          ["haste"] = 901,
          ["mastery"] = 1121,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYswMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Totemtickler",
          ["guild"] = "Without Limits",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 342524,
          ["ilvl"] = 325,
          ["crit"] = 793,
          ["haste"] = 998,
          ["mastery"] = 1218,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZsxMDWmZmZGDjZAAmhxMDjAzMYwYA"
        },
        {
          ["name"] = "Вкаски",
          ["guild"] = "Вечный Сон \"Ловец Снов\"",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 331296,
          ["ilvl"] = 320,
          ["crit"] = 830,
          ["haste"] = 939,
          ["mastery"] = 1042,
          ["vers"] = 210,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YxMzMDWGzAAMDjZGzIwMDGMGA"
        },
        {
          ["name"] = "Castazap",
          ["guild"] = "ComeBack",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327536,
          ["ilvl"] = 323,
          ["crit"] = 421,
          ["haste"] = 1022,
          ["mastery"] = 1256,
          ["vers"] = 255,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjlFjNmZ2YZmZmhhxMAAzwYmxMTgZGMYMA"
        },
        {
          ["name"] = "Langni",
          ["guild"] = "Occasional Excellence",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 327097,
          ["ilvl"] = 323,
          ["crit"] = 1078,
          ["haste"] = 889,
          ["mastery"] = 835,
          ["vers"] = 214,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Youngsplyze",
          ["guild"] = "Salty Tears",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 322185,
          ["ilvl"] = 320,
          ["crit"] = 866,
          ["haste"] = 929,
          ["mastery"] = 1028,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYswYhZmtxyMzMzDYsMmBAYGGzMmRgZGMYMA"
        },
        {
          ["name"] = "Hakoda",
          ["guild"] = "Proud",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 321278,
          ["ilvl"] = 320,
          ["crit"] = 1050,
          ["haste"] = 913,
          ["mastery"] = 967,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
        },
        {
          ["name"] = "Lavasurfer",
          ["guild"] = "Custom Options",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 321036,
          ["ilvl"] = 318,
          ["crit"] = 533,
          ["haste"] = 1012,
          ["mastery"] = 1301,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250225,
              ["name"] = "Void Execution Mandate",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Giorc",
          ["guild"] = "Blue Castle",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 320453,
          ["ilvl"] = 323,
          ["crit"] = 981,
          ["haste"] = 938,
          ["mastery"] = 1055,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYssMjNmZ2GLzMzMPgxCzAAMDjZGGBmZwgxA"
        },
        {
          ["name"] = "Binnie",
          ["guild"] = "Set Sail For Fail",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 320384,
          ["ilvl"] = 320,
          ["crit"] = 980,
          ["haste"] = 967,
          ["mastery"] = 2625,
          ["vers"] = -213,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
        },
        {
          ["name"] = "Archivon",
          ["guild"] = "Negative Aura",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 319343,
          ["ilvl"] = 324,
          ["crit"] = 845,
          ["haste"] = 949,
          ["mastery"] = 1258,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzYstYswMz2YZGzMDWGzAAMDjZGzMBmZwgxA"
        },
        {
          ["name"] = "Käris",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 278602,
          ["ilvl"] = 326,
          ["crit"] = 1098,
          ["haste"] = 905,
          ["mastery"] = 1062,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjlFjFmZ2YZmZm5BgxMAAzwYmxMTgZGMYMA"
        },
        {
          ["name"] = "Totemtickler",
          ["guild"] = "Without Limits",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 278544,
          ["ilvl"] = 325,
          ["crit"] = 793,
          ["haste"] = 998,
          ["mastery"] = 1218,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZsxMDWmZmZGDjZAAmhxMDjAzMYwYA"
        },
        {
          ["name"] = "Toorup",
          ["guild"] = "Pluto",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 263755,
          ["ilvl"] = 324,
          ["crit"] = 772,
          ["haste"] = 1057,
          ["mastery"] = 1061,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzMzstMjFzMzGLzMzMgxAAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "Ravnir",
          ["guild"] = "Cinder",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 262205,
          ["ilvl"] = 323,
          ["crit"] = 918,
          ["haste"] = 1062,
          ["mastery"] = 1036,
          ["vers"] = 71,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYmlFjNzMz2YZmZmBWGzAAMDjZGGBmZwgxA"
        },
        {
          ["name"] = "Jggleshock",
          ["guild"] = "All into Boss",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 258441,
          ["ilvl"] = 323,
          ["crit"] = 730,
          ["haste"] = 872,
          ["mastery"] = 1139,
          ["vers"] = 323,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzMjllZgZmNWmZmZYsMmBAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "Werdup",
          ["guild"] = "Echoes",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 258302,
          ["ilvl"] = 323,
          ["crit"] = 1017,
          ["haste"] = 943,
          ["mastery"] = 1014,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzMjlFDMzsxyMzMzAjZAAmhxMjZmAzMYwYA"
        },
        {
          ["name"] = "Youngsplyze",
          ["guild"] = "Salty Tears",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 258119,
          ["ilvl"] = 322,
          ["crit"] = 870,
          ["haste"] = 933,
          ["mastery"] = 1032,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYswMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Lemonelement",
          ["guild"] = "Trivial",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 257171,
          ["ilvl"] = 324,
          ["crit"] = 598,
          ["haste"] = 955,
          ["mastery"] = 1296,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZbGzYssMjNmZMWmZmZGjFmBAYGGzMMCMzgBjB"
        },
        {
          ["name"] = "푸른쿠마",
          ["guild"] = "썩은굴",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 256569,
          ["ilvl"] = 321,
          ["crit"] = 1092,
          ["haste"] = 1002,
          ["mastery"] = 821,
          ["vers"] = 147,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYstYsxMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Plumbous",
          ["guild"] = "Slurp Squad",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 256033,
          ["ilvl"] = 326,
          ["crit"] = 902,
          ["haste"] = 753,
          ["mastery"] = 1442,
          ["vers"] = 49,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZ5BGzYmllZsYmZ2YZmHYmhxyYGAgZYMzwMBmZwgxA"
        },
        {
          ["name"] = "Вкаски",
          ["guild"] = "Вечный Сон \"Ловец Снов\"",
          ["boss"] = "Sszorak",
          ["amount"] = 214163,
          ["ilvl"] = 326,
          ["crit"] = 856,
          ["haste"] = 1022,
          ["mastery"] = 1037,
          ["vers"] = 217,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YxMzMDWGzAAMDjZGzIwMDGMGA"
        },
        {
          ["name"] = "Langni",
          ["guild"] = "Occasional Excellence",
          ["boss"] = "Sszorak",
          ["amount"] = 213276,
          ["ilvl"] = 323,
          ["crit"] = 1078,
          ["haste"] = 892,
          ["mastery"] = 835,
          ["vers"] = 215,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Tervatoteemi",
          ["guild"] = "TURBO SAAB",
          ["boss"] = "Sszorak",
          ["amount"] = 212239,
          ["ilvl"] = 323,
          ["crit"] = 931,
          ["haste"] = 954,
          ["mastery"] = 1071,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBALzYmZstMjNmZ2YZmZmhhxMAAzwYmxMTgZGMYMA"
        },
        {
          ["name"] = "Werdup",
          ["guild"] = "Echoes",
          ["boss"] = "Sszorak",
          ["amount"] = 209717,
          ["ilvl"] = 322,
          ["crit"] = 2792,
          ["haste"] = 884,
          ["mastery"] = 1014,
          ["vers"] = -121,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzMjtlZsxMzGLzMzMMMmBAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "Totemtickler",
          ["guild"] = "Without Limits",
          ["boss"] = "Sszorak",
          ["amount"] = 207535,
          ["ilvl"] = 320,
          ["crit"] = 1070,
          ["haste"] = 881,
          ["mastery"] = 1020,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYssMjNmZ2GLmZmZMMmBAYGGzMMCMzgBjB"
        },
        {
          ["name"] = "Decoyy",
          ["guild"] = "Axon Terminal",
          ["boss"] = "Sszorak",
          ["amount"] = 205689,
          ["ilvl"] = 323,
          ["crit"] = 815,
          ["haste"] = 1039,
          ["mastery"] = 1152,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzYmllZwMzsZWmZmZeAYMDAwMMmZYEYmBDGDA"
        },
        {
          ["name"] = "Shamyrage",
          ["guild"] = "mythic raid guild",
          ["boss"] = "Sszorak",
          ["amount"] = 205076,
          ["ilvl"] = 321,
          ["crit"] = 885,
          ["haste"] = 1065,
          ["mastery"] = 1083,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYssMjNmZ2GLzMzMMMmBAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "Zinesham",
          ["guild"] = "Iris",
          ["boss"] = "Sszorak",
          ["amount"] = 204300,
          ["ilvl"] = 322,
          ["crit"] = 863,
          ["haste"] = 1043,
          ["mastery"] = 2800,
          ["vers"] = -137,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYssYsxMz2YZmZmZgxMAAzwYmhZCMzgBjB"
        },
        {
          ["name"] = "Turbotine",
          ["guild"] = "Rhythm",
          ["boss"] = "Sszorak",
          ["amount"] = 203690,
          ["ilvl"] = 325,
          ["crit"] = 1087,
          ["haste"] = 738,
          ["mastery"] = 1098,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzYssYsxMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Weberkraut",
          ["guild"] = "No Shame",
          ["boss"] = "Sszorak",
          ["amount"] = 203561,
          ["ilvl"] = 322,
          ["crit"] = 997,
          ["haste"] = 979,
          ["mastery"] = 960,
          ["vers"] = 93,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYstMjNmZ2GLzMzMMMGAAzwYmxMTgZGMYMA"
        },
        {
          ["name"] = "Cyclrin",
          ["guild"] = "No Skill",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 280916,
          ["ilvl"] = 324,
          ["crit"] = 1113,
          ["haste"] = 759,
          ["mastery"] = 1122,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZbGzYmllZsxMDWmxMzYsMmBAYGGzMmRgZGMYMA"
        },
        {
          ["name"] = "Totemtickler",
          ["guild"] = "Without Limits",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 279886,
          ["ilvl"] = 323,
          ["crit"] = 889,
          ["haste"] = 1053,
          ["mastery"] = 1124,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYstMjNmZ2GLmZmZMMmBAYGGzMMCMzgBjB"
        },
        {
          ["name"] = "Werdup",
          ["guild"] = "Echoes",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 277838,
          ["ilvl"] = 325,
          ["crit"] = 1037,
          ["haste"] = 943,
          ["mastery"] = 1030,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjlFDMzsxyMzMzAjZAAmhxMjZmAzMYwYA"
        },
        {
          ["name"] = "Hungnuts",
          ["guild"] = "comma",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 271652,
          ["ilvl"] = 326,
          ["crit"] = 957,
          ["haste"] = 938,
          ["mastery"] = 894,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZswMzGLzMzMMMGAAzwYmxMTgZGMYMA"
        },
        {
          ["name"] = "Decoyy",
          ["guild"] = "Axon Terminal",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 271622,
          ["ilvl"] = 325,
          ["crit"] = 818,
          ["haste"] = 1039,
          ["mastery"] = 1164,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYssYsxMz2YZmZm5BwyYGAgZYMzYGBmZwgxA"
        },
        {
          ["name"] = "Cigh",
          ["guild"] = "Rewind",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 270504,
          ["ilvl"] = 327,
          ["crit"] = 893,
          ["haste"] = 985,
          ["mastery"] = 1084,
          ["vers"] = 214,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZbGzYmlFjNmZ2YZmZmZgxMAAzwYmhZCMzgBjB"
        },
        {
          ["name"] = "Wuxing",
          ["guild"] = "Tempo",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 269889,
          ["ilvl"] = 326,
          ["crit"] = 1056,
          ["haste"] = 766,
          ["mastery"] = 1210,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZZGzYssMjFmZ2YZmZmhhxMAAzwYmxMTgZGMYMA"
        },
        {
          ["name"] = "Bigshac",
          ["guild"] = "Rancour",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 252650,
          ["ilvl"] = 322,
          ["crit"] = 754,
          ["haste"] = 1028,
          ["mastery"] = 1124,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZsxMz2YZmZmhBmBAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "Gorkies",
          ["guild"] = "Might",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 250609,
          ["ilvl"] = 324,
          ["crit"] = 795,
          ["haste"] = 1183,
          ["mastery"] = 1009,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzMjtlZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
        },
        {
          ["name"] = "Adalid",
          ["guild"] = "Notion",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 246040,
          ["ilvl"] = 324,
          ["crit"] = 917,
          ["haste"] = 1051,
          ["mastery"] = 1105,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYstYsxMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Вкаски",
          ["guild"] = "Вечный Сон \"Ловец Снов\"",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 247866,
          ["ilvl"] = 326,
          ["crit"] = 856,
          ["haste"] = 1023,
          ["mastery"] = 1040,
          ["vers"] = 217,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YxMzMDWGzAAMDjZGzIwMDGMGA"
        },
        {
          ["name"] = "Hungnuts",
          ["guild"] = "comma",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 246551,
          ["ilvl"] = 325,
          ["crit"] = 1118,
          ["haste"] = 772,
          ["mastery"] = 887,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZsxMzGLzMzMMMGAAzwYmxMTgZGMYMA"
        },
        {
          ["name"] = "Myn",
          ["guild"] = "Wild Things",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 243251,
          ["ilvl"] = 325,
          ["crit"] = 1084,
          ["haste"] = 1060,
          ["mastery"] = 975,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYssMjNmZ2YZmZmZMMmBAYGGzMMCMzgBjB"
        },
        {
          ["name"] = "ßugg",
          ["guild"] = "Drama",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 240937,
          ["ilvl"] = 319,
          ["crit"] = 996,
          ["haste"] = 991,
          ["mastery"] = 973,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssMjNmZ2YZmZmhhxMAAzwYmxMTgZGMYMA"
        },
        {
          ["name"] = "Werdup",
          ["guild"] = "Echoes",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 237943,
          ["ilvl"] = 325,
          ["crit"] = 1037,
          ["haste"] = 943,
          ["mastery"] = 1030,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjlFDMzsxyMzMzAjZAAmhxMjZmAzMYwYA"
        },
        {
          ["name"] = "Whorcrocs",
          ["guild"] = "Pretty Standard",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 237742,
          ["ilvl"] = 321,
          ["crit"] = 898,
          ["haste"] = 945,
          ["mastery"] = 1094,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZwCzAAMDjZGmJwMDGMGA"
        },
        {
          ["name"] = "Zeuos",
          ["guild"] = "Nineteen Reasons Why",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 236234,
          ["ilvl"] = 321,
          ["crit"] = 1032,
          ["haste"] = 811,
          ["mastery"] = 1104,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzMjllZsxMzCLzMzMMMmBAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "Penguman",
          ["guild"] = "FAEN",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 236212,
          ["ilvl"] = 323,
          ["crit"] = 764,
          ["haste"] = 948,
          ["mastery"] = 1292,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLwCMDDNYBgZbGzMjllZswMzGLzMzMMMmBAYGGzMMTgZGMYMA"
        },
        {
          ["name"] = "Totemtickler",
          ["guild"] = "Without Limits",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 234282,
          ["ilvl"] = 323,
          ["crit"] = 884,
          ["haste"] = 1044,
          ["mastery"] = 1121,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZbGzYssMjNmZ2GLmZmZMMmBAYGGzMMCMzgBjB"
        },
        {
          ["name"] = "Joru",
          ["guild"] = "Pathogen",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 232931,
          ["ilvl"] = 320,
          ["crit"] = 445,
          ["haste"] = 1149,
          ["mastery"] = 1180,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 311
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssMjNmZ2YZmZmhhxMAAzwYmxMTgZGMYMA"
        }
      }
    },
    {
      ["spec"] = "Restoration",
      ["role"] = "healer",
      ["metric"] = "HPS",
      ["players"] = {
        {
          ["name"] = "Laren",
          ["guild"] = "Avalerion",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 364887,
          ["ilvl"] = 320,
          ["crit"] = 1265,
          ["haste"] = 531,
          ["mastery"] = 155,
          ["vers"] = 1002,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzMzMgFYDmxiGbDgZgNzgBLjZGNbLzMbmxswyMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Jetskisham",
          ["guild"] = "Deception",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 364604,
          ["ilvl"] = 326,
          ["crit"] = 1632,
          ["haste"] = 686,
          ["mastery"] = 180,
          ["vers"] = 468,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxiGbDgZgNzgBbjZmpZbZmhZMbsMzYGzwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Snowrella",
          ["guild"] = "azure",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 361298,
          ["ilvl"] = 316,
          ["crit"] = 1359,
          ["haste"] = 686,
          ["mastery"] = 418,
          ["vers"] = 540,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxiGbDgZgNzgBbjZmpZbZmZzMGsMzMzYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Donutsham",
          ["guild"] = "No Whimsy",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 360111,
          ["ilvl"] = 322,
          ["crit"] = 1419,
          ["haste"] = 870,
          ["mastery"] = 159,
          ["vers"] = 498,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjZGzMYsAbwMW0YbAMDsZGMGbjxMNbLzMbmZmFWMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Virstas",
          ["guild"] = "Team Immortality - PTH",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 358554,
          ["ilvl"] = 321,
          ["crit"] = 1317,
          ["haste"] = 710,
          ["mastery"] = 108,
          ["vers"] = 752,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjxMNbLzMbmZmNWMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Hakashaga",
          ["guild"] = "Pissed My Jorts",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 355563,
          ["ilvl"] = 320,
          ["crit"] = 1470,
          ["haste"] = 999,
          ["mastery"] = 321,
          ["vers"] = 109,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxiGbDgZgNzghZbMzMNbLzMbmxglZGzYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "仙丹",
          ["guild"] = "意犹未尽的青春",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 354251,
          ["ilvl"] = 319,
          ["crit"] = 1337,
          ["haste"] = 861,
          ["mastery"] = 161,
          ["vers"] = 530,
          ["trinkets"] = {
            {
              ["id"] = 264507,
              ["name"] = "Crucible of Erratic Energies",
              ["ilvl"] = 295
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmhZMLsYmZGzwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Intherainpls",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 350756,
          ["ilvl"] = 325,
          ["crit"] = 1239,
          ["haste"] = 669,
          ["mastery"] = 101,
          ["vers"] = 958,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsALwMW0YbAMDsZGmBLzMzMNbLzMbmZmFWmhZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "아란치아",
          ["guild"] = "BUSOH SENSEN",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 350754,
          ["ilvl"] = 319,
          ["crit"] = 1508,
          ["haste"] = 626,
          ["mastery"] = 285,
          ["vers"] = 397,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmNWmZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Kyuras",
          ["guild"] = "Nocturnal Animals",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 347932,
          ["ilvl"] = 321,
          ["crit"] = 1309,
          ["haste"] = 659,
          ["mastery"] = 474,
          ["vers"] = 439,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmhZbMzMNbLzMMjZhlZMz8ADmlBAAAmZGMzAADmB"
        },
        {
          ["name"] = "Aawhouu",
          ["guild"] = "dalaran starbucks",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 383796,
          ["ilvl"] = 320,
          ["crit"] = 1210,
          ["haste"] = 642,
          ["mastery"] = 325,
          ["vers"] = 731,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMYbMmpZbZmZzMmFWMPwMjZYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "半糖豆奶",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 379372,
          ["ilvl"] = 325,
          ["crit"] = 1378,
          ["haste"] = 905,
          ["mastery"] = 94,
          ["vers"] = 533,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYBmxiGbDgZgNzwMYbMmpZbZmZzMmNWMPwMjZYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "月咏丶",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 377679,
          ["ilvl"] = 323,
          ["crit"] = 1471,
          ["haste"] = 472,
          ["mastery"] = 760,
          ["vers"] = 149,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmNWm5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Dumleklubban",
          ["guild"] = "Diktaturen",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 375970,
          ["ilvl"] = 321,
          ["crit"] = 1066,
          ["haste"] = 884,
          ["mastery"] = 419,
          ["vers"] = 780,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMYbMmpZbZmZzMmFWMPwMjZYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Heloisea",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 375194,
          ["ilvl"] = 324,
          ["crit"] = 1276,
          ["haste"] = 353,
          ["mastery"] = 432,
          ["vers"] = 889,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZmZmBsAbwMW0YbAMDsZGmhZbmxMNbLzMMzMbsYMzYwsMDAAAmZGMzAADmB"
        },
        {
          ["name"] = "Laykablue",
          ["guild"] = "BigBrain",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 373000,
          ["ilvl"] = 328,
          ["crit"] = 1637,
          ["haste"] = 771,
          ["mastery"] = 50,
          ["vers"] = 527,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwM20YbAMDsZGmBbjZmpZbZmZzMmFWmZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Sliskéh",
          ["guild"] = "Der er tilbud i Netto",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 372802,
          ["ilvl"] = 318,
          ["crit"] = 1293,
          ["haste"] = 929,
          ["mastery"] = 459,
          ["vers"] = 128,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMYbMmpZbZmZzMmFWMPwMjZYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "生命活性法",
          ["guild"] = "灰色军团",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 371354,
          ["ilvl"] = 324,
          ["crit"] = 1191,
          ["haste"] = 1009,
          ["mastery"] = 366,
          ["vers"] = 548,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmFWmZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Acrnsham",
          ["guild"] = "Myth",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 370748,
          ["ilvl"] = 327,
          ["crit"] = 1444,
          ["haste"] = 967,
          ["mastery"] = 320,
          ["vers"] = 247,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMMbjxMNbLzMMjZhFzDMzYGmlBAAAmZGMzAADmB"
        },
        {
          ["name"] = "Donutsham",
          ["guild"] = "No Whimsy",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 370656,
          ["ilvl"] = 324,
          ["crit"] = 1435,
          ["haste"] = 870,
          ["mastery"] = 117,
          ["vers"] = 535,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjZGzMYsAbwMW0YbAMDsZGMGbjxMNbLzMbmZmFWMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Quimo",
          ["guild"] = "Stand Up Comedy",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 368071,
          ["ilvl"] = 322,
          ["crit"] = 1537,
          ["haste"] = 874,
          ["mastery"] = 294,
          ["vers"] = 727,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmFWmZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Knockzsham",
          ["guild"] = "Bound",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 366519,
          ["ilvl"] = 324,
          ["crit"] = 1018,
          ["haste"] = 715,
          ["mastery"] = 470,
          ["vers"] = 778,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmFWm5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Fiskensfar",
          ["guild"] = "In Denial",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 356025,
          ["ilvl"] = 325,
          ["crit"] = 1416,
          ["haste"] = 950,
          ["mastery"] = 66,
          ["vers"] = 675,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMMbjxMNbLzMbmxswi5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "슈슈파나",
          ["guild"] = "엿보기 구렁",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 352113,
          ["ilvl"] = 328,
          ["crit"] = 1706,
          ["haste"] = 510,
          ["mastery"] = 273,
          ["vers"] = 512,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBLjZmpZbZmZzMGsMzMzYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Kògeras",
          ["guild"] = "Arey",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 351507,
          ["ilvl"] = 320,
          ["crit"] = 1309,
          ["haste"] = 786,
          ["mastery"] = 224,
          ["vers"] = 561,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjxMNbLzMbmxswmZmZMDzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Pingachéw",
          ["guild"] = "A Little Bit Sweaty",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 347580,
          ["ilvl"] = 324,
          ["crit"] = 1372,
          ["haste"] = 902,
          ["mastery"] = 101,
          ["vers"] = 538,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBsAbwMW0YbAMDsZGmhZbMmpZbZmhZmZhFzYGzwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Rampö",
          ["guild"] = "Well Named guild",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 347068,
          ["ilvl"] = 321,
          ["crit"] = 1402,
          ["haste"] = 687,
          ["mastery"] = 165,
          ["vers"] = 661,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxmGbDgZgNzgBbjZmpZbZmhZmZhlZGzYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Ztohh",
          ["guild"] = "Hård",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 343260,
          ["ilvl"] = 323,
          ["crit"] = 1256,
          ["haste"] = 323,
          ["mastery"] = 549,
          ["vers"] = 800,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbzMzMNbLzMbmxsxyMmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Thullithnor",
          ["guild"] = "Force",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 341398,
          ["ilvl"] = 323,
          ["crit"] = 1423,
          ["haste"] = 428,
          ["mastery"] = 435,
          ["vers"] = 694,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsALwMW0YbAMDsZGmBbjxMNbLzMbmxsxiZmZMDzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Erisshaman",
          ["guild"] = "Expurged",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 341375,
          ["ilvl"] = 320,
          ["crit"] = 1505,
          ["haste"] = 721,
          ["mastery"] = 256,
          ["vers"] = 618,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 264507,
              ["name"] = "Crucible of Erratic Energies",
              ["ilvl"] = 295
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBLjZmpZbZmZzMmFWmZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "平原上的摩西",
          ["guild"] = "春华秋实丶",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 418757,
          ["ilvl"] = 324,
          ["crit"] = 1425,
          ["haste"] = 767,
          ["mastery"] = 153,
          ["vers"] = 792,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMMLjZmpZZZmhZMYZmxMGMLDAAAMzMYmBAGMD"
        },
        {
          ["name"] = "Skelix",
          ["guild"] = "Divergence",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 405595,
          ["ilvl"] = 325,
          ["crit"] = 1261,
          ["haste"] = 720,
          ["mastery"] = 599,
          ["vers"] = 355,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmFWmZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Andersototem",
          ["guild"] = "V r e d e",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 403826,
          ["ilvl"] = 316,
          ["crit"] = 1130,
          ["haste"] = 779,
          ["mastery"] = 276,
          ["vers"] = 637,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBLjZmpZbZmZzMmFWm5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Pingachéw",
          ["guild"] = "A Little Bit Sweaty",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 403629,
          ["ilvl"] = 324,
          ["crit"] = 1372,
          ["haste"] = 902,
          ["mastery"] = 101,
          ["vers"] = 538,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBsAbwMW0YbAMDsZGmhZbMmpZbZmZzMmFWMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Deideideidei",
          ["guild"] = "Prototype",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 401754,
          ["ilvl"] = 321,
          ["crit"] = 1437,
          ["haste"] = 737,
          ["mastery"] = 152,
          ["vers"] = 507,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmNWmZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Escapone",
          ["guild"] = "Pink Pony Death Squad",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 395516,
          ["ilvl"] = 324,
          ["crit"] = 1444,
          ["haste"] = 750,
          ["mastery"] = 175,
          ["vers"] = 617,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmhZbMmpZbZmZzMmFWMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Aawhouu",
          ["guild"] = "dalaran starbucks",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 394330,
          ["ilvl"] = 319,
          ["crit"] = 905,
          ["haste"] = 674,
          ["mastery"] = 388,
          ["vers"] = 909,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMYbMmpZbZmZzMmFWMPwMjZYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Snowrella",
          ["guild"] = "azure",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 394283,
          ["ilvl"] = 322,
          ["crit"] = 1521,
          ["haste"] = 689,
          ["mastery"] = 275,
          ["vers"] = 432,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxiGbDgZgNzgBbjZmpZbZmZzMGsMzMzYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "月咏丶",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 393365,
          ["ilvl"] = 324,
          ["crit"] = 1478,
          ["haste"] = 494,
          ["mastery"] = 767,
          ["vers"] = 149,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBLjZmpZbZmZzMmFWm5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Creamconisur",
          ["guild"] = "Deified",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 392087,
          ["ilvl"] = 319,
          ["crit"] = 1316,
          ["haste"] = 678,
          ["mastery"] = 344,
          ["vers"] = 531,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMYbMmpZbZmZzMmF2MPwMjZYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "丷饺子丷",
          ["guild"] = "不老实打本就会被抓去和猎马人连麦",
          ["boss"] = "Sszorak",
          ["amount"] = 436889,
          ["ilvl"] = 327,
          ["crit"] = 1384,
          ["haste"] = 644,
          ["mastery"] = 185,
          ["vers"] = 831,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxiGbDgZgNzghZbMzMNbLzMbmxswyMPgZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Chihao",
          ["guild"] = "Reckoning",
          ["boss"] = "Sszorak",
          ["amount"] = 425862,
          ["ilvl"] = 327,
          ["crit"] = 1544,
          ["haste"] = 618,
          ["mastery"] = 117,
          ["vers"] = 770,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZYMzYmBjFYDmxiGbDgZgNzgZGLjxMNbLzMbmxsZ2MzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Moontìdes",
          ["guild"] = "Close Proximity",
          ["boss"] = "Sszorak",
          ["amount"] = 424534,
          ["ilvl"] = 325,
          ["crit"] = 1491,
          ["haste"] = 533,
          ["mastery"] = 524,
          ["vers"] = 466,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMYZMmpZbZmZzMmFWMPwMjZYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "슈슈파나",
          ["guild"] = "엿보기 구렁",
          ["boss"] = "Sszorak",
          ["amount"] = 424239,
          ["ilvl"] = 328,
          ["crit"] = 1706,
          ["haste"] = 510,
          ["mastery"] = 273,
          ["vers"] = 512,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBLjZmpZbZmZzMGsMzMzYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Sleepyowls",
          ["guild"] = "Vibrant",
          ["boss"] = "Sszorak",
          ["amount"] = 422994,
          ["ilvl"] = 324,
          ["crit"] = 1443,
          ["haste"] = 810,
          ["mastery"] = 476,
          ["vers"] = 292,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNmZGjZGzMDjFYDmxiGbDgZgNzwMMbjxMNbLzMbmxswi5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Myws",
          ["guild"] = "WICKED",
          ["boss"] = "Sszorak",
          ["amount"] = 418616,
          ["ilvl"] = 324,
          ["crit"] = 1363,
          ["haste"] = 746,
          ["mastery"] = 93,
          ["vers"] = 712,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwM20YbAMDsZGmBbjZGNbLzMbmxswyMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Sharly",
          ["guild"] = "The Hex Pistols",
          ["boss"] = "Sszorak",
          ["amount"] = 416393,
          ["ilvl"] = 325,
          ["crit"] = 1568,
          ["haste"] = 340,
          ["mastery"] = 354,
          ["vers"] = 646,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmhZbmxMNbLzMbmxswi5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Sethm",
          ["guild"] = "Occasional Excellence",
          ["boss"] = "Sszorak",
          ["amount"] = 416009,
          ["ilvl"] = 324,
          ["crit"] = 1445,
          ["haste"] = 768,
          ["mastery"] = 204,
          ["vers"] = 553,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmhZbMmpZbZmZzMzswiZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Laykablue",
          ["guild"] = "BigBrain",
          ["boss"] = "Sszorak",
          ["amount"] = 415153,
          ["ilvl"] = 328,
          ["crit"] = 1637,
          ["haste"] = 771,
          ["mastery"] = 50,
          ["vers"] = 527,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwM20YbAMDsZGmBbjZmpZbZmZzMmFWmZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Thullithnor",
          ["guild"] = "Force",
          ["boss"] = "Sszorak",
          ["amount"] = 409215,
          ["ilvl"] = 326,
          ["crit"] = 1461,
          ["haste"] = 477,
          ["mastery"] = 305,
          ["vers"] = 756,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsALwMW0YbAMDsZGmBbjxMNbLzMbmxsxiZmZMDzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Mymtide",
          ["guild"] = "Innervision",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 440745,
          ["ilvl"] = 327,
          ["crit"] = 1446,
          ["haste"] = 743,
          ["mastery"] = 114,
          ["vers"] = 690,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjZGzMYsAbwM20YbAMDsZGMmZbMzMNbLzMMjBLz8AzMGMLzAAAgZmBzMAwgZA"
        },
        {
          ["name"] = "Krissya",
          ["guild"] = "fish zoo",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 430210,
          ["ilvl"] = 323,
          ["crit"] = 1368,
          ["haste"] = 960,
          ["mastery"] = 344,
          ["vers"] = 401,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMMbjxMNbLzMbmxsxi5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "슈슈파나",
          ["guild"] = "엿보기 구렁",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 424623,
          ["ilvl"] = 328,
          ["crit"] = 1706,
          ["haste"] = 510,
          ["mastery"] = 273,
          ["vers"] = 512,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBLjZmpZbZmZzMGsMzMzYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Dorkus",
          ["guild"] = "Pool Noodle Pirates",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 417971,
          ["ilvl"] = 325,
          ["crit"] = 1479,
          ["haste"] = 755,
          ["mastery"] = 164,
          ["vers"] = 670,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMjHYMzYmBjFYDmxmGbDgZgNzghZZMzoZZZmhZMLsMzMzYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Zensham",
          ["guild"] = "Ancient Tempest",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 417248,
          ["ilvl"] = 325,
          ["crit"] = 1477,
          ["haste"] = 506,
          ["mastery"] = 162,
          ["vers"] = 915,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZmZmBjFYDmxiGbDgZgNzghZbMzMNbLzMMjBLzMzMGMLDAAAMzMYmBAGMD"
        },
        {
          ["name"] = "곽철씨",
          ["guild"] = "술공대",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 415969,
          ["ilvl"] = 323,
          ["crit"] = 1213,
          ["haste"] = 830,
          ["mastery"] = 581,
          ["vers"] = 565,
          ["trinkets"] = {
            {
              ["id"] = 270171,
              ["name"] = "Preternatural Antivenom",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmhZbMmpZbZmhZMbsYmZGzwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Meowtide",
          ["guild"] = "Hatewatching",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 413282,
          ["ilvl"] = 329,
          ["crit"] = 1565,
          ["haste"] = 1106,
          ["mastery"] = 86,
          ["vers"] = 430,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwM20YbAMDsZGmhZbMzMNbLzMbmxswyMmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Burgus",
          ["guild"] = "Medium",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 410184,
          ["ilvl"] = 324,
          ["crit"] = 1283,
          ["haste"] = 811,
          ["mastery"] = 291,
          ["vers"] = 567,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxiGbDgZgNzghZbMmpZZZmhZMLsYmZGDmlZAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Julies",
          ["guild"] = "Resonate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 407552,
          ["ilvl"] = 327,
          ["crit"] = 1551,
          ["haste"] = 722,
          ["mastery"] = 462,
          ["vers"] = 410,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmhZbMmpZbZmhZMLsYmZmHYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Jakearu",
          ["guild"] = "Reforged",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 406310,
          ["ilvl"] = 327,
          ["crit"] = 1854,
          ["haste"] = 169,
          ["mastery"] = 212,
          ["vers"] = 729,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmhZZMzMNbLzMbmxswyMmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Sunnyshocks",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 368269,
          ["ilvl"] = 326,
          ["crit"] = 1484,
          ["haste"] = 480,
          ["mastery"] = 520,
          ["vers"] = 699,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZxMmFWmxMjBzyMAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Shoomon",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 366558,
          ["ilvl"] = 322,
          ["crit"] = 1490,
          ["haste"] = 214,
          ["mastery"] = 446,
          ["vers"] = 727,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjZGzMgFYDmxmGbDgZgNzMMYbMzMNbLzMLmxswyMPwMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Xilam",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 365474,
          ["ilvl"] = 327,
          ["crit"] = 1130,
          ["haste"] = 1141,
          ["mastery"] = 247,
          ["vers"] = 511,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBsAbwMW0YbAMDsZGmBLjZmpZbZmZxMmFWm5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Darôt",
          ["guild"] = "baited",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 360901,
          ["ilvl"] = 327,
          ["crit"] = 1566,
          ["haste"] = 982,
          ["mastery"] = 168,
          ["vers"] = 452,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBsAbwMW0YbAMDsZGmhZbMmpZbZmZxMmFWMPwMjBzyMAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Bluemàster",
          ["guild"] = "Fragglene",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 358983,
          ["ilvl"] = 327,
          ["crit"] = 1323,
          ["haste"] = 788,
          ["mastery"] = 547,
          ["vers"] = 454,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxiGbDgZgNzgBbjxMNbLzMLmZmNWMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "牢三",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 356056,
          ["ilvl"] = 328,
          ["crit"] = 1466,
          ["haste"] = 790,
          ["mastery"] = 221,
          ["vers"] = 674,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjxYmBjFYBmxiGbDgZgNzMMMbjxMNbLzMLmxswiZmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Zacsham",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 346001,
          ["ilvl"] = 326,
          ["crit"] = 1152,
          ["haste"] = 1136,
          ["mastery"] = 401,
          ["vers"] = 489,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxmGbDgZgNzgBbzMzMNbLzMLmxsxyMmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Pig",
          ["guild"] = "The Next Step",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 342488,
          ["ilvl"] = 323,
          ["crit"] = 1357,
          ["haste"] = 727,
          ["mastery"] = 386,
          ["vers"] = 532,
          ["trinkets"] = {
            {
              ["id"] = 270605,
              ["name"] = "Venomous Gladiator's Medallion",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjZGzMYsAbwMW0YbAMDsZmHgBLjZmpZbZmZxMmFWm5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Saracens",
          ["guild"] = "Infinity",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 340511,
          ["ilvl"] = 327,
          ["crit"] = 1574,
          ["haste"] = 1145,
          ["mastery"] = 44,
          ["vers"] = 282,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjxYmBjFYDmxiGbDgZgNzMMMLjZmpZbZmZxMmNWmxMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Gchillz",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 335924,
          ["ilvl"] = 320,
          ["crit"] = 1495,
          ["haste"] = 551,
          ["mastery"] = 427,
          ["vers"] = 493,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 264507,
              ["name"] = "Crucible of Erratic Energies",
              ["ilvl"] = 295
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjxYmZYsALwMW0YbAMDsZmhBbjxMNbLzMLmxswi5BmZMDzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "까만마음흑구",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 395032,
          ["ilvl"] = 327,
          ["crit"] = 1575,
          ["haste"] = 940,
          ["mastery"] = 363,
          ["vers"] = 372,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjZGzMgFYDmxiGbDgZgNzMMYZMzMNbLzMbmxswyMjZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Hexqt",
          ["guild"] = "Pathogen",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 400989,
          ["ilvl"] = 323,
          ["crit"] = 1476,
          ["haste"] = 763,
          ["mastery"] = 221,
          ["vers"] = 489,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMMbjxMNbLzMLmxswi5BmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Асураммая",
          ["guild"] = "Санаторий",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 351315,
          ["ilvl"] = 327,
          ["crit"] = 1849,
          ["haste"] = 790,
          ["mastery"] = 235,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmFWmZMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "Laykablue",
          ["guild"] = "BigBrain",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 350330,
          ["ilvl"] = 328,
          ["crit"] = 1637,
          ["haste"] = 771,
          ["mastery"] = 50,
          ["vers"] = 527,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmhZbmxMNbLzMMjZjFzMzYwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Alisah",
          ["guild"] = "The Audacity",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 344846,
          ["ilvl"] = 323,
          ["crit"] = 1205,
          ["haste"] = 613,
          ["mastery"] = 116,
          ["vers"] = 974,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDgZgNzwMYbMmpZbZmZzMmFWMPwMjZYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Dtf",
          ["guild"] = "Notion",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 341939,
          ["ilvl"] = 326,
          ["crit"] = 1241,
          ["haste"] = 1014,
          ["mastery"] = 302,
          ["vers"] = 426,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmhZbMmpZbZmZzMmFWMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "团霸",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 337847,
          ["ilvl"] = 320,
          ["crit"] = 1602,
          ["haste"] = 407,
          ["mastery"] = 430,
          ["vers"] = 534,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 318
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbzMmpZbZmhZMLmFzYGzwsMAAAwMzgZGAYwM"
        },
        {
          ["name"] = "Meowtide",
          ["guild"] = "Hatewatching",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 334977,
          ["ilvl"] = 329,
          ["crit"] = 1565,
          ["haste"] = 1106,
          ["mastery"] = 86,
          ["vers"] = 430,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwM20YbAMDsZGmhZbMzMNbLzMLmxswyMmZMYWGAAAYmZwMDAMYG"
        },
        {
          ["name"] = "Dalfaëran",
          ["guild"] = "YEP",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 333548,
          ["ilvl"] = 326,
          ["crit"] = 1509,
          ["haste"] = 850,
          ["mastery"] = 114,
          ["vers"] = 657,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMDjZmZmBjFYDmxmGbDgZgNzghZbmZmpZZZmhZMbsMjZGDmlBAAAmZGMzAADmB"
        },
        {
          ["name"] = "白熊喵",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 332806,
          ["ilvl"] = 325,
          ["crit"] = 1436,
          ["haste"] = 859,
          ["mastery"] = nil,
          ["vers"] = 787,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmFWMzMjBzyAAAAzMDmZAgBzA"
        },
        {
          ["name"] = "克軌",
          ["guild"] = "喵吼",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 332137,
          ["ilvl"] = 322,
          ["crit"] = 1487,
          ["haste"] = 527,
          ["mastery"] = 456,
          ["vers"] = 516,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsAbwMW0YbAMDsZGmBbjZmpZbZmZzMmFWmZMjBzyAAAAzMDmZAgBzA"
        }
      }
    }
  }
}
