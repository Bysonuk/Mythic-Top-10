MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Hunter"] = {
  ["className"] = "Hunter",
  ["specs"] = {
    {
      ["spec"] = "Beast Mastery",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Snorkken",
          ["guild"] = "Winters Heart",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 219048,
          ["ilvl"] = 326,
          ["crit"] = 1024,
          ["haste"] = 669,
          ["mastery"] = 1081,
          ["vers"] = 558,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYGzssNzMmxM4BMNDAAAAYGAAAGzMDwMbADzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Escanuts",
          ["guild"] = "Vibe Police",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217850,
          ["ilvl"] = 324,
          ["crit"] = 947,
          ["haste"] = 861,
          ["mastery"] = 1230,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGbzMjZMDGaGAAAAwMAAAMzMDgZ2AwsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Tributroll",
          ["guild"] = "Frenzied Apes",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217053,
          ["ilvl"] = 326,
          ["crit"] = 1104,
          ["haste"] = 936,
          ["mastery"] = 1079,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYGzwMGzYGM0MAAAAgZAAAYmZGDYmNgZxsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "尤菲",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 216998,
          ["ilvl"] = 325,
          ["crit"] = 922,
          ["haste"] = 861,
          ["mastery"] = 962,
          ["vers"] = 443,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGPwMzsMzwMzMjZGMzYmhZGzMzgZGzYGM0MAAAAAAAAwMzYAzsBMmZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Dpxhunt",
          ["guild"] = "Gravity",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 216727,
          ["ilvl"] = 325,
          ["crit"] = 1142,
          ["haste"] = 792,
          ["mastery"] = 1146,
          ["vers"] = 84,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzwMGzYGWGaAAAAAAAAgZGzMgZ2gNYWAbDAD",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "兰迪",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215055,
          ["ilvl"] = 324,
          ["crit"] = 1055,
          ["haste"] = 642,
          ["mastery"] = 1204,
          ["vers"] = 253,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZssNzMmxMYoZAAAAAzAAAw8AjZAmZDwiZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "未來的輪廊",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 214936,
          ["ilvl"] = 323,
          ["crit"] = 1037,
          ["haste"] = 267,
          ["mastery"] = 3187,
          ["vers"] = 1,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYzMjZMDGaGAAAAAAAAMzYmBMzGAmFw2AwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Гирелуп",
          ["guild"] = "Hard Charge",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 213897,
          ["ilvl"] = 325,
          ["crit"] = 930,
          ["haste"] = 795,
          ["mastery"] = 1172,
          ["vers"] = 265,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYGzwMzYGzghmBAAAAMDAAAzMzMAzsBMMLgtBgB",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Пабелзор",
          ["guild"] = "Инвинсибл",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 213334,
          ["ilvl"] = 324,
          ["crit"] = 931,
          ["haste"] = 660,
          ["mastery"] = 1351,
          ["vers"] = 226,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYGzwMzYGzghmBAAAAMDAAAzMzMAzsBbwsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Mojj",
          ["guild"] = "Reanimated",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 213200,
          ["ilvl"] = 323,
          ["crit"] = 1108,
          ["haste"] = 652,
          ["mastery"] = 1152,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYGzwMzYGzghmBAAAAMDAAAzMzMAzsBMMLgtBgB",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Ramwog",
          ["guild"] = "Mid Team",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 202029,
          ["ilvl"] = 325,
          ["crit"] = 1226,
          ["haste"] = 652,
          ["mastery"] = 1106,
          ["vers"] = 153,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGmxYGzgx0MAAAAgZAAAYmZGAzsBMMLgtBgB",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "금칩",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 199549,
          ["ilvl"] = 322,
          ["crit"] = 1258,
          ["haste"] = 929,
          ["mastery"] = 1005,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGmxYGzghmZAAAAgZAAAYmZGDYmNAMLgtBgB",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Snorkken",
          ["guild"] = "Winters Heart",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 199170,
          ["ilvl"] = 324,
          ["crit"] = 869,
          ["haste"] = 663,
          ["mastery"] = 1071,
          ["vers"] = 551,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYGzssNzMmxM4BMNDAAAAYGAAAGzMDwMbADzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Escanuts",
          ["guild"] = "Vibe Police",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198043,
          ["ilvl"] = 322,
          ["crit"] = 524,
          ["haste"] = 1148,
          ["mastery"] = 1275,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYGzssNzMmxM4BMNDAAAAYGAAAGzMDwMbADzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Ashendarien",
          ["guild"] = "Idiot",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 197989,
          ["ilvl"] = 326,
          ["crit"] = 1008,
          ["haste"] = 595,
          ["mastery"] = 1239,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 171642,
              ["name"] = "The Hungerer",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZmFzMjZMDGTzAAAAAmBAAgxMDgZ2AGmFw2AwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Leczis",
          ["guild"] = "Shattered",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 197094,
          ["ilvl"] = 322,
          ["crit"] = 1032,
          ["haste"] = 840,
          ["mastery"] = 1429,
          ["vers"] = 176,
          ["trinkets"] = {
            {
              ["id"] = 249806,
              ["name"] = "Radiant Plume",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYGzwMGzYGMmmBAAAAMDAAAzMzMAzsBMMLgtBgB",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Calzurv",
          ["guild"] = "Miracle",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 196371,
          ["ilvl"] = 325,
          ["crit"] = 1115,
          ["haste"] = 935,
          ["mastery"] = 1193,
          ["vers"] = 153,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGmxYGzgx0MAAAAgZAAAYMzMAzsBMmZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Tributroll",
          ["guild"] = "Frenzied Apes",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 195109,
          ["ilvl"] = 326,
          ["crit"] = 1104,
          ["haste"] = 936,
          ["mastery"] = 1079,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYmZmFzYMjZwYaGAAAAwMAAAMmZGgZ2gNYWAbDAD",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Jwag",
          ["guild"] = "Pure",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 194033,
          ["ilvl"] = 322,
          ["crit"] = 3041,
          ["haste"] = 612,
          ["mastery"] = 1177,
          ["vers"] = -139,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYmZGmxYGzwyQzAAAAAmBAAgxMzMgZ2AGmFw2AwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Lagyo",
          ["guild"] = "Opposite",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 192887,
          ["ilvl"] = 323,
          ["crit"] = 1353,
          ["haste"] = 712,
          ["mastery"] = 853,
          ["vers"] = 272,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYGzsYmZMjZwYaGAAAAwMAAAMmZGgZ2gNYWAbDAD",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Фруктовыйсэд",
          ["guild"] = "Just Play",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 389983,
          ["ilvl"] = 327,
          ["crit"] = 1301,
          ["haste"] = 632,
          ["mastery"] = 1279,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYbmZMjZwQzAAAAAAAAgZGzAMzGAmFw2AwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "北极猎",
          ["guild"] = "咏冻黎明12.0",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 373204,
          ["ilvl"] = 326,
          ["crit"] = 1264,
          ["haste"] = 294,
          ["mastery"] = 1467,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzwMzYGzgx0MAAAAAAAAYmxMAzsBgZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "滴滴嘀",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 372729,
          ["ilvl"] = 326,
          ["crit"] = 1066,
          ["haste"] = 791,
          ["mastery"] = 1263,
          ["vers"] = 56,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYbmZMjZYZMNDAAAAAAAAGjxAmZDAzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "爬山丶丶",
          ["guild"] = "Reborn Advance",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 364203,
          ["ilvl"] = 328,
          ["crit"] = 1173,
          ["haste"] = 558,
          ["mastery"] = 1258,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsMzwMmZMzgZGzMMzYmZGMGzYGMmmBAAAAAAAAzMzAYmNgZxsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "崔莱蒂",
          ["guild"] = "醉星辰",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 360399,
          ["ilvl"] = 324,
          ["crit"] = 1133,
          ["haste"] = 584,
          ["mastery"] = 1118,
          ["vers"] = 306,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2AsMzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Superbo",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 357505,
          ["ilvl"] = 323,
          ["crit"] = 1013,
          ["haste"] = 523,
          ["mastery"] = 1586,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYbmZMjZYZMNDAAAAAAAA8AjxAmZDAzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Zlrthirteen",
          ["guild"] = "Mythic+",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 356328,
          ["ilvl"] = 315,
          ["crit"] = 1193,
          ["haste"] = 471,
          ["mastery"] = 1414,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            },
            {
              ["id"] = 249806,
              ["name"] = "Radiant Plume",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYbmZMjZwQzAAAAAAAAgZGzAMzGAmFw2AwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "浪漫派柯基",
          ["guild"] = "诗与远方",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 353704,
          ["ilvl"] = 326,
          ["crit"] = 966,
          ["haste"] = 912,
          ["mastery"] = 1394,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzgZGzYGMmmBAAAAAAAAzMzAYmNALmFwyAwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Lyrai",
          ["guild"] = "Banelings",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 351216,
          ["ilvl"] = 326,
          ["crit"] = 1487,
          ["haste"] = 518,
          ["mastery"] = 869,
          ["vers"] = 326,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZYMDLDNDAAAAAAAAmHYMzAmZDAzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Greystalker",
          ["guild"] = "Black Wall",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 351103,
          ["ilvl"] = 324,
          ["crit"] = 1039,
          ["haste"] = 693,
          ["mastery"] = 1340,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYbmZMjZYZMNDAAAAAAAA8AjxAmZDAzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "금칩",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 260268,
          ["ilvl"] = 326,
          ["crit"] = 1290,
          ["haste"] = 454,
          ["mastery"] = 1520,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzwMzYGzghmBAAAAAAAAzMmZAzsBgZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Redbarclub",
          ["guild"] = "Блэкбёрд",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 260068,
          ["ilvl"] = 326,
          ["crit"] = 1138,
          ["haste"] = 727,
          ["mastery"] = 1241,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbAYWAbDAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "渐渐了溅溅",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 259108,
          ["ilvl"] = 325,
          ["crit"] = 1126,
          ["haste"] = 494,
          ["mastery"] = 1542,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2AsMzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "崔莱蒂",
          ["guild"] = "醉星辰",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 255591,
          ["ilvl"] = 327,
          ["crit"] = 1015,
          ["haste"] = 569,
          ["mastery"] = 1246,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAYGjBMzGAmFw2AA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Yùnyu",
          ["guild"] = "BIG PULL ET AU LIT",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 255142,
          ["ilvl"] = 323,
          ["crit"] = 1366,
          ["haste"] = 354,
          ["mastery"] = 1485,
          ["vers"] = 153,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbAYWAbDAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "非常粗鲁先生",
          ["guild"] = "老友俱乐部后起之秀团_",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 255120,
          ["ilvl"] = 327,
          ["crit"] = 1255,
          ["haste"] = 481,
          ["mastery"] = 1279,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYbmZMjZwQzAAAAAAAAg5BGjBMzGgFzCYbAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "北极猎",
          ["guild"] = "咏冻黎明12.0",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 252885,
          ["ilvl"] = 326,
          ["crit"] = 1264,
          ["haste"] = 294,
          ["mastery"] = 1467,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzwMzYGzgx0MAAAAAAAAYmxMAzsBgZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Jafaraway",
          ["guild"] = "mythic raid guild",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 252239,
          ["ilvl"] = 326,
          ["crit"] = 1222,
          ["haste"] = 299,
          ["mastery"] = 1473,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAA4BGjBMzGwwsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Tributroll",
          ["guild"] = "Frenzied Apes",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 251796,
          ["ilvl"] = 326,
          ["crit"] = 1240,
          ["haste"] = 561,
          ["mastery"] = 1326,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZYZMNDAAAAAAAA8AjxAmZDAzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Bilbohunter",
          ["guild"] = "Synergize",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 251109,
          ["ilvl"] = 325,
          ["crit"] = 1085,
          ["haste"] = 752,
          ["mastery"] = 1178,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGPwMzs8AzYmZmZMzgZGzMMzYmZGbzMDjZwQzAAAAAAAAgZGzMgZ2AwsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Cyrene",
          ["guild"] = "Nerd Rage",
          ["boss"] = "Sszorak",
          ["amount"] = 231735,
          ["ilvl"] = 327,
          ["crit"] = 1175,
          ["haste"] = 781,
          ["mastery"] = 1218,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYmZGmxYGzgx0MAAAAgZAAAYMzYAzsBMLmFwyAwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "爬山丶丶",
          ["guild"] = "Reborn Advance",
          ["boss"] = "Sszorak",
          ["amount"] = 230990,
          ["ilvl"] = 328,
          ["crit"] = 959,
          ["haste"] = 882,
          ["mastery"] = 1140,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGMGzYGMmmBAAAAMDAAAzMzAYmNgZxsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Rosyuwu",
          ["guild"] = "Mythicc",
          ["boss"] = "Sszorak",
          ["amount"] = 230980,
          ["ilvl"] = 325,
          ["crit"] = 998,
          ["haste"] = 914,
          ["mastery"] = 1132,
          ["vers"] = 58,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGmxYGzghmBAAAAMDAAAzMzAYmNgZxsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Hogcranker",
          ["guild"] = "Low Expectations",
          ["boss"] = "Sszorak",
          ["amount"] = 230341,
          ["ilvl"] = 325,
          ["crit"] = 1281,
          ["haste"] = 760,
          ["mastery"] = 1073,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYmZGbzMjZMDLjpZAAAAAzAAAAzMGwMbAYWAbDAD",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Nickkie",
          ["guild"] = "Omnia",
          ["boss"] = "Sszorak",
          ["amount"] = 228805,
          ["ilvl"] = 322,
          ["crit"] = 1156,
          ["haste"] = 885,
          ["mastery"] = 1031,
          ["vers"] = 56,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGMzYGzgx0MAAAAgZAAAYmZGAzsBYxsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "北极猎",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 228732,
          ["ilvl"] = 326,
          ["crit"] = 1088,
          ["haste"] = 679,
          ["mastery"] = 1251,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGmZGzYGMmmBAAAAMDAAAzMGAzsBYxsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Ronesx",
          ["guild"] = "Unluck",
          ["boss"] = "Sszorak",
          ["amount"] = 228474,
          ["ilvl"] = 324,
          ["crit"] = 1193,
          ["haste"] = 928,
          ["mastery"] = 878,
          ["vers"] = 190,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGmxYGzghmBAAAAMDAAAzMzMAzsBMMLgtBgB",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Iduohunter",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 228288,
          ["ilvl"] = 326,
          ["crit"] = 1159,
          ["haste"] = 563,
          ["mastery"] = 1515,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGmZGzYmhx0MAAAAgZAAAYMzAYmNAmZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Hawasshunter",
          ["guild"] = "No Shame",
          ["boss"] = "Sszorak",
          ["amount"] = 228103,
          ["ilvl"] = 323,
          ["crit"] = 1059,
          ["haste"] = 709,
          ["mastery"] = 1299,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZMDzMGzMMzYmZGmxYGzgx0MAAAAgZAAAYMzYAzsBMLmFw2AwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Arkhunt",
          ["guild"] = "Tab Target",
          ["boss"] = "Sszorak",
          ["amount"] = 227790,
          ["ilvl"] = 324,
          ["crit"] = 824,
          ["haste"] = 1008,
          ["mastery"] = 979,
          ["vers"] = 408,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYmZGmxYGzghmBAAAAMDAAAzMzAYmNgZxsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "北极猎",
          ["guild"] = "咏冻黎明12.0",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 257220,
          ["ilvl"] = 326,
          ["crit"] = 1264,
          ["haste"] = 294,
          ["mastery"] = 1467,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzwMzYGzgx0MAAAAAAAAYmxMAzsBgZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Weenusmobile",
          ["guild"] = "Rewind",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 256219,
          ["ilvl"] = 326,
          ["crit"] = 1398,
          ["haste"] = 265,
          ["mastery"] = 1430,
          ["vers"] = 124,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGPwMzsMzwMzMjZGMzYmhZGzMzYbmZYMDLDNDAAAAAAAAmZMGwMbAYWAbDAD",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "금칩",
          ["guild"] = "태상이와 아이들",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 253385,
          ["ilvl"] = 322,
          ["crit"] = 1452,
          ["haste"] = 539,
          ["mastery"] = 1215,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzYbmZMjZwQzAAAAAAAAgZGzAMzGAmFw2AwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Lagyo",
          ["guild"] = "Opposite",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 252743,
          ["ilvl"] = 324,
          ["crit"] = 1103,
          ["haste"] = 842,
          ["mastery"] = 1026,
          ["vers"] = 219,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzwMzYGzgx0MAAAAAAAAYmxMAzsBgZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Ramwog",
          ["guild"] = "Mid Team",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 250838,
          ["ilvl"] = 325,
          ["crit"] = 1226,
          ["haste"] = 652,
          ["mastery"] = 1106,
          ["vers"] = 153,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYzMjZMDGTzAAAAAAAAAzYMgZ2AGmFw2AwA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "초록오리너구리",
          ["guild"] = "애옹",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 246743,
          ["ilvl"] = 322,
          ["crit"] = 1241,
          ["haste"] = 433,
          ["mastery"] = 1364,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGPwMzsMzwMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAMPwYMgZ2AwsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Tributroll",
          ["guild"] = "Frenzied Apes",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 243037,
          ["ilvl"] = 326,
          ["crit"] = 1240,
          ["haste"] = 561,
          ["mastery"] = 1326,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZYMDLDNDAAAAAAAAmHYMzAmZDAzCYbAYA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Scuffedaim",
          ["guild"] = "Death and Glory",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 238914,
          ["ilvl"] = 326,
          ["crit"] = 892,
          ["haste"] = 1026,
          ["mastery"] = 1193,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZYMDGTzAAAAAAAAg5BGjBMzGAzsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Vórtéx",
          ["guild"] = "Raze",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 238907,
          ["ilvl"] = 322,
          ["crit"] = 1128,
          ["haste"] = 755,
          ["mastery"] = 1029,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 159617,
              ["name"] = "Lustrous Golden Plumage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLDNDAAAAAAAAMjxAmZDAzCYbAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Naggash",
          ["guild"] = "The Reckless",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 237410,
          ["ilvl"] = 324,
          ["crit"] = 1312,
          ["haste"] = 568,
          ["mastery"] = 1070,
          ["vers"] = 227,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGmZmlZGzMzMjZGMzYmhZGzMzsYmZMjZwYaGAAAAAAAAMmZGgZ2AwsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "爬山丶丶",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 256399,
          ["ilvl"] = 327,
          ["crit"] = 1168,
          ["haste"] = 558,
          ["mastery"] = 1242,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsMzwMmZMzgZGzMMzYmZGMGzYGMmmBAAAAAAAAzMzMAzsBYxsA2GAG",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Dpxhunt",
          ["guild"] = "Gravity",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 255042,
          ["ilvl"] = 325,
          ["crit"] = 1142,
          ["haste"] = 792,
          ["mastery"] = 1146,
          ["vers"] = 84,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzwMGzYGWGaAAAAAAAAgZGzMgZ2gNYWAbDAD",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Tokasan",
          ["guild"] = "RETRY",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 249397,
          ["ilvl"] = 326,
          ["crit"] = 1553,
          ["haste"] = 303,
          ["mastery"] = 1295,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzYGbmZMjZwQzAAAAAAAAgZGzMgZ2gNYWAbDAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "風流小郎君",
          ["guild"] = "Prologue",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 248910,
          ["ilvl"] = 323,
          ["crit"] = 1146,
          ["haste"] = 95,
          ["mastery"] = 1610,
          ["vers"] = 319,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsNzwMzMjZGMzYmhZGzMzYzMjZMDLjpZAAAAAAAAgZMGwMbAYWAbDAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "黑蚊子多",
          ["guild"] = "泼墨成苍穹",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 246949,
          ["ilvl"] = 322,
          ["crit"] = 1147,
          ["haste"] = 56,
          ["mastery"] = 1478,
          ["vers"] = 248,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzwMzYGzghmBAAAAAAAAzMmBYmNYDmFw2AA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "不系之舟",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 246650,
          ["ilvl"] = 324,
          ["crit"] = 1236,
          ["haste"] = 367,
          ["mastery"] = 1458,
          ["vers"] = 130,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzMzgxYGzgx0MAAAAAAAAYmZmBYmNghZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Zonl",
          ["guild"] = "爱与新生",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 245398,
          ["ilvl"] = 318,
          ["crit"] = 1293,
          ["haste"] = 273,
          ["mastery"] = 1450,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYzMjZMDLDNDAAAAAAAAMjxAmZDgZWAbDAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Salamigomez",
          ["guild"] = "Drunk n loaded",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 244387,
          ["ilvl"] = 324,
          ["crit"] = 1255,
          ["haste"] = 485,
          ["mastery"] = 1309,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGPwMzsMzwMzMjZGMzYmhZGzYGmZGzYGM0MAAAAAAAAYmZmBYmNghZBsNAM",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "屠龙猎手",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 243713,
          ["ilvl"] = 321,
          ["crit"] = 1167,
          ["haste"] = 108,
          ["mastery"] = 1200,
          ["vers"] = 462,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzsYmZMjZwYaGAAAAAAAAMGzAMzGsBzCYbAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Фруктовыйсэд",
          ["guild"] = "Just Play",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 242546,
          ["ilvl"] = 323,
          ["crit"] = 1202,
          ["haste"] = 613,
          ["mastery"] = 1272,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYbmZYMDLDNDAAAAAAAAMjxAmZDYYWAbDAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        }
      }
    },
    {
      ["spec"] = "Marksmanship",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Tinylegs",
          ["guild"] = "Soft Enrage",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 262154,
          ["ilvl"] = 326,
          ["crit"] = 1612,
          ["haste"] = 212,
          ["mastery"] = 1247,
          ["vers"] = 296,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYegZGGAzYjZxAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Imnotanorc",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 254408,
          ["ilvl"] = 329,
          ["crit"] = 1789,
          ["haste"] = 213,
          ["mastery"] = 1288,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBz222MzMzMzMzAzywMAAAzMzMGAzYjhBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Azortharion",
          ["guild"] = "Noctis",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 245795,
          ["ilvl"] = 325,
          ["crit"] = 1752,
          ["haste"] = 32,
          ["mastery"] = 1172,
          ["vers"] = 410,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAwMzwAYGbMmBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Qenjua",
          ["guild"] = "Hatewatching",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 245555,
          ["ilvl"] = 327,
          ["crit"] = 1608,
          ["haste"] = 175,
          ["mastery"] = 1087,
          ["vers"] = 525,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMwsMMzAAAGzMzMAmx2GMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Gdolfhunter",
          ["guild"] = "Revoke",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 241383,
          ["ilvl"] = 327,
          ["crit"] = 1771,
          ["haste"] = 300,
          ["mastery"] = 1005,
          ["vers"] = 303,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGMzywMAAAzDMzwAYGbMMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Robviously",
          ["guild"] = "Hi Five",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 241236,
          ["ilvl"] = 325,
          ["crit"] = 1491,
          ["haste"] = 348,
          ["mastery"] = 1354,
          ["vers"] = 138,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMwsMMzAAAGzMjBwM2wyMAbMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Macho",
          ["guild"] = "Memento Morí",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 239131,
          ["ilvl"] = 325,
          ["crit"] = 1510,
          ["haste"] = 334,
          ["mastery"] = 1379,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmBjZmxMYMNjBz2mZmZmZmZmZBzywMAAAzMmZGAzYjhBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Airponchik",
          ["guild"] = "Grim",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 239013,
          ["ilvl"] = 320,
          ["crit"] = 1458,
          ["haste"] = 384,
          ["mastery"] = 969,
          ["vers"] = 437,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLbzYmZMDeATzYwstZmZmZmZmZwMLDzMAAgxMzYAMjNGGgNmZbGD",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Bîstand",
          ["guild"] = "Sabotage",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 238560,
          ["ilvl"] = 325,
          ["crit"] = 2014,
          ["haste"] = 244,
          ["mastery"] = 1125,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmZxMmZGzgx0MGMbbmZmZmZmZGMzywMDAAYMzwAYGbMMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Celance",
          ["guild"] = "Advent",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 238281,
          ["ilvl"] = 324,
          ["crit"] = 1688,
          ["haste"] = 133,
          ["mastery"] = 1127,
          ["vers"] = 294,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYMzwAYGbMLzAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Azortharion",
          ["guild"] = "Noctis",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 254062,
          ["ilvl"] = 325,
          ["crit"] = 1615,
          ["haste"] = 126,
          ["mastery"] = 1139,
          ["vers"] = 504,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAwMzwAYGbMmBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Qenjua",
          ["guild"] = "Hatewatching",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 253637,
          ["ilvl"] = 327,
          ["crit"] = 1608,
          ["haste"] = 175,
          ["mastery"] = 1087,
          ["vers"] = 525,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMwsMMzAAAGzMzMAmx2GMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Loveirlmoney",
          ["guild"] = "Deception",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 251383,
          ["ilvl"] = 327,
          ["crit"] = 1705,
          ["haste"] = 133,
          ["mastery"] = 1257,
          ["vers"] = 283,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYmZGGAzYjhBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Imnotanorc",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 250966,
          ["ilvl"] = 330,
          ["crit"] = 1801,
          ["haste"] = 214,
          ["mastery"] = 1286,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBjtlZmZmZmZmBmlBzAAAmZmhZAmxGziBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Tinylegs",
          ["guild"] = "Soft Enrage",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 249776,
          ["ilvl"] = 326,
          ["crit"] = 1614,
          ["haste"] = 212,
          ["mastery"] = 1248,
          ["vers"] = 296,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYegZGGAzYjZxAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Tdyipce",
          ["guild"] = "velocity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 248287,
          ["ilvl"] = 325,
          ["crit"] = 1657,
          ["haste"] = 181,
          ["mastery"] = 1038,
          ["vers"] = 484,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAwMzwAYGbMmBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Grebet",
          ["guild"] = "Tempo",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 244134,
          ["ilvl"] = 326,
          ["crit"] = 1858,
          ["haste"] = 197,
          ["mastery"] = 1228,
          ["vers"] = 49,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLbzYmZMDeATzYwstZmZmZmZmZwMLDzMAAgxMzYAMjNGGgNmZbGD",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Ericjunior",
          ["guild"] = "Lucid",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 243475,
          ["ilvl"] = 326,
          ["crit"] = 1798,
          ["haste"] = 183,
          ["mastery"] = 1278,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGMzywMAAAegZGGAzYjxMAbMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Choehunt",
          ["guild"] = "The Amazing Zoo",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 242254,
          ["ilvl"] = 325,
          ["crit"] = 1556,
          ["haste"] = 205,
          ["mastery"] = 1183,
          ["vers"] = 394,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGMzywMAAAzDMzwAYGbMMAbMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Kralgesek",
          ["guild"] = "Wave",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 241942,
          ["ilvl"] = 326,
          ["crit"] = 1631,
          ["haste"] = 427,
          ["mastery"] = 1183,
          ["vers"] = 154,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMYmlhZGAAwYmxMAmxGDDwGzsNjB",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Imnotnarcs",
          ["guild"] = "Leviathan",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 349865,
          ["ilvl"] = 324,
          ["crit"] = 1975,
          ["haste"] = 220,
          ["mastery"] = 1054,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLbzYmZMDeATzYwstZmZmZmZmZwMLDzMAAgxMzYAMjNGGgNmZbGD",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Imnotanorc",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 348694,
          ["ilvl"] = 330,
          ["crit"] = 1801,
          ["haste"] = 214,
          ["mastery"] = 1286,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBz222MzMzMzMzAzywMAAAzMzMGAzYjhBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Grantørino",
          ["guild"] = "Frenzied Apes",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 346164,
          ["ilvl"] = 326,
          ["crit"] = 1690,
          ["haste"] = 265,
          ["mastery"] = 1004,
          ["vers"] = 412,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxM2mxMzYGMmmxgZbbbmZmZmZmZwMLDzAAAMPwMDDgZsxwAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Celance",
          ["guild"] = "Advent",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 344582,
          ["ilvl"] = 326,
          ["crit"] = 1597,
          ["haste"] = 133,
          ["mastery"] = 1092,
          ["vers"] = 434,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYMzwAYGbMLzAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Azortharion",
          ["guild"] = "Noctis",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 342460,
          ["ilvl"] = 326,
          ["crit"] = 1666,
          ["haste"] = 126,
          ["mastery"] = 1139,
          ["vers"] = 467,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAwMzwAYGbMmBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Stormixh",
          ["guild"] = "Kodeks",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 340485,
          ["ilvl"] = 326,
          ["crit"] = 1508,
          ["haste"] = 255,
          ["mastery"] = 1444,
          ["vers"] = 115,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMMjZmxMYMNjBz2mZmZmZmZmBmlhZGAAwYmZMAmx2GLzAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Bàzingà",
          ["guild"] = "Profanities",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 340218,
          ["ilvl"] = 324,
          ["crit"] = 3513,
          ["haste"] = -123,
          ["mastery"] = 1187,
          ["vers"] = 317,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmZxMmZGzgx0MGMbbLzMzMzMzMDmZZYGAAgxMzYAMjNwAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "陈年风褛",
          ["guild"] = "炉火糖粥",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 331464,
          ["ilvl"] = 326,
          ["crit"] = 1613,
          ["haste"] = 258,
          ["mastery"] = 1186,
          ["vers"] = 340,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMwsMMzAAAGzMmBwM2YWMAbMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Qenjua",
          ["guild"] = "Hatewatching",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 330531,
          ["ilvl"] = 327,
          ["crit"] = 3401,
          ["haste"] = -56,
          ["mastery"] = 1087,
          ["vers"] = 525,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMwsMMzAAAGzMzMAmx2GMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "파강마",
          ["guild"] = "비 상",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 329789,
          ["ilvl"] = 319,
          ["crit"] = 1845,
          ["haste"] = 16,
          ["mastery"] = 1222,
          ["vers"] = 109,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMMjZmxMYMNjBz2mZmZmZmZmBzsMMzAAAmHYmZMAmxGDDwGzsNjB",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Imnotanorc",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 328581,
          ["ilvl"] = 328,
          ["crit"] = 1783,
          ["haste"] = 211,
          ["mastery"] = 1288,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBz2mZmZmZmZmBmlhZGAAwMzMjBwM2YYA2YmtZMA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Loveirlmoney",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 326437,
          ["ilvl"] = 327,
          ["crit"] = 1657,
          ["haste"] = 133,
          ["mastery"] = 1210,
          ["vers"] = 376,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBz2mZmZmZmZmBmlhZGAAwMzMjBwM2YYA2YmtZMA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "파개왕태우스",
          ["guild"] = "Mate",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 325820,
          ["ilvl"] = 332,
          ["crit"] = 1601,
          ["haste"] = 356,
          ["mastery"] = 1284,
          ["vers"] = 240,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYMzMGAzYDLzAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Azortharion",
          ["guild"] = "Noctis",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 316030,
          ["ilvl"] = 325,
          ["crit"] = 1615,
          ["haste"] = 126,
          ["mastery"] = 1139,
          ["vers"] = 504,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAwMzwAYGbMmBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Luumu",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 315625,
          ["ilvl"] = 326,
          ["crit"] = 1863,
          ["haste"] = 110,
          ["mastery"] = 1110,
          ["vers"] = 257,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMwsMMzAAAmHYmZMAmxGDDwGzsNjB",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "弧光丶",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 314180,
          ["ilvl"] = 326,
          ["crit"] = 1752,
          ["haste"] = 298,
          ["mastery"] = 930,
          ["vers"] = 793,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBz2mZmZmZmZmBmlhZGAAwMzMMAmxGziBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Leevilh",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 313104,
          ["ilvl"] = 327,
          ["crit"] = 1708,
          ["haste"] = 249,
          ["mastery"] = 1284,
          ["vers"] = 569,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMYmlhZGAAwYmxMAmxGDDwGzsNjB",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Èd",
          ["guild"] = "HKM",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 311472,
          ["ilvl"] = 324,
          ["crit"] = 1685,
          ["haste"] = 175,
          ["mastery"] = 1059,
          ["vers"] = 326,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYmZGGAzYjhBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Gdolfhunter",
          ["guild"] = "Revoke",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 305922,
          ["ilvl"] = 327,
          ["crit"] = 1771,
          ["haste"] = 300,
          ["mastery"] = 1005,
          ["vers"] = 303,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGMzywMAAAzDMzwAYGbMMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "陈年风褛",
          ["guild"] = "炉火糖粥",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 301444,
          ["ilvl"] = 326,
          ["crit"] = 1613,
          ["haste"] = 258,
          ["mastery"] = 1186,
          ["vers"] = 339,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMwsMMzAAAGzMmBwM2YWMAbMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "파개왕태우스",
          ["guild"] = "Mate",
          ["boss"] = "Sszorak",
          ["amount"] = 234077,
          ["ilvl"] = 332,
          ["crit"] = 1601,
          ["haste"] = 356,
          ["mastery"] = 1284,
          ["vers"] = 240,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmZxMmZGzgx0MGM2WmZmZmZmZGYWGMDAAYMzwMAzYjZxAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "绒绒猫球",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 230372,
          ["ilvl"] = 326,
          ["crit"] = 1542,
          ["haste"] = 303,
          ["mastery"] = 1477,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMYstMzMzMzMzMwsMYGAAw8AzMMDwM2YWMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Tdyipce",
          ["guild"] = "velocity",
          ["boss"] = "Sszorak",
          ["amount"] = 230279,
          ["ilvl"] = 325,
          ["crit"] = 1657,
          ["haste"] = 181,
          ["mastery"] = 1038,
          ["vers"] = 484,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBjtlZmZmZmZmBmlBzAAAmZmhZAmxGziBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Imnotanorc",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Sszorak",
          ["amount"] = 229551,
          ["ilvl"] = 323,
          ["crit"] = 1830,
          ["haste"] = 176,
          ["mastery"] = 1216,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBjtlZmZmZmZmBmlBzAAAmZmhZAmxGziBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Noscopenate",
          ["guild"] = "Noctis",
          ["boss"] = "Sszorak",
          ["amount"] = 227830,
          ["ilvl"] = 324,
          ["crit"] = 1683,
          ["haste"] = 146,
          ["mastery"] = 1223,
          ["vers"] = 261,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMYstMzMzMzMzMLYWGMDAAYegZGGAzYjZxAswMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Slickyy",
          ["guild"] = "constant",
          ["boss"] = "Sszorak",
          ["amount"] = 226025,
          ["ilvl"] = 321,
          ["crit"] = 1649,
          ["haste"] = 254,
          ["mastery"] = 1251,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBjtlZmZmZmZmBmlBzAAAmZmhZAmxGziBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Socronh",
          ["guild"] = "Revolutions",
          ["boss"] = "Sszorak",
          ["amount"] = 225000,
          ["ilvl"] = 322,
          ["crit"] = 1671,
          ["haste"] = 215,
          ["mastery"] = 1053,
          ["vers"] = 229,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 159617,
              ["name"] = "Lustrous Golden Plumage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMYstMzMzMzMzMwsMYGAAwMzMMDwM2wiBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Rngu",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Sszorak",
          ["amount"] = 224966,
          ["ilvl"] = 321,
          ["crit"] = 1580,
          ["haste"] = 126,
          ["mastery"] = 1036,
          ["vers"] = 414,
          ["trinkets"] = {
            {
              ["id"] = 159617,
              ["name"] = "Lustrous Golden Plumage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmZxMmZGzgx0MGM2WmZmZmZmZmFMLDmBAAMmZGDgZsxwAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Azortharion",
          ["guild"] = "Noctis",
          ["boss"] = "Sszorak",
          ["amount"] = 224920,
          ["ilvl"] = 321,
          ["crit"] = 1692,
          ["haste"] = 32,
          ["mastery"] = 1231,
          ["vers"] = 345,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMYstMzMzMzMzMLYWGMDAAwMzwAYGbMmBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Ледибак",
          ["guild"] = "Фаерфлай",
          ["boss"] = "Sszorak",
          ["amount"] = 223983,
          ["ilvl"] = 326,
          ["crit"] = 1774,
          ["haste"] = 16,
          ["mastery"] = 1235,
          ["vers"] = 321,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBjtlZmZmZmZmBmlBzAAAmZmhZAmxGziBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Imnotanorc",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 318472,
          ["ilvl"] = 330,
          ["crit"] = 1801,
          ["haste"] = 214,
          ["mastery"] = 1286,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBz222MzMzMzMzAzywMAAAzMzMGAzYjhBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "파개왕태우스",
          ["guild"] = "Mate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 307290,
          ["ilvl"] = 332,
          ["crit"] = 1601,
          ["haste"] = 356,
          ["mastery"] = 1284,
          ["vers"] = 240,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYMzMGAzYDLzAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Tdyipce",
          ["guild"] = "velocity",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 306374,
          ["ilvl"] = 325,
          ["crit"] = 1657,
          ["haste"] = 181,
          ["mastery"] = 1038,
          ["vers"] = 484,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAwMzwAYGbMmBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Azortharion",
          ["guild"] = "Noctis",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 302971,
          ["ilvl"] = 325,
          ["crit"] = 1664,
          ["haste"] = 126,
          ["mastery"] = 1208,
          ["vers"] = 395,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxM2mxMzYGMmmxgZbbbmZmZmZmZwMLDzAAAYmZYAMjNGGgNmZbGD",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Doodthingy",
          ["guild"] = "Comfy",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 300242,
          ["ilvl"] = 326,
          ["crit"] = 1523,
          ["haste"] = 275,
          ["mastery"] = 1196,
          ["vers"] = 216,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLbzYmZMDeATzYwsttNzMzMzMzMYmlhZAAAGzMjBwM2YYA2YmtZMA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Stilldre",
          ["guild"] = "Blinded",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 299107,
          ["ilvl"] = 326,
          ["crit"] = 1697,
          ["haste"] = 180,
          ["mastery"] = 997,
          ["vers"] = 512,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMMjZmxMYMNjBz222MzMzMzMzgZWGmBAAYmZGGAzYjhBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "绒绒猫球",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 298586,
          ["ilvl"] = 326,
          ["crit"] = 1542,
          ["haste"] = 303,
          ["mastery"] = 1477,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22WmZmZmZmZGYWGmBAAYegZGGAzYjZxAswMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Slickyy",
          ["guild"] = "constant",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 298254,
          ["ilvl"] = 325,
          ["crit"] = 1712,
          ["haste"] = 352,
          ["mastery"] = 1218,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBz2mZmZmZmZmBmlhZGAAwMzMjBwM2YYA2YmtZMA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Èd",
          ["guild"] = "HKM",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 297778,
          ["ilvl"] = 323,
          ["crit"] = 1680,
          ["haste"] = 175,
          ["mastery"] = 1057,
          ["vers"] = 326,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxM2mxMzYGMmmxgZbzMzMzMzMzswMLDzAAAYmZYAMjNGGgNmZbGD",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Qenjua",
          ["guild"] = "Hatewatching",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 295442,
          ["ilvl"] = 327,
          ["crit"] = 1608,
          ["haste"] = 175,
          ["mastery"] = 1087,
          ["vers"] = 525,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmx2MmZGzgx0MGMbbmZmZmZmZGMzywMDAAYMzYGAzYDMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Imnotanorc",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 274777,
          ["ilvl"] = 330,
          ["crit"] = 1801,
          ["haste"] = 214,
          ["mastery"] = 1286,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBz222MzMzMzMzAzywMAAAzMzMGAzYjhBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "파개왕태우스",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 266548,
          ["ilvl"] = 332,
          ["crit"] = 1527,
          ["haste"] = 356,
          ["mastery"] = 1284,
          ["vers"] = 660,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYMzMGAzYbDzAswMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Firaa",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 260194,
          ["ilvl"] = 326,
          ["crit"] = 1842,
          ["haste"] = 113,
          ["mastery"] = 1378,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmZxMmZGzgx0MGMbbbzMzMzMzMDMLDzAAAMmZGDgZstBDwGzsNjB",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Bîstand",
          ["guild"] = "Sabotage",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 260053,
          ["ilvl"] = 327,
          ["crit"] = 1853,
          ["haste"] = 358,
          ["mastery"] = 1051,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmZxMmZGzgx0MGMbbmZmZmZmZGMzywMDAAYMzwAYGbMMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "炎老师",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 258516,
          ["ilvl"] = 328,
          ["crit"] = 1465,
          ["haste"] = 483,
          ["mastery"] = 1278,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22WmZmZmZmZGYWGmBAAYmZGGAzYjhBYhZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Kralgesek",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 254549,
          ["ilvl"] = 327,
          ["crit"] = 1779,
          ["haste"] = 427,
          ["mastery"] = 1063,
          ["vers"] = 154,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMYmlhZGAAwYmxMAmxGDDwGzsNjB",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Domestic",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 252739,
          ["ilvl"] = 326,
          ["crit"] = 1502,
          ["haste"] = 468,
          ["mastery"] = 1275,
          ["vers"] = 523,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22WmZmZmZmZGMzywMAAAzMzwAYGbgBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Hunterz",
          ["guild"] = "Myth",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 250028,
          ["ilvl"] = 327,
          ["crit"] = 1640,
          ["haste"] = 253,
          ["mastery"] = 1113,
          ["vers"] = 361,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmZxMmZGzgx0MGMbbmZmZmZmZGMzywMDAAYMzMGAzYDMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Vocif",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 248589,
          ["ilvl"] = 328,
          ["crit"] = 1499,
          ["haste"] = 454,
          ["mastery"] = 1065,
          ["vers"] = 277,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLbzYmZMDeATzYwstZmZmZmZmZwMLDzMAAgxMzYAMjNGGgNmZbGD",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Matcheh",
          ["guild"] = "Infinity",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 245645,
          ["ilvl"] = 325,
          ["crit"] = 1770,
          ["haste"] = 244,
          ["mastery"] = 1132,
          ["vers"] = 245,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYegZmxAYGbbwAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "파개왕태우스",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 372677,
          ["ilvl"] = 333,
          ["crit"] = 1531,
          ["haste"] = 356,
          ["mastery"] = 1302,
          ["vers"] = 1500,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMwsMMzAAAGzMMAmxGzyMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Chazh",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 368604,
          ["ilvl"] = 330,
          ["crit"] = 1486,
          ["haste"] = 510,
          ["mastery"] = 1108,
          ["vers"] = 1643,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22MzMzMzMzMLYWGmBAAYegZmxAYGbYxAswMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Domestic",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 346719,
          ["ilvl"] = 331,
          ["crit"] = 1742,
          ["haste"] = 417,
          ["mastery"] = 1289,
          ["vers"] = 1276,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY22WmZmZmZmZGYWGmBAAYmZGGAzYjhBYhZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Celance",
          ["guild"] = "Advent",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 271024,
          ["ilvl"] = 324,
          ["crit"] = 1688,
          ["haste"] = 133,
          ["mastery"] = 1127,
          ["vers"] = 294,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYMzwAYGbMLzAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Èd",
          ["guild"] = "HKM",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 266718,
          ["ilvl"] = 324,
          ["crit"] = 1685,
          ["haste"] = 175,
          ["mastery"] = 1059,
          ["vers"] = 326,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLbzYmZMDeATzYwsttNzMzMzMzMYmlhZAAAGzMjBwM2YYA2YmtZMA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Imnotanorc",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 264843,
          ["ilvl"] = 325,
          ["crit"] = 1836,
          ["haste"] = 176,
          ["mastery"] = 1229,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBDNjBz2mZmZmZmZmBmlhZGAAwMzMjBwM2YYA2YmtZMA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Azortharion",
          ["guild"] = "Noctis",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 263208,
          ["ilvl"] = 326,
          ["crit"] = 1666,
          ["haste"] = 126,
          ["mastery"] = 1139,
          ["vers"] = 467,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAwMzwAYGbMmBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Tdyipce",
          ["guild"] = "velocity",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 262524,
          ["ilvl"] = 323,
          ["crit"] = 1803,
          ["haste"] = 146,
          ["mastery"] = 1000,
          ["vers"] = 362,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAwMzwAYGbMmBYjZ2mxA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "파개왕태우스",
          ["guild"] = "Mate",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 254917,
          ["ilvl"] = 332,
          ["crit"] = 1601,
          ["haste"] = 356,
          ["mastery"] = 1284,
          ["vers"] = 240,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGYWGmBAAYMzMGAzYDLzAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Geethdwarf",
          ["guild"] = "Wild Things",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 252889,
          ["ilvl"] = 325,
          ["crit"] = 1623,
          ["haste"] = 212,
          ["mastery"] = 1139,
          ["vers"] = 250,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLmxMzYGMmmxgZbbbmZmZmZmZwMLDzAAAMmZGDgZstBDwGzsNjB",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Gdolfhunter",
          ["guild"] = "Revoke",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 249266,
          ["ilvl"] = 327,
          ["crit"] = 1821,
          ["haste"] = 357,
          ["mastery"] = 1113,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmhZMzMmBjpZMY222mZmZmZmZGMzywMAAAzDMzwAYGbMMALMz2MG",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Stormixh",
          ["guild"] = "Kodeks",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 249150,
          ["ilvl"] = 325,
          ["crit"] = 1322,
          ["haste"] = 783,
          ["mastery"] = 1099,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMMjZmxMYMNjBz2mZmZmZmZmBmlhZGAAwYmZMAmx2GLzAsxMbzYA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Itsdnl",
          ["guild"] = "Lucid",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 248802,
          ["ilvl"] = 322,
          ["crit"] = 1796,
          ["haste"] = 269,
          ["mastery"] = 1211,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmx2MmZGzghmxgZbbbmZmZmZmZwMLDzAAAMzMDDgZsBGgNmZbGD",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        }
      }
    },
    {
      ["spec"] = "Survival",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Naintrapable",
          ["guild"] = "Ashveil",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 221595,
          ["ilvl"] = 322,
          ["crit"] = 836,
          ["haste"] = 800,
          ["mastery"] = 1412,
          ["vers"] = 54,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYGMGzYGMmmBAAAYAwMWWmZmFmZmZmZGAYGLMLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Amelden",
          ["guild"] = "Stay Hydrated",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 221275,
          ["ilvl"] = 324,
          ["crit"] = 1137,
          ["haste"] = 658,
          ["mastery"] = 1360,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGjZZAAAAAAYGzYmltZMmxMYMNDAAAwAgZssMzMLGzMzYmZAwMWAjhxmBA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Jujan",
          ["guild"] = "The Shining Dawn",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217849,
          ["ilvl"] = 323,
          ["crit"] = 982,
          ["haste"] = 921,
          ["mastery"] = 1211,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAAAwMWWmZmFzMzMzMmBAzYhZxYMjNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "音箱蟀侠",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 214207,
          ["ilvl"] = 324,
          ["crit"] = 576,
          ["haste"] = 1109,
          ["mastery"] = 1298,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAADAmxyyMzswMzMzMGAYGLMLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Izze",
          ["guild"] = "Legacy",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 214134,
          ["ilvl"] = 323,
          ["crit"] = 833,
          ["haste"] = 777,
          ["mastery"] = 1258,
          ["vers"] = 157,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAADAmxyyMzsYmZmZmZGAYGLYxYMjNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Leaku",
          ["guild"] = "Regular Average Gamers",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 209871,
          ["ilvl"] = 320,
          ["crit"] = 965,
          ["haste"] = 641,
          ["mastery"] = 1687,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249806,
              ["name"] = "Radiant Plume",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYGMGzYGMmmBAAAYAwMWWmZmFmZmZmZGAYGLMLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "残锋猎影",
          ["guild"] = "Universe",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 209123,
          ["ilvl"] = 319,
          ["crit"] = 1123,
          ["haste"] = 792,
          ["mastery"] = 1450,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 249806,
              ["name"] = "Radiant Plume",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmxyyMzswMzMzMGAYGLMLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Custardy",
          ["guild"] = "Just Kill the Boss",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 207513,
          ["ilvl"] = 319,
          ["crit"] = 757,
          ["haste"] = 761,
          ["mastery"] = 1450,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYmZmZGmxYGzgx0MAAAADAmxyyMzsYmZmZMzAAzYhhxYGbGAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Frostrend",
          ["guild"] = "comma",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 206970,
          ["ilvl"] = 320,
          ["crit"] = 1058,
          ["haste"] = 577,
          ["mastery"] = 3065,
          ["vers"] = -70,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAYAwwyyMzsYmZmZMGDAzYBLzYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Mocords",
          ["guild"] = "Chimera",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 204049,
          ["ilvl"] = 323,
          ["crit"] = 1207,
          ["haste"] = 645,
          ["mastery"] = 1326,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGWGaGAAAgBAzYZZmZWYmZmxMjBgZswwYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Proudidiot",
          ["guild"] = "Hård",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 204241,
          ["ilvl"] = 327,
          ["crit"] = 759,
          ["haste"] = 864,
          ["mastery"] = 1489,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGjZZAAAAAAYmZmZGmxYGzgx0MAAAADAmZWWmZmFMzMjZmBAzYBMGGbGAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Øttër",
          ["guild"] = "Zero Gravity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 203342,
          ["ilvl"] = 325,
          ["crit"] = 908,
          ["haste"] = 931,
          ["mastery"] = 1184,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGjZZAAAAAAYGzMzgxYGzgx0MAAAADAmZWWmZmFMzMmZGDAzYhhxwYzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Leaku",
          ["guild"] = "Regular Average Gamers",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 200949,
          ["ilvl"] = 326,
          ["crit"] = 848,
          ["haste"] = 762,
          ["mastery"] = 1429,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYGbGjZMDGTzAAAAMAYGLLzMzCzMzMzYAgZswsYMmZ2MAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Izze",
          ["guild"] = "Legacy",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 199772,
          ["ilvl"] = 323,
          ["crit"] = 833,
          ["haste"] = 777,
          ["mastery"] = 1258,
          ["vers"] = 157,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAADAmxyyMzsYmZmZmZGAYGLYxYMjNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Cyndr",
          ["guild"] = "Judge",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 198451,
          ["ilvl"] = 322,
          ["crit"] = 924,
          ["haste"] = 664,
          ["mastery"] = 1499,
          ["vers"] = 134,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYmZGzwMGzYGMmmBAAAYAwMWWmZmFmZmZMzAAzYhZxYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Шмалетар",
          ["guild"] = "Колесо сансары",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 197810,
          ["ilvl"] = 321,
          ["crit"] = 688,
          ["haste"] = 1050,
          ["mastery"] = 1094,
          ["vers"] = 225,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYmZmZGmxYGzgx0MAAAADAmxyyMzswMzMjZGDAzYBMGzMbGAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Kayzerh",
          ["guild"] = "Resonate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 197628,
          ["ilvl"] = 324,
          ["crit"] = 1107,
          ["haste"] = 445,
          ["mastery"] = 1503,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmxyyMzswMzMzDMzAAzYhZxYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Prey",
          ["guild"] = "Idiots",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 197204,
          ["ilvl"] = 326,
          ["crit"] = 843,
          ["haste"] = 701,
          ["mastery"] = 1471,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmxyyMzswMzMzDMzMAYGbMMGzMbGAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Graysurv",
          ["guild"] = "Alpha",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 195546,
          ["ilvl"] = 321,
          ["crit"] = 930,
          ["haste"] = 759,
          ["mastery"] = 1463,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzYbGjZMDGTzAAAAMAYGLLzMzCzMzMmZMAMjNwYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Alexini",
          ["guild"] = "Primori Morte",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 193629,
          ["ilvl"] = 322,
          ["crit"] = 827,
          ["haste"] = 800,
          ["mastery"] = 1233,
          ["vers"] = 181,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYGMGzYGMmmBAAAYAwMWWmZmFmZmZmZGAYGLMLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Mörkö",
          ["guild"] = "Kilta",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 338654,
          ["ilvl"] = 325,
          ["crit"] = 1175,
          ["haste"] = 725,
          ["mastery"] = 1320,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGzMbDAAAAAAzYmZGmxYGzgx0MAAAAAAW2mZmFegZmZMzMAYGbbYGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Alexini",
          ["guild"] = "Primori Morte",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 337252,
          ["ilvl"] = 327,
          ["crit"] = 802,
          ["haste"] = 843,
          ["mastery"] = 1379,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAADAmxyyMzswMzMzMzAAzYhhxYmZzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "狩野",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 329227,
          ["ilvl"] = 325,
          ["crit"] = 612,
          ["haste"] = 1205,
          ["mastery"] = 1115,
          ["vers"] = 200,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMG2gFYGGawiZmZGzYZAAAAAAYmZmZGmxYGzgx0MAAAAAwwyyMzswDMzMjxMAzsBbsYMmZ2MAA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Øttër",
          ["guild"] = "Zero Gravity",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 322359,
          ["ilvl"] = 325,
          ["crit"] = 908,
          ["haste"] = 931,
          ["mastery"] = 1184,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGzMbDAAAAAAzYmZGMGzYGMmmBAAAYAgxy2MzswDMzMmZGDAzYhhxYGbGAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Leaku",
          ["guild"] = "Regular Average Gamers",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 312872,
          ["ilvl"] = 324,
          ["crit"] = 658,
          ["haste"] = 927,
          ["mastery"] = 1417,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmZmZGDLDAAAAAAzYmZGMGzYGMmmBAAAYAwMWWmZmFjZmZmxAAzYjZxYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Amelden",
          ["guild"] = "Stay Hydrated",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 311424,
          ["ilvl"] = 324,
          ["crit"] = 1195,
          ["haste"] = 638,
          ["mastery"] = 1322,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MzMzYMLDAAAAAAzYGzssNjxMmBjpZAAAAGAMjllZmZxYmxYmZAwMWAjhxmBA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Graysurv",
          ["guild"] = "Alpha",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 309997,
          ["ilvl"] = 321,
          ["crit"] = 930,
          ["haste"] = 759,
          ["mastery"] = 1463,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmZmZGDLDAAAAAAzYmZGbzYMjZwYaGAAAgBAzYZZmZWMmZmxMjBgZsBGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Kayzerh",
          ["guild"] = "Resonate",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 309351,
          ["ilvl"] = 324,
          ["crit"] = 1107,
          ["haste"] = 445,
          ["mastery"] = 1503,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmxyyMzswMzMzDMzAAzYhZxYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Valilichhunt",
          ["guild"] = "Инвиктус",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 308682,
          ["ilvl"] = 325,
          ["crit"] = 1225,
          ["haste"] = 629,
          ["mastery"] = 1425,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWgFYGGawiZmZGzYZAAAAAAYGzMzwMGzYGM0MAAAAAwwyyMzswDMzMzMmBYmNYjFjxMzmBA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Cyndr",
          ["guild"] = "Judge",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 308046,
          ["ilvl"] = 323,
          ["crit"] = 1054,
          ["haste"] = 795,
          ["mastery"] = 1223,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGzMbDAAAAAAzMzYGmxYGzgx0MAAAADAwy2MzswDMzMjZGDAzYDLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Amelden",
          ["guild"] = "Stay Hydrated",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 265866,
          ["ilvl"] = 324,
          ["crit"] = 1137,
          ["haste"] = 658,
          ["mastery"] = 1360,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGjZZAAAAAAYGzYmltZMmxMYMNDAAAwAgZssMzMLGzMGzMDAmxCYMMzmBA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Graysurv",
          ["guild"] = "Alpha",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 265138,
          ["ilvl"] = 322,
          ["crit"] = 932,
          ["haste"] = 763,
          ["mastery"] = 1464,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzYbGjZMDGTzAAAAMAYGLLzMzCzMzMmZMAMjFwYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Proudidiot",
          ["guild"] = "Hård",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 262580,
          ["ilvl"] = 327,
          ["crit"] = 759,
          ["haste"] = 864,
          ["mastery"] = 1489,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYmZmZGmxYGzghmBAAAAAmxyyMzswMzMzMzAAzYhhxYmZzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Kayzerh",
          ["guild"] = "Resonate",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 257762,
          ["ilvl"] = 324,
          ["crit"] = 1107,
          ["haste"] = 445,
          ["mastery"] = 1503,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmxyyMzswMzMzDMzAAzYhZxYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Leaku",
          ["guild"] = "Regular Average Gamers",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 257572,
          ["ilvl"] = 326,
          ["crit"] = 848,
          ["haste"] = 762,
          ["mastery"] = 1429,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYGbGjZMDGTzAAAAMAYGLLzMzCzMzMzYAgZswsYMmZ2MAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Tayu",
          ["guild"] = "Hypérium",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 253145,
          ["ilvl"] = 322,
          ["crit"] = 1037,
          ["haste"] = 641,
          ["mastery"] = 1507,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAAAwMWWmZmFmZmZmZGAYGbMLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Soleruh",
          ["guild"] = "Spiral Out",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 252345,
          ["ilvl"] = 322,
          ["crit"] = 1170,
          ["haste"] = 825,
          ["mastery"] = 1173,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYmZmZGmxYGzgx0MAAAADAmxyyMzswMzMjZGDAzYBMGzMbGAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Сэйджен",
          ["guild"] = "Токсичные Пепеги",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 249937,
          ["ilvl"] = 325,
          ["crit"] = 878,
          ["haste"] = 766,
          ["mastery"] = 1275,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzYbGjZMDGTzAAAAMAYGbLzMziZmZmxMjBgZsAGjZsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Alexini",
          ["guild"] = "Primori Morte",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 249479,
          ["ilvl"] = 327,
          ["crit"] = 802,
          ["haste"] = 843,
          ["mastery"] = 1379,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAADAmxyyMzswMzMzMzAAzYhhxYmZzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Хикази",
          ["guild"] = "Аксиома Эскобара",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 247808,
          ["ilvl"] = 326,
          ["crit"] = 796,
          ["haste"] = 1063,
          ["mastery"] = 1283,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmxyyMzswMzMzMzAAzYhhxYmZzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Graysurv",
          ["guild"] = "Alpha",
          ["boss"] = "Sszorak",
          ["amount"] = 227870,
          ["ilvl"] = 323,
          ["crit"] = 1110,
          ["haste"] = 683,
          ["mastery"] = 1441,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzYbGjZMDGTzAAAAMAYmZbZmZWYmZmxMjBgZsAGjZsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Leaku",
          ["guild"] = "Regular Average Gamers",
          ["boss"] = "Sszorak",
          ["amount"] = 223266,
          ["ilvl"] = 324,
          ["crit"] = 838,
          ["haste"] = 754,
          ["mastery"] = 3228,
          ["vers"] = -139,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAYAwM2WmZmFzMzMzMGAYGLMMGzYzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Proudidiot",
          ["guild"] = "Hård",
          ["boss"] = "Sszorak",
          ["amount"] = 218139,
          ["ilvl"] = 327,
          ["crit"] = 759,
          ["haste"] = 864,
          ["mastery"] = 1489,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzYzYMjZwYaGAAAgBAzMbLzMzCzMzMzMDAMjFwYMjNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Alexini",
          ["guild"] = "Primori Morte",
          ["boss"] = "Sszorak",
          ["amount"] = 213095,
          ["ilvl"] = 327,
          ["crit"] = 886,
          ["haste"] = 800,
          ["mastery"] = 1339,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAADAmxyyMzswMzMzMzAAzYhhxYmZzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Valilichhunt",
          ["guild"] = "Инвиктус",
          ["boss"] = "Sszorak",
          ["amount"] = 201040,
          ["ilvl"] = 325,
          ["crit"] = 1225,
          ["haste"] = 629,
          ["mastery"] = 1425,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGM0MAAAAAwM2WmZmFzMzMzMzAAzYhZxYMjNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Tozbek",
          ["guild"] = "SNAP",
          ["boss"] = "Sszorak",
          ["amount"] = 198914,
          ["ilvl"] = 324,
          ["crit"] = 1063,
          ["haste"] = 783,
          ["mastery"] = 1262,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAYAwM2WmZmFzMzMzMGAYGLMMGzYzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Сэйджен",
          ["guild"] = "Токсичные Пепеги",
          ["boss"] = "Sszorak",
          ["amount"] = 198502,
          ["ilvl"] = 324,
          ["crit"] = 921,
          ["haste"] = 861,
          ["mastery"] = 2998,
          ["vers"] = -182,
          ["trinkets"] = {
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmx2yMzsYmZmZMzYAYGLMLGjZsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Ramztard",
          ["guild"] = "Flare",
          ["boss"] = "Sszorak",
          ["amount"] = 197307,
          ["ilvl"] = 323,
          ["crit"] = 1029,
          ["haste"] = 572,
          ["mastery"] = 1472,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAAAwMzyyMzswMzMzMzAAzYhZxYMjNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Эльвиша",
          ["guild"] = "Фаерфлай",
          ["boss"] = "Sszorak",
          ["amount"] = 197110,
          ["ilvl"] = 326,
          ["crit"] = 1352,
          ["haste"] = 342,
          ["mastery"] = 1526,
          ["vers"] = 182,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGM0MAAAADAmx2yMzsYmZmZmZGAYGLMMGzYzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Frostrend",
          ["guild"] = "comma",
          ["boss"] = "Sszorak",
          ["amount"] = 196630,
          ["ilvl"] = 325,
          ["crit"] = 1132,
          ["haste"] = 612,
          ["mastery"] = 3021,
          ["vers"] = -65,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAYAwM2WmZmFzMzMjxYAYGLYZGjZsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Peponkiller",
          ["guild"] = "Skill Issue",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 223263,
          ["ilvl"] = 323,
          ["crit"] = 843,
          ["haste"] = 746,
          ["mastery"] = 1314,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmxyyMzswMzMzMzAAzYBLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Graysurv",
          ["guild"] = "Alpha",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 226017,
          ["ilvl"] = 321,
          ["crit"] = 930,
          ["haste"] = 759,
          ["mastery"] = 1463,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzYbGjZMDGTzAAAAMAYGLLzMzCzMzMmZMAMjFwYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Øttër",
          ["guild"] = "Zero Gravity",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 219999,
          ["ilvl"] = 326,
          ["crit"] = 847,
          ["haste"] = 1030,
          ["mastery"] = 1096,
          ["vers"] = 146,
          ["trinkets"] = {
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzYbGjZMDLjpZAAAAGAMjllZmZxMzMjHYMGAmxCYMmxmBA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Leaku",
          ["guild"] = "Regular Average Gamers",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 219176,
          ["ilvl"] = 324,
          ["crit"] = 658,
          ["haste"] = 927,
          ["mastery"] = 1417,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYGMGzYGMmmBAAAYAwMWWmZmFmZmZmZGAYGLMLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Dalkus",
          ["guild"] = "Baboon Platoon",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 217910,
          ["ilvl"] = 322,
          ["crit"] = 1039,
          ["haste"] = 800,
          ["mastery"] = 1337,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYGMGzYGMmmBAAAYAwMWWmZmFmZmZmZGAYGLMLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Alexini",
          ["guild"] = "Primori Morte",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 217861,
          ["ilvl"] = 327,
          ["crit"] = 802,
          ["haste"] = 843,
          ["mastery"] = 1379,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMG2gFYGGawiZmZmZGLDAAAAAAzYmZGbzYMjZwYaGAAAgBAzYZZmxCzMjxYmBMzGAGjZmNDA",
          ["hero"] = {
            ["name"] = "Pack Leader",
            ["atlas"] = "talents-heroclass-hunter-packleader",
            ["icon"] = "inv_ability_packleaderhunter_vicioushunt"
          }
        },
        {
          ["name"] = "Tayu",
          ["guild"] = "Hypérium",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 217141,
          ["ilvl"] = 322,
          ["crit"] = 1009,
          ["haste"] = 733,
          ["mastery"] = 1445,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmx2yMzsYmZmZmZGAYGbYxYMjNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Frostrend",
          ["guild"] = "comma",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 212023,
          ["ilvl"] = 325,
          ["crit"] = 1132,
          ["haste"] = 612,
          ["mastery"] = 3021,
          ["vers"] = -65,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAYAwwyyMzsYmZmZMGDAzYBLzYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Kayzerh",
          ["guild"] = "Resonate",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 211890,
          ["ilvl"] = 323,
          ["crit"] = 1210,
          ["haste"] = 347,
          ["mastery"] = 1558,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzwMGzYGMmmBAAAAAmxyyMzswMzMzDMzAAzYhZxYMzsZAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "音箱蟀侠",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 211767,
          ["ilvl"] = 324,
          ["crit"] = 830,
          ["haste"] = 754,
          ["mastery"] = 1414,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzMzgxYGzgx0MAAAADAmxyyMzswMzMzMGAYGLMLGjZmNDA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        },
        {
          ["name"] = "Berrybad",
          ["guild"] = "Bingohallen",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 211276,
          ["ilvl"] = 323,
          ["crit"] = 963,
          ["haste"] = 816,
          ["mastery"] = 1369,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYGMGzYGMmmBAAAYAwMWWmZmFmZmZmZmBAzYhhxYmZzAA",
          ["hero"] = {
            ["name"] = "Sentinel",
            ["atlas"] = "talents-heroclass-hunter-sentinel",
            ["icon"] = "inv_ability_sentinelhunter_lunarstorm"
          }
        }
      }
    }
  }
}
