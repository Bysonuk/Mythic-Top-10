MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Druid"] = {
  ["className"] = "Druid",
  ["specs"] = {
    {
      ["spec"] = "Balance",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Yasa",
          ["guild"] = "Schwingen des Phoenix",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 242684,
          ["ilvl"] = 326,
          ["crit"] = 931,
          ["haste"] = 861,
          ["mastery"] = 1454,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGjZWmZxMzYjlZWGjZGLYYAGbbzMYMLDgJAAAALmZmZGsZgxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Fenth",
          ["guild"] = "Waít for it",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 241686,
          ["ilvl"] = 325,
          ["crit"] = 936,
          ["haste"] = 913,
          ["mastery"] = 1180,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Cotti",
          ["guild"] = "Hatewatching",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 234045,
          ["ilvl"] = 327,
          ["crit"] = 951,
          ["haste"] = 1011,
          ["mastery"] = 1194,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGjZWmZzMzYjlZWGjZGLYYAGbbzMYMLDgJAAAALmZmZGsZgxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Hovisloaf",
          ["guild"] = "mythic raid guild",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 233537,
          ["ilvl"] = 322,
          ["crit"] = 862,
          ["haste"] = 910,
          ["mastery"] = 1312,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmtxMzMYYGjZWmZxMzYjlZWGjZGLYYAGbbzMYMbDgJAAAALmZmZGsZgxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "龙舌兰咕娘",
          ["guild"] = "我全都要",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 233488,
          ["ilvl"] = 325,
          ["crit"] = 914,
          ["haste"] = 926,
          ["mastery"] = 1181,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMaGjZG4BMLMzMDGmxYmlZ2MzMWYZmlxYmxCGGgx22MDGz2AYCAAAwiZmZmBbGzYMDAgZGYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Båt",
          ["guild"] = "Spicy Personas",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 232107,
          ["ilvl"] = 323,
          ["crit"] = 657,
          ["haste"] = 1018,
          ["mastery"] = 1249,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwswMzMYYGjZWmZxMzYjlZWGjZGLYYAGbbzMYMLDgJAAAALmZmZGsZMjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "布莱恩乌瑞恩",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 230002,
          ["ilvl"] = 323,
          ["crit"] = 845,
          ["haste"] = 897,
          ["mastery"] = 1152,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYYMzyMbmZGbsMzyYMzYBDDwYbbmBjZZAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Nickdruid",
          ["guild"] = "baited",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 229791,
          ["ilvl"] = 324,
          ["crit"] = 754,
          ["haste"] = 843,
          ["mastery"] = 1167,
          ["vers"] = 252,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmlZmZmBDzYMzyMbmZGbsMzyYMzYBDAGbbzMYMLDgJAAAALmZmZGsZgxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "妹妹的滴滴徳",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 229119,
          ["ilvl"] = 325,
          ["crit"] = 954,
          ["haste"] = 932,
          ["mastery"] = 1134,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYYMzyMLmZGLsMzyYMzYBDAGbbzMYMbDgJAAAALmZmZGsZMjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Sunstep",
          ["guild"] = "lmao",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 227866,
          ["ilvl"] = 326,
          ["crit"] = 646,
          ["haste"] = 967,
          ["mastery"] = 1295,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGjZWmZxMzYjlZWGjZGLYYAGbbzMYMLDgJAAAALmZmZGsZgxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Hovisloaf",
          ["guild"] = "mythic raid guild",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 253970,
          ["ilvl"] = 322,
          ["crit"] = 862,
          ["haste"] = 910,
          ["mastery"] = 1187,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmFmZmBDzYMzyMLmZGLsMzyYMzYBDDwYbbmBjZbAMBAAAYhZmZGsZYMmBAwMDMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Fenth",
          ["guild"] = "Waít for it",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 253551,
          ["ilvl"] = 325,
          ["crit"] = 936,
          ["haste"] = 913,
          ["mastery"] = 1180,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Cotti",
          ["guild"] = "Hatewatching",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 252474,
          ["ilvl"] = 328,
          ["crit"] = 947,
          ["haste"] = 958,
          ["mastery"] = 1418,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGjZWmZxMzYjlZWGjZGLYYAGbbzMYMbDgJAAAALmZmZGsZgxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Crexsen",
          ["guild"] = "ÆVUM",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 249084,
          ["ilvl"] = 325,
          ["crit"] = 919,
          ["haste"] = 869,
          ["mastery"] = 1114,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmlZmZmBDzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYhZmZGsZgxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Druinor",
          ["guild"] = "Equity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 248327,
          ["ilvl"] = 325,
          ["crit"] = 894,
          ["haste"] = 985,
          ["mastery"] = 1180,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYGjZWmZxMzYjlZWGjZGLYYAGbbzMYMbDgJAAAALMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Daddydog",
          ["guild"] = "The Fugitives",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 246392,
          ["ilvl"] = 323,
          ["crit"] = 1122,
          ["haste"] = 810,
          ["mastery"] = 980,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYwYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Dusterz",
          ["guild"] = "Nascent",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 246293,
          ["ilvl"] = 327,
          ["crit"] = 1177,
          ["haste"] = 830,
          ["mastery"] = 962,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmFzMzMAzYMzyMLmZGLsMzyYmZGLYYAGbbzMYMbDgJAAAALMzMzgNjhxAAwMDMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Shroomee",
          ["guild"] = "Northern Sky",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 245822,
          ["ilvl"] = 328,
          ["crit"] = 997,
          ["haste"] = 752,
          ["mastery"] = 1356,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Kitzuh",
          ["guild"] = "Mental Apocalypse",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 244581,
          ["ilvl"] = 326,
          ["crit"] = 913,
          ["haste"] = 922,
          ["mastery"] = 1209,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Shidann",
          ["guild"] = "Esprit",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 244489,
          ["ilvl"] = 325,
          ["crit"] = 824,
          ["haste"] = 846,
          ["mastery"] = 1209,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLgZMmZZmFzMjNWmZZMmZsghBYstNzgxsNAmAAAAswMzMD2MMGzAAYmBGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Kyodruid",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 344246,
          ["ilvl"] = 326,
          ["crit"] = 1055,
          ["haste"] = 743,
          ["mastery"] = 1139,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsNjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "半闲先生",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 343549,
          ["ilvl"] = 322,
          ["crit"] = 993,
          ["haste"] = 702,
          ["mastery"] = 1162,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsNjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Yasa",
          ["guild"] = "Schwingen des Phoenix",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 342519,
          ["ilvl"] = 325,
          ["crit"] = 1073,
          ["haste"] = 850,
          ["mastery"] = 1167,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGjZWmZzMzYhlZWGjZGbYYAGbbzMYMbDgJAAAALmZmZGsZgxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "龙舌兰咕娘",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 333950,
          ["ilvl"] = 325,
          ["crit"] = 938,
          ["haste"] = 736,
          ["mastery"] = 1332,
          ["vers"] = 209,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbZMmZgHwswMzMY8AzY2mZZsMjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsxMzMD2MmxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Hedwigjr",
          ["guild"] = "Advent",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 330634,
          ["ilvl"] = 324,
          ["crit"] = 926,
          ["haste"] = 1080,
          ["mastery"] = 975,
          ["vers"] = 176,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsNjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "雪花焉落時",
          ["guild"] = "Clown Return",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 329595,
          ["ilvl"] = 324,
          ["crit"] = 694,
          ["haste"] = 952,
          ["mastery"] = 1265,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmFzMzMAzY2mZZsNjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmBGDAzMAwA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Straíly",
          ["guild"] = "Save The Wife",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 329323,
          ["ilvl"] = 325,
          ["crit"] = 727,
          ["haste"] = 932,
          ["mastery"] = 1136,
          ["vers"] = 181,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsNjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Andorius",
          ["guild"] = "Reset",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 325409,
          ["ilvl"] = 325,
          ["crit"] = 1076,
          ["haste"] = 807,
          ["mastery"] = 1200,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGjZWmZzMzYhlZWGjZGbYYAGbbzMYMbDgJAAAALmZmZGsZgxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Zorkincore",
          ["guild"] = "Wrong Tactics Folks",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 323472,
          ["ilvl"] = 323,
          ["crit"] = 952,
          ["haste"] = 814,
          ["mastery"] = 1296,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYYMzyMbmZGLsMzyYMzYDDDwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "기한이익상실",
          ["guild"] = "고른햇살",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 322977,
          ["ilvl"] = 322,
          ["crit"] = 835,
          ["haste"] = 905,
          ["mastery"] = 1263,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsNjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Boltxb",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 340769,
          ["ilvl"] = 326,
          ["crit"] = 671,
          ["haste"] = 1099,
          ["mastery"] = 909,
          ["vers"] = 349,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmFzMzMAzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDMmBAwMDMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Matteosix",
          ["guild"] = "baited",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 336835,
          ["ilvl"] = 324,
          ["crit"] = 805,
          ["haste"] = 918,
          ["mastery"] = 1205,
          ["vers"] = 233,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYhZmZGsZMjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Tarisant",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 333068,
          ["ilvl"] = 328,
          ["crit"] = 990,
          ["haste"] = 913,
          ["mastery"] = 1371,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLmZGLsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Lerepam",
          ["guild"] = "Mate",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 332776,
          ["ilvl"] = 329,
          ["crit"] = 784,
          ["haste"] = 961,
          ["mastery"] = 1382,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmlZmZmBwYMzyMLmZGLsMzyYMzYBDDwYbbmBjZbAMBAAAYhZmZGsZMMmBAwMDMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Fenth",
          ["guild"] = "Waít for it",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 330627,
          ["ilvl"] = 325,
          ["crit"] = 936,
          ["haste"] = 913,
          ["mastery"] = 1180,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Kloakrotten",
          ["guild"] = "Revoke",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 328435,
          ["ilvl"] = 326,
          ["crit"] = 939,
          ["haste"] = 736,
          ["mastery"] = 1237,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZZAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Jabbadruid",
          ["guild"] = "Myth",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 326424,
          ["ilvl"] = 324,
          ["crit"] = 679,
          ["haste"] = 867,
          ["mastery"] = 1412,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhhZMmZZmFzMjNWmZZMmZsghBYstNzgxsNAmAAAAswMzMD2MMGzAAYmBGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Rotí",
          ["guild"] = "WICKED",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 325974,
          ["ilvl"] = 326,
          ["crit"] = 879,
          ["haste"] = 955,
          ["mastery"] = 1096,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYhZmZGsZMjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Cotti",
          ["guild"] = "Hatewatching",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 325346,
          ["ilvl"] = 328,
          ["crit"] = 947,
          ["haste"] = 958,
          ["mastery"] = 1277,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGjZWmZhZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDMmBAwMDWGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Zephrane",
          ["guild"] = "Ethical",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 324504,
          ["ilvl"] = 326,
          ["crit"] = 894,
          ["haste"] = 763,
          ["mastery"] = 1347,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmFzMzMAzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDMmBAwMDMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Porlix",
          ["guild"] = "guppy pond",
          ["boss"] = "Sszorak",
          ["amount"] = 219289,
          ["ilvl"] = 325,
          ["crit"] = 1005,
          ["haste"] = 720,
          ["mastery"] = 1371,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGMz2MmxMWmZZGzMGzshhBYAW2GLYamZZAAAAwmZmZmBbGYMDgZGAYA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Fenth",
          ["guild"] = "Waít for it",
          ["boss"] = "Sszorak",
          ["amount"] = 217345,
          ["ilvl"] = 325,
          ["crit"] = 936,
          ["haste"] = 913,
          ["mastery"] = 1180,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzgZ2mxMmxyMLzYmxYmNMMADwy2YBTzMLDAAAA2MzMzMYzwYMDgZGAYA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Sazuna",
          ["guild"] = "YEP",
          ["boss"] = "Sszorak",
          ["amount"] = 216927,
          ["ilvl"] = 327,
          ["crit"] = 1017,
          ["haste"] = 866,
          ["mastery"] = 1173,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbZMmZgxsYmZmBDzgZ2mxMmxyMLzYmxYmNMMADwy2YBTzMLDAAAA2Mz8AzMYzwYMDgZGAYA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Shidann",
          ["guild"] = "Esprit",
          ["boss"] = "Sszorak",
          ["amount"] = 215877,
          ["ilvl"] = 327,
          ["crit"] = 871,
          ["haste"] = 818,
          ["mastery"] = 1261,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbZMmZgHwsYmZmBDzwyMbzYGzYxsMjZGjZ2wwAMALbjFMNzsMAAAAYzMzMzgNDjxMAmZAgBA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Yasa",
          ["guild"] = "Schwingen des Phoenix",
          ["boss"] = "Sszorak",
          ["amount"] = 214778,
          ["ilvl"] = 327,
          ["crit"] = 1096,
          ["haste"] = 803,
          ["mastery"] = 1236,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGWmZbGzYGLmlZMzYMzGGGgBYZbsgpZmlBAAAAbmZmZGsZgxMAmZAgBA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Хексберд",
          ["guild"] = "Блэкбёрд",
          ["boss"] = "Sszorak",
          ["amount"] = 212156,
          ["ilvl"] = 328,
          ["crit"] = 801,
          ["haste"] = 765,
          ["mastery"] = 1355,
          ["vers"] = 127,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMYYGMz2MmxMWmZZGzMGzshhBYAW2GLYamZZAAAAwmZmZmBbGYMDgZGAYA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Canyonero",
          ["guild"] = "evicted",
          ["boss"] = "Sszorak",
          ["amount"] = 212139,
          ["ilvl"] = 327,
          ["crit"] = 839,
          ["haste"] = 631,
          ["mastery"] = 1463,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmtZmZmBYGMz2MmxMWmZZGzMGzshhBYAW2GbYamZZAAAAwGzMzMYzAjZAMzAADA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Kroghelf",
          ["guild"] = "TED",
          ["boss"] = "Sszorak",
          ["amount"] = 211965,
          ["ilvl"] = 325,
          ["crit"] = 978,
          ["haste"] = 644,
          ["mastery"] = 1298,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMaGjZGYMLzMzMDGGsMz2MmxMWMLzYmxYmNMMADwy2YBTzMLDAAAA2YmZmBbGDjZAMzAADA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Kocho",
          ["guild"] = "Revelations",
          ["boss"] = "Sszorak",
          ["amount"] = 211633,
          ["ilvl"] = 326,
          ["crit"] = 851,
          ["haste"] = 933,
          ["mastery"] = 1324,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMmZmBDzgZ2mxMmxyMLzYmxYmNMMADwy2YBTzMLDAAAA2MzMzMYzwYMDgZGAYA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Finalsai",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 211006,
          ["ilvl"] = 326,
          ["crit"] = 848,
          ["haste"] = 901,
          ["mastery"] = 1323,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMmZmZhhZYZmtZMjZsYWmxMjxMbYYAGgltxCmmZWGAAAAsxMzMD2MMGzAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Yasa",
          ["guild"] = "Schwingen des Phoenix",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 309699,
          ["ilvl"] = 328,
          ["crit"] = 984,
          ["haste"] = 946,
          ["mastery"] = 1213,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbZMmZgHwsYmZmZhhZMmZZmFzMjNWmZZMmZsghBYstNzgxsNAmAAAAswMzMD2MMGzAAYmBGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Cotti",
          ["guild"] = "Hatewatching",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 309484,
          ["ilvl"] = 328,
          ["crit"] = 947,
          ["haste"] = 1094,
          ["mastery"] = 1418,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhhZMLzsMzCzM2YZmlxYmxCGGgx22MDGz2AYCAAAwCzMzMYzwYMDAgZGYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Srbasile",
          ["guild"] = "Skill Issue",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 291641,
          ["ilvl"] = 326,
          ["crit"] = 860,
          ["haste"] = 953,
          ["mastery"] = 1252,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhhZMmZZmFzMjNWmZZMmZsghBYstNzgxsNAmAAAAswMzMD2MMGzAAYmBGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Recruitie",
          ["guild"] = "Shade",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 288595,
          ["ilvl"] = 326,
          ["crit"] = 989,
          ["haste"] = 860,
          ["mastery"] = 1288,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbZMmZgxswMzMLMMjxMLzsYmZsxyMLjxMjFMMAjttZGMmtBwEAAAgFzMPwMD2MMGzAAYmBGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Sazuna",
          ["guild"] = "YEP",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 284422,
          ["ilvl"] = 327,
          ["crit"] = 1017,
          ["haste"] = 866,
          ["mastery"] = 1032,
          ["vers"] = 114,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLMMjxMLzsYmZsxyMLjxMjFMMAjttZGMmtBwEAAAgFm5BmZwmhxYGAAzMwA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Кукульдру",
          ["guild"] = "Проксима",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 283533,
          ["ilvl"] = 327,
          ["crit"] = 993,
          ["haste"] = 924,
          ["mastery"] = 1199,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLgZMmZZmFzMjNWmZZMmZsghBYstNzgxsNAmAAAAswMzMD2MMGzAAYmBGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "梅茵菲娜",
          ["guild"] = "咏冻黎明12.0",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 283462,
          ["ilvl"] = 326,
          ["crit"] = 778,
          ["haste"] = 929,
          ["mastery"] = 1266,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMaGjZG4BMLmZmZWMYGjZWmZxMzYjlZWGjZGLYAwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Lerepam",
          ["guild"] = "Mate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 282896,
          ["ilvl"] = 329,
          ["crit"] = 784,
          ["haste"] = 961,
          ["mastery"] = 1241,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMaGjZGYMLmZmZWAzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYhZmZGsZYMmBAwMDMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Noctuss",
          ["guild"] = "velocity",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 282427,
          ["ilvl"] = 325,
          ["crit"] = 757,
          ["haste"] = 876,
          ["mastery"] = 1431,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLgZMmZZmFzMjNWmZZMmZsghBYstNzgxsNAmAAAAswMzMD2MMGzAAYmBGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Clecia",
          ["guild"] = "Incarnate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 282160,
          ["ilvl"] = 323,
          ["crit"] = 785,
          ["haste"] = 927,
          ["mastery"] = 1139,
          ["vers"] = 337,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLgZMmZZmFzMjNWmZZMmZsghBYstNzgxsNAmAAAAswMzMD2MMGzAAYmBGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "조드에겐귀여움뿐",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 232269,
          ["ilvl"] = 331,
          ["crit"] = 680,
          ["haste"] = 1118,
          ["mastery"] = 1095,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2oMbNjxMDwsMzMzMYYGjZWmZxMzYhlZWGjZGLYYAGbbzMYMbDgJAAAALMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Darilldruide",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 227651,
          ["ilvl"] = 326,
          ["crit"] = 1061,
          ["haste"] = 879,
          ["mastery"] = 950,
          ["vers"] = 148,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2oMbZMmZgHwsMzMzMYYGjZWmZxYGLsMzyYMzYBDDwYbZmBjZbAMBAAAYhZmZGsZYMmBAwMDWGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Lerepam",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 226391,
          ["ilvl"] = 329,
          ["crit"] = 784,
          ["haste"] = 961,
          ["mastery"] = 1241,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2oMbZMmZgHwsMzMzMYYGjZWmZxMzYhlZWGjZGLYYAGbbzMYMbDgJAAAALMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Oofkin",
          ["guild"] = "Sabotage",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 226089,
          ["ilvl"] = 327,
          ["crit"] = 978,
          ["haste"] = 914,
          ["mastery"] = 1239,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2oMbZMmZgHwsMzMzMYYGjZWmZxYGLsMzyYMmZBDDwYbZmBjZZAMBAAAYhZmZGsZYMmBAwMDWGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Seventhchord",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 225246,
          ["ilvl"] = 328,
          ["crit"] = 810,
          ["haste"] = 889,
          ["mastery"] = 1198,
          ["vers"] = 146,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2oMbZMmZgHwsMmZmBDzYMzyMLmZGLsMzyYMzYBDDwYbbmBjZZAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Whitehenning",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 223182,
          ["ilvl"] = 327,
          ["crit"] = 942,
          ["haste"] = 997,
          ["mastery"] = 1169,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2oMbNjxMDwsMzMzMYYGjZWmZxMzYhlZWGjZGLYYAGbbzMYMbDgJAAAALMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Clecia",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 223045,
          ["ilvl"] = 326,
          ["crit"] = 801,
          ["haste"] = 933,
          ["mastery"] = 1155,
          ["vers"] = 342,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2oMbZMmZgHwsYmZmBDzYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbAMBAAAYxMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Tarisant",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 218802,
          ["ilvl"] = 328,
          ["crit"] = 997,
          ["haste"] = 929,
          ["mastery"] = 1230,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2oMbNjxMDwsMzMzMYYYMzyMLGzYhlZWGjxMLYYAGbLzMYMbDgJAAAALmZmZGsZYMmBAwMDWGA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Iittala",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 215881,
          ["ilvl"] = 327,
          ["crit"] = 553,
          ["haste"] = 977,
          ["mastery"] = 1145,
          ["vers"] = 327,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsNzMzMYYGjZWmZxMzYhlZWGjZGLYYAGbbzMYMbDgJAAAALMzMzgNDjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Jabbadruid",
          ["guild"] = "Myth",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 215786,
          ["ilvl"] = 325,
          ["crit"] = 681,
          ["haste"] = 874,
          ["mastery"] = 1560,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2oMbNjxMDwswMzMYYGjZWmZxYGLsMzyYMzMLYYAGbLzMYMLDgJAAAALmZmZGsZMjxMAAmZgBA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Lerepam",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 338763,
          ["ilvl"] = 329,
          ["crit"] = 990,
          ["haste"] = 703,
          ["mastery"] = 1434,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbZMmZgxsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYA22GbYamZZAAAAwGzMzMYzAjZAMzAADA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Gorelul",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 329532,
          ["ilvl"] = 328,
          ["crit"] = 816,
          ["haste"] = 935,
          ["mastery"] = 1236,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYA22GbYamZZAAAAwmZmZmBbGYMDgZGAYA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "조드에겐귀여움뿐",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 310045,
          ["ilvl"] = 331,
          ["crit"] = 680,
          ["haste"] = 1330,
          ["mastery"] = 1095,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYA22GbYamZZAAAAwmZmZmBbGYMDgZGAYA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Arzenal",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 288502,
          ["ilvl"] = 328,
          ["crit"] = 874,
          ["haste"] = 819,
          ["mastery"] = 1557,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYY2mZZsMMjNzyMLjZmhNMMADw22YDTzMLDAAAA2MzMzMYzwYMDgZGAYA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "默斯肯",
          ["guild"] = "Team Spirit",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 434302,
          ["ilvl"] = 325,
          ["crit"] = 512,
          ["haste"] = 997,
          ["mastery"] = 1500,
          ["vers"] = 157,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmlZmZmhBzY2mZZsMjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsxMzMD2MwYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Porlix",
          ["guild"] = "guppy pond",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 393470,
          ["ilvl"] = 325,
          ["crit"] = 979,
          ["haste"] = 869,
          ["mastery"] = 1389,
          ["vers"] = 95,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMjZsZWmxYmZGbYYAGgttxCmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Lenfa",
          ["guild"] = "Wipe Fest",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 376987,
          ["ilvl"] = 321,
          ["crit"] = 783,
          ["haste"] = 942,
          ["mastery"] = 1119,
          ["vers"] = 301,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Broragra",
          ["guild"] = "Doki Doki Kawaii Club",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 369928,
          ["ilvl"] = 321,
          ["crit"] = 977,
          ["haste"] = 701,
          ["mastery"] = 1046,
          ["vers"] = 246,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMmZmBDDz2MLjlZMjNzyMGzMzYDDDwAstN2w0MzyAAAAgNzMzMD2MmxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Oouwoou",
          ["guild"] = "OG Konflikt",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 367436,
          ["ilvl"] = 322,
          ["crit"] = 767,
          ["haste"] = 790,
          ["mastery"] = 1341,
          ["vers"] = 188,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Zorkincore",
          ["guild"] = "Wrong Tactics Folks",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 365578,
          ["ilvl"] = 322,
          ["crit"] = 1079,
          ["haste"] = 698,
          ["mastery"] = 1315,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYGz2MLjlZMjNzyMGzMzYDDAGgttxGmmZWGAAAAsxMzMD22GGjBgZGAYA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Fenth",
          ["guild"] = "Waít for it",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 363056,
          ["ilvl"] = 317,
          ["crit"] = 954,
          ["haste"] = 922,
          ["mastery"] = 1108,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Klika",
          ["guild"] = "K L I K A",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 360014,
          ["ilvl"] = 324,
          ["crit"] = 920,
          ["haste"] = 889,
          ["mastery"] = 1348,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwswMzMYYGz2MLjlZMjNzyMGzMzYDDDwAstN2w0MzyAAAAgNzMzMD2MmxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Manguilon",
          ["guild"] = "Frenzied Apes",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 359034,
          ["ilvl"] = 323,
          ["crit"] = 839,
          ["haste"] = 642,
          ["mastery"] = 1225,
          ["vers"] = 289,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMmZmBDDz2MLjlZMjNzyMGzMzYDDDwAstN2w0MzyAAAAgNzMzMD2MmxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        },
        {
          ["name"] = "Spakle",
          ["guild"] = "The Meme Team",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 357468,
          ["ilvl"] = 320,
          ["crit"] = 904,
          ["haste"] = 769,
          ["mastery"] = 1165,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 311
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMjZsZWmxYmZGbYYAGgttxGmmZWGAAAAsZmZmZwmhxYAYmBAGA",
          ["hero"] = {
            ["name"] = "Keeper of the Grove",
            ["atlas"] = "talents-heroclass-druid-keeperofthegrove",
            ["icon"] = "inv_ability_keeperofthegrovedruid_dreamsurge_fiendly"
          }
        }
      }
    },
    {
      ["spec"] = "Feral",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Olofmaster",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217156,
          ["ilvl"] = 324,
          ["crit"] = 844,
          ["haste"] = 1073,
          ["mastery"] = 1306,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 249806,
              ["name"] = "Radiant Plume",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwYmZMmtl5BWGbzMzMzMDAAAAbBzGMmZUzYWGzMzYMjZAAAAAAMwAAAAAAMbzs0sMzyGYmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "호덕맨",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 209253,
          ["ilvl"] = 323,
          ["crit"] = 857,
          ["haste"] = 879,
          ["mastery"] = 1294,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwYmZMmtl5BWGbzMzMzMDAAAALBzGMmZUzYWYmZGjZeADAAAAAgBGAAAAAgZbmlmlZW2AzMALmZYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "喵喵猫猫喵喵",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 207993,
          ["ilvl"] = 325,
          ["crit"] = 831,
          ["haste"] = 1071,
          ["mastery"] = 1071,
          ["vers"] = 148,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMzGzMzMzY2WGLjtZmZmHYmBAAAglgZzwYmRNjZZMzMjxMmBAAAAAwADAAAAAwsNzSzyMLbgZeAgFzgBAwMDAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Noobegg",
          ["guild"] = "Primarch",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 206872,
          ["ilvl"] = 322,
          ["crit"] = 783,
          ["haste"] = 1111,
          ["mastery"] = 1869,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwYmZMmtl5BWGbzMzMzMDAAAALBzGMmZUzYWGzMzYMDDAAAAAgBGAAAAAgZbmlmlZW2gZmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Kengiee",
          ["guild"] = "Arcane Energies",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 206811,
          ["ilvl"] = 322,
          ["crit"] = 652,
          ["haste"] = 886,
          ["mastery"] = 1181,
          ["vers"] = 368,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwYmZMmtl5BWGbzMzMzMDAAAALBzmhHwMjaGzyYmZGjZYAAAAAAMwAAAAAAMbzs0sMzyGMzMALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "데리바사삭",
          ["guild"] = "뇌파밍",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 204038,
          ["ilvl"] = 323,
          ["crit"] = 1108,
          ["haste"] = 741,
          ["mastery"] = 1027,
          ["vers"] = 184,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwYmZMmtl5BWGbzMzMzMDAAAAbBzGMmZUzYWYmZGjZMDAAAAAgBGAAAAAgZbmlmlZW2gZmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Jackmerrius",
          ["guild"] = "Utter Chaos",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 203201,
          ["ilvl"] = 324,
          ["crit"] = 917,
          ["haste"] = 945,
          ["mastery"] = 1231,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2MMmZUzYWGzMzYMzDMDAAAAAAwAAAAAAMbzs0sNzyGYmHAYZzgBAwMDAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Isuck",
          ["guild"] = "Scallywags",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 202643,
          ["ilvl"] = 323,
          ["crit"] = 688,
          ["haste"] = 1090,
          ["mastery"] = 1154,
          ["vers"] = 975,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGzCzMzYMzAAAAAAgBGAAAAAgZbmlmtZW2AzMALmZYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "魍魉叔叔丶",
          ["guild"] = "一枝春易别-丽丽",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 200256,
          ["ilvl"] = 322,
          ["crit"] = 611,
          ["haste"] = 1239,
          ["mastery"] = 1042,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ8AmZmZMmtlxyYbmZm5BmZAAAAYLYYYMzomxsMmZmxYGGAAAAAADMAAAAAAz2MbNLzssBzMDwiZwAAYmBAD",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Neks",
          ["guild"] = "Checkmate",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 200127,
          ["ilvl"] = 324,
          ["crit"] = 1021,
          ["haste"] = 865,
          ["mastery"] = 1131,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMDGzMjxstMPwyYbmZGzMDAAAALBzmhxMjaGzyYmZGjZMDAAAAAgBGAAAAAgZbmtmtZW2Az8AALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Olofmaster",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 214361,
          ["ilvl"] = 324,
          ["crit"] = 844,
          ["haste"] = 1075,
          ["mastery"] = 1307,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 249806,
              ["name"] = "Radiant Plume",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMzMjxstMPwyYbmZGzMDAAAAbBDDjZG1MmlxMzMGzYGAAAAAADMAAAAAAz2MLNLzssBmZAWMDGAAzMAYA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Cosini",
          ["guild"] = "Bound To Fail",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 201942,
          ["ilvl"] = 326,
          ["crit"] = 1044,
          ["haste"] = 664,
          ["mastery"] = 1332,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMzMjxstMPwyYbmZGzMDAAAALBzGMmZUzYWYmZGjZegZAAAAAAMwAAAAAAMbzs0sMzyGYmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Aleasamna",
          ["guild"] = "Welcome",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 201792,
          ["ilvl"] = 325,
          ["crit"] = 826,
          ["haste"] = 1018,
          ["mastery"] = 1052,
          ["vers"] = 217,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMzMjxstMPwyYbmZGzMDAAAALBDDjZG1MmFmZmZZMjZAAAAAAMwAAAAAAMbzs0sMzyGYmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Guiltyas",
          ["guild"] = "Pure",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 200769,
          ["ilvl"] = 325,
          ["crit"] = 965,
          ["haste"] = 965,
          ["mastery"] = 1079,
          ["vers"] = 176,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMzMjxstMPwyYbmZGzMDAAAALBDDjZG1MmFmZmZZMjZAAAAAAMwAAAAAAMbzs0sMzyGYmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "可以啊我的弟",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 199563,
          ["ilvl"] = 323,
          ["crit"] = 758,
          ["haste"] = 813,
          ["mastery"] = 1347,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 328
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2YmZmxY2WGLjtZmZMzMAAAAsEMMMmZUzYWGzMzYMDDAAAAAgBGAAAAAgZbmlmlZW2gZmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Sorgenqt",
          ["guild"] = "The Reckless",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 195346,
          ["ilvl"] = 324,
          ["crit"] = 962,
          ["haste"] = 1142,
          ["mastery"] = 1574,
          ["vers"] = 227,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMDGzMjxstMPwyYbmZGzMDAAAALBzGMmZUzYWGzMzYMjBAAAAAgBGAAAAAgZbmlmlZW2gZmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Milpsps",
          ["guild"] = "Drama",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 194542,
          ["ilvl"] = 325,
          ["crit"] = 802,
          ["haste"] = 816,
          ["mastery"] = 1084,
          ["vers"] = 366,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMzMjxstMPwyYbmZGzMDAAAAbBzGMmZUzYWMzMzYMjBAAAAAgBGAAAAAgZbmlmlZW2gZmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Kaladiel",
          ["guild"] = "Memento Morí",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 193061,
          ["ilvl"] = 325,
          ["crit"] = 1056,
          ["haste"] = 967,
          ["mastery"] = 1033,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMzMjxstMPwyYbmZGzMDAAAAbBzGMmZUzYWYmZGjZMDAAAAAgBGAAAAAgZbmlmlZW2gZmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Chomping",
          ["guild"] = "MythicDungeonFools",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 192666,
          ["ilvl"] = 324,
          ["crit"] = 963,
          ["haste"] = 840,
          ["mastery"] = 1162,
          ["vers"] = 153,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMzMjxstMPwyYbmZGzMDAAAALBDDjZG1MmFmZmZZMjZAAAAAAMwAAAAAAMbzs0sMzyGYmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Bigbloom",
          ["guild"] = "Envelop",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 190893,
          ["ilvl"] = 318,
          ["crit"] = 528,
          ["haste"] = 940,
          ["mastery"] = 1247,
          ["vers"] = 120,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMzMjxstMPwyYbmZGzMDAAAAbBzGMmZUzYWYmZGjZMDAAAAAgBGAAAAAgZbmlmlZW2gZmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Bigmeow",
          ["guild"] = "Quasar",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 305877,
          ["ilvl"] = 323,
          ["crit"] = 1067,
          ["haste"] = 949,
          ["mastery"] = 1047,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2MzMzMzY2wyMLzYm5BmZAAAAYJY2gxMjaGzCzMzYMjZAAAAAAMwAAAAAAMbzs0sMzyGMzMALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Acés",
          ["guild"] = "Wizards on the Block",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 301542,
          ["ilvl"] = 321,
          ["crit"] = 661,
          ["haste"] = 1347,
          ["mastery"] = 802,
          ["vers"] = 231,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2MzMzMGzGWmZZmZm5BmZAAAAYJY2gxMjaGzyMzMzYMjBAAAAAgBGAAAAAgZZmlmlZW2AzMALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Noobegg",
          ["guild"] = "Primarch",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 299882,
          ["ilvl"] = 326,
          ["crit"] = 769,
          ["haste"] = 1210,
          ["mastery"] = 946,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2MzMzMzY2wyMLzYm5BmZAAAAYJY2gxMjaGzyYmZGjZYAAAAAAMwAAAAAAMbzs0sMzyGMzMALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Meowzah",
          ["guild"] = "rotten apples",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 294673,
          ["ilvl"] = 326,
          ["crit"] = 1081,
          ["haste"] = 883,
          ["mastery"] = 955,
          ["vers"] = 212,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 250259,
              ["name"] = "Sapling of the Dawnroot",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2MzMzMzY2wyMLzYm5BmZAAAAYLY2M8AmZUzYWGzMzsMmxMAAAAAAADAAAAAwsNzWzyMLbwMzAswgBAwMDAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Scaricat",
          ["guild"] = "LSXD",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 293116,
          ["ilvl"] = 325,
          ["crit"] = 681,
          ["haste"] = 1242,
          ["mastery"] = 1063,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2MzMzMGzGWmZZmZm5BmZAAAAYJY2MMmZUzYWMzMzYMDDAAAAAgBGAAAAAgZbmlmlZW2AzMALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Vividia",
          ["guild"] = "Beyond Harmless",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 291644,
          ["ilvl"] = 323,
          ["crit"] = 580,
          ["haste"] = 889,
          ["mastery"] = 1446,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2MzMzMzY2wyMLzYm5BmZAAAAYLY2gxMjaGzyMzMzYMjZAAAAAAMwAAAAAAMLzs0sMzyGYmBYhBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "卡西法尔丶",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 291381,
          ["ilvl"] = 323,
          ["crit"] = 835,
          ["haste"] = 958,
          ["mastery"] = 1183,
          ["vers"] = 208,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMzmZmZmZGzGWmZZmZm5BmZAAAAYLY2MMmZUzYWGzMzYMjZAAAAAAMwAAAAAAMbzs0sMzyGYmHAYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Isuck",
          ["guild"] = "Scallywags",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 287548,
          ["ilvl"] = 324,
          ["crit"] = 854,
          ["haste"] = 929,
          ["mastery"] = 1154,
          ["vers"] = 975,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2MzMzMzY2MWGbzYm5BmZAAAAYJY2MMmZUzYWYmZGjZGAAAAAAMwAAAAAAMbzs0sMzyGYmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Kengiee",
          ["guild"] = "Arcane Energies",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 286333,
          ["ilvl"] = 322,
          ["crit"] = 734,
          ["haste"] = 790,
          ["mastery"] = 1165,
          ["vers"] = 368,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2MzMzMGzGWmZZmZm5BmZAAAAYJY2M8AmZUzYWGzMzYMDDAAAAAgBGAAAAAgZbmlmlZW2gZmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 286247,
          ["ilvl"] = 325,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Aleasamna",
          ["guild"] = "Welcome",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 266016,
          ["ilvl"] = 326,
          ["crit"] = 843,
          ["haste"] = 1027,
          ["mastery"] = 1078,
          ["vers"] = 223,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZWYmZmxY2WmBbzMzYmZAAAAYJYYYMzomxsYmZmxYGzAAAAAAYgBAAAAAY2mZpZZmlNwMDwiZwAAYmBAD",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Nymocel",
          ["guild"] = "Reset",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 252746,
          ["ilvl"] = 321,
          ["crit"] = 732,
          ["haste"] = 735,
          ["mastery"] = 1324,
          ["vers"] = 308,
          ["trinkets"] = {
            {
              ["id"] = 193757,
              ["name"] = "Ruby Whelp Shell",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZWYmZmxY2WmBbzMzYmZAAAAYJY2MMmZUzYWmZmZGjZMDAAAAAAwAAAAAAMbzs0sMzyGYmHAYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "动容",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 245535,
          ["ilvl"] = 323,
          ["crit"] = 804,
          ["haste"] = 1106,
          ["mastery"] = 1239,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2YmZmxY2WGLjtZmZMzMAAAAsEMbwYmRNjZZMzMjxMmBAAAAAwADAAAAAwsNzSzyMLbgZGgFzgBAwMDAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Cantrelle",
          ["guild"] = "LoF",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 243787,
          ["ilvl"] = 322,
          ["crit"] = 644,
          ["haste"] = 787,
          ["mastery"] = 1281,
          ["vers"] = 265,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 159617,
              ["name"] = "Lustrous Golden Plumage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMGz2yYZsNjZmHYmBAAAglgZzwYmRNjZZmZmZMm5BGAAAAAAADAAAAAwsNzSzyMLbgZeAgFzgBAwMDAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "一般不吃人",
          ["guild"] = "爱魔兽爱生活(MagicTavern)",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 241506,
          ["ilvl"] = 323,
          ["crit"] = 847,
          ["haste"] = 962,
          ["mastery"] = 1218,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2YmZmxY2WGmZZmZGzMDAAAALBzmhxMjaGzyYmZGjZMDAAAAAgBGAAAAAgZbmlmlZW2Az8AALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Baumgartner",
          ["guild"] = "Muisted",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 241465,
          ["ilvl"] = 325,
          ["crit"] = 955,
          ["haste"] = 913,
          ["mastery"] = 1039,
          ["vers"] = 244,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMmZ2MWmZbGzMmZAAAAYJY2M8AmZUzYWMzMzYMjZAAAAAAMwAAAAAAMbzs0sMzyGYmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Zzet",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 241382,
          ["ilvl"] = 323,
          ["crit"] = 893,
          ["haste"] = 879,
          ["mastery"] = 1238,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2YmZmxY2WGLjtZmZMzMAAAAsEMbGeAzMqZMLjZmZMmxAAAAAAwADAAAAAwsNzSzyMLbwMzAswMMAAmZAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "魍魉叔叔丶",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 239923,
          ["ilvl"] = 324,
          ["crit"] = 753,
          ["haste"] = 1126,
          ["mastery"] = 1083,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZWYmZmxY2WmBbzMzYmZAAAAYLYYYMzomxsMmZmxYGzAAAAAAYgBAAAAAY2mZpZZmlNwMDwiZwAAYmBAD",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Guiltyas",
          ["guild"] = "Pure",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 239210,
          ["ilvl"] = 321,
          ["crit"] = 889,
          ["haste"] = 879,
          ["mastery"] = 1114,
          ["vers"] = 232,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMmZ2WGLjtZMzYmBAAAgtgZDGzMqZMLjZmZMmZMAAAAAAADAAAAAwsNzSzyMbbgZGgFzgBAwMDAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Almo",
          ["guild"] = "Theoretical",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 235504,
          ["ilvl"] = 326,
          ["crit"] = 840,
          ["haste"] = 855,
          ["mastery"] = 1275,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZWYmZmxY2WmBbzMzYmZAAAAYJYYYMzomxsMmZmxYmHwAAAAAAYgBAAAAAY2mZpZZmlNwMDwiZwAAYmBAD",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "一般不吃人",
          ["guild"] = "爱魔兽爱生活(MagicTavern)",
          ["boss"] = "Sszorak",
          ["amount"] = 225503,
          ["ilvl"] = 322,
          ["crit"] = 839,
          ["haste"] = 800,
          ["mastery"] = 1237,
          ["vers"] = 232,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwgZ8AGzMzMmtFPwyYbmZGzMDAAAALBzmhxMjaGzyYmZGjZMDAAAAAgBGAAAAAgZbmlmlZW2Az8AALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Aleasamna",
          ["guild"] = "Welcome",
          ["boss"] = "Sszorak",
          ["amount"] = 224081,
          ["ilvl"] = 326,
          ["crit"] = 843,
          ["haste"] = 1027,
          ["mastery"] = 1078,
          ["vers"] = 223,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCmNYMzomxsMzMzMGzYGAAAAAADMAAAAamlZZmZGAwCYmBYhBDAAgZ2wA",
          ["hero"] = {
            ["name"] = "Druid of the Claw",
            ["atlas"] = "talents-heroclass-druid-druidoftheclaw",
            ["icon"] = "inv_ability_druidoftheclawdruid_ravage"
          }
        },
        {
          ["name"] = "Guiltyas",
          ["guild"] = "Pure",
          ["boss"] = "Sszorak",
          ["amount"] = 220842,
          ["ilvl"] = 325,
          ["crit"] = 965,
          ["haste"] = 965,
          ["mastery"] = 1079,
          ["vers"] = 176,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCmNYMzomxsMmZmxYGDAAAAAADMAAAAamlZZmZGAwCMzMALmBDAAgZ2wA",
          ["hero"] = {
            ["name"] = "Druid of the Claw",
            ["atlas"] = "talents-heroclass-druid-druidoftheclaw",
            ["icon"] = "inv_ability_druidoftheclawdruid_ravage"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 220425,
          ["ilvl"] = 322,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Sorgenqt",
          ["guild"] = "The Reckless",
          ["boss"] = "Sszorak",
          ["amount"] = 218802,
          ["ilvl"] = 324,
          ["crit"] = 965,
          ["haste"] = 1145,
          ["mastery"] = 1577,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMDGzMjxstMPwyYbmZGzMDAAAALBzGMmZUzYWGzMzYMjBAAAAAgBGAAAAAgZbmlmlZW2gZmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Anímal",
          ["guild"] = "Easy Katka",
          ["boss"] = "Sszorak",
          ["amount"] = 215920,
          ["ilvl"] = 324,
          ["crit"] = 827,
          ["haste"] = 1060,
          ["mastery"] = 929,
          ["vers"] = 316,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwgZMGzMzMmtFWGbzMzYmZAAAAYJY2gxMjaGz2MzMzYMjBAAAAAgBGAAAAAgZbmlmlZW2AzMALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Acés",
          ["guild"] = "Wizards on the Block",
          ["boss"] = "Sszorak",
          ["amount"] = 208563,
          ["ilvl"] = 326,
          ["crit"] = 951,
          ["haste"] = 963,
          ["mastery"] = 1012,
          ["vers"] = 275,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwgZ8AGzMzMmtFPwyYbmZGzMDAAAALBzmhxMjaGzyYmZGjZMAAAAAAMwAAAAAAMbzs0sMzyGYmHAYxMDDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Nintendogz",
          ["guild"] = "Atrocious",
          ["boss"] = "Sszorak",
          ["amount"] = 207341,
          ["ilvl"] = 325,
          ["crit"] = 978,
          ["haste"] = 1006,
          ["mastery"] = 1033,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMDGzMjxstMPwyYbmZGzMDAAAALBzmhxMjaGz2YmZGjZMAAAAAAMwAAAAAAMbzs0sNzyGYmBYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Teodruid",
          ["guild"] = "Dont Heal Phase One",
          ["boss"] = "Sszorak",
          ["amount"] = 206990,
          ["ilvl"] = 326,
          ["crit"] = 749,
          ["haste"] = 933,
          ["mastery"] = 1135,
          ["vers"] = 152,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCGGGzMqZMLmZmZMmxMAAAAAAGYAAAA0MLzyMzMAgFYmZAWYwAAAYmNMA",
          ["hero"] = {
            ["name"] = "Druid of the Claw",
            ["atlas"] = "talents-heroclass-druid-druidoftheclaw",
            ["icon"] = "inv_ability_druidoftheclawdruid_ravage"
          }
        },
        {
          ["name"] = "Rior",
          ["guild"] = "ohno",
          ["boss"] = "Sszorak",
          ["amount"] = 206496,
          ["ilvl"] = 326,
          ["crit"] = 901,
          ["haste"] = 733,
          ["mastery"] = 1028,
          ["vers"] = 371,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCGGGzMqZMLmZmZMmxMAAAAAAGYAAAA0MLzyMzMAgFYmZAWYwAAAYmNMA",
          ["hero"] = {
            ["name"] = "Druid of the Claw",
            ["atlas"] = "talents-heroclass-druid-druidoftheclaw",
            ["icon"] = "inv_ability_druidoftheclawdruid_ravage"
          }
        },
        {
          ["name"] = "Guiltyas",
          ["guild"] = "Pure",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 258791,
          ["ilvl"] = 321,
          ["crit"] = 1025,
          ["haste"] = 879,
          ["mastery"] = 913,
          ["vers"] = 297,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMmZ2WGmZZGzMmZAAAAYLYYYMzomxsMmZmZZMjBAAAAAgBGAAAAAgZbmlmlZ22AzMALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Когтезавр",
          ["guild"] = "Дворфийский Ковен",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 237825,
          ["ilvl"] = 322,
          ["crit"] = 1019,
          ["haste"] = 1016,
          ["mastery"] = 1017,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmZ2MzMzMGzmxyYbmZm5BmZAAAAYJY2MMmZUzYWGzMzYMzDMAAAAAAMwAAAAAAMbzs0sMzyGYmBYhBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Vividia",
          ["guild"] = "Beyond Harmless",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 230812,
          ["ilvl"] = 320,
          ["crit"] = 665,
          ["haste"] = 889,
          ["mastery"] = 1301,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 159617,
              ["name"] = "Lustrous Golden Plumage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMzmZmZmZGzmxyYbmZm5BmZAAAAYLY2MMmZUzY2GzMzYMzDMAAAAAAMwAAAAAAMbzs0sMzyGYmBYhBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Vidiv",
          ["guild"] = "Divided",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 228554,
          ["ilvl"] = 320,
          ["crit"] = 594,
          ["haste"] = 963,
          ["mastery"] = 1163,
          ["vers"] = 340,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2MjZmxY2MWGbzMzMzMDAAAALBzGMmZUzYWYmZGjZegZAAAAAAMwAAAAAAMbzs0sMzyGYmBYhZYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Basedelf",
          ["guild"] = "Lags to Riches",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 227699,
          ["ilvl"] = 321,
          ["crit"] = 431,
          ["haste"] = 1181,
          ["mastery"] = 1260,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmZ2MzMzMGzmxyYbmZm5BmZAAAAYJY2MMmZUzYWGzMzYMzDMAAAAAAMwAAAAAAMbzs0sMzyGYmBYhBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Scaricat",
          ["guild"] = "LSXD",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 225734,
          ["ilvl"] = 325,
          ["crit"] = 681,
          ["haste"] = 1239,
          ["mastery"] = 1063,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZ2YmZmxY2WGLjtZmZmHYmBAAAglgZzwYmRNjZhZmZMmxMAAAAAAGYAAAAAAmtZWaWmZZDMzAsYGMAAmZAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Gloomlight",
          ["guild"] = "R A D",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 224514,
          ["ilvl"] = 321,
          ["crit"] = 977,
          ["haste"] = 907,
          ["mastery"] = 802,
          ["vers"] = 373,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 265657,
              ["name"] = "Fiber of Living Agony",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMzmZmZmZGzmxyYbmZm5BmZAAAAYJY2MMmZUzY2GzMzYMzDAAAAAAgBGAAAAAgZbmlmlZW2gZmBYhBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Nymocel",
          ["guild"] = "Reset",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 223960,
          ["ilvl"] = 319,
          ["crit"] = 720,
          ["haste"] = 744,
          ["mastery"] = 1168,
          ["vers"] = 428,
          ["trinkets"] = {
            {
              ["id"] = 193757,
              ["name"] = "Ruby Whelp Shell",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMzmZmZmZGzmxyYbmZm5BmZAAAAYJY2MMmZUzYWmZmZGjZMDAAAAAAwAAAAAAMbzs0sMzyGYmHAYxMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Turbogronil",
          ["guild"] = "Wisp",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 222578,
          ["ilvl"] = 326,
          ["crit"] = 912,
          ["haste"] = 810,
          ["mastery"] = 1176,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGzCzMzYMjZAAAAAAMwAAAAAAMbzs0sNzyGMzMALmBDAgZGAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Faauve",
          ["guild"] = "Calm Before the Storm",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 221545,
          ["ilvl"] = 322,
          ["crit"] = 824,
          ["haste"] = 832,
          ["mastery"] = 1230,
          ["vers"] = 266,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmZ2MzMzMGzmxyYbmZm5BmZAAAAYJY2gxMjaGzyYmZmlxMGAAAAAAGYAAAAAAmtZWaWmZZDMzAsYGMAAmZAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Kengiee",
          ["guild"] = "Arcane Energies",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 221460,
          ["ilvl"] = 322,
          ["crit"] = 734,
          ["haste"] = 790,
          ["mastery"] = 1165,
          ["vers"] = 368,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMzmZmZmZGzmxyYbmZm5BmZAAAAYJY2MGmZUzYWMzMzYMjZAAAAAAMwAAAAAAMbzs0sMzyGMzMALMYAAMzAgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        }
      }
    },
    {
      ["spec"] = "Guardian",
      ["role"] = "tank",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "박제",
          ["guild"] = "영구정지",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 123590,
          ["ilvl"] = 321,
          ["crit"] = 748,
          ["haste"] = 1096,
          ["mastery"] = 699,
          ["vers"] = 363,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbGGNRzMzyMzMzYMDDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYALW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Nyannix",
          ["guild"] = "Curse of Years",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 118742,
          ["ilvl"] = 324,
          ["crit"] = 673,
          ["haste"] = 1327,
          ["mastery"] = 597,
          ["vers"] = 618,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbmxoJamZWMzMzsMmhBAAAAAMjtZALbzMYMLDgJAAAgNMzDMgFDMgNLbDwMDgB",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gwfd",
          ["guild"] = "Review the Data",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 116046,
          ["ilvl"] = 326,
          ["crit"] = 881,
          ["haste"] = 1082,
          ["mastery"] = 526,
          ["vers"] = 682,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsZGjZ2MLGMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYCAAAYDzYALmBDYxy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "은근히귀여워놀간",
          ["guild"] = "Step in",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 115605,
          ["ilvl"] = 321,
          ["crit"] = 784,
          ["haste"] = 1201,
          ["mastery"] = 818,
          ["vers"] = 312,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMjRT0MzsMzMzMGzYGAAAAAwM2mBssNzgxsNAmAAAA2wMPAwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Barnagoly",
          ["guild"] = "Invalid Target",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 115370,
          ["ilvl"] = 323,
          ["crit"] = 924,
          ["haste"] = 1259,
          ["mastery"] = 423,
          ["vers"] = 524,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGLzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "天引",
          ["guild"] = "晨曦启明1",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 115194,
          ["ilvl"] = 320,
          ["crit"] = 846,
          ["haste"] = 1150,
          ["mastery"] = 574,
          ["vers"] = 550,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMzYMzmZxgxyAzGMaimZmlZmZmxYGGAAAAAwMz2MgltZGMmtBwEAAAwGmZAWMDGwmltBYmBwA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Érutane",
          ["guild"] = "SaveCowEatPanda",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 115106,
          ["ilvl"] = 326,
          ["crit"] = 821,
          ["haste"] = 1330,
          ["mastery"] = 492,
          ["vers"] = 549,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMzYMzmZxgxyA2YMaimZmlZmZmxYGGAAAAAwMz2MgltZGMmtBwEAAAwGm5BGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Daemu",
          ["guild"] = "Cherry Dogs",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 114733,
          ["ilvl"] = 323,
          ["crit"] = 685,
          ["haste"] = 1614,
          ["mastery"] = 348,
          ["vers"] = 450,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMzYMzmZxgxyAzmhRT0MzsMzMzMGzYAAAAAAmx2MgltZGMmlBwEAAAwGmZAWMDGwmltBYmBwA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "外星伴侣",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 113786,
          ["ilvl"] = 321,
          ["crit"] = 828,
          ["haste"] = 1218,
          ["mastery"] = 711,
          ["vers"] = 222,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZYAAAAAAzMbzAW2mZwY2GATAAAAbYmBYxMYALW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Vanela",
          ["guild"] = "Nightshade",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 113726,
          ["ilvl"] = 323,
          ["crit"] = 812,
          ["haste"] = 1283,
          ["mastery"] = 476,
          ["vers"] = 472,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDYjxoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmHYALmBDYxy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gnomerender",
          ["guild"] = "Opposite",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 126217,
          ["ilvl"] = 326,
          ["crit"] = 1081,
          ["haste"] = 1292,
          ["mastery"] = 312,
          ["vers"] = 600,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLbDMbwoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "오렌지파프리카",
          ["guild"] = "Mate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 125932,
          ["ilvl"] = 324,
          ["crit"] = 739,
          ["haste"] = 1332,
          ["mastery"] = 524,
          ["vers"] = 443,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZYAAAAAAzMbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Denerocxd",
          ["guild"] = "The Next Step",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 118151,
          ["ilvl"] = 312,
          ["crit"] = 837,
          ["haste"] = 1403,
          ["mastery"] = 284,
          ["vers"] = 266,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmtBwEAAAwGmZAWMDGwiltBYmBwA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gwfd",
          ["guild"] = "Review the Data",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 117397,
          ["ilvl"] = 326,
          ["crit"] = 881,
          ["haste"] = 1082,
          ["mastery"] = 526,
          ["vers"] = 682,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYCAAAYDzYALmBDYxy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Ahrilia",
          ["guild"] = "CV",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 117372,
          ["ilvl"] = 324,
          ["crit"] = 623,
          ["haste"] = 1543,
          ["mastery"] = 456,
          ["vers"] = 561,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Ludicator",
          ["guild"] = "Everybody Gets One",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 113678,
          ["ilvl"] = 325,
          ["crit"] = 1059,
          ["haste"] = 1246,
          ["mastery"] = 305,
          ["vers"] = 647,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMjRT0MzsMzMzMGzwAAAAAAmZ2mBssNzgxsNAmAAAA2wMGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Érutane",
          ["guild"] = "SaveCowEatPanda",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 113318,
          ["ilvl"] = 326,
          ["crit"] = 986,
          ["haste"] = 1333,
          ["mastery"] = 492,
          ["vers"] = 385,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2mZxgxyA2YMaimZmlZmZmxYGGAAAAAwMz2MgltZGMmtBwEAAAwGm5BGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "박제",
          ["guild"] = "영구정지",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 112795,
          ["ilvl"] = 319,
          ["crit"] = 655,
          ["haste"] = 1117,
          ["mastery"] = 735,
          ["vers"] = 454,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZYAAAAAAzMbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Yamaka",
          ["guild"] = "Paradox",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 111325,
          ["ilvl"] = 323,
          ["crit"] = 807,
          ["haste"] = 1300,
          ["mastery"] = 478,
          ["vers"] = 377,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDYzwoJamZWmZmZGjZYAAAAAAzYbGw22MDGz2AYCAAAYDzMALmZYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Jumbobear",
          ["guild"] = "comma",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 110692,
          ["ilvl"] = 325,
          ["crit"] = 764,
          ["haste"] = 1319,
          ["mastery"] = 405,
          ["vers"] = 688,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZ2mZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYALW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Érutane",
          ["guild"] = "SaveCowEatPanda",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 175341,
          ["ilvl"] = 326,
          ["crit"] = 821,
          ["haste"] = 1333,
          ["mastery"] = 492,
          ["vers"] = 550,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2mZxgxyA2YMaimZmlZmZmxYGGAAAAAwMz2MgltZGMmtBwEAAAwGm5BGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Budgetarla",
          ["guild"] = "Bedtime Bandits",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 173944,
          ["ilvl"] = 323,
          ["crit"] = 1064,
          ["haste"] = 1377,
          ["mastery"] = 273,
          ["vers"] = 413,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2mZxgZZZgZzwoJamZWmZmZGjZMDAAAAAYGbzAW2mZwYWGATAAAAbYmHAYxYYAbWMAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Ludicator",
          ["guild"] = "Everybody Gets One",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 172727,
          ["ilvl"] = 325,
          ["crit"] = 1059,
          ["haste"] = 1246,
          ["mastery"] = 305,
          ["vers"] = 647,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMjRT0MzsMzMzMGzwAAAAAAmZ2mBssNzgxsNAmAAAA2wMGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Denerocxd",
          ["guild"] = "The Next Step",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 167376,
          ["ilvl"] = 319,
          ["crit"] = 862,
          ["haste"] = 1437,
          ["mastery"] = 201,
          ["vers"] = 376,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMzYMzmZxgxyAzGjRT0MzsMzMzMGzYGAAAAAwM2mBssNzgxsNAmAAAA2wMGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Sol",
          ["guild"] = "Nurfed",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 166705,
          ["ilvl"] = 324,
          ["crit"] = 805,
          ["haste"] = 1215,
          ["mastery"] = 449,
          ["vers"] = 715,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWMzMzYMjZAAAAAAzMbzA22mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Zenimal",
          ["guild"] = "Unbalanced",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 166341,
          ["ilvl"] = 324,
          ["crit"] = 824,
          ["haste"] = 1034,
          ["mastery"] = 760,
          ["vers"] = 486,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2mZxgZZZghhRT0MzsMzMzMGzYGAAAAAwM2mBstNzgxsNAmAAAA2wMDwiZwAWsYAmZAMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Daemu",
          ["guild"] = "Cherry Dogs",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 165131,
          ["ilvl"] = 325,
          ["crit"] = 803,
          ["haste"] = 1419,
          ["mastery"] = 317,
          ["vers"] = 600,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMzYMzmZxgxyAzmhRT0MzsMzMzMGzYAAAAAAmx2MgltZGMmlBwEAAAwGmZAWMDGwmltBYmBwA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Tombears",
          ["guild"] = "Iris",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 163660,
          ["ilvl"] = 325,
          ["crit"] = 988,
          ["haste"] = 1159,
          ["mastery"] = 532,
          ["vers"] = 549,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYmZbGwy2MDGz2AYCAAAYDzMALGYALW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gwfd",
          ["guild"] = "Review the Data",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 162354,
          ["ilvl"] = 326,
          ["crit"] = 881,
          ["haste"] = 1082,
          ["mastery"] = 526,
          ["vers"] = 682,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYCAAAYDzYALmBDYxy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gnomerender",
          ["guild"] = "Opposite",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 160442,
          ["ilvl"] = 319,
          ["crit"] = 915,
          ["haste"] = 984,
          ["mastery"] = 424,
          ["vers"] = 809,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMbLDYzwoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Ahrilia",
          ["guild"] = "CV",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 158030,
          ["ilvl"] = 324,
          ["crit"] = 623,
          ["haste"] = 1543,
          ["mastery"] = 456,
          ["vers"] = 561,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gwfd",
          ["guild"] = "Review the Data",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 148266,
          ["ilvl"] = 326,
          ["crit"] = 881,
          ["haste"] = 1082,
          ["mastery"] = 526,
          ["vers"] = 682,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYCAAAYDzYALmBDYxy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Ludicator",
          ["guild"] = "Everybody Gets One",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 146284,
          ["ilvl"] = 325,
          ["crit"] = 1060,
          ["haste"] = 1246,
          ["mastery"] = 305,
          ["vers"] = 648,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMjRT0MzsMzMzMGzwAAAAAAmZ2mBssNzgxsNAmAAAA2wMGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Érutane",
          ["guild"] = "SaveCowEatPanda",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 144810,
          ["ilvl"] = 326,
          ["crit"] = 821,
          ["haste"] = 1331,
          ["mastery"] = 492,
          ["vers"] = 550,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMzYMzmZxgxyA2YMaimZmlZmZmxYGGAAAAAwMz2MgltZGMmtBwEAAAwGm5BGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gnomerender",
          ["guild"] = "Opposite",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 143033,
          ["ilvl"] = 322,
          ["crit"] = 888,
          ["haste"] = 1337,
          ["mastery"] = 390,
          ["vers"] = 573,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Sol",
          ["guild"] = "Nurfed",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 140188,
          ["ilvl"] = 326,
          ["crit"] = 510,
          ["haste"] = 1548,
          ["mastery"] = 354,
          ["vers"] = 654,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWMzMzYMjZAAAAAAzMbzA22mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Bulandan",
          ["guild"] = "Gnomaste",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 137279,
          ["ilvl"] = 324,
          ["crit"] = 586,
          ["haste"] = 1159,
          ["mastery"] = 604,
          ["vers"] = 617,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDYDzoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Беруб",
          ["guild"] = "Пять Бутылок Водки",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 137040,
          ["ilvl"] = 325,
          ["crit"] = 347,
          ["haste"] = 1331,
          ["mastery"] = 562,
          ["vers"] = 886,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYCAAAYDzYALmBDYxy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Morídín",
          ["guild"] = "TERRA",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 131829,
          ["ilvl"] = 319,
          ["crit"] = 572,
          ["haste"] = 1466,
          ["mastery"] = 539,
          ["vers"] = 428,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbmxoJamZWmZmZGjZYAAAAAAzYbGwy2MDGz2AYCAAAYDz8ADYxADMbW2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "外星伴侣",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 130972,
          ["ilvl"] = 324,
          ["crit"] = 603,
          ["haste"] = 1445,
          ["mastery"] = 758,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMzYMzmZxgZZZgZDGNRzMzyMzMzYMDDAAAAAYmZbGwy2MDGz2AYCAAAYDzMALmBDYxiBYmBwA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gnomerender",
          ["guild"] = "Opposite",
          ["boss"] = "Sszorak",
          ["amount"] = 138699,
          ["ilvl"] = 326,
          ["crit"] = 1081,
          ["haste"] = 1292,
          ["mastery"] = 312,
          ["vers"] = 600,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsZGjZ2MLGMLLDMbwoJamZWMzMzYMjZAAAAAAzMbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Denerocxd",
          ["guild"] = "The Next Step",
          ["boss"] = "Sszorak",
          ["amount"] = 136149,
          ["ilvl"] = 318,
          ["crit"] = 862,
          ["haste"] = 1416,
          ["mastery"] = 201,
          ["vers"] = 376,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmtBwEAAAwGmZAWMDGwmltBYmBwA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gwfd",
          ["guild"] = "Review the Data",
          ["boss"] = "Sszorak",
          ["amount"] = 133942,
          ["ilvl"] = 326,
          ["crit"] = 1046,
          ["haste"] = 917,
          ["mastery"] = 526,
          ["vers"] = 682,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsZGjZ2MLGMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYCAAAYDzYALmBDYzy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Seepdruid",
          ["guild"] = "all gas no break",
          ["boss"] = "Sszorak",
          ["amount"] = 131927,
          ["ilvl"] = 322,
          ["crit"] = 642,
          ["haste"] = 1336,
          ["mastery"] = 794,
          ["vers"] = 402,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmtBwEAAAwGmZAWMDGwmltBYmBwA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Sol",
          ["guild"] = "Nurfed",
          ["boss"] = "Sszorak",
          ["amount"] = 128889,
          ["ilvl"] = 326,
          ["crit"] = 510,
          ["haste"] = 1550,
          ["mastery"] = 354,
          ["vers"] = 657,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWMzMzYMjZAAAAAAzMbzA22mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Jumbobear",
          ["guild"] = "comma",
          ["boss"] = "Sszorak",
          ["amount"] = 125098,
          ["ilvl"] = 325,
          ["crit"] = 764,
          ["haste"] = 1319,
          ["mastery"] = 405,
          ["vers"] = 688,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZ2mZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYALW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Ludicator",
          ["guild"] = "Everybody Gets One",
          ["boss"] = "Sszorak",
          ["amount"] = 123887,
          ["ilvl"] = 322,
          ["crit"] = 788,
          ["haste"] = 1240,
          ["mastery"] = 599,
          ["vers"] = 582,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMjRT0MzsMzMzMGzwAAAAAAmZ2mBssNzgxsNAmAAAA2wMGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Fangora",
          ["guild"] = "Mercy Killers",
          ["boss"] = "Sszorak",
          ["amount"] = 123097,
          ["ilvl"] = 321,
          ["crit"] = 1052,
          ["haste"] = 1425,
          ["mastery"] = 153,
          ["vers"] = 383,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmtBwEAAAwGmZAWMDGwmltBYmBwA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Vanela",
          ["guild"] = "Nightshade",
          ["boss"] = "Sszorak",
          ["amount"] = 121125,
          ["ilvl"] = 326,
          ["crit"] = 822,
          ["haste"] = 1334,
          ["mastery"] = 358,
          ["vers"] = 560,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDYjxoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmHYALmBDYxy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Kachop",
          ["guild"] = "Welcome",
          ["boss"] = "Sszorak",
          ["amount"] = 120640,
          ["ilvl"] = 322,
          ["crit"] = 1128,
          ["haste"] = 1234,
          ["mastery"] = 374,
          ["vers"] = 342,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDYjxoJamZWmZmZGjZMDAAAAAYGbzAW2mZwYWGATAAAAbYmBYxMYALW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gnomerender",
          ["guild"] = "Opposite",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 158605,
          ["ilvl"] = 326,
          ["crit"] = 1081,
          ["haste"] = 1292,
          ["mastery"] = 312,
          ["vers"] = 600,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZmlxMmBAAAAAMjtZALbzMYMbDgJAAAgNMzAsYgBsYZbAmZAMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Sol",
          ["guild"] = "Nurfed",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 156615,
          ["ilvl"] = 324,
          ["crit"] = 805,
          ["haste"] = 1215,
          ["mastery"] = 449,
          ["vers"] = 715,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2mZxgZZZgZDGNRzMziZmZmlxMmBAAAAAMzsNDYbbmBjZbAMBAAAshZGgFDMAW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Jumbobear",
          ["guild"] = "comma",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 153285,
          ["ilvl"] = 325,
          ["crit"] = 779,
          ["haste"] = 1319,
          ["mastery"] = 457,
          ["vers"] = 629,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270166,
              ["name"] = "Vashnik's Sanguine Rancor",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZ2MzMzsMmxMAAAAAgZsNDYZbmBjZbAMBAAAshZGgFzgBsYZbAmZAMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Skysec",
          ["guild"] = "Defenestrate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 142678,
          ["ilvl"] = 324,
          ["crit"] = 887,
          ["haste"] = 1214,
          ["mastery"] = 560,
          ["vers"] = 490,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMMaimZmFzMzMLjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYALW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Shaker",
          ["guild"] = "Might",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 129411,
          ["ilvl"] = 323,
          ["crit"] = 509,
          ["haste"] = 1545,
          ["mastery"] = 722,
          ["vers"] = 389,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250259,
              ["name"] = "Sapling of the Dawnroot",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWMzMzsMmxMAAAAAgZsNDYbbmBjZbAMBAAAshZGgFzgBsZZbAmZAMA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Bèbbì",
          ["guild"] = "Northstar",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 125918,
          ["ilvl"] = 323,
          ["crit"] = 556,
          ["haste"] = 1218,
          ["mastery"] = 1060,
          ["vers"] = 187,
          ["trinkets"] = {
            {
              ["id"] = 270160,
              ["name"] = "First Mate's Shellward",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2mZxgZZZgZDGNRzMziZmZmlxMmBAAAAAMzsNDYbbmBjZbAMBAAAshZGgFDMAW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "楠柯一梦丶",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 121111,
          ["ilvl"] = 326,
          ["crit"] = 720,
          ["haste"] = 1619,
          ["mastery"] = 623,
          ["vers"] = 236,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZWMLGjZZZgZDGNRzMzyMzMzsMmxAAAAAAMjtZALbzMYMbDgJAAAgNMzAsYGMgFMAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Haisnap",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 111221,
          ["ilvl"] = 322,
          ["crit"] = 809,
          ["haste"] = 1264,
          ["mastery"] = 130,
          ["vers"] = 927,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLbDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYCAAAYDz8AALmBDYzy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gnomerender",
          ["guild"] = "Opposite",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 125076,
          ["ilvl"] = 326,
          ["crit"] = 1081,
          ["haste"] = 1292,
          ["mastery"] = 312,
          ["vers"] = 600,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Gwfd",
          ["guild"] = "Review the Data",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 124755,
          ["ilvl"] = 322,
          ["crit"] = 869,
          ["haste"] = 1029,
          ["mastery"] = 551,
          ["vers"] = 678,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYCAAAYDzYALmBDYxy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Ludicator",
          ["guild"] = "Everybody Gets One",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 124124,
          ["ilvl"] = 322,
          ["crit"] = 788,
          ["haste"] = 1240,
          ["mastery"] = 599,
          ["vers"] = 582,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250228,
              ["name"] = "Resonant Bellowstone",
              ["ilvl"] = 311
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMjRT0MzsMzMzMGzwAAAAAAmZ2mBssNzgxsNAmAAAA2wMGwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "박제",
          ["guild"] = "영구정지",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 123382,
          ["ilvl"] = 321,
          ["crit"] = 748,
          ["haste"] = 1096,
          ["mastery"] = 699,
          ["vers"] = 363,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbGGNRzMzyMzMzYMDDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYALW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Sol",
          ["guild"] = "Nurfed",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 122571,
          ["ilvl"] = 324,
          ["crit"] = 583,
          ["haste"] = 1309,
          ["mastery"] = 390,
          ["vers"] = 764,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWMzMzYMjZAAAAAAzMbzA22mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Ahrilia",
          ["guild"] = "CV",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 118529,
          ["ilvl"] = 323,
          ["crit"] = 478,
          ["haste"] = 1542,
          ["mastery"] = 456,
          ["vers"] = 561,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 328
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmBYxMYAbW2GgZGAD",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Denerocxd",
          ["guild"] = "The Next Step",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 117573,
          ["ilvl"] = 319,
          ["crit"] = 862,
          ["haste"] = 1437,
          ["mastery"] = 201,
          ["vers"] = 376,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMjRT0MzsMzMzMGzwAAAAAAmx2MgltZGMmtBwEAAAwGmxAWMzwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "Vanela",
          ["guild"] = "Nightshade",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 116700,
          ["ilvl"] = 324,
          ["crit"] = 816,
          ["haste"] = 1159,
          ["mastery"] = 358,
          ["vers"] = 722,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 318
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDYjxoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATAAAAbYmHYALmBDYxy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "은근히귀여워놀간",
          ["guild"] = "Step in",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 116364,
          ["ilvl"] = 321,
          ["crit"] = 784,
          ["haste"] = 1201,
          ["mastery"] = 818,
          ["vers"] = 312,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMMjRT0MzsMzMzMGzYGAAAAAwM2mBssNzgxsNAmAAAA2wMPAwiZwA2ssNAzMAG",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        },
        {
          ["name"] = "珩珩丶",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 115978,
          ["ilvl"] = 323,
          ["crit"] = 648,
          ["haste"] = 1262,
          ["mastery"] = 570,
          ["vers"] = 494,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbMGNRzMzyMzMzYMDDAAAAAYmZbGwy2MDGz2AYCAAAYDzYALmBDYzy2AMzAYA",
          ["hero"] = {
            ["name"] = "Elune's Chosen",
            ["atlas"] = "talents-heroclass-druid-eluneschosen",
            ["icon"] = "inv_ability_eluneschosendruid_boundlessmoonlight"
          }
        }
      }
    },
    {
      ["spec"] = "Restoration",
      ["role"] = "healer",
      ["metric"] = "HPS",
      ["players"] = {
        {
          ["name"] = "구원의나무",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 389404,
          ["ilvl"] = 319,
          ["crit"] = 589,
          ["haste"] = 1149,
          ["mastery"] = 1078,
          ["vers"] = 263,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAMjxMLzMjZmxsNMDmNjNmBAAAAAAAAAAbGa2MjpZG4BMLjZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMMzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Ninjaristic",
          ["guild"] = "Honestly",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 384555,
          ["ilvl"] = 327,
          ["crit"] = 90,
          ["haste"] = 1578,
          ["mastery"] = 1258,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Wolfelord",
          ["guild"] = "EGG MONEY",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 384020,
          ["ilvl"] = 323,
          ["crit"] = 142,
          ["haste"] = 1637,
          ["mastery"] = 965,
          ["vers"] = 364,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGaMzYamBYWmZmZGGmBAAAAgBAAAAAAAMbzs0sNzmNGzMDmBGNDAwMDADA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "夏冷灬秋殇",
          ["guild"] = "哆啦美梦",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 382804,
          ["ilvl"] = 315,
          ["crit"] = 137,
          ["haste"] = 1563,
          ["mastery"] = 1326,
          ["vers"] = 76,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthhxsYsNmBAAAAAAAAAAbQzmZMNzAjZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YmZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "凯尔血蹄",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 382352,
          ["ilvl"] = 323,
          ["crit"] = 16,
          ["haste"] = 1572,
          ["mastery"] = 1110,
          ["vers"] = 457,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbGa2MjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "灰啊灰啊",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 381229,
          ["ilvl"] = 316,
          ["crit"] = 162,
          ["haste"] = 1298,
          ["mastery"] = 1378,
          ["vers"] = 257,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthhxsYsNmBAAAAAAAAAALGa2YMNzAjZZMzMDDzAAAAAwAAAAAAAAmtZWa2mZzGjZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Crewez",
          ["guild"] = "Elysian",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 376416,
          ["ilvl"] = 322,
          ["crit"] = 197,
          ["haste"] = 1667,
          ["mastery"] = 1072,
          ["vers"] = 175,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDa2MjpZYMjZbmZmZYYGAAAAAAAAAAAAAmtZ2a2mZzGjZGYGgmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "大德羅伊",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 374872,
          ["ilvl"] = 320,
          ["crit"] = 159,
          ["haste"] = 1534,
          ["mastery"] = 1345,
          ["vers"] = 102,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbDa2MjpZGDPgZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YmZGYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "우리동네힐러대장",
          ["guild"] = "끽끽이",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 373050,
          ["ilvl"] = 319,
          ["crit"] = 508,
          ["haste"] = 1869,
          ["mastery"] = 580,
          ["vers"] = 177,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthHYYmFjtxMAAAAAAAAAAYDa2MjpZGYMLjZmZYYGAAAAAAAAAAAAAmtZWa2mZzGzMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "水鸟忘记湖泊",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 372649,
          ["ilvl"] = 305,
          ["crit"] = 313,
          ["haste"] = 1115,
          ["mastery"] = 1324,
          ["vers"] = 210,
          ["trinkets"] = {
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 289
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALGaYGTzMwDYWmZmZGGmBAAAAgBMAAAAAAgZbmlmtZ2sxYmZwMANDAwMDADA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Shaso",
          ["guild"] = "Tabbed Out",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 473450,
          ["ilvl"] = 321,
          ["crit"] = 163,
          ["haste"] = 1852,
          ["mastery"] = 1203,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNGAAAAAAAAAAYzQzyMjpZGgZbmZmZYYGAAAAAGAwAAAAAAmtZWa2mZzGjZegBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "灰啊灰啊",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 472659,
          ["ilvl"] = 323,
          ["crit"] = 55,
          ["haste"] = 1427,
          ["mastery"] = 1536,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALGa2YMNzAjZZMzMDDzAAAAAwAAAAAAAAmtZWa2mZzGjZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "夏冷灬秋殇",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 448817,
          ["ilvl"] = 317,
          ["crit"] = 137,
          ["haste"] = 1613,
          ["mastery"] = 1375,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthhxsYsNmBAAAAAAAAAAbQzmZMNzAjZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YmZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "阿泰尔丷",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 443303,
          ["ilvl"] = 322,
          ["crit"] = 109,
          ["haste"] = 1326,
          ["mastery"] = 1348,
          ["vers"] = 237,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDa2MjpZGDPgZZmZmZYYGAAAAAAAAAAAAAmtZWa2mZzGjZGYmFQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "香咕滑鸡",
          ["guild"] = "十年",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 442960,
          ["ilvl"] = 322,
          ["crit"] = 69,
          ["haste"] = 1944,
          ["mastery"] = 1087,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALGa2mZMNzAMLjZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YmZGYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "嗨丶小熊饼干",
          ["guild"] = "夜晓-N.Aurora",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 430865,
          ["ilvl"] = 320,
          ["crit"] = 416,
          ["haste"] = 1546,
          ["mastery"] = 937,
          ["vers"] = 303,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2GjpZGgZZMzMzihZAAAAAYAAAAAAAAz2MLNbzsZjxMzgZgRzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "咕咕丶哒",
          ["guild"] = "抖音：黄瓜-魔兽世界",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 428554,
          ["ilvl"] = 315,
          ["crit"] = 647,
          ["haste"] = 1103,
          ["mastery"] = 1091,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthHgZmNjtxMAAAAAAAAAAYxQzGjpZG4BMLjZmZYYGAAAAAGwAAAAAAAmtZWa2mZzGjZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Frozenthree",
          ["guild"] = "Born In Shadow",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 426628,
          ["ilvl"] = 310,
          ["crit"] = 365,
          ["haste"] = 1223,
          ["mastery"] = 1192,
          ["vers"] = 261,
          ["trinkets"] = {
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALGaYGTzMwDYWmZmZGGmBAAAAgBMAAAAAAgZbmlmtZ2sxYmZwMANDAwMDADA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "水鸟忘记湖泊",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 423990,
          ["ilvl"] = 308,
          ["crit"] = 313,
          ["haste"] = 1270,
          ["mastery"] = 1056,
          ["vers"] = 210,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALGaYGTzMwDYWmZmZGGmBAAAAgBMAAAAAAgZbmlmtZ2sxYmZwMANDAwMDADA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Vrocas",
          ["guild"] = "Vestige",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 421831,
          ["ilvl"] = 323,
          ["crit"] = 110,
          ["haste"] = 1720,
          ["mastery"] = 1124,
          ["vers"] = 253,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbDa2MjpZGDPgZZmZmZWMMDAAAAAAAAAAAAAz2MLNbzsZjxMDMDQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "夏冷灬秋殇",
          ["guild"] = "哆啦美梦",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 397004,
          ["ilvl"] = 319,
          ["crit"] = 137,
          ["haste"] = 1638,
          ["mastery"] = 1320,
          ["vers"] = 83,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthhxsYsNmBAAAAAAAAAAbQzmZMNzAjZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YmZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Coomidos",
          ["guild"] = "Warden",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 373672,
          ["ilvl"] = 324,
          ["crit"] = 253,
          ["haste"] = 1783,
          ["mastery"] = 954,
          ["vers"] = 390,
          ["trinkets"] = {
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbGa2MjpZAPgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "林巴德",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 362076,
          ["ilvl"] = 319,
          ["crit"] = 343,
          ["haste"] = 1354,
          ["mastery"] = 1192,
          ["vers"] = 246,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2mZMNzAMLzMzMDDzAAAAAwAAAAAAAAmlZ2a2mZzGzMzDMYGgmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "香咕滑鸡",
          ["guild"] = "十年",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 358336,
          ["ilvl"] = 322,
          ["crit"] = 99,
          ["haste"] = 1843,
          ["mastery"] = 1154,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAAbGa2mZMNzAMLjZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YmZGYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Glewellin",
          ["guild"] = "Down Bad",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 357724,
          ["ilvl"] = 325,
          ["crit"] = 16,
          ["haste"] = 1636,
          ["mastery"] = 1379,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDa2MjpZGDPgZZmZmZYYmBAAAAAAAAAAAAwsNzSz2Mb2YMzAzA0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Katerpie",
          ["guild"] = "Shots Fired",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 353574,
          ["ilvl"] = 325,
          ["crit"] = 243,
          ["haste"] = 1563,
          ["mastery"] = 1120,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthHwMmFjtxMAAAAAAAAAAYzQzmZMNzAMLzMzMDDzAAAAAwAAAAAAAAmtZWa2mZzGjZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Rastadoo",
          ["guild"] = "Dumbrava Minunata",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 347896,
          ["ilvl"] = 322,
          ["crit"] = 224,
          ["haste"] = 1460,
          ["mastery"] = 1088,
          ["vers"] = 335,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthBzsZs9AmBAAAAAAAAAALGa2GjpZG4BMLjZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMMzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Ninjaristic",
          ["guild"] = "Honestly",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 347030,
          ["ilvl"] = 327,
          ["crit"] = 90,
          ["haste"] = 1578,
          ["mastery"] = 1258,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Kermix",
          ["guild"] = "Proper Guild Name",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 346793,
          ["ilvl"] = 321,
          ["crit"] = 157,
          ["haste"] = 1667,
          ["mastery"] = 1141,
          ["vers"] = 193,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbDa2YMNzY4BMLzMzMzihZAAAAAAAAAAAAAY2mZpZbmNbMmZGMDQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Rawrlox",
          ["guild"] = "Helden in Pyjamas",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 343970,
          ["ilvl"] = 325,
          ["crit"] = 256,
          ["haste"] = 1739,
          ["mastery"] = 964,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYmNQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "灰啊灰啊",
          ["guild"] = "冰山英雄",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 460834,
          ["ilvl"] = 323,
          ["crit"] = 55,
          ["haste"] = 1427,
          ["mastery"] = 1536,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALGa2YMNzAjZZMzMDDzAAAAAwAAAAAAAAmtZWa2mZzGjZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "国澐",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 453165,
          ["ilvl"] = 320,
          ["crit"] = 258,
          ["haste"] = 1467,
          ["mastery"] = 1193,
          ["vers"] = 121,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALGa2GjpZG4BMLjZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Xavroar",
          ["guild"] = "Fair Enough",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 431382,
          ["ilvl"] = 324,
          ["crit"] = 287,
          ["haste"] = 1619,
          ["mastery"] = 1083,
          ["vers"] = 166,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALQzmZMNzAjZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YmZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Looqd",
          ["guild"] = "The Next Step",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 426864,
          ["ilvl"] = 316,
          ["crit"] = 285,
          ["haste"] = 1527,
          ["mastery"] = 1159,
          ["vers"] = 300,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDa2MjpZGDPgZZmZmZYYGAAAAAAAAAAAAAmtZWa2mZzGjZGYmFQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Ninjaristic",
          ["guild"] = "Honestly",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 426606,
          ["ilvl"] = 327,
          ["crit"] = 90,
          ["haste"] = 1578,
          ["mastery"] = 1258,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "吃饱了睡觉",
          ["guild"] = "宝宝巴士",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 423776,
          ["ilvl"] = 323,
          ["crit"] = 174,
          ["haste"] = 1221,
          ["mastery"] = 954,
          ["vers"] = 702,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZbmZMzMmthZwsYsNmBAAAAAAAAAAbQzmZMNzAjZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YmZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "夜澜听雪",
          ["guild"] = "初心-奥尔加隆",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 418455,
          ["ilvl"] = 318,
          ["crit"] = 251,
          ["haste"] = 1721,
          ["mastery"] = 932,
          ["vers"] = 276,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAMjxMLzMjZmxsNMDmNjNmBAAAAAAAAAALDa2YMNzY4BMLzMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YMzMMzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "메가곰",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 414347,
          ["ilvl"] = 324,
          ["crit"] = 150,
          ["haste"] = 1713,
          ["mastery"] = 1082,
          ["vers"] = 240,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbGa2MjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Aldur",
          ["guild"] = "Elex",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 411475,
          ["ilvl"] = 324,
          ["crit"] = 203,
          ["haste"] = 1834,
          ["mastery"] = 998,
          ["vers"] = 163,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDa2YMNzY4BMLzMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "夏冷灬秋殇",
          ["guild"] = "哆啦美梦",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 411302,
          ["ilvl"] = 315,
          ["crit"] = 137,
          ["haste"] = 1563,
          ["mastery"] = 1326,
          ["vers"] = 76,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthhxsYsNmBAAAAAAAAAAbQzmZMNzAjZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YmZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Ninjaristic",
          ["guild"] = "Honestly",
          ["boss"] = "Sszorak",
          ["amount"] = 496845,
          ["ilvl"] = 327,
          ["crit"] = 90,
          ["haste"] = 1578,
          ["mastery"] = 1258,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Allys",
          ["guild"] = "Primori Morte",
          ["boss"] = "Sszorak",
          ["amount"] = 493271,
          ["ilvl"] = 323,
          ["crit"] = 149,
          ["haste"] = 1802,
          ["mastery"] = 1007,
          ["vers"] = 205,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2mZmpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMjBzsBaGAgZGAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Lillaregn",
          ["guild"] = "Something Clever",
          ["boss"] = "Sszorak",
          ["amount"] = 479404,
          ["ilvl"] = 326,
          ["crit"] = nil,
          ["haste"] = 1764,
          ["mastery"] = 1168,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALDa2MjpZGDPgZZmZmZYYGAAAAAAAAAAAAAmtZWa2mZzGjZGYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Hotauntie",
          ["guild"] = "From Ashes",
          ["boss"] = "Sszorak",
          ["amount"] = 477424,
          ["ilvl"] = 326,
          ["crit"] = 228,
          ["haste"] = 1657,
          ["mastery"] = 1078,
          ["vers"] = 148,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2YMNzAPgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "柚子超小可爱",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 463134,
          ["ilvl"] = 322,
          ["crit"] = 532,
          ["haste"] = 1316,
          ["mastery"] = 1027,
          ["vers"] = 222,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZbmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "脸红红四号",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 449195,
          ["ilvl"] = 322,
          ["crit"] = 298,
          ["haste"] = 1250,
          ["mastery"] = 1261,
          ["vers"] = 247,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALGa2MjpZGgZbmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "泰葻不是德",
          ["guild"] = "老狗",
          ["boss"] = "Sszorak",
          ["amount"] = 447531,
          ["ilvl"] = 323,
          ["crit"] = 293,
          ["haste"] = 1149,
          ["mastery"] = 1145,
          ["vers"] = 414,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZbmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Lysk",
          ["guild"] = "고인물",
          ["boss"] = "Sszorak",
          ["amount"] = 445857,
          ["ilvl"] = 321,
          ["crit"] = 110,
          ["haste"] = 1697,
          ["mastery"] = 1059,
          ["vers"] = 284,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2GjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Thottpatrol",
          ["guild"] = "POLAR",
          ["boss"] = "Sszorak",
          ["amount"] = 443395,
          ["ilvl"] = 317,
          ["crit"] = 195,
          ["haste"] = 1570,
          ["mastery"] = 1117,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2GjpZGgZZMzMDDzAAAAAwAAAAAAAAmtZWa2mZzGzMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Treevor",
          ["guild"] = "Stupid Fat Hobbits",
          ["boss"] = "Sszorak",
          ["amount"] = 441947,
          ["ilvl"] = 321,
          ["crit"] = 401,
          ["haste"] = 1714,
          ["mastery"] = 765,
          ["vers"] = 339,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZG4BMLzMzMDDzAAAAAwAAAAAAAAmtZWa2mZzGzMzDMYGgmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Pyrró",
          ["guild"] = "Wisp",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 460284,
          ["ilvl"] = 320,
          ["crit"] = 154,
          ["haste"] = 1957,
          ["mastery"] = 1003,
          ["vers"] = 180,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALQz2YMNzAPgZZMzMzihZAAAAAYAAAAAAAAz2MLNbzsZjxMzgZgRzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Vrocas",
          ["guild"] = "Vestige",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 454953,
          ["ilvl"] = 324,
          ["crit"] = 114,
          ["haste"] = 1724,
          ["mastery"] = 1128,
          ["vers"] = 257,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDa2MjpZGDPgZZmZmZWMMDAAAAAAAAAAAAAz2MLNbzsZjxMDMDQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Neton",
          ["guild"] = "Save The Wife",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 452867,
          ["ilvl"] = 324,
          ["crit"] = 322,
          ["haste"] = 1513,
          ["mastery"] = 1071,
          ["vers"] = 238,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbGa2YMNzAPgZZMzMzihZAAAAAYAAAAAAAAz2MLNbzsZjxMzgZgRzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Rappdruid",
          ["guild"] = "Competence Optional",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 452843,
          ["ilvl"] = 324,
          ["crit"] = 231,
          ["haste"] = 1846,
          ["mastery"] = 1012,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDa2MjpZGDPgZZmZmZWMMDAAAAAAAAAAAAAz2MLNbzsZjxMDMDQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Kermix",
          ["guild"] = "Proper Guild Name",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 443674,
          ["ilvl"] = 324,
          ["crit"] = 159,
          ["haste"] = 1707,
          ["mastery"] = 1158,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbGa2YMNzAPgZZmZmZWMMDAAAAADAAAAAAAY2mZpZbmNbMmZGMDQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "咣咣还真有",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 433019,
          ["ilvl"] = 322,
          ["crit"] = 253,
          ["haste"] = 1371,
          ["mastery"] = 1228,
          ["vers"] = 139,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALQz2YMNzAjZhZmZWMMDAAAAADAAAAAAAY2mZpZbmNbMzMDMDMaGAgZGAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Ninjaristic",
          ["guild"] = "Honestly",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 431329,
          ["ilvl"] = 320,
          ["crit"] = 247,
          ["haste"] = 1565,
          ["mastery"] = 1023,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDaYGTzMGeAzyMzMzsMDzAAAAAAAAAAAAAwsNzSz2Mb2YMzAzA0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Quandedudu",
          ["guild"] = "Reflection",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 427444,
          ["ilvl"] = 325,
          ["crit"] = 348,
          ["haste"] = 1576,
          ["mastery"] = 1214,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZZmZmZWM8ADAAAAADAAAAAAAY2mZpZbmNbMmZGMDMaGAgZGAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Ndrprsr",
          ["guild"] = "Scuffed",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 425777,
          ["ilvl"] = 321,
          ["crit"] = 322,
          ["haste"] = 1708,
          ["mastery"] = 795,
          ["vers"] = 311,
          ["trinkets"] = {
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDa2YMNzYgZZmZmZWmhZAAAAAAAAAAAAAY2mZpZbmNbMmZGMDQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Qwadsfwfgads",
          ["guild"] = "TRK",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 424665,
          ["ilvl"] = 327,
          ["crit"] = 216,
          ["haste"] = 1634,
          ["mastery"] = 958,
          ["vers"] = 288,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALzQzGjpZGgZxMzMzihZAAAAAYAAAAAAAAz2MLNbzsZjxMzgZ2ANDAwMDADA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Ninjaristic",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 460496,
          ["ilvl"] = 327,
          ["crit"] = 90,
          ["haste"] = 1578,
          ["mastery"] = 1258,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbzQzGjpZYYMLzMzMMDzAAAAAwAAAAAAAAmtZWa2mZzGjZMYmFQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Elunesix",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 396932,
          ["ilvl"] = 324,
          ["crit"] = 112,
          ["haste"] = 1505,
          ["mastery"] = 1192,
          ["vers"] = 356,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbQzyYMNzAjZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YmZGYGgmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Cépakos",
          ["guild"] = "Quichons",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 355042,
          ["ilvl"] = 325,
          ["crit"] = 402,
          ["haste"] = 1726,
          ["mastery"] = 991,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbDa2YMNzY4BMLzMzMjZYGAAAAAAAAAAAAAmtZWa2mZzGjZGYmFQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Ninjaristic",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 535352,
          ["ilvl"] = 330,
          ["crit"] = 90,
          ["haste"] = 1817,
          ["mastery"] = 1257,
          ["vers"] = 52,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALzQzGjpZGDMLzMzMDDzAAAAAwAAAAAAAAmtZWa2mZzGjZegBzsAaGAgZGAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "夏冷灬秋殇",
          ["guild"] = "哆啦美梦",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 392470,
          ["ilvl"] = 323,
          ["crit"] = 155,
          ["haste"] = 1574,
          ["mastery"] = 1326,
          ["vers"] = 249,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthhxsYsNmBAAAAAAAAAALQzmZMNzAjZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YmZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "灰啊灰啊",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 386524,
          ["ilvl"] = 323,
          ["crit"] = 55,
          ["haste"] = 1427,
          ["mastery"] = 1536,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALGa2YMNzAjZZMzMDDzAAAAAwAAAAAAAAmtZWa2mZzGjZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "吃饱了睡觉",
          ["guild"] = "宝宝巴士",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 364095,
          ["ilvl"] = 321,
          ["crit"] = 174,
          ["haste"] = 1220,
          ["mastery"] = 962,
          ["vers"] = 681,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZbmZMzMmthZwsYsNmBAAAAAAAAAAbQzmZMNzAjZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YmZmBzAjmBAYmBgB",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Kárra",
          ["guild"] = "Fluffy Lemon Noodles",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 353737,
          ["ilvl"] = 318,
          ["crit"] = 411,
          ["haste"] = 1672,
          ["mastery"] = 762,
          ["vers"] = 232,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALQzmZMNzwYMbzMzMzihZAAAAAAAAAAAAAY2mZpZbmNbMmZgZAaGAgZGAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Ninjaristic",
          ["guild"] = "Honestly",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 352587,
          ["ilvl"] = 327,
          ["crit"] = 90,
          ["haste"] = 1578,
          ["mastery"] = 1258,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "凯尔血蹄",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 352180,
          ["ilvl"] = 322,
          ["crit"] = 16,
          ["haste"] = 1431,
          ["mastery"] = 1211,
          ["vers"] = 453,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthhxsYsNmBAAAAAAAAAAbGa2MjpZGgZZmZmZYYGAAAAAGAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "月光小鬼鬼",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 350097,
          ["ilvl"] = 328,
          ["crit"] = 56,
          ["haste"] = 1765,
          ["mastery"] = 1291,
          ["vers"] = 190,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALGa2MjpZGgZZMzMDDzAAAAAwAAAAAAAAmtZWa2mZzGzMzMYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Slerpyy",
          ["guild"] = "The FeIIowship",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 348812,
          ["ilvl"] = 319,
          ["crit"] = 236,
          ["haste"] = 1508,
          ["mastery"] = 1141,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbDa2MjpZGDPgZZmZmZYYGAAAAAAAAAAAAAmtZWa2mZzGjZGYGY0MAAzMAMA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Биллиприхлоп",
          ["guild"] = "Революция",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 348134,
          ["ilvl"] = 323,
          ["crit"] = 116,
          ["haste"] = 1874,
          ["mastery"] = 1079,
          ["vers"] = 277,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALDa2MjpZGDPgZZmZmZWMMDAAAAAAAAAAAAAz2MLNbzsZjxMDMDQzAAMzAwA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        },
        {
          ["name"] = "Lillaregn",
          ["guild"] = "Something Clever",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 347873,
          ["ilvl"] = 321,
          ["crit"] = nil,
          ["haste"] = 1653,
          ["mastery"] = 1157,
          ["vers"] = 315,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALQzmZMNzAjZZMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YMzMYGbMaGAgZGAGA",
          ["hero"] = {
            ["name"] = "Wildstalker",
            ["atlas"] = "talents-heroclass-druid-wildstalker",
            ["icon"] = "inv_ability_wildstalkerdruid_thrivinggrowth"
          }
        }
      }
    }
  }
}
