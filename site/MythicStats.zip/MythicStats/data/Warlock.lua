MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Warlock"] = {
  ["className"] = "Warlock",
  ["specs"] = {
    {
      ["spec"] = "Affliction",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Handlerone",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 227661,
          ["ilvl"] = 323,
          ["crit"] = 906,
          ["haste"] = 1329,
          ["mastery"] = 643,
          ["vers"] = 231,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbmZ2mZGz2AAAMzsYZmZWGDAM22GYADYG2CMsNAAAMDAAgZmZmxMAmZmZmxMDzMzAAMDMA"
        },
        {
          ["name"] = "Skelleen",
          ["guild"] = "Synergize",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 226647,
          ["ilvl"] = 325,
          ["crit"] = 1159,
          ["haste"] = 1232,
          ["mastery"] = 805,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAsZmxMjmNmxMzYWGAAgZmlZZmZWmHYAALwAziRjZAMbglBAAgZAAgZGMzMmBmhZGzMjBzMzMAgZgB"
        },
        {
          ["name"] = "트롤여캐성기사",
          ["guild"] = "SEEREAL",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 223008,
          ["ilvl"] = 325,
          ["crit"] = 1019,
          ["haste"] = 1036,
          ["mastery"] = 789,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjxYMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Gock",
          ["guild"] = "Without Limits",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 219114,
          ["ilvl"] = 326,
          ["crit"] = 963,
          ["haste"] = 809,
          ["mastery"] = 1007,
          ["vers"] = 254,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjxYMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Lockvig",
          ["guild"] = "Hypothetical",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 213633,
          ["ilvl"] = 319,
          ["crit"] = 692,
          ["haste"] = 1412,
          ["mastery"] = 530,
          ["vers"] = 453,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjZMzMmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjZwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Sõrrÿ",
          ["guild"] = "Threat Level Midnight",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 212323,
          ["ilvl"] = 321,
          ["crit"] = 1112,
          ["haste"] = 1181,
          ["mastery"] = 585,
          ["vers"] = 173,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 328
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMgZmxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Minx",
          ["guild"] = "Epoch",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 210825,
          ["ilvl"] = 321,
          ["crit"] = 942,
          ["haste"] = 1333,
          ["mastery"] = 589,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZegxsMAAAzMLzyMzsYGAYstNwAGwMsFYYbAAAYGAAAzMjZMzsxMMzMzMjBzMzMAgBMA"
        },
        {
          ["name"] = "Netherward",
          ["guild"] = "Tenacity",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 210432,
          ["ilvl"] = 320,
          ["crit"] = 978,
          ["haste"] = 1102,
          ["mastery"] = 813,
          ["vers"] = 182,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMgZmxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Prazzin",
          ["guild"] = "Deadly Momentum",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 210033,
          ["ilvl"] = 322,
          ["crit"] = 743,
          ["haste"] = 1354,
          ["mastery"] = 660,
          ["vers"] = 314,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAgxMzMNbMjZmxsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjZGmZYmxMzYwMzMAAzAD"
        },
        {
          ["name"] = "Джеоли",
          ["guild"] = "У беляша",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 209725,
          ["ilvl"] = 325,
          ["crit"] = 1053,
          ["haste"] = 2244,
          ["mastery"] = 560,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Maddino",
          ["guild"] = "Expurged",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 240157,
          ["ilvl"] = 323,
          ["crit"] = 1053,
          ["haste"] = 1377,
          ["mastery"] = 445,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMegZmpZjZMzMmlBAAYmZZWmZml5BGAwCMwsY0YGAzCYZAAAYGAAYmBzMjZGMDzMmZGDmZmBAYGYA"
        },
        {
          ["name"] = "Handlerone",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 238866,
          ["ilvl"] = 323,
          ["crit"] = 955,
          ["haste"] = 1278,
          ["mastery"] = 643,
          ["vers"] = 231,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzMNbMMzMmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Barbecuesorc",
          ["guild"] = "Pig Pen",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 238111,
          ["ilvl"] = 328,
          ["crit"] = 1312,
          ["haste"] = 793,
          ["mastery"] = 442,
          ["vers"] = 526,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMDNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Scorpylock",
          ["guild"] = "baited",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 235595,
          ["ilvl"] = 326,
          ["crit"] = 1242,
          ["haste"] = 1233,
          ["mastery"] = 448,
          ["vers"] = 248,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBmZMzsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Amogustwerk",
          ["guild"] = "No Hard Feelings",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 235577,
          ["ilvl"] = 323,
          ["crit"] = 1148,
          ["haste"] = 972,
          ["mastery"] = 564,
          ["vers"] = 335,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZZMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBMjxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Dlrush",
          ["guild"] = "Stormbound",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 225906,
          ["ilvl"] = 322,
          ["crit"] = 1152,
          ["haste"] = 1249,
          ["mastery"] = 630,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMYmZMGmZYmxMzYwMzMAAzAD"
        },
        {
          ["name"] = "Qvazar",
          ["guild"] = "Mercy Killers",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 225631,
          ["ilvl"] = 323,
          ["crit"] = 1172,
          ["haste"] = 986,
          ["mastery"] = 775,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZmZWGAAgZmlZZmZWGDAYBGYWMaMDgZBsMAAAMDAAMzAzMzYYmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Reoru",
          ["guild"] = "WICKED",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224910,
          ["ilvl"] = 325,
          ["crit"] = 1364,
          ["haste"] = 1113,
          ["mastery"] = 382,
          ["vers"] = 258,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMYmZMGmZYmxMzYwMzMAAzAD"
        },
        {
          ["name"] = "Luckehlock",
          ["guild"] = "The Remnant",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224130,
          ["ilvl"] = 325,
          ["crit"] = 1408,
          ["haste"] = 1330,
          ["mastery"] = 100,
          ["vers"] = 171,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAYmZegZGNbMWmZGzyAAAMzsMLmZWGDAYBGYWMaMDgZBsMAAAYAAgZGYmxYMzMMzYmZmBzMzMAgZgB"
        },
        {
          ["name"] = "Webbyminion",
          ["guild"] = "Lucky",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 222937,
          ["ilvl"] = 326,
          ["crit"] = 1180,
          ["haste"] = 1421,
          ["mastery"] = 454,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "宇佐见莲子",
          ["guild"] = "月泽正式服",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 302921,
          ["ilvl"] = 322,
          ["crit"] = 1021,
          ["haste"] = 1221,
          ["mastery"] = 580,
          ["vers"] = 196,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbMz2MzY2GAAgZmFLzMzyYAgx2yADYAzwWghtBAAgZAAAMzMzMmZAmZmZmxMDzMzAAMDMA"
        },
        {
          ["name"] = "Webbyminion",
          ["guild"] = "Lucky",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 295600,
          ["ilvl"] = 326,
          ["crit"] = 1180,
          ["haste"] = 1421,
          ["mastery"] = 454,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhZMzMmlBAAYmZx2MzsMGAYstNwAGwMsFYYbAAAYGAAAzMmZMDgZmZmZMzwMzMDAYGYA"
        },
        {
          ["name"] = "Undrtkr",
          ["guild"] = "Crescendo",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 289502,
          ["ilvl"] = 321,
          ["crit"] = 1312,
          ["haste"] = 871,
          ["mastery"] = 649,
          ["vers"] = 51,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbMz2MzY2GAAgZmFLzMzyYAgx2yADYAzwWghtBAAgZAAAMzMzMmZAmZmZmxMDzMzAAMDMA"
        },
        {
          ["name"] = "Handlerone",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 280268,
          ["ilvl"] = 323,
          ["crit"] = 941,
          ["haste"] = 1278,
          ["mastery"] = 643,
          ["vers"] = 231,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbmZ2mZGz2AAAMzsYZmZWGDAM22GYADYG2CMsNAAAMDAAgZmZmxMAmZmZmxMDzMzAAMDMA"
        },
        {
          ["name"] = "Dlrush",
          ["guild"] = "Stormbound",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 276344,
          ["ilvl"] = 322,
          ["crit"] = 1152,
          ["haste"] = 1249,
          ["mastery"] = 630,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMYmZMGmZYmxMzYwMzMAAzAD"
        },
        {
          ["name"] = "Turbii",
          ["guild"] = "Cosmik",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 275231,
          ["ilvl"] = 324,
          ["crit"] = 599,
          ["haste"] = 1039,
          ["mastery"] = 1329,
          ["vers"] = 152,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbMz2MzYWGAAgZmFLzMzyYAgx22ADYAzwWghtBAAgZAAAMzMzMmZAmZmZmxMDzMzAAMDMA"
        },
        {
          ["name"] = "Marotgus",
          ["guild"] = "Move Left",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 272022,
          ["ilvl"] = 325,
          ["crit"] = 837,
          ["haste"] = 1528,
          ["mastery"] = 403,
          ["vers"] = 186,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMMzoZzMz2MzYWGAAwMmlZZmZWGDAM22GYADYG2CMsNAAAMAAAMzMmxMzGDzMzMzwMMzMDAwMwA"
        },
        {
          ["name"] = "Igglegiggle",
          ["guild"] = "Yup",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 260924,
          ["ilvl"] = 323,
          ["crit"] = 1039,
          ["haste"] = 1647,
          ["mastery"] = 401,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzMNbMMzMmlBAAYmZZWmZmtxAAWgBmFjGzAY2ALDAAAzAAAzMwMDzgZYmxMzMDmZmZAAzAD"
        },
        {
          ["name"] = "Hugeweenis",
          ["guild"] = "Wizards on the Block",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 260167,
          ["ilvl"] = 325,
          ["crit"] = 980,
          ["haste"] = 1102,
          ["mastery"] = 857,
          ["vers"] = 218,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzDMzoZjZMzMmtBAAYmZxyMzsMGAYstMwAGwMsFYYbAAAYGAAAzMzMjZAMzMzMjZGmZmZAAzAD"
        },
        {
          ["name"] = "Maddino",
          ["guild"] = "Expurged",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 257213,
          ["ilvl"] = 322,
          ["crit"] = 1053,
          ["haste"] = 1330,
          ["mastery"] = 487,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMegZmpZjZMzMmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMYmZMzwMDzMmZGDmZmBAYGYA"
        },
        {
          ["name"] = "Kellslocks",
          ["guild"] = "Deception",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 316786,
          ["ilvl"] = 327,
          ["crit"] = 1159,
          ["haste"] = 944,
          ["mastery"] = 569,
          ["vers"] = 329,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMDzsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Webbyminion",
          ["guild"] = "Lucky",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 296194,
          ["ilvl"] = 326,
          ["crit"] = 1180,
          ["haste"] = 1421,
          ["mastery"] = 454,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Lockropet",
          ["guild"] = "OG Konflikt",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 295735,
          ["ilvl"] = 325,
          ["crit"] = 1155,
          ["haste"] = 1287,
          ["mastery"] = 452,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjxsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Madthelock",
          ["guild"] = "Fierce",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 291293,
          ["ilvl"] = 325,
          ["crit"] = 1189,
          ["haste"] = 1205,
          ["mastery"] = 583,
          ["vers"] = 194,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Skelleen",
          ["guild"] = "Synergize",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 288510,
          ["ilvl"] = 324,
          ["crit"] = 1159,
          ["haste"] = 1232,
          ["mastery"] = 662,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAsZmxMjmNmxMzYWGAAgZmlZZmZWGDAYBGYWMaMDgZBsMAAAMDAAMzgZmxMYmhZGzMjBzMzMAgZgB"
        },
        {
          ["name"] = "Barbecuesorc",
          ["guild"] = "Pig Pen",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 287672,
          ["ilvl"] = 327,
          ["crit"] = 1096,
          ["haste"] = 710,
          ["mastery"] = 712,
          ["vers"] = 526,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMDNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjxYMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Maddino",
          ["guild"] = "Expurged",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 287592,
          ["ilvl"] = 323,
          ["crit"] = 1053,
          ["haste"] = 1377,
          ["mastery"] = 445,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjhZmxsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjZGjZYmxMzYwMzMAAzAD"
        },
        {
          ["name"] = "Dlrush",
          ["guild"] = "Stormbound",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 285473,
          ["ilvl"] = 322,
          ["crit"] = 1152,
          ["haste"] = 1249,
          ["mastery"] = 630,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMYmZMGmZYmxMzYwMzMAAzAD"
        },
        {
          ["name"] = "Darklycid",
          ["guild"] = "evicted",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 283692,
          ["ilvl"] = 322,
          ["crit"] = 1019,
          ["haste"] = 1120,
          ["mastery"] = 718,
          ["vers"] = 237,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmxsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBjZMzwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Gock",
          ["guild"] = "Without Limits",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 283362,
          ["ilvl"] = 326,
          ["crit"] = 963,
          ["haste"] = 809,
          ["mastery"] = 1007,
          ["vers"] = 254,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Zachx",
          ["guild"] = "Rain",
          ["boss"] = "Sszorak",
          ["amount"] = 203030,
          ["ilvl"] = 325,
          ["crit"] = 1250,
          ["haste"] = 1265,
          ["mastery"] = 588,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAsZmxMjmNmxMzYWGAAgZmlZZmZWGDAYBGYWMaMDgZDsMAAAMDAAMzgZmxMMmhZGzMjBzMzMAgZgB"
        },
        {
          ["name"] = "Madthelock",
          ["guild"] = "Fierce",
          ["boss"] = "Sszorak",
          ["amount"] = 200395,
          ["ilvl"] = 325,
          ["crit"] = 1189,
          ["haste"] = 1062,
          ["mastery"] = 719,
          ["vers"] = 194,
          ["trinkets"] = {
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAsZmxMjmNmxMzYWGAAgZmlZZmZWGDAYBGYWMaMDgZDsMAAAMDAAMzgZmxMMmhZGzMjBzMzMAgZgB"
        },
        {
          ["name"] = "Braska",
          ["guild"] = "Post Prog Clarity",
          ["boss"] = "Sszorak",
          ["amount"] = 198663,
          ["ilvl"] = 324,
          ["crit"] = 947,
          ["haste"] = 1223,
          ["mastery"] = 635,
          ["vers"] = 211,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjhZmZmlBAAYmZZWmZmlxAA2gBmFjGzAY2ALDAAAzAAAzMwMzMGmZYmxMzYwMzMAAzAD"
        },
        {
          ["name"] = "Skelleen",
          ["guild"] = "Synergize",
          ["boss"] = "Sszorak",
          ["amount"] = 196437,
          ["ilvl"] = 325,
          ["crit"] = 1159,
          ["haste"] = 1232,
          ["mastery"] = 805,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAsZmxMjmNmxMzYWGAAgZmlZZmZWGDAYBGYWMaMDgZDsMAAAMDAAMzgZmxMMmhZGzMjBzMzMAgZgB"
        },
        {
          ["name"] = "Scorpylock",
          ["guild"] = "baited",
          ["boss"] = "Sszorak",
          ["amount"] = 194681,
          ["ilvl"] = 326,
          ["crit"] = 1242,
          ["haste"] = 1233,
          ["mastery"] = 448,
          ["vers"] = 248,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBmZMzsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Selarât",
          ["guild"] = "The Amazing Zoo",
          ["boss"] = "Sszorak",
          ["amount"] = 194007,
          ["ilvl"] = 324,
          ["crit"] = 1313,
          ["haste"] = 989,
          ["mastery"] = 613,
          ["vers"] = 105,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAsZmxMjmNmxMzYWGAAgZmlZZmZWGDAYBGYWMaMDgZDsMAAAMDAAMzgZmxMMmhZGzMjBzMzMAgZgB"
        },
        {
          ["name"] = "Gock",
          ["guild"] = "Without Limits",
          ["boss"] = "Sszorak",
          ["amount"] = 193857,
          ["ilvl"] = 328,
          ["crit"] = 967,
          ["haste"] = 816,
          ["mastery"] = 1011,
          ["vers"] = 263,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAsZmxMjmNmxMzYWGAAgZmlZZmZWGDAYBGYWMaMDgZDsMAAAMDAAMzgZmxMMmhZGzMjBzMzMAgZgB"
        },
        {
          ["name"] = "Oreganow",
          ["guild"] = "Vindicatum",
          ["boss"] = "Sszorak",
          ["amount"] = 192584,
          ["ilvl"] = 325,
          ["crit"] = 926,
          ["haste"] = 1216,
          ["mastery"] = 621,
          ["vers"] = 172,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhx2MzYWGAAgZmlZZmZWGDAYDGYWMaMDgZBsMAAAMDAAMzgxMmZYmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Oiledbody",
          ["guild"] = "Aotic",
          ["boss"] = "Sszorak",
          ["amount"] = 192461,
          ["ilvl"] = 324,
          ["crit"] = 1016,
          ["haste"] = 1044,
          ["mastery"] = 822,
          ["vers"] = 141,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAsZmxMjmNmxMzYWGAAgZmlZZmZWGDAYBGYWMaMDgZDsMAAAMDAAMzgZmxMMmhZGzMjBzMzMAgZgB"
        },
        {
          ["name"] = "千雪加油努力",
          ["guild"] = "THE SHADOWS",
          ["boss"] = "Sszorak",
          ["amount"] = 191793,
          ["ilvl"] = 328,
          ["crit"] = 970,
          ["haste"] = 1141,
          ["mastery"] = 764,
          ["vers"] = 174,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjZGmZYmxMzYwMzMAAzAD"
        },
        {
          ["name"] = "Arklan",
          ["guild"] = "Fraudes",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 266976,
          ["ilvl"] = 321,
          ["crit"] = 1277,
          ["haste"] = 1182,
          ["mastery"] = 496,
          ["vers"] = 183,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMWmZmZWGAAwMzsMLzMzyYAALwAziRjZAMLglBAAgZAAgZGMzMGjhhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Barbecuesorc",
          ["guild"] = "Pig Pen",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 248902,
          ["ilvl"] = 328,
          ["crit"] = 1306,
          ["haste"] = 793,
          ["mastery"] = 426,
          ["vers"] = 526,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMDNbMWmZmZWGAAgZmlZZmZWGDAYBGYWMaMDgZBsMAAAMDAAMzgZmxYMmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Pfw",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 240342,
          ["ilvl"] = 318,
          ["crit"] = 1025,
          ["haste"] = 1233,
          ["mastery"] = 708,
          ["vers"] = 282,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZzMWmZmZWGAAwMzsMbzMz2YAgx2yADYAzwWghtBAAgZAAAMzwMGDGzYmZmZYYmZGAgBMA"
        },
        {
          ["name"] = "Reoru",
          ["guild"] = "WICKED",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 235715,
          ["ilvl"] = 325,
          ["crit"] = 1379,
          ["haste"] = 1105,
          ["mastery"] = 382,
          ["vers"] = 258,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAgxMzoZzMWmZmZWGAAgZmlZZmZWGDAYBGYWMaMDgZBsMAAAMDAAMzgZmxYYmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Vïzër",
          ["guild"] = "Nerd Rage",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 223071,
          ["ilvl"] = 327,
          ["crit"] = 1307,
          ["haste"] = 837,
          ["mastery"] = 650,
          ["vers"] = 199,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzDMzoZjxyMzYWGAAwMzsMLmZWGDAM2WGYADYG2CMsNAAAMDAAgZmxMmZMGzYMzMzYYmZmBAMgB"
        },
        {
          ["name"] = "Poneybøy",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 268007,
          ["ilvl"] = 327,
          ["crit"] = 1067,
          ["haste"] = 1065,
          ["mastery"] = 821,
          ["vers"] = 392,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmtBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMYMDmNzMMzYmZMYmZmBAMDMA"
        },
        {
          ["name"] = "Kellso",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 263145,
          ["ilvl"] = 327,
          ["crit"] = 937,
          ["haste"] = 1267,
          ["mastery"] = 750,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjxsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Coffee",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 261889,
          ["ilvl"] = 326,
          ["crit"] = 1070,
          ["haste"] = 1353,
          ["mastery"] = 450,
          ["vers"] = 264,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjxsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Haykok",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 261819,
          ["ilvl"] = 327,
          ["crit"] = 1085,
          ["haste"] = 1086,
          ["mastery"] = 544,
          ["vers"] = 294,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmtBAAYmZZWmZmlxAAWgBmFjGzAYWALDAAAzAAAzMwMjxwMDzMmZGDmZmZAAzAD"
        },
        {
          ["name"] = "Gregl",
          ["guild"] = "Infinity",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 261275,
          ["ilvl"] = 326,
          ["crit"] = 1425,
          ["haste"] = 1261,
          ["mastery"] = 495,
          ["vers"] = 147,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjxsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Lausen",
          ["guild"] = "The Next Step",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 260455,
          ["ilvl"] = 327,
          ["crit"] = 1387,
          ["haste"] = 1070,
          ["mastery"] = 588,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjxsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Pfw",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 258033,
          ["ilvl"] = 326,
          ["crit"] = 1217,
          ["haste"] = 1290,
          ["mastery"] = 467,
          ["vers"] = 339,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjxsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Kolwl",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 257578,
          ["ilvl"] = 328,
          ["crit"] = 1274,
          ["haste"] = 1304,
          ["mastery"] = 481,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAwAAAzMwMzMmtZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "Shn",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 256835,
          ["ilvl"] = 325,
          ["crit"] = 1343,
          ["haste"] = 1362,
          ["mastery"] = 446,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMzMGmZYmxMzYwMzMAAzAD"
        },
        {
          ["name"] = "일산구흑마법사",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 256394,
          ["ilvl"] = 328,
          ["crit"] = 1155,
          ["haste"] = 1320,
          ["mastery"] = 483,
          ["vers"] = 253,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGAzCYZAAAYGAAYmBzMjxsZmhZGzMjBzMzAAMDMA"
        },
        {
          ["name"] = "小树可是真菜",
          ["guild"] = "鸽王世家",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 315838,
          ["ilvl"] = 324,
          ["crit"] = 977,
          ["haste"] = 1207,
          ["mastery"] = 705,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMMzoZbMz2MzMzyAAAmZmlZxMzyYAgx2yADYAzwWghtBAAgZAAAMzMzMmhxYGjZmZGDzMzAAMgB"
        },
        {
          ["name"] = "죽음의강력공걱맨",
          ["guild"] = "인앤아웃",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 311695,
          ["ilvl"] = 324,
          ["crit"] = 1168,
          ["haste"] = 1358,
          ["mastery"] = 412,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZGzyAAAmZmlZxMzyYAgx2yADYAzwWghtBAAgZAAAMzMzMmZMGzYMzMzYYmZGAgBMA"
        },
        {
          ["name"] = "죽음의강럭공격맨",
          ["guild"] = "One of a Kind",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 310612,
          ["ilvl"] = 319,
          ["crit"] = 1039,
          ["haste"] = 1388,
          ["mastery"] = 650,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZGzyAAAmZmlZxMzyYAgx2yADYAzwWghtBAAgZAAAMzMzMmZMGzYMzMzYYmZGAgBMA"
        },
        {
          ["name"] = "흑샤니",
          ["guild"] = "인앤아웃",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 307135,
          ["ilvl"] = 328,
          ["crit"] = 1285,
          ["haste"] = 962,
          ["mastery"] = 605,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZGzyAAAmZmlZxMzyYAgx2yADYAzwWghtBAAgZAAAMzMzMmZMGzYMzMzYYmZGAgBMA"
        },
        {
          ["name"] = "华尔兹尔华",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 306421,
          ["ilvl"] = 322,
          ["crit"] = 1203,
          ["haste"] = 764,
          ["mastery"] = 832,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNbmZ2mZGzyAAAMzsMLmZWGDAM2WGYADYG2CMsNAAAMDAAgZmxMmZMzYGjZmZGDzMzAAMgB"
        },
        {
          ["name"] = "埃索达尔",
          ["guild"] = "Dim Moon",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 301746,
          ["ilvl"] = 327,
          ["crit"] = 1259,
          ["haste"] = 1325,
          ["mastery"] = 478,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZGz2AAAmZmlZzMzyYAgx22ADYAzwWghtBAAgZAAAMzMmxMz2YMjxMzMjhZmZAAGwA"
        },
        {
          ["name"] = "Zachx",
          ["guild"] = "Rain",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 301403,
          ["ilvl"] = 323,
          ["crit"] = 1046,
          ["haste"] = 1303,
          ["mastery"] = 716,
          ["vers"] = 91,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZGz2AAAmZmlZxMzyYAgx2yADYAzwSghtBAAgZAAAMzMzMmZMGzYMzMzYYmZGAgBMA"
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 300409,
          ["ilvl"] = 328,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["potion"] = nil,
          ["talents"] = ""
        },
        {
          ["name"] = "Barkgrønar",
          ["guild"] = "Fragglene",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 299684,
          ["ilvl"] = 329,
          ["crit"] = 1152,
          ["haste"] = 1356,
          ["mastery"] = 440,
          ["vers"] = 83,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbmx2MzYWGAAwMzsMLmZWGDAM2WGYADYG2CMsNAAAMDAAgZmZmxMjxYGjZmZGDzMzAAMgB"
        },
        {
          ["name"] = "Azorahai",
          ["guild"] = "Milkin Time",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 296732,
          ["ilvl"] = 323,
          ["crit"] = 891,
          ["haste"] = 1135,
          ["mastery"] = 640,
          ["vers"] = 324,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CkQAAAAAAAAAAAAAAAAAAAAAAgxMzMNbM2mZGzyAAAmZmlZxMzyYAgx22ADYAzwWghtBAAgZAAAMzMmxMz2YMjxMzMjhZmZAAGwA"
        }
      }
    },
    {
      ["spec"] = "Demonology",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "흑샤니",
          ["guild"] = "인앤아웃",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 257524,
          ["ilvl"] = 328,
          ["crit"] = 1285,
          ["haste"] = 962,
          ["mastery"] = 605,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Нюдси",
          ["guild"] = "Инвиктус",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 252478,
          ["ilvl"] = 322,
          ["crit"] = 1149,
          ["haste"] = 929,
          ["mastery"] = 772,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZGzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBYmZMzAAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "埃索达尔",
          ["guild"] = "Dim Moon",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 252161,
          ["ilvl"] = 326,
          ["crit"] = 1444,
          ["haste"] = 858,
          ["mastery"] = 577,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmZmtBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "席露",
          ["guild"] = "不羁的肥皂厂12.0",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 250888,
          ["ilvl"] = 326,
          ["crit"] = 1382,
          ["haste"] = 754,
          ["mastery"] = 762,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjhZmxsNAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Yungseamen",
          ["guild"] = "Hollowed",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 249866,
          ["ilvl"] = 320,
          ["crit"] = 1206,
          ["haste"] = 784,
          ["mastery"] = 610,
          ["vers"] = 370,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjhZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Nevermoove",
          ["guild"] = "Pure",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 249501,
          ["ilvl"] = 328,
          ["crit"] = 1221,
          ["haste"] = 950,
          ["mastery"] = 704,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMegZmpZjxyMzMz2AAAAAAAAGzYYDGYbYhGWMmZsMLzMzYGAYmxMzYmBYmZMGAAgxMzMGGWmxAGA"
        },
        {
          ["name"] = "Bssi",
          ["guild"] = "Interstellar Bum Orcs",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 248034,
          ["ilvl"] = 323,
          ["crit"] = 1284,
          ["haste"] = 734,
          ["mastery"] = 807,
          ["vers"] = 260,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDwMzwMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Nyrolock",
          ["guild"] = "baited",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 247483,
          ["ilvl"] = 326,
          ["crit"] = 1395,
          ["haste"] = 820,
          ["mastery"] = 608,
          ["vers"] = 296,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "杰尼儿",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 247264,
          ["ilvl"] = 327,
          ["crit"] = 1340,
          ["haste"] = 910,
          ["mastery"] = 667,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDAzYmBAAYMzMzMMsMjBMA"
        },
        {
          ["name"] = "Wrayenne",
          ["guild"] = "Muisted",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 246618,
          ["ilvl"] = 326,
          ["crit"] = 1240,
          ["haste"] = 837,
          ["mastery"] = 806,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGjBAAYMzMzMMsMjBMA"
        },
        {
          ["name"] = "Tulparlock",
          ["guild"] = "月刃",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 259865,
          ["ilvl"] = 327,
          ["crit"] = 1224,
          ["haste"] = 1023,
          ["mastery"] = 652,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjx2MzYWGAAAAAAAwYGDLwAbDL0wixMjlZZmZGzAAzMmZGzMAzMDzAAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "埃索达尔",
          ["guild"] = "Dim Moon",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 255772,
          ["ilvl"] = 327,
          ["crit"] = 1474,
          ["haste"] = 857,
          ["mastery"] = 556,
          ["vers"] = 199,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjZMzMzsNAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAMzYGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Eonjr",
          ["guild"] = "Scuffed",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 238531,
          ["ilvl"] = 329,
          ["crit"] = 1302,
          ["haste"] = 840,
          ["mastery"] = 631,
          ["vers"] = 328,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjhZmxsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Scorpylock",
          ["guild"] = "baited",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 237607,
          ["ilvl"] = 326,
          ["crit"] = 1264,
          ["haste"] = 724,
          ["mastery"] = 637,
          ["vers"] = 382,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjZMzMmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMzMMsMjBMA"
        },
        {
          ["name"] = "异世界情緒",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 227328,
          ["ilvl"] = 323,
          ["crit"] = 1094,
          ["haste"] = 1030,
          ["mastery"] = 863,
          ["vers"] = 64,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "灰色原本哀殇",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 225218,
          ["ilvl"] = 324,
          ["crit"] = 1004,
          ["haste"] = 1127,
          ["mastery"] = 678,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmxsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Рофолошка",
          ["guild"] = "Без Лжи",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224708,
          ["ilvl"] = 323,
          ["crit"] = 1270,
          ["haste"] = 1235,
          ["mastery"] = 481,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMMzoZzMz2MzYWGAAAAAAAwYGDLwAbDL0wixMjlZZmZGzAAzMmZGzMAzMjZsBAAGzMzYYYZGDYA"
        },
        {
          ["name"] = "Fisko",
          ["guild"] = "Проксима",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224093,
          ["ilvl"] = 324,
          ["crit"] = 1460,
          ["haste"] = 938,
          ["mastery"] = 549,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGjBAAYMzMzMMsMjBMA"
        },
        {
          ["name"] = "Chubbycheek",
          ["guild"] = "Drama",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 221109,
          ["ilvl"] = 326,
          ["crit"] = 1190,
          ["haste"] = 759,
          ["mastery"] = 855,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMegZmpZjxyMzMzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBYmZMGAAgxMzMGGWmxAGA"
        },
        {
          ["name"] = "Robinwl",
          ["guild"] = "Northern Sky",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 220282,
          ["ilvl"] = 327,
          ["crit"] = 1218,
          ["haste"] = 991,
          ["mastery"] = 597,
          ["vers"] = 190,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGmZBAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "窃灵",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 400044,
          ["ilvl"] = 323,
          ["crit"] = 1261,
          ["haste"] = 871,
          ["mastery"] = 746,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMMzoZzMz2MzYWGAAAAAAAwYGDLwAbDL0wixMjlZbmZGzAAzMGzMzMAjZMzsBAAGzMzYYYZGDYA"
        },
        {
          ["name"] = "小沈起门",
          ["guild"] = "B L C",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 397862,
          ["ilvl"] = 318,
          ["crit"] = 1041,
          ["haste"] = 990,
          ["mastery"] = 696,
          ["vers"] = 287,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbjZMzMzsNAAAAAAAgxMGWgB2G2ohFjZGLzyMzMmBAmZMmZmZAMzYMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Larolas",
          ["guild"] = "Debauchéry Tea Party",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 397724,
          ["ilvl"] = 325,
          ["crit"] = 1109,
          ["haste"] = 908,
          ["mastery"] = 803,
          ["vers"] = 133,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjZYmxsMAAAAAAAgxMGWgB2GWohFjZGLz2MzMmBAmZMmZmZAm5BmZmBAAYMzMjhhlZMgB"
        },
        {
          ["name"] = "小锅初号机",
          ["guild"] = "B L C",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 393082,
          ["ilvl"] = 325,
          ["crit"] = 1056,
          ["haste"] = 1159,
          ["mastery"] = 831,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMjZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjxMzMDwMzYGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Лвнг",
          ["guild"] = "Нулевая видимость",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 387285,
          ["ilvl"] = 325,
          ["crit"] = 1262,
          ["haste"] = 895,
          ["mastery"] = 472,
          ["vers"] = 319,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzMNLMjZmxsMAAAAAAAgxMGWgB2GWohFjZGLz2MzMmBAmZMmZmZAmZGGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Skellestone",
          ["guild"] = "Unethical",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 385952,
          ["ilvl"] = 324,
          ["crit"] = 1278,
          ["haste"] = 638,
          ["mastery"] = 859,
          ["vers"] = 260,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjZ2mZGzyAAAAAAAAGzYYBGYbYhGWMmZsMbzMzYGAYmxYmZmBYMjxAAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "顾灬俊皓",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 383806,
          ["ilvl"] = 322,
          ["crit"] = 1062,
          ["haste"] = 880,
          ["mastery"] = 864,
          ["vers"] = 207,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbmZ2mZmZWGAAAAAAAwYGDLwAbDL0wixMjlZbmZGzAAzMGzMzMAjZwsBAAGzMzYYYZGDYA"
        },
        {
          ["name"] = "Hailene",
          ["guild"] = "Nineteen Reasons Why",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 381340,
          ["ilvl"] = 324,
          ["crit"] = 1410,
          ["haste"] = 669,
          ["mastery"] = 698,
          ["vers"] = 270,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 334
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMjZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZ2mZmxMAwMjxMzMDwMzYGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Booruce",
          ["guild"] = "Spiral Out",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 380698,
          ["ilvl"] = 327,
          ["crit"] = 1043,
          ["haste"] = 927,
          ["mastery"] = 784,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjZMzMmlBAAAAAAAMmxwCMw2wCNsYMzYZ2mZmxMAwMjxMzMDwMzYGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "沈浪丶",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 379770,
          ["ilvl"] = 327,
          ["crit"] = 1055,
          ["haste"] = 1016,
          ["mastery"] = 680,
          ["vers"] = 263,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjZ2mZGz2AAAAAAAAGzYYBGYbYhGWMmZsMbzMzYGAYmxYmZmBYmZYAAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "埃索达尔",
          ["guild"] = "Dim Moon",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 339737,
          ["ilvl"] = 328,
          ["crit"] = 1478,
          ["haste"] = 857,
          ["mastery"] = 558,
          ["vers"] = 199,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjZMzMzsNAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAMzYGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Nyrolock",
          ["guild"] = "baited",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 339411,
          ["ilvl"] = 326,
          ["crit"] = 1388,
          ["haste"] = 688,
          ["mastery"] = 723,
          ["vers"] = 296,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Fisor",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 331976,
          ["ilvl"] = 328,
          ["crit"] = 1165,
          ["haste"] = 886,
          ["mastery"] = 796,
          ["vers"] = 237,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAgxMzoZjZ2mZGz2AAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxYmZmBYmZMzAAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "Livevil",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 329579,
          ["ilvl"] = 326,
          ["crit"] = 1247,
          ["haste"] = 829,
          ["mastery"] = 880,
          ["vers"] = 251,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMz2MzYWGAAAAAAAwYGDLwAbDL0wixMjlZZmZGzAAzMmZGzMAzMjZAAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "Lockyschönee",
          ["guild"] = "Husk at Crit",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 329152,
          ["ilvl"] = 326,
          ["crit"] = 1355,
          ["haste"] = 731,
          ["mastery"] = 778,
          ["vers"] = 157,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbMWmZmZWGAAAAAAAwYGDLwAbDL0wixMjlZZmZGzAAzMmZGzMAzMjZGAAgxMzMGGWmxAGA"
        },
        {
          ["name"] = "龍蛋蛋",
          ["guild"] = "For the Glory of JO JO",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 325238,
          ["ilvl"] = 324,
          ["crit"] = 1271,
          ["haste"] = 825,
          ["mastery"] = 676,
          ["vers"] = 192,
          ["trinkets"] = {
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMjZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZ2mZmxMAwMjZmxMDwMzYMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Robinwl",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 324771,
          ["ilvl"] = 327,
          ["crit"] = 1218,
          ["haste"] = 991,
          ["mastery"] = 597,
          ["vers"] = 190,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGmZBAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "Muffnz",
          ["guild"] = "Shade",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 317571,
          ["ilvl"] = 326,
          ["crit"] = 1355,
          ["haste"] = 748,
          ["mastery"] = 733,
          ["vers"] = 203,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMjZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZ2mZmxMAwMjZmxMDwMzYGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "트롤여캐성기사",
          ["guild"] = "SEEREAL",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 316756,
          ["ilvl"] = 326,
          ["crit"] = 1124,
          ["haste"] = 943,
          ["mastery"] = 788,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZbMjZmxsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMmZmZAMzYMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Loonwhy",
          ["guild"] = "CMT",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 316561,
          ["ilvl"] = 327,
          ["crit"] = 1149,
          ["haste"] = 835,
          ["mastery"] = 715,
          ["vers"] = 317,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbmZWmZGzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBYmZYGAAgxMzMGGWmxAGA"
        },
        {
          ["name"] = "埃索达尔",
          ["guild"] = "Dim Moon",
          ["boss"] = "Sszorak",
          ["amount"] = 225884,
          ["ilvl"] = 328,
          ["crit"] = 1478,
          ["haste"] = 857,
          ["mastery"] = 558,
          ["vers"] = 199,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmZmtBAAAAAAAMmxwCMw2wCNsYMGLzyMzMmBAmZMzMmZAMzYmBAAYMzMjhZsMjBMA"
        },
        {
          ["name"] = "Scorpylock",
          ["guild"] = "baited",
          ["boss"] = "Sszorak",
          ["amount"] = 218049,
          ["ilvl"] = 324,
          ["crit"] = 1243,
          ["haste"] = 723,
          ["mastery"] = 634,
          ["vers"] = 372,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjZMzMmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMzMMsMjBMA"
        },
        {
          ["name"] = "Лвнг",
          ["guild"] = "Нулевая видимость",
          ["boss"] = "Sszorak",
          ["amount"] = 217503,
          ["ilvl"] = 328,
          ["crit"] = 1233,
          ["haste"] = 876,
          ["mastery"] = 601,
          ["vers"] = 319,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMMzMzsNAAAAAAAgxMGWgB2GWohFjxYZWmZmxMAwMjZmxMDwMzYmBAAYMzMjhZsMjBMA"
        },
        {
          ["name"] = "Zroed",
          ["guild"] = "YEP",
          ["boss"] = "Sszorak",
          ["amount"] = 217501,
          ["ilvl"] = 324,
          ["crit"] = 1037,
          ["haste"] = 922,
          ["mastery"] = 785,
          ["vers"] = 253,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMjZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Fisko",
          ["guild"] = "Проксима",
          ["boss"] = "Sszorak",
          ["amount"] = 216186,
          ["ilvl"] = 325,
          ["crit"] = 1423,
          ["haste"] = 758,
          ["mastery"] = 780,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGjBAAYMzMzMMsMjBMA"
        },
        {
          ["name"] = "Morgates",
          ["guild"] = "Nascent",
          ["boss"] = "Sszorak",
          ["amount"] = 216022,
          ["ilvl"] = 326,
          ["crit"] = 1335,
          ["haste"] = 894,
          ["mastery"] = 619,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjZMzMzsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAMzYGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "銀色飛行船",
          ["guild"] = "冷涩",
          ["boss"] = "Sszorak",
          ["amount"] = 215021,
          ["ilvl"] = 326,
          ["crit"] = 1361,
          ["haste"] = 887,
          ["mastery"] = 656,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMjZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGjZDAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "Eonjr",
          ["guild"] = "Scuffed",
          ["boss"] = "Sszorak",
          ["amount"] = 215002,
          ["ilvl"] = 329,
          ["crit"] = 1302,
          ["haste"] = 840,
          ["mastery"] = 631,
          ["vers"] = 328,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjZMzMzsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "트롤여캐성기사",
          ["guild"] = "SEEREAL",
          ["boss"] = "Sszorak",
          ["amount"] = 212983,
          ["ilvl"] = 327,
          ["crit"] = 1292,
          ["haste"] = 778,
          ["mastery"] = 789,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGjBAAYMzMzMMsMjBMA"
        },
        {
          ["name"] = "Robinwl",
          ["guild"] = "Northern Sky",
          ["boss"] = "Sszorak",
          ["amount"] = 212859,
          ["ilvl"] = 324,
          ["crit"] = 1261,
          ["haste"] = 911,
          ["mastery"] = 558,
          ["vers"] = 253,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbjZMzMmlBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDwMzYGAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "埃索达尔",
          ["guild"] = "Dim Moon",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 353422,
          ["ilvl"] = 327,
          ["crit"] = 1450,
          ["haste"] = 858,
          ["mastery"] = 577,
          ["vers"] = 198,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMWmZmZ2GAAAAAAAwYGDLwAbDL0wixMjlZZmZGzAAzMmZGzMAmZMzAAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "嘤嘤蘑菇",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 334726,
          ["ilvl"] = 326,
          ["crit"] = 1279,
          ["haste"] = 902,
          ["mastery"] = 793,
          ["vers"] = 204,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmxsMAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGmBAAYMzMzMMsMjBMA"
        },
        {
          ["name"] = "Eonjr",
          ["guild"] = "Scuffed",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 334384,
          ["ilvl"] = 329,
          ["crit"] = 1302,
          ["haste"] = 840,
          ["mastery"] = 631,
          ["vers"] = 328,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbjxyMzMzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBwMjxAAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "Loonwhy",
          ["guild"] = "CMT",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 330392,
          ["ilvl"] = 327,
          ["crit"] = 1277,
          ["haste"] = 888,
          ["mastery"] = 621,
          ["vers"] = 207,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbmZWmZGzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBYmZYGAAgxMzMGGWmxAGA"
        },
        {
          ["name"] = "Fisko",
          ["guild"] = "Проксима",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 326825,
          ["ilvl"] = 328,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["potion"] = nil,
          ["talents"] = ""
        },
        {
          ["name"] = "Droopy",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 323364,
          ["ilvl"] = 326,
          ["crit"] = 1321,
          ["haste"] = 791,
          ["mastery"] = 830,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMz2MzMz2AAAAAAAAGzYYBGYbYjGWMmZsMLzMzYGAYmxMzYmBYMDjNAAwYmZGDDLzYAD"
        },
        {
          ["name"] = "Elwitcher",
          ["guild"] = "SB Menagerie",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 323161,
          ["ilvl"] = 325,
          ["crit"] = 1342,
          ["haste"] = 949,
          ["mastery"] = 591,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAgxMzoZxMWmZGzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBYmZmxAAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "Killakin",
          ["guild"] = "Opposite",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 317518,
          ["ilvl"] = 324,
          ["crit"] = 1276,
          ["haste"] = 873,
          ["mastery"] = 708,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjxyMzMzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBwMDGAAgxMzMzwwyMGwA"
        },
        {
          ["name"] = "Babybrain",
          ["guild"] = "Consequence",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 316193,
          ["ilvl"] = 326,
          ["crit"] = 1326,
          ["haste"] = 929,
          ["mastery"] = 744,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMegZmpZhxyMzMzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBYmZMGAAgxMzMGGWmxAGA"
        },
        {
          ["name"] = "Morgates",
          ["guild"] = "Nascent",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 316087,
          ["ilvl"] = 324,
          ["crit"] = 1300,
          ["haste"] = 755,
          ["mastery"] = 751,
          ["vers"] = 183,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzDMzMNLMWmZGzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBwMjxAAAMmZmZGGWmxAGA"
        },
        {
          ["name"] = "Shn",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 403620,
          ["ilvl"] = 329,
          ["crit"] = 1349,
          ["haste"] = 1167,
          ["mastery"] = 580,
          ["vers"] = 1500,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsNAAAAAAAgxMGWgB2GWohFjZGLz2MzMmBAmZMmZmZAGzYmZBAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "일산구흑마법사",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 379997,
          ["ilvl"] = 327,
          ["crit"] = 1280,
          ["haste"] = 1196,
          ["mastery"] = 532,
          ["vers"] = 1451,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMmlBAAAAAAAMmxwCMw2wCNsYMzYZ2mZmxMAwMjxMzMDwMzYmZBAAMmZmxwwyMGwA"
        },
        {
          ["name"] = "Bukklao",
          ["guild"] = "Divergence",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 283186,
          ["ilvl"] = 325,
          ["crit"] = 1112,
          ["haste"] = 864,
          ["mastery"] = 710,
          ["vers"] = 313,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMMzMzsNAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "尐仦术",
          ["guild"] = "重逢",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 278910,
          ["ilvl"] = 324,
          ["crit"] = 1187,
          ["haste"] = 869,
          ["mastery"] = 886,
          ["vers"] = 135,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmxsNAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Durtylock",
          ["guild"] = "nVus",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 271762,
          ["ilvl"] = 325,
          ["crit"] = 1367,
          ["haste"] = 651,
          ["mastery"] = 736,
          ["vers"] = 281,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMjZmxsNAAAAAAAgxMGWgB2GWohFjZGLzyMzMmBAmZMzMmZAmZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Qiaoqi",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 270540,
          ["ilvl"] = 325,
          ["crit"] = 1252,
          ["haste"] = 973,
          ["mastery"] = 720,
          ["vers"] = 41,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmhZGNbmx2MzYWGAAAAAAAwYGDLwAbDb0wixMjlZbmZGzAAzMGzMzMAzMDzsBAAGzMzYYYZGDYA"
        },
        {
          ["name"] = "Baykerztwo",
          ["guild"] = "The Full Stick",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 269465,
          ["ilvl"] = 317,
          ["crit"] = 1159,
          ["haste"] = 872,
          ["mastery"] = 553,
          ["vers"] = 348,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbmx2MzYWGAAAAAAAwYGDLwAbDL0wixMjlZZmZGzAAzMmZGzMAzMjZGAAgxMzMGGWmxAGA"
        },
        {
          ["name"] = "Paithy",
          ["guild"] = "Quichons",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 268551,
          ["ilvl"] = 317,
          ["crit"] = 1331,
          ["haste"] = 906,
          ["mastery"] = 537,
          ["vers"] = 167,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 311
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMMzoZzMz2MzMzyAAAAAAAAGzYYBGYbYhGWMmZsMbzMzYGAYmxYmZmBYMjZGAAgxMzMGGWmxAGA"
        },
        {
          ["name"] = "Silph",
          ["guild"] = "Sylvanas Garde",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 268308,
          ["ilvl"] = 324,
          ["crit"] = 1272,
          ["haste"] = 834,
          ["mastery"] = 547,
          ["vers"] = 382,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmtBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGjBAAYMzMzMMsMjBMA"
        },
        {
          ["name"] = "埃索达尔",
          ["guild"] = "Dim Moon",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 268073,
          ["ilvl"] = 327,
          ["crit"] = 1450,
          ["haste"] = 858,
          ["mastery"] = 577,
          ["vers"] = 198,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmZmtBAAAAAAAMmxwCMw2wCNsYMzYZWmZmxMAwMjZmxMDgZGzMAAAjZmZMMsMjBMA"
        },
        {
          ["name"] = "Sikarilock",
          ["guild"] = "Profanities",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 267873,
          ["ilvl"] = 327,
          ["crit"] = 1109,
          ["haste"] = 963,
          ["mastery"] = 810,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAgZMzoZxM2mZGzyAAAAAAAAGzYYBGYbYhGWMmZsMbzMzYGAYmxMzYmBYMzYmNAAwYmZmZYYbGDYA"
        },
        {
          ["name"] = "Damnology",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 267363,
          ["ilvl"] = 319,
          ["crit"] = 1088,
          ["haste"] = 889,
          ["mastery"] = 879,
          ["vers"] = 290,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CoQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMz2MzMzyAAAAAAAAGzYYBGYbYhGWMmZsMLzMzYGAYmxMzYmBwMjZAAAMmZmxwwyMGwA"
        }
      }
    },
    {
      ["spec"] = "Destruction",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Kiralock",
          ["guild"] = "Retired Extremely Bad",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 213905,
          ["ilvl"] = 322,
          ["crit"] = 1159,
          ["haste"] = 799,
          ["mastery"] = 912,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYmZmZGNbMWmZmZWmlZmZmFjZbxMAAYGjZmZxCMwsY0YGAzG2YAAgxAsBAMzAmxYAAAYmZGAAGDD"
        },
        {
          ["name"] = "Summergale",
          ["guild"] = "Scallywags",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 205294,
          ["ilvl"] = 321,
          ["crit"] = 653,
          ["haste"] = 917,
          ["mastery"] = 1115,
          ["vers"] = 249,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMjZmZmlZZmZmZxY2WMDAAmxYmZWsBDMLGNmBwshNGAAYMAbAAzMYMjZsBAAYmZGAAGDD"
        },
        {
          ["name"] = "Diivil",
          ["guild"] = "뜨겁다",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 204870,
          ["ilvl"] = 322,
          ["crit"] = 1026,
          ["haste"] = 917,
          ["mastery"] = 836,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAgZmZmpZzM2mZGz2sMzMzsYMbLmBAAzYMzML2gBmFjGzAY2wGDAAMGgNAgZGwMGDAAAzMzMAAGDD"
        },
        {
          ["name"] = "Pêntex",
          ["guild"] = "Burden",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 204483,
          ["ilvl"] = 325,
          ["crit"] = 991,
          ["haste"] = 975,
          ["mastery"] = 1127,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmxsMLzMzMLGz2iHYAAwMzYmZWsADMLGNmBwshNGAAYMAbAAzMYmZMGAAAmZmZAAMGG"
        },
        {
          ["name"] = "Handywandy",
          ["guild"] = "The Silent Circle",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 203406,
          ["ilvl"] = 323,
          ["crit"] = 1116,
          ["haste"] = 888,
          ["mastery"] = 943,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlZZmZmZxY2WMDAAmxYmZWsBDMLGNmBwshNGAAYMAbAAzMYmZMGAAAmZmBAgxwA"
        },
        {
          ["name"] = "Zroed",
          ["guild"] = "YEP",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 202277,
          ["ilvl"] = 324,
          ["crit"] = 1037,
          ["haste"] = 922,
          ["mastery"] = 785,
          ["vers"] = 253,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMz2MzYWmlZmZmFjZbxMAAYGjZmZxCMwsY0YGAzG2YAAgxAsBAMzgZmxMAAAYmZGAAGDD"
        },
        {
          ["name"] = "Jubeto",
          ["guild"] = "뜨겁다",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 202176,
          ["ilvl"] = 322,
          ["crit"] = 1024,
          ["haste"] = 893,
          ["mastery"] = 801,
          ["vers"] = 228,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAgZmZmpZzM2mZGz2sMzMzsYMbLmBAAzYMzML2gBmFjGzAY2wGDAAMGgNAgZGwMGDAAAzMzMAAGDD"
        },
        {
          ["name"] = "Valyphar",
          ["guild"] = "Vibrant",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 201753,
          ["ilvl"] = 326,
          ["crit"] = 1148,
          ["haste"] = 872,
          ["mastery"] = 957,
          ["vers"] = 178,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZmZWmlZmZmFzMbLegBAAzYMzMLWgBmFjGzAY2wGDAAMGgNAgZGMzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Rosenrot",
          ["guild"] = "High Quality",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 201690,
          ["ilvl"] = 325,
          ["crit"] = 1068,
          ["haste"] = 660,
          ["mastery"] = 1149,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZbMMzMzsNLzMzMLGz2iZAAwMGzMziFYgZxoxMAmNsxAAAjBYDAYmBmZMGAAAmZmBAgxwA"
        },
        {
          ["name"] = "Akigrim",
          ["guild"] = "Group Finders Guide",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 201504,
          ["ilvl"] = 324,
          ["crit"] = 916,
          ["haste"] = 1077,
          ["mastery"] = 937,
          ["vers"] = 219,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMegZmpZzM2mZmZWmlZmZmFzMLLMAAYGjZmZxCMwsY0YGAzG2YAAgxghNAgZGMzMYAAAYmZGAAGDD"
        },
        {
          ["name"] = "Morgates",
          ["guild"] = "Nascent",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 284284,
          ["ilvl"] = 326,
          ["crit"] = 1335,
          ["haste"] = 894,
          ["mastery"] = 619,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMLzMzMLGz2iHYAAwMzYmZWsADMLGNmBwshNGAAYMAbAAzMYmZMmNAAAzMzAAwYYA"
        },
        {
          ["name"] = "일산구흑마법사",
          ["guild"] = "Mate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 280648,
          ["ilvl"] = 327,
          ["crit"] = 1221,
          ["haste"] = 821,
          ["mastery"] = 697,
          ["vers"] = 325,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsNLzMzMLGz2iHYAAwMGzMziFYgZxoxMAmNsxAAAjBGbAAzMYmZMmNAAAzMzAAwYYA"
        },
        {
          ["name"] = "트롤여캐성기사",
          ["guild"] = "SEEREAL",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 277648,
          ["ilvl"] = 325,
          ["crit"] = 1082,
          ["haste"] = 913,
          ["mastery"] = 876,
          ["vers"] = 174,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlZZMzMLGz2iHYAAwMzYmZWsADMLGNmBwshNGAAYMAbAAzMYMjxAAAwMzMDAAzwA"
        },
        {
          ["name"] = "Rískí",
          ["guild"] = "Slack",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 275672,
          ["ilvl"] = 326,
          ["crit"] = 1008,
          ["haste"] = 914,
          ["mastery"] = 1006,
          ["vers"] = 126,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMzmZmZWmlZmZmFjZbxMAAYGjZmZxGMwsY0YGAzG2YAAgxAsBAMzgZmxMAAAYmZGAAGDD"
        },
        {
          ["name"] = "Falkeron",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 274406,
          ["ilvl"] = 328,
          ["crit"] = 1184,
          ["haste"] = 872,
          ["mastery"] = 1018,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlZZmZmZxY2W8ADAAmZGzMziFYgZxoxMAmNsxAAAjBYDAYmBMzMGAAAmZmZAAMGG"
        },
        {
          ["name"] = "Babybrain",
          ["guild"] = "Consequence",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 274090,
          ["ilvl"] = 326,
          ["crit"] = 1161,
          ["haste"] = 929,
          ["mastery"] = 909,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZbMMzMzsMLzMzMLGz2iHYAAwMzYmZWsBDMLGNmBwshNGAAYMAbAAzMwMjxAAAwMzMAAMGG"
        },
        {
          ["name"] = "芋泥仙草",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 273249,
          ["ilvl"] = 326,
          ["crit"] = 1205,
          ["haste"] = 934,
          ["mastery"] = 922,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYMzMzoZjhZmZmtZZmZmZxY2WYAAwMzYmZWsBDMLGNmBwshNGAAYMwYDAYmBmZMGAAAmZmZAAMGG"
        },
        {
          ["name"] = "Qiaoqi",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 271526,
          ["ilvl"] = 325,
          ["crit"] = 1252,
          ["haste"] = 973,
          ["mastery"] = 720,
          ["vers"] = 41,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjhZmxsNLzMzMLGz2iHYAAwMGzMziFYgZxoxMAmNsxAAAjBGbAAzMYmZMzAAAwMzMAAMGG"
        },
        {
          ["name"] = "Hannumon",
          ["guild"] = "Slack",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 271215,
          ["ilvl"] = 325,
          ["crit"] = 1024,
          ["haste"] = 949,
          ["mastery"] = 752,
          ["vers"] = 310,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMLzMzMLGz2iZAAwMGzMziFYgZxoxMAmNsxAAAjBYDAYmBzMjxsBAAYmZGAAGDD"
        },
        {
          ["name"] = "Mattmurdock",
          ["guild"] = "Skill Issue",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 270677,
          ["ilvl"] = 323,
          ["crit"] = 1133,
          ["haste"] = 824,
          ["mastery"] = 852,
          ["vers"] = 186,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 324
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmZmlZZmZmZxY2W8ADAAmZGzMziFYgZxoxMAmNsxAAAjBYDAYmBzMjxAAAwMzMAAMGG"
        },
        {
          ["name"] = "Sitomey",
          ["guild"] = "The Depraved",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 292390,
          ["ilvl"] = 326,
          ["crit"] = 1123,
          ["haste"] = 913,
          ["mastery"] = 704,
          ["vers"] = 266,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjZMzMzsMLzMzMLmZ2WYAAwMGzMziFYgZxoxMAmNsxAAAjBDbAAzMwMjxAAAwMzMAAMGG"
        },
        {
          ["name"] = "Rosenrot",
          ["guild"] = "High Quality",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 282002,
          ["ilvl"] = 325,
          ["crit"] = 1068,
          ["haste"] = 663,
          ["mastery"] = 1150,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZbMMzMzsNLzMzMLmZ2WYAAwMGzMziFYgZxoxMAmNsxAAAjBDbAAzMwMjxAAAwMzMAAMGG"
        },
        {
          ["name"] = "Bloise",
          ["guild"] = "A Necessary Evil",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 267500,
          ["ilvl"] = 323,
          ["crit"] = 919,
          ["haste"] = 899,
          ["mastery"] = 1061,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhZ2MzYWmlZmZmFzMbLMAAYGjZmZxCMwsY0YGAzG2YAAgxghNAgZGMmxYAAAYmZmBAwYYA"
        },
        {
          ["name"] = "Falkeron",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 266489,
          ["ilvl"] = 318,
          ["crit"] = 919,
          ["haste"] = 1202,
          ["mastery"] = 833,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhZ2MzYWmlZmZmFzMbLMAAYGjZmZxCMwsY0YGAzG2YAAgxghNAgZGMmxYAAAYmZmBAwYYA"
        },
        {
          ["name"] = "Intns",
          ["guild"] = "Vestige",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 263134,
          ["ilvl"] = 327,
          ["crit"] = 1218,
          ["haste"] = 1120,
          ["mastery"] = 614,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhZ2MzYWmlZmZmFzMbLMAAYGjZmZxCMwsY0YGAzG2YAAgxghNAgZGMmxYAAAYmZmBAwYYA"
        },
        {
          ["name"] = "Vut",
          ["guild"] = "DILFZ",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 261019,
          ["ilvl"] = 322,
          ["crit"] = 1070,
          ["haste"] = 695,
          ["mastery"] = 965,
          ["vers"] = 196,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMzmZmZWmlZmZmFzMbLMAAYGjZmZxGMwsY0YGAzG2YAAgxghNAgZGMzMmBAAAzMzAAwYYA"
        },
        {
          ["name"] = "Tinkersoul",
          ["guild"] = "Rabid Porcupine",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 254259,
          ["ilvl"] = 324,
          ["crit"] = 1062,
          ["haste"] = 810,
          ["mastery"] = 1035,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjZMzMmlZZmZmZxMz2CDAAmxYmZWsADMLGNmBwshNGAAYMYYDAYmBzMjxAAAwMzMAAMGG"
        },
        {
          ["name"] = "Summergale",
          ["guild"] = "Scallywags",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 254236,
          ["ilvl"] = 325,
          ["crit"] = 676,
          ["haste"] = 1024,
          ["mastery"] = 1109,
          ["vers"] = 196,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMjZmZmlZZmZmZxMz2CDAAmxYmZWsBDMLGNmBwshNGAAYMYYDAYmBjZMjNAAAzMzAAwYYA"
        },
        {
          ["name"] = "Diivil",
          ["guild"] = "뜨겁다",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 253715,
          ["ilvl"] = 321,
          ["crit"] = 1019,
          ["haste"] = 911,
          ["mastery"] = 833,
          ["vers"] = 193,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAgZmZmpZjZ2mZGz2sMzMzsYmZbhBAAzYMzML2gBmFjGzAY2wGDAAMGMsBAMzAmxYAAAYmZmBAwYYA"
        },
        {
          ["name"] = "흑샤니",
          ["guild"] = "인앤아웃",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 253366,
          ["ilvl"] = 313,
          ["crit"] = 880,
          ["haste"] = 1026,
          ["mastery"] = 1023,
          ["vers"] = 38,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLM2mZmZWmlZmZmFzMbLMAAYGjZmZxGMwsY0YGAzG2YAAgxghNAgZGMzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "銀色飛行船",
          ["guild"] = "冷涩",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 340580,
          ["ilvl"] = 327,
          ["crit"] = 960,
          ["haste"] = 827,
          ["mastery"] = 1153,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlZZmZmZxYWWMDAAmxYmZWsADMLGNmBwshNGAAYMAbAAzMYmZMGAAAmZmBAgxwA"
        },
        {
          ["name"] = "Zedrad",
          ["guild"] = "Offline",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 338399,
          ["ilvl"] = 326,
          ["crit"] = 1141,
          ["haste"] = 652,
          ["mastery"] = 933,
          ["vers"] = 331,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYmZmZGNbMMzMmlZZmZmZxYWWYAAwMzYmZWsADMLGNmBwshNGAAYMwYDAYmBmZMmNAAAzMzAAwYYA"
        },
        {
          ["name"] = "Shadowsbad",
          ["guild"] = "Ethical",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 337772,
          ["ilvl"] = 326,
          ["crit"] = 1133,
          ["haste"] = 1017,
          ["mastery"] = 930,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmxsMLzMzMLGzyiHYAAwMzYmZWsADMLGNmBwshNGAAYMAbAAzMYmZMzAAAwMzMAAMGG"
        },
        {
          ["name"] = "Selarât",
          ["guild"] = "The Amazing Zoo",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 334910,
          ["ilvl"] = 327,
          ["crit"] = 1403,
          ["haste"] = 758,
          ["mastery"] = 880,
          ["vers"] = 16,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZxMWMzMzysMzMzsYMLLmBAAzYMzMLWgBmFjGzAY2wGDAAMGgNAgZGMmxYAAAYmZGAAGDD"
        },
        {
          ["name"] = "Poneybøy",
          ["guild"] = "Wave",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 330305,
          ["ilvl"] = 326,
          ["crit"] = 1135,
          ["haste"] = 808,
          ["mastery"] = 821,
          ["vers"] = 291,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmtZZmZmZxYWW8ADAAmZGzMziFYgZxoxMAmNsxAAAjBYDAYmBmZMGAAAmZmZAAMGG"
        },
        {
          ["name"] = "Seth",
          ["guild"] = "INSERTCOIN",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 330275,
          ["ilvl"] = 325,
          ["crit"] = 1002,
          ["haste"] = 799,
          ["mastery"] = 1094,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjhZmxsMLzMzMLGzyiHYAAwMzYmZWsADMLGNmBwshNGAAYMAbAAzMYmZMzAAAwMzMAAMGG"
        },
        {
          ["name"] = "Atrilock",
          ["guild"] = "HKM",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 330231,
          ["ilvl"] = 326,
          ["crit"] = 901,
          ["haste"] = 1147,
          ["mastery"] = 752,
          ["vers"] = 181,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZmZWmlZmZmFjZZxMAAYGjZmZxGMwsY0YGAzG2YAAgxAsBAMzgZmxYAAAYmZGAAGDD"
        },
        {
          ["name"] = "Zacx",
          ["guild"] = "Ethical",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 329966,
          ["ilvl"] = 326,
          ["crit"] = 951,
          ["haste"] = 1113,
          ["mastery"] = 839,
          ["vers"] = 199,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysNzMzsYMLLmBAAzYMzMLWgBmFjGzAY2wGDAAMGgNAgZGMzMMzGAAgZmZGAAjhB"
        },
        {
          ["name"] = "Demonhak",
          ["guild"] = "Salt Mines",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 327298,
          ["ilvl"] = 326,
          ["crit"] = 1197,
          ["haste"] = 968,
          ["mastery"] = 899,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMjZmZmlZZmZmZxYWWMDAAmxYmZWsADMLGNmBwshNGAAYMAbAAzMYmZMDAAAmZmBAgxwA"
        },
        {
          ["name"] = "죽음의강력공걱맨",
          ["guild"] = "인앤아웃",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 327200,
          ["ilvl"] = 324,
          ["crit"] = 1009,
          ["haste"] = 827,
          ["mastery"] = 968,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMLzMzMLGzyiHYAAwMzYmZWsADMLGNmBwshNGAAYMAbAAzMYmZMzAAAwMzMAAMGG"
        },
        {
          ["name"] = "Falkeron",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Sszorak",
          ["amount"] = 196970,
          ["ilvl"] = 328,
          ["crit"] = 1184,
          ["haste"] = 872,
          ["mastery"] = 1018,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlZxMzMLGjFzAAgZmxMzsYBGYWMaMDgZDbMAAwYgxGAwMDYmZMAAAMzMzAAYMM"
        },
        {
          ["name"] = "贝贝猫丶",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 188791,
          ["ilvl"] = 325,
          ["crit"] = 990,
          ["haste"] = 784,
          ["mastery"] = 1172,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbjhZmZmlZxMzMLGjFzAAgZmxMzsYBGYWMaMDgZDbMAAwYgxGAwMDMzYMbAAAmZmBAgxwA"
        },
        {
          ["name"] = "Diivil",
          ["guild"] = "뜨겁다",
          ["boss"] = "Sszorak",
          ["amount"] = 188612,
          ["ilvl"] = 322,
          ["crit"] = 1022,
          ["haste"] = 917,
          ["mastery"] = 833,
          ["vers"] = 193,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAgZmZmpZzM2mZGz2sYmZmFjxiZAAwMzYmZWsBDMLGNmBwshNGAAYMwYDAYmBMjxAAAwMzMDAgxwA"
        },
        {
          ["name"] = "Intns",
          ["guild"] = "Vestige",
          ["boss"] = "Sszorak",
          ["amount"] = 185203,
          ["ilvl"] = 327,
          ["crit"] = 1218,
          ["haste"] = 1120,
          ["mastery"] = 614,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlZxMzMLGjFzAAgZmxMzsYBGYWMaMDgZDbMAAwYgxGAwMDYmZMAAAMzMzAAYMM"
        },
        {
          ["name"] = "芋泥仙草",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "Sszorak",
          ["amount"] = 183215,
          ["ilvl"] = 322,
          ["crit"] = 1095,
          ["haste"] = 834,
          ["mastery"] = 1046,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYMzMzoZjhZmZmtZxMzMLGjFzAAgZmxMzsZDGYWMaMDgZDbMAAwYgxGAwMDMzYMAAAMzMzAAYMM"
        },
        {
          ["name"] = "Valyphar",
          ["guild"] = "Vibrant",
          ["boss"] = "Sszorak",
          ["amount"] = 182138,
          ["ilvl"] = 324,
          ["crit"] = 1146,
          ["haste"] = 863,
          ["mastery"] = 951,
          ["vers"] = 174,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZmZWmFzMzsYMWMDAAmZGzMziFYgZxoxMAmNsxAAAjBGbAAzMYmZMGAAAmZmBAgxwA"
        },
        {
          ["name"] = "Rosenrot",
          ["guild"] = "High Quality",
          ["boss"] = "Sszorak",
          ["amount"] = 177749,
          ["ilvl"] = 320,
          ["crit"] = 785,
          ["haste"] = 838,
          ["mastery"] = 1108,
          ["vers"] = 238,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZbMMzMzsNLmZmZxYsYGAAMzMmZmFLwAziRjZAMbYjBAAGDM2AAmZgZGjBAAgZmZAAYMM"
        },
        {
          ["name"] = "Pêntex",
          ["guild"] = "Burden",
          ["boss"] = "Sszorak",
          ["amount"] = 177099,
          ["ilvl"] = 324,
          ["crit"] = 985,
          ["haste"] = 973,
          ["mastery"] = 1127,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmxsMLmZmZxYsYGAAMzMmZmFLwAziRjZAMbYjBAAGDM2AAmZwMzYMAAAMzMzAAYMM"
        },
        {
          ["name"] = "Kiralock",
          ["guild"] = "Retired Extremely Bad",
          ["boss"] = "Sszorak",
          ["amount"] = 175648,
          ["ilvl"] = 322,
          ["crit"] = 1159,
          ["haste"] = 799,
          ["mastery"] = 912,
          ["vers"] = 110,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYmZmZGNbMWmZmZWmFzMzsYMWMDAAmZGzMziFYgZxoxMAmNsxAAAjBGbAAzMgZMGAAAmZmBAgxwA"
        },
        {
          ["name"] = "Thornfallow",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 173728,
          ["ilvl"] = 324,
          ["crit"] = 936,
          ["haste"] = 936,
          ["mastery"] = 1042,
          ["vers"] = 209,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbjhZmxsMLmZmZZGjFzAAgZMmZmFLwAziRjZAMbYjBAAGDM2AAmZwMzYmBAAgZmZAAYMM"
        },
        {
          ["name"] = "Kiralock",
          ["guild"] = "Retired Extremely Bad",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 308925,
          ["ilvl"] = 324,
          ["crit"] = 1175,
          ["haste"] = 806,
          ["mastery"] = 930,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYmZmZGNbMWmZmZWmlZmZmFjZZxMAAYGjZmZxCMwsY0YGAzG2YAAgxAsBAMzAmxYAAAYmZGAAGDD"
        },
        {
          ["name"] = "Babybrain",
          ["guild"] = "Consequence",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 295239,
          ["ilvl"] = 326,
          ["crit"] = 1174,
          ["haste"] = 941,
          ["mastery"] = 862,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjxyMzMzysMzMzsYMLLegBAAzMjZmZxCMwsY0YGAzG2YAAgxAsBAMzAzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Pêntex",
          ["guild"] = "Burden",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 288018,
          ["ilvl"] = 326,
          ["crit"] = 996,
          ["haste"] = 977,
          ["mastery"] = 1129,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmxsMLzMzMLGzyiHYAAwMzYmZWsADMLGNmBwshNGAAYMAbAAzMYmZMGAAAmZmZAAMGG"
        },
        {
          ["name"] = "Zedrad",
          ["guild"] = "Offline",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 287812,
          ["ilvl"] = 326,
          ["crit"] = 1141,
          ["haste"] = 652,
          ["mastery"] = 933,
          ["vers"] = 331,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAYmZmZGNbMWmZGzysMzMzsYMLLMAAYmZMzMLWgBmFjGzAY2wGDAAMGYsBAMzAzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Rikuwl",
          ["guild"] = "Schwingen des Phoenix",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 284823,
          ["ilvl"] = 324,
          ["crit"] = 997,
          ["haste"] = 909,
          ["mastery"] = 1135,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZmpZjxyMzMzysMzMzsYMLLegBAAzMjZmZxCMwsY0YGAzG2YAAgxAsBAMzAzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Zachx",
          ["guild"] = "Rain",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 281003,
          ["ilvl"] = 322,
          ["crit"] = 1005,
          ["haste"] = 937,
          ["mastery"] = 1087,
          ["vers"] = 91,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMWmZmZWmlZmZmFjZZxDMAAYmZMzMLWgBmFjGzAY2wGDAAMGgNAgZGMzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Diivil",
          ["guild"] = "뜨겁다",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 279688,
          ["ilvl"] = 322,
          ["crit"] = 1026,
          ["haste"] = 917,
          ["mastery"] = 836,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAgZmZmpZzMWmZGz2sMmZmFjZZxDMAAYGjZmZxGMwsY0YGAzG2YAAgxAjNAgZGwMGDAAAzMzMAAMDD"
        },
        {
          ["name"] = "Falkeron",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 277448,
          ["ilvl"] = 328,
          ["crit"] = 1184,
          ["haste"] = 872,
          ["mastery"] = 1018,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZxM2MzMzysMzMzsYMbLegBAAzMjZmZxCMwsY0YGAzG2YAAgxAsBAMzAmZGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Shn",
          ["guild"] = "Honestly",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 275972,
          ["ilvl"] = 327,
          ["crit"] = 1109,
          ["haste"] = 1050,
          ["mastery"] = 871,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMWmZmZ2mlZmZmFjZZxDMAAYmZMzMLWgBmFjGzAY2wGDAAMGgNAgZGMzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Aprikano",
          ["guild"] = "Schwingen des Phoenix",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 275491,
          ["ilvl"] = 323,
          ["crit"] = 1177,
          ["haste"] = 971,
          ["mastery"] = 907,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMegZGNbmxyMzMzysMzMzsYMLLmBAAzYMzMLWgBmFjGzAY2wGDAAMGgNAgZGMzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Falkeron",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 241490,
          ["ilvl"] = 324,
          ["crit"] = 1007,
          ["haste"] = 1253,
          ["mastery"] = 809,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlZZmZmZxMz2iHYAAwMGzMziFYgZxoxMAmNsxAAAjBYDAYmBMjxsBAAYmZmBAwYYA"
        },
        {
          ["name"] = "Valyphar",
          ["guild"] = "Vibrant",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 223017,
          ["ilvl"] = 326,
          ["crit"] = 1148,
          ["haste"] = 872,
          ["mastery"] = 957,
          ["vers"] = 178,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbM2mZmZWmlZmZmFzMbLegBAAzYMzMLWgBmFjGzAY2wGDAAMGgNAgZGMzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Sleeplock",
          ["guild"] = "Kilta",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 221552,
          ["ilvl"] = 321,
          ["crit"] = 1013,
          ["haste"] = 1072,
          ["mastery"] = 786,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlZZmZmZxMz2iHYAAwMGzMziFYgZxoxMAmNsxAAAjBYDAYmBMjxsBAAYmZmBAwYYA"
        },
        {
          ["name"] = "Rosenrot",
          ["guild"] = "High Quality",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 219851,
          ["ilvl"] = 324,
          ["crit"] = 1068,
          ["haste"] = 613,
          ["mastery"] = 1191,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZbMMzMzsNLzMzMLmZ2W8ADAAmxYmZWsADMLGNmBwshNGAAYMAbAAzMwMjxAAAwMzMAAMGG"
        },
        {
          ["name"] = "Diivil",
          ["guild"] = "뜨겁다",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 218718,
          ["ilvl"] = 322,
          ["crit"] = 1026,
          ["haste"] = 917,
          ["mastery"] = 836,
          ["vers"] = 195,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAgZmZmpZzM2mZGz2sMzMzsYMbLmBAAzYMzML2gBmFjGzAY2wGDAAMGgNAgZGwMGDAAAzMzMAAGDD"
        },
        {
          ["name"] = "Mannimarco",
          ["guild"] = "Octopals",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 218576,
          ["ilvl"] = 323,
          ["crit"] = 1161,
          ["haste"] = 783,
          ["mastery"] = 734,
          ["vers"] = 333,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNbMMzMzsMLzMzMLmZ2W8ADAAmxYmZWsADMLGNmBwshNGAAYMAbAAzMYmZMmNAAAzMzAAwYYA"
        },
        {
          ["name"] = "Sitomey",
          ["guild"] = "The Depraved",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 216611,
          ["ilvl"] = 326,
          ["crit"] = 1677,
          ["haste"] = 946,
          ["mastery"] = 772,
          ["vers"] = 266,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjZMzMzsMLzMzMLmZ2W8ADAAmxYmZWsADMLGNmBwshNGAAYMAbAAzMwMjxAAAwMzMAAMGG"
        },
        {
          ["name"] = "Hoshlenain",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 212372,
          ["ilvl"] = 321,
          ["crit"] = 1322,
          ["haste"] = 531,
          ["mastery"] = 1037,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjx2MzY2mlZmZmFzMbLegBAAzYMzMLWgBmFjGzAY2wGDAAMGgNAgZGMzMGDAAAzMzAAwYYA"
        },
        {
          ["name"] = "Boogiebomb",
          ["guild"] = "Anything to Live",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 212244,
          ["ilvl"] = 322,
          ["crit"] = 1188,
          ["haste"] = 634,
          ["mastery"] = 964,
          ["vers"] = 294,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlZZmZmZxMz2iHYAAwMGzMziFYgZxoxMAmNsxAAAjBYDAYmBmZMGAAAmZmZAAMGG"
        },
        {
          ["name"] = "Cassîa",
          ["guild"] = "Thot Process",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 211578,
          ["ilvl"] = 323,
          ["crit"] = 989,
          ["haste"] = 771,
          ["mastery"] = 1089,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhx2MzMzysMzMzsYmZbxDMAAYGjZmZxCMwsY0YGAzG2YAAgxAsBAMzAmxYAAAYmZmBAwYYA"
        }
      }
    }
  }
}
