MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Paladin"] = {
  ["className"] = "Paladin",
  ["specs"] = {
    {
      ["spec"] = "Holy",
      ["role"] = "healer",
      ["metric"] = "HPS",
      ["players"] = {
        {
          ["name"] = "伏衍方圆",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 369656,
          ["ilvl"] = 321,
          ["crit"] = 712,
          ["haste"] = 611,
          ["mastery"] = 1268,
          ["vers"] = 393,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLmZMjHYZwMLmpJmNjZmhxslBgBMsB2MbDzsMbzMzWDAAAwCAsZYMjBzAAYmhZMGGA"
        },
        {
          ["name"] = "Akilless",
          ["guild"] = "Impasse",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 356605,
          ["ilvl"] = 324,
          ["crit"] = 704,
          ["haste"] = 842,
          ["mastery"] = 1390,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZGMjZGLmZmZ8ALDmZZGNxsMjZmhxslBgBgNwmZZGzsMbzMzWDAAAwCAsxYMMzYGAAzMMjxwA"
        },
        {
          ["name"] = "Cyrri",
          ["guild"] = "Mid Team",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 348164,
          ["ilvl"] = 326,
          ["crit"] = 738,
          ["haste"] = 1024,
          ["mastery"] = 1250,
          ["vers"] = 309,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxsZMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWADsNDjZYYGAAzMMwwA"
        },
        {
          ["name"] = "圣陶陶",
          ["guild"] = "你杀我我就杀你",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 346273,
          ["ilvl"] = 320,
          ["crit"] = 1033,
          ["haste"] = 817,
          ["mastery"] = 1140,
          ["vers"] = 181,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMzyMjFDzMsMYmFz0EDjZmhxslBgBMsB2YZGzsMbzMzWDAAAwCAsZYMjZGzAAYmhZMGGA"
        },
        {
          ["name"] = "上帝化身",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 344187,
          ["ilvl"] = 317,
          ["crit"] = 648,
          ["haste"] = 919,
          ["mastery"] = 1175,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 311
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzDMGzYGmBAwMDzYMMA"
        },
        {
          ["name"] = "Silverneka",
          ["guild"] = "Invalid Target",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 343460,
          ["ilvl"] = 318,
          ["crit"] = 813,
          ["haste"] = 931,
          ["mastery"] = 1032,
          ["vers"] = 323,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 305
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "丹青浓郁",
          ["guild"] = "不羁者的茶会",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 341843,
          ["ilvl"] = 321,
          ["crit"] = 758,
          ["haste"] = 682,
          ["mastery"] = 1564,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 311
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxMmZYZwMLmJxYGzMzYMbZAYAYDsxyMmZZ2mZmtGAAAgFAYzMGzwwMAAmZYGjhB"
        },
        {
          ["name"] = "Hilermajster",
          ["guild"] = "Clown Town",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 341282,
          ["ilvl"] = 317,
          ["crit"] = 877,
          ["haste"] = 793,
          ["mastery"] = 1197,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 268292,
              ["name"] = "Sporelord's Mycelial Insignia",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Demö",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 339804,
          ["ilvl"] = 320,
          ["crit"] = 407,
          ["haste"] = 942,
          ["mastery"] = 1269,
          ["vers"] = 350,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Puríst",
          ["guild"] = "Paradise Kiss",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 338725,
          ["ilvl"] = 320,
          ["crit"] = 439,
          ["haste"] = 935,
          ["mastery"] = 1301,
          ["vers"] = 347,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "쾅쾅성",
          ["guild"] = "패러다임",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 402268,
          ["ilvl"] = 323,
          ["crit"] = 745,
          ["haste"] = 870,
          ["mastery"] = 1318,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxsMjZmhxslBgBgNwGbzYmlZbmZ2aAAAAWAgNDjZMDzAAYmhZMGGA"
        },
        {
          ["name"] = "Purepala",
          ["guild"] = "Jade Falcons",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 388448,
          ["ilvl"] = 327,
          ["crit"] = 556,
          ["haste"] = 917,
          ["mastery"] = 1494,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "微风再拂",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 387752,
          ["ilvl"] = 317,
          ["crit"] = 1066,
          ["haste"] = 747,
          ["mastery"] = 1041,
          ["vers"] = 256,
          ["trinkets"] = {
            {
              ["id"] = 270171,
              ["name"] = "Preternatural Antivenom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Ebtishaa",
          ["guild"] = "Interrupt Rotation",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 387200,
          ["ilvl"] = 321,
          ["crit"] = 549,
          ["haste"] = 1005,
          ["mastery"] = 1306,
          ["vers"] = 144,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzDMGzYGmBAwMDzYMMA"
        },
        {
          ["name"] = "Youngmic",
          ["guild"] = "value",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 383214,
          ["ilvl"] = 323,
          ["crit"] = 563,
          ["haste"] = 808,
          ["mastery"] = 1403,
          ["vers"] = 336,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxYGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "是流光唷",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 379221,
          ["ilvl"] = 318,
          ["crit"] = 988,
          ["haste"] = 1115,
          ["mastery"] = 781,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLjpJGzYmZYMbZAYAYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "圣陶陶",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 377795,
          ["ilvl"] = 324,
          ["crit"] = 973,
          ["haste"] = 807,
          ["mastery"] = 1433,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDshZMzysNzMbNAAAALAwmhxMmZMDAgZGmxYYA"
        },
        {
          ["name"] = "好运菜菜子",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 374199,
          ["ilvl"] = 318,
          ["crit"] = 552,
          ["haste"] = 807,
          ["mastery"] = 1340,
          ["vers"] = 262,
          ["trinkets"] = {
            {
              ["id"] = 268292,
              ["name"] = "Sporelord's Mycelial Insignia",
              ["ilvl"] = 298
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "緲緲灬",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 373818,
          ["ilvl"] = 325,
          ["crit"] = 1031,
          ["haste"] = 770,
          ["mastery"] = 1189,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "渺二十八",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 372792,
          ["ilvl"] = 316,
          ["crit"] = 733,
          ["haste"] = 863,
          ["mastery"] = 1077,
          ["vers"] = 315,
          ["trinkets"] = {
            {
              ["id"] = 274495,
              ["name"] = "Pulse Seeker's Oculus",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "쾅쾅성",
          ["guild"] = "패러다임",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 360330,
          ["ilvl"] = 320,
          ["crit"] = 744,
          ["haste"] = 851,
          ["mastery"] = 1311,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLzIxsMjZmhxslBgBgNwGbzYmlZbmZ2aAAAAWAgNDjZMDzAAYmhZMGGA"
        },
        {
          ["name"] = "Silliee",
          ["guild"] = "Bound",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 359085,
          ["ilvl"] = 325,
          ["crit"] = 779,
          ["haste"] = 1018,
          ["mastery"] = 1238,
          ["vers"] = 141,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Sqizzpal",
          ["guild"] = "CK",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 357732,
          ["ilvl"] = 325,
          ["crit"] = 672,
          ["haste"] = 895,
          ["mastery"] = 1210,
          ["vers"] = 421,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Deepressed",
          ["guild"] = "Unluck",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 356975,
          ["ilvl"] = 320,
          ["crit"] = 572,
          ["haste"] = 905,
          ["mastery"] = 1263,
          ["vers"] = 268,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 318
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxsZMzMMmlMAMAsB2MbzYmlZbmZ2aAAAAWAPAs5BYMzyMMDAgZGMGDDA"
        },
        {
          ["name"] = "Yggproc",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 356915,
          ["ilvl"] = 324,
          ["crit"] = 694,
          ["haste"] = 976,
          ["mastery"] = 1068,
          ["vers"] = 255,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Ørya",
          ["guild"] = "У беляша",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 355355,
          ["ilvl"] = 325,
          ["crit"] = 458,
          ["haste"] = 939,
          ["mastery"] = 1453,
          ["vers"] = 344,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Goldlooks",
          ["guild"] = "Husk at Crit",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 352252,
          ["ilvl"] = 322,
          ["crit"] = 830,
          ["haste"] = 780,
          ["mastery"] = 1264,
          ["vers"] = 144,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFgxYzDwYGzwMAAmZwYMMA"
        },
        {
          ["name"] = "Chrislight",
          ["guild"] = "Инвинсибл",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 351529,
          ["ilvl"] = 321,
          ["crit"] = 590,
          ["haste"] = 1009,
          ["mastery"] = 1268,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGmZYZwMLmpJGzYmZYMbZAYADbgN2mxMLz2Mzs1AAAAswGgNDjZMDzAAYmhZMGGA"
        },
        {
          ["name"] = "Inthiàs",
          ["guild"] = "Star Doggo Royal Club",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 350514,
          ["ilvl"] = 322,
          ["crit"] = 737,
          ["haste"] = 779,
          ["mastery"] = 1227,
          ["vers"] = 263,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLzoJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "伏衍方圆",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 349539,
          ["ilvl"] = 324,
          ["crit"] = 667,
          ["haste"] = 663,
          ["mastery"] = 1343,
          ["vers"] = 399,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLmZMjHYZwMLmpJmNjZmhxslBgBMsB2MbDzsMbzMzWDAAAwCAsZYMjBzAAYmhZMGGA"
        },
        {
          ["name"] = "Mcbubbling",
          ["guild"] = "Cherry Dogs",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 397580,
          ["ilvl"] = 322,
          ["crit"] = 615,
          ["haste"] = 854,
          ["mastery"] = 1412,
          ["vers"] = 138,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Saltywings",
          ["guild"] = "Mid Tier Crisis",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 387083,
          ["ilvl"] = 325,
          ["crit"] = 505,
          ["haste"] = 1034,
          ["mastery"] = 1398,
          ["vers"] = 250,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "蕉小蛙",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 384680,
          ["ilvl"] = 319,
          ["crit"] = 453,
          ["haste"] = 989,
          ["mastery"] = 1318,
          ["vers"] = 146,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 324
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "草莓芬达子",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 381730,
          ["ilvl"] = 321,
          ["crit"] = 868,
          ["haste"] = 769,
          ["mastery"] = 1220,
          ["vers"] = 83,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 311
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "伏衍方圆",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 380837,
          ["ilvl"] = 321,
          ["crit"] = 728,
          ["haste"] = 627,
          ["mastery"] = 1268,
          ["vers"] = 393,
          ["trinkets"] = {
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLmZMjHYZwMLmpJmNjZmhxslBgBMsB2MbDzsMbzMzWDAAAwCAsZYMjBzAAYmhZMGGA"
        },
        {
          ["name"] = "Sqizzpal",
          ["guild"] = "CK",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 379975,
          ["ilvl"] = 318,
          ["crit"] = 591,
          ["haste"] = 921,
          ["mastery"] = 1170,
          ["vers"] = 263,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 273649,
              ["name"] = "Stormbound Emblem of Dazar",
              ["ilvl"] = 311
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Evelinari",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 379134,
          ["ilvl"] = 329,
          ["crit"] = 540,
          ["haste"] = 1159,
          ["mastery"] = 1210,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxsNjZmhxslBgBMsB2YZGzsMbzMzWDAAAwCAsZYMjZYGAAzMMjBGA"
        },
        {
          ["name"] = "Holytoob",
          ["guild"] = "No Picnic",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 378693,
          ["ilvl"] = 317,
          ["crit"] = 524,
          ["haste"] = 644,
          ["mastery"] = 1230,
          ["vers"] = 565,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 318
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 311
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzgZMzYxYmZMLDmZxMJGGzMDjZJDADAbgN2mxMLz2Mzs1AAAAsAAbzwYGzMmBAwMDzYMMA"
        },
        {
          ["name"] = "帕烙斯",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 378282,
          ["ilvl"] = 320,
          ["crit"] = 946,
          ["haste"] = 1053,
          ["mastery"] = 469,
          ["vers"] = 480,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxsZMzMMmlMAMAsB2MbzYmlZbmZ2aAAAAWAPAs5BYMzyMMDAgZGMGDDA"
        },
        {
          ["name"] = "星锤弋丷",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 376035,
          ["ilvl"] = 322,
          ["crit"] = 696,
          ["haste"] = 1099,
          ["mastery"] = 1087,
          ["vers"] = 166,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDshZMzysNzMbNAAAALAwmZMmxMMDAgZGmxYYA"
        },
        {
          ["name"] = "Trappsy",
          ["guild"] = "Welcome",
          ["boss"] = "Sszorak",
          ["amount"] = 434927,
          ["ilvl"] = 325,
          ["crit"] = 669,
          ["haste"] = 887,
          ["mastery"] = 1357,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "渺渺丶",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 433824,
          ["ilvl"] = 323,
          ["crit"] = 647,
          ["haste"] = 799,
          ["mastery"] = 1335,
          ["vers"] = 213,
          ["trinkets"] = {
            {
              ["id"] = 250254,
              ["name"] = "Seed of Radiant Hope",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 318
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZmhxMzwygZWMTTMmxMzwY2yAwAG2AbsNjZWmtZmZrBAAAYBA2MMmxMMDAgZGmxYYA"
        },
        {
          ["name"] = "阿库娅的微笑",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 425303,
          ["ilvl"] = 328,
          ["crit"] = 465,
          ["haste"] = 1062,
          ["mastery"] = 1402,
          ["vers"] = 152,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbmxYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Cgabî",
          ["guild"] = "Aprèm",
          ["boss"] = "Sszorak",
          ["amount"] = 418961,
          ["ilvl"] = 327,
          ["crit"] = 840,
          ["haste"] = 669,
          ["mastery"] = 1570,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Purepala",
          ["guild"] = "Jade Falcons",
          ["boss"] = "Sszorak",
          ["amount"] = 416954,
          ["ilvl"] = 324,
          ["crit"] = 489,
          ["haste"] = 987,
          ["mastery"] = 1428,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "쾅쾅성",
          ["guild"] = "패러다임",
          ["boss"] = "Sszorak",
          ["amount"] = 415602,
          ["ilvl"] = 323,
          ["crit"] = 745,
          ["haste"] = 870,
          ["mastery"] = 1318,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxsNjZmhxslBgBgNwGbzYmlZbmZ2aAAAAWAgNDjZMDzAAYmhZMGGA"
        },
        {
          ["name"] = "Nilssoñ",
          ["guild"] = "Arctic Avengers",
          ["boss"] = "Sszorak",
          ["amount"] = 412868,
          ["ilvl"] = 323,
          ["crit"] = 1059,
          ["haste"] = 626,
          ["mastery"] = 1291,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYAYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Wuarlarr",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 412474,
          ["ilvl"] = 316,
          ["crit"] = 873,
          ["haste"] = 597,
          ["mastery"] = 1459,
          ["vers"] = 90,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxsZMzMMmlMAMghNwGLzYmlZbmZ2aAAAAWAgNjZMz2MMDAgZGMGYA"
        },
        {
          ["name"] = "緲緲灬",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 412458,
          ["ilvl"] = 325,
          ["crit"] = 1031,
          ["haste"] = 935,
          ["mastery"] = 1024,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Dreadlight",
          ["guild"] = "Doomed",
          ["boss"] = "Sszorak",
          ["amount"] = 411555,
          ["ilvl"] = 321,
          ["crit"] = 545,
          ["haste"] = 716,
          ["mastery"] = 1430,
          ["vers"] = 320,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 311
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Purepala",
          ["guild"] = "Jade Falcons",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 418007,
          ["ilvl"] = 325,
          ["crit"] = 491,
          ["haste"] = 992,
          ["mastery"] = 1435,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Mythmaster",
          ["guild"] = "macht DRUCK",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 417230,
          ["ilvl"] = 325,
          ["crit"] = 809,
          ["haste"] = 915,
          ["mastery"] = 1205,
          ["vers"] = 142,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJmFjZmhxslBgBMsB2YZGzsMbzMzWDAAAwCAs5BGjZ2gZAAMzwMGDDA"
        },
        {
          ["name"] = "Exitius",
          ["guild"] = "NonSense",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 409570,
          ["ilvl"] = 325,
          ["crit"] = 806,
          ["haste"] = 915,
          ["mastery"] = 1187,
          ["vers"] = 164,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGzYGzMmBAwMDGjhB"
        },
        {
          ["name"] = "Ulrigge",
          ["guild"] = "Huhuholics",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 408179,
          ["ilvl"] = 325,
          ["crit"] = 878,
          ["haste"] = 643,
          ["mastery"] = 1389,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Dejavupal",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 407210,
          ["ilvl"] = 323,
          ["crit"] = 781,
          ["haste"] = 833,
          ["mastery"] = 1217,
          ["vers"] = 174,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAgBAA2mZmZMzyMjFDzMsMYmFz0Ez2MmZGGzWGAGwwGYjlZMzysNzMbNAAAALAM2YMmxMMDAgZGMGDDA"
        },
        {
          ["name"] = "Skyrîx",
          ["guild"] = "Bloody Tearz",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 406397,
          ["ilvl"] = 325,
          ["crit"] = 691,
          ["haste"] = 858,
          ["mastery"] = 1429,
          ["vers"] = 217,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbeAGzYGmBAwMDzYMMA"
        },
        {
          ["name"] = "Clarius",
          ["guild"] = "Sabotage",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 399413,
          ["ilvl"] = 319,
          ["crit"] = 873,
          ["haste"] = 912,
          ["mastery"] = 1218,
          ["vers"] = 177,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 311
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAwYDGzYGmBAwMDzYMMA"
        },
        {
          ["name"] = "Títaníá",
          ["guild"] = "Agency",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 399114,
          ["ilvl"] = 326,
          ["crit"] = 728,
          ["haste"] = 812,
          ["mastery"] = 1414,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAYw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbmBzYwMAAmZYGjhB"
        },
        {
          ["name"] = "Emna",
          ["guild"] = "Fun with Friends",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 398969,
          ["ilvl"] = 326,
          ["crit"] = 705,
          ["haste"] = 1041,
          ["mastery"] = 1174,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "尐骑士丶",
          ["guild"] = "Dim Moon",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 394869,
          ["ilvl"] = 326,
          ["crit"] = 870,
          ["haste"] = 1108,
          ["mastery"] = 1016,
          ["vers"] = 50,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZJDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Repugg",
          ["guild"] = "Fragglene",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 397878,
          ["ilvl"] = 327,
          ["crit"] = 1009,
          ["haste"] = 914,
          ["mastery"] = 1197,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJmlZMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWAgNYMjZYGAAzMMjxwA"
        },
        {
          ["name"] = "Evelinari",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 384334,
          ["ilvl"] = 329,
          ["crit"] = 540,
          ["haste"] = 1159,
          ["mastery"] = 1210,
          ["vers"] = 230,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAGYzDYGzYmxMAAmZwYgB"
        },
        {
          ["name"] = "Clarius",
          ["guild"] = "Sabotage",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 377605,
          ["ilvl"] = 327,
          ["crit"] = 1015,
          ["haste"] = 876,
          ["mastery"] = 1184,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyMzMjZMzMYMGzygZWMTTMLzYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Shirup",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 375188,
          ["ilvl"] = 325,
          ["crit"] = 930,
          ["haste"] = 848,
          ["mastery"] = 1349,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJmlZMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWADsxYMjZYGAAzMAGGA"
        },
        {
          ["name"] = "Joki",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 360068,
          ["ilvl"] = 324,
          ["crit"] = 936,
          ["haste"] = 674,
          ["mastery"] = 1447,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Freè",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 353897,
          ["ilvl"] = 328,
          ["crit"] = 868,
          ["haste"] = 884,
          ["mastery"] = 1320,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzMLwMDLDmZxMJmlZMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWYBwmhxMmhZAAMzgxYYA"
        },
        {
          ["name"] = "Almeypala",
          ["guild"] = "baited",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 351635,
          ["ilvl"] = 325,
          ["crit"] = 907,
          ["haste"] = 600,
          ["mastery"] = 1449,
          ["vers"] = 213,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAGYzwYGzwMAAmZwYMMA"
        },
        {
          ["name"] = "Beavn",
          ["guild"] = "Infinity",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 336595,
          ["ilvl"] = 327,
          ["crit"] = 734,
          ["haste"] = 621,
          ["mastery"] = 1515,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZGjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzDwYGDmBAwMDzYMMA"
        },
        {
          ["name"] = "Väsykone",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 332793,
          ["ilvl"] = 328,
          ["crit"] = 631,
          ["haste"] = 824,
          ["mastery"] = 1715,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYBmZYZwMLmJxsYMzMMmtMAMghNwGLzMzsMbzMzWDAAAwCLA28AMmxMjZAAMzwMGDDA"
        },
        {
          ["name"] = "Bigartorius",
          ["guild"] = "Myth",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 312092,
          ["ilvl"] = 327,
          ["crit"] = 560,
          ["haste"] = 811,
          ["mastery"] = 1456,
          ["vers"] = 275,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJmlZMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWADsxYMjZYGAAzMAGGA"
        },
        {
          ["name"] = "Holypoggers",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 389054,
          ["ilvl"] = 329,
          ["crit"] = 760,
          ["haste"] = 881,
          ["mastery"] = 1537,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZ2mZmFYmhlBzsYmmYYMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWAgNPgZMjZYGAAzMMjxwA"
        },
        {
          ["name"] = "兰萨利",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 389202,
          ["ilvl"] = 323,
          ["crit"] = 880,
          ["haste"] = 972,
          ["mastery"] = 1231,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxYGzMDjZLDADYYDsZ2mxMLz2Mzs1AAAAsAAbGGzwwMAAmZYGjhB"
        },
        {
          ["name"] = "琦诗",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 371769,
          ["ilvl"] = 323,
          ["crit"] = 553,
          ["haste"] = 1213,
          ["mastery"] = 1276,
          ["vers"] = 150,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsx2MmZZ2mZmtGAAAgFAYzDMGzYGmBAwMDzYMMA"
        },
        {
          ["name"] = "莉亞",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 369054,
          ["ilvl"] = 326,
          ["crit"] = 621,
          ["haste"] = 1011,
          ["mastery"] = 1370,
          ["vers"] = 52,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDshZMzysNzMbNAAAALAwmZMmxMMDAgZGmxYYA"
        },
        {
          ["name"] = "聖罚红塵丶",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 364076,
          ["ilvl"] = 319,
          ["crit"] = 931,
          ["haste"] = 686,
          ["mastery"] = 1231,
          ["vers"] = 134,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "ßò",
          ["guild"] = "Artistic",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 363119,
          ["ilvl"] = 326,
          ["crit"] = 606,
          ["haste"] = 749,
          ["mastery"] = 1684,
          ["vers"] = 182,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzgZGzYWGMzyMSMbGzMDjZLDADYYDsx2wMLz2Mzs1AAAAsAAbGGzYGmBAwMDzYMMA"
        },
        {
          ["name"] = "矜持的訫",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 362862,
          ["ilvl"] = 321,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = ""
        },
        {
          ["name"] = "佳小骑",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 362105,
          ["ilvl"] = 316,
          ["crit"] = 725,
          ["haste"] = 836,
          ["mastery"] = 1278,
          ["vers"] = 181,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 315
            }
          },
          ["potion"] = nil,
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "霜满地",
          ["guild"] = "Nebulation",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 358545,
          ["ilvl"] = 323,
          ["crit"] = 823,
          ["haste"] = 993,
          ["mastery"] = 1150,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmJxYGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        },
        {
          ["name"] = "Xiaoomei",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 356972,
          ["ilvl"] = 321,
          ["crit"] = 317,
          ["haste"] = 1098,
          ["mastery"] = 1448,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 193757,
              ["name"] = "Ruby Whelp Shell",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 295
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjhB"
        },
        {
          ["name"] = "Stàrs",
          ["guild"] = "Ancient Tempest",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 356777,
          ["ilvl"] = 322,
          ["crit"] = 804,
          ["haste"] = 810,
          ["mastery"] = 1297,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYAYDsx2MmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjhB"
        }
      }
    },
    {
      ["spec"] = "Protection",
      ["role"] = "tank",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Renerock",
          ["guild"] = "Primarch",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 131028,
          ["ilvl"] = 323,
          ["crit"] = 1059,
          ["haste"] = 1097,
          ["mastery"] = 609,
          ["vers"] = 307,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNYWGWGGAgBAAAAAANNzsNzYmhZegtAgBGwAbAAAAwMzy2SLzMWstxMAGMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Elnosso",
          ["guild"] = "improved",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 127960,
          ["ilvl"] = 325,
          ["crit"] = 1090,
          ["haste"] = 986,
          ["mastery"] = 635,
          ["vers"] = 378,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmHYmZmhlBzywywAAMAAAAAAINzsYGzgZmt2AwAzAzgNAAAAYmZZZplZGL22YGAMmhBAMzAgZGwYB"
        },
        {
          ["name"] = "Chaddopala",
          ["guild"] = "Ritual",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 126881,
          ["ilvl"] = 322,
          ["crit"] = 1443,
          ["haste"] = 714,
          ["mastery"] = 724,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNYWGWGGAgBAAAAAANNzsNzYmhZegtAgBGwAbAAAAwMzy2SLzMWstxMAGMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Mplp",
          ["guild"] = "Mean Girls",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 125522,
          ["ilvl"] = 322,
          ["crit"] = 811,
          ["haste"] = 1284,
          ["mastery"] = 740,
          ["vers"] = 406,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMz8AzMzM2WGjZZYbGDAwAAAAAAg0MjZGzMjxs1GAGYAzgNAAAAYmZZbplZGL22wAAmhBAMzAwMzAGL"
        },
        {
          ["name"] = "Ayerio",
          ["guild"] = "Djungelpatrullen",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 123401,
          ["ilvl"] = 323,
          ["crit"] = 990,
          ["haste"] = 904,
          ["mastery"] = 441,
          ["vers"] = 581,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzMzMsNGzywyMGAAAAAAAAopZGmxMDjZLAYAgZw2AAAAgZmltlWmZsYbDDgxYGGDAmZAYmZAjF"
        },
        {
          ["name"] = "Fejjmegapuci",
          ["guild"] = "Invalid Target",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 123102,
          ["ilvl"] = 325,
          ["crit"] = 819,
          ["haste"] = 1081,
          ["mastery"] = 813,
          ["vers"] = 433,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYmHYmZmx2yYMLjZZGDAwAAAAAAgmmZWmZMzwY2aDADAMD2AAAAgZmltlWmZsYZDDAGzwYAwMDAmZAjF"
        },
        {
          ["name"] = "Eláî",
          ["guild"] = "Value",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 122773,
          ["ilvl"] = 321,
          ["crit"] = 1064,
          ["haste"] = 1007,
          ["mastery"] = 328,
          ["vers"] = 474,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNwyYWmxAAMAAAAAAINzsMzYmhxsFAMwAmBbDAAAAmZW2WaZmxilNMAGjZYMAYmBAGgxC"
        },
        {
          ["name"] = "Naithpala",
          ["guild"] = "Effective Chaos",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 122430,
          ["ilvl"] = 321,
          ["crit"] = 939,
          ["haste"] = 1152,
          ["mastery"] = 533,
          ["vers"] = 269,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250259,
              ["name"] = "Sapling of the Dawnroot",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzDYWmZYmZmx2yYMLDLDDAwAAAAAAg0MjZGzMjxs1GAGYAzgNAAAAYmZZbplZGL22wAGwMMGAMzAwMzAGL"
        },
        {
          ["name"] = "Waitforunban",
          ["guild"] = "Deception Blue",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 121476,
          ["ilvl"] = 326,
          ["crit"] = 1294,
          ["haste"] = 1287,
          ["mastery"] = 412,
          ["vers"] = 166,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzMzMsMGWGWGGAgBAAAAAApZmlZGzMjxs1GAGYAzgNAAAAYmZZbplZGL22wAgxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Solpaladin",
          ["guild"] = "Mage Tout Pichtou",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 121368,
          ["ilvl"] = 325,
          ["crit"] = 1051,
          ["haste"] = 1200,
          ["mastery"] = 380,
          ["vers"] = 380,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmHYGzMWWGMLDLzYAAGAAAAAA00MziZMzw4B2CAGYADsBAAAAzMLbLtMzYx2GzAYMmhxAgZGAMzAGL"
        },
        {
          ["name"] = "Chaddopala",
          ["guild"] = "Ritual",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 120869,
          ["ilvl"] = 322,
          ["crit"] = 1443,
          ["haste"] = 714,
          ["mastery"] = 724,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNYWGWGGAgBAAAAAANNzsNzYmhZegtAgBGwAbAAAAwMzy2SLzMWstxMAGMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Willpaladin",
          ["guild"] = "Deathstroke Division",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 118952,
          ["ilvl"] = 325,
          ["crit"] = 1101,
          ["haste"] = 969,
          ["mastery"] = 756,
          ["vers"] = 184,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 467281,
            ["name"] = "Healing Elixir"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsMDzyMjZmZmhlxYWGWmxAAAAAAAAANNzsYGzMMmt2AwAAzgtBAAAAzMbbLtMzYx2GzAgxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Vivipld",
          ["guild"] = "Honolulu",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 115436,
          ["ilvl"] = 325,
          ["crit"] = 1552,
          ["haste"] = 812,
          ["mastery"] = 627,
          ["vers"] = 312,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNwyYWmxAAMAAAAAAINzsMzYmhxsFAMwAmBbDAAAAmZW2WaZmxilNMAGjZYMAYmBAGgxC"
        },
        {
          ["name"] = "Renerock",
          ["guild"] = "Primarch",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 115171,
          ["ilvl"] = 323,
          ["crit"] = 1059,
          ["haste"] = 1097,
          ["mastery"] = 609,
          ["vers"] = 307,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsMYWGWGGAgBAAAAAANNzsNzYmhZegtAgBGwAbAAAAwMzy2SLzMWstxMAGMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Ty",
          ["guild"] = "TURBO SAAB",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 114482,
          ["ilvl"] = 325,
          ["crit"] = 1113,
          ["haste"] = 922,
          ["mastery"] = 476,
          ["vers"] = 478,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMjZmZmx2yYYZYZGDAwAAAAAAg0MjZGzgxs1GAGYAzgNAAAAYmZZbplZGLW2YGAjxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Guacamolen",
          ["guild"] = "Mental Apocalypse",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 113526,
          ["ilvl"] = 324,
          ["crit"] = 947,
          ["haste"] = 792,
          ["mastery"] = 805,
          ["vers"] = 426,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzy8Az8AzMzM2WGjZZYZGDAwAAAAAAg0MziZMzMGzWbAYAgZwGAAAAMzsst0yMjFbbMDAGzwYAwMDAmZAjF"
        },
        {
          ["name"] = "Ayerio",
          ["guild"] = "Djungelpatrullen",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 111735,
          ["ilvl"] = 323,
          ["crit"] = 990,
          ["haste"] = 899,
          ["mastery"] = 441,
          ["vers"] = 581,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzMzMsNGzywyMGAAAAAAAAopZGmxMDjZLAYAgZw2AAAAgZmltlWmZsYbDDgxYGGDAmZAYmZAjF"
        },
        {
          ["name"] = "Слейпънир",
          ["guild"] = "Фаерфлай",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 111191,
          ["ilvl"] = 322,
          ["crit"] = 1183,
          ["haste"] = 1112,
          ["mastery"] = 684,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYmZmZmx2yYYZMLzYAAGAAAAAAkmZWmZMzwY2aDADMgZw2AAAAgZmltlWmZsYZDDgxYGGDAmZAgBYsA"
        },
        {
          ["name"] = "Dreamwithyou",
          ["guild"] = "도원",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 110654,
          ["ilvl"] = 323,
          ["crit"] = 1312,
          ["haste"] = 1397,
          ["mastery"] = 173,
          ["vers"] = 164,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzMzMsMGWGWmxAAMAAAAAAINzsMzYmZMmtWAwAAzgNAAAAYmZZbplZGL22wAgxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Domideus",
          ["guild"] = "velocity",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 110121,
          ["ilvl"] = 326,
          ["crit"] = 1290,
          ["haste"] = 934,
          ["mastery"] = 377,
          ["vers"] = 393,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzMzMsNGWGWmxAAMAAAAAAINzsMzYmZMzs1GAGAYGsBAAAAzMLbLtMzYx2GzAYwMMGAMzAADwYB"
        },
        {
          ["name"] = "Willpaladin",
          ["guild"] = "Deathstroke Division",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 208961,
          ["ilvl"] = 322,
          ["crit"] = 1035,
          ["haste"] = 869,
          ["mastery"] = 764,
          ["vers"] = 327,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzy8AzMzMzM2WGDLDLzYAAAAAAAAgmmZWMjZGGzWbAYAgZw2AAAAgZmttlWmZsYbhZAwYGGDAmZAwMDYsA"
        },
        {
          ["name"] = "Слейпънир",
          ["guild"] = "Фаерфлай",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 202362,
          ["ilvl"] = 322,
          ["crit"] = 1183,
          ["haste"] = 1112,
          ["mastery"] = 684,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZGzyYGzMzMz2yYMLDLzYAAGAAAAAA00MzyMjZw4B2aDADMgZwGAAAAMzsst0yMjFbLMDgxYGGDAmZAwMAjF"
        },
        {
          ["name"] = "Lightstic",
          ["guild"] = "Rage Against the Meta",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 202274,
          ["ilvl"] = 320,
          ["crit"] = 986,
          ["haste"] = 1374,
          ["mastery"] = 277,
          ["vers"] = 207,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWGzYmZmx2yYMLDLzYAAGAAAAAA00MjZGzMMegt2AwAAzgNAAAAYmZZbplZGL2WYGAjxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Ribzpal",
          ["guild"] = "Leviathan",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 200545,
          ["ilvl"] = 323,
          ["crit"] = 1259,
          ["haste"] = 1156,
          ["mastery"] = 477,
          ["vers"] = 246,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZYGzM2WGjZZYZYAAGAAAAAAkmZWmZMDGzWbAYgZgZwGAAAAMzsst0yMjFbbMDAGzwYAwMDAmZAjF"
        },
        {
          ["name"] = "Chaddopala",
          ["guild"] = "Ritual",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 198342,
          ["ilvl"] = 321,
          ["crit"] = 1307,
          ["haste"] = 690,
          ["mastery"] = 739,
          ["vers"] = 166,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWGzYmZmx2yYMLDLzYAAGAAAAAA00MjZGzMMegt2AwAAzgNAAAAYmZZbplZGL2WYGAjxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Naithpala",
          ["guild"] = "Effective Chaos",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 197704,
          ["ilvl"] = 321,
          ["crit"] = 989,
          ["haste"] = 1172,
          ["mastery"] = 463,
          ["vers"] = 269,
          ["trinkets"] = {
            {
              ["id"] = 250259,
              ["name"] = "Sapling of the Dawnroot",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWGzYGzMz2yYMLDLzYAAGAAAAAA00MzyMjZGGPwWbAYgBMD2AAAAgZmltlWmZsYbhZAMYGGDAmZAwMAjF"
        },
        {
          ["name"] = "Renerock",
          ["guild"] = "Primarch",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 196177,
          ["ilvl"] = 323,
          ["crit"] = 1059,
          ["haste"] = 1097,
          ["mastery"] = 609,
          ["vers"] = 307,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzDYWmZmZGzMsNGWGWGGAgBAAAAAANNzsNzYmhZegt2AwADYgNAAAAYmZZbplZGL22YGADmhxAgZGAMzAGL"
        },
        {
          ["name"] = "Eluviell",
          ["guild"] = "No Skill",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 195767,
          ["ilvl"] = 324,
          ["crit"] = 1050,
          ["haste"] = 1149,
          ["mastery"] = 714,
          ["vers"] = 124,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZYmZmhlxYWGWGGAgBAAAAAANNmNzYmhZmt2AwAAzgNAAAAYmZZbplZGL2WYGADmZxYAwMDAmZAjF"
        },
        {
          ["name"] = "吃我一槌",
          ["guild"] = "oops",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 195274,
          ["ilvl"] = 322,
          ["crit"] = 1364,
          ["haste"] = 1017,
          ["mastery"] = 422,
          ["vers"] = 313,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZGzyYmZGzM2WGDLjZZYAAGAAAAAAkmZWMjZGGzWbAYADMD2AAAAgZmltlWmZsYbhZAwYGGDAmZAYmZAjN"
        },
        {
          ["name"] = "Holychinoo",
          ["guild"] = "Banelings",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 193123,
          ["ilvl"] = 323,
          ["crit"] = 815,
          ["haste"] = 1222,
          ["mastery"] = 745,
          ["vers"] = 258,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZGzMzMsMGWGWGGAgBAAAAAANNzsMzYmhxs1GAGYGYGsBAAAAzMLbLtMzYx2CzAAmhxAgZGAMDwYB"
        },
        {
          ["name"] = "Chaddopala",
          ["guild"] = "Ritual",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 156648,
          ["ilvl"] = 322,
          ["crit"] = 1443,
          ["haste"] = 714,
          ["mastery"] = 724,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNYWGWGGAgBAAAAAANNzsNzYmhZegtAgBGwAbAAAAwMzy2SLzMWstxMAGMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Renerock",
          ["guild"] = "Primarch",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 149388,
          ["ilvl"] = 321,
          ["crit"] = 869,
          ["haste"] = 999,
          ["mastery"] = 668,
          ["vers"] = 384,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNYWGWGGAgBAAAAAANNzsNzYmhZegtAgBGwAbAAAAwMzy2SLzMWstxMAGMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Pedretti",
          ["guild"] = "Pig Pen",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 149355,
          ["ilvl"] = 325,
          ["crit"] = 1232,
          ["haste"] = 1229,
          ["mastery"] = 538,
          ["vers"] = 111,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNYWGWmxAAAAAAAAApZmtZGzMMzsFAMwAmBbAAAAwMz22SLzMWstxMAPwgZYMAYmBAGgxC"
        },
        {
          ["name"] = "Palaschuin",
          ["guild"] = "BigBrain",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 146602,
          ["ilvl"] = 324,
          ["crit"] = 1260,
          ["haste"] = 973,
          ["mastery"] = 449,
          ["vers"] = 225,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzYmhtxYWGWGGAgBAAAAAANNzsNzYmhZegt2AwADYgNAAAAYmZZbplZGL22YGADmhxAgZGAMzAGL"
        },
        {
          ["name"] = "Naithpala",
          ["guild"] = "Effective Chaos",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 145397,
          ["ilvl"] = 321,
          ["crit"] = 939,
          ["haste"] = 1138,
          ["mastery"] = 533,
          ["vers"] = 269,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250259,
              ["name"] = "Sapling of the Dawnroot",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzy8AzMzMzM2WGDLDLzYAAGAAAAAAkmZWmZMzwY2aDADMgZw2AAAAgZmltlWmZsYbDDgxYGGDAmZAgBYsA"
        },
        {
          ["name"] = "Domideus",
          ["guild"] = "velocity",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 142488,
          ["ilvl"] = 326,
          ["crit"] = 1290,
          ["haste"] = 934,
          ["mastery"] = 377,
          ["vers"] = 393,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzMzMsNGWGWmxAAMAAAAAAINzsMzYmZMzs1GAGAYGsBAAAAzMLbLtMzYx2GzAYwMMGAMzAADwYB"
        },
        {
          ["name"] = "Shantwe",
          ["guild"] = "Pathogen",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 141695,
          ["ilvl"] = 325,
          ["crit"] = 1035,
          ["haste"] = 1245,
          ["mastery"] = 472,
          ["vers"] = 424,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzDYWmZmZGzMsNGWGWGGAgBAAAAAANNzsNzYmhZegt2AwADYgNAAAAYmZZbplZGL22YGADmhxAgZGAMzAGL"
        },
        {
          ["name"] = "Vivipld",
          ["guild"] = "Honolulu",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 140042,
          ["ilvl"] = 325,
          ["crit"] = 1209,
          ["haste"] = 869,
          ["mastery"] = 684,
          ["vers"] = 369,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNwyYWmxAAMAAAAAAINzsMzYmhxsFAMwAmBbDAAAAmZW2WaZmxilNMAGjZYMAYmBAGgxC"
        },
        {
          ["name"] = "Eluviell",
          ["guild"] = "No Skill",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 139852,
          ["ilvl"] = 323,
          ["crit"] = 953,
          ["haste"] = 968,
          ["mastery"] = 968,
          ["vers"] = 124,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMjZmZmhlxYWGWGGAgBAAAAAANNzsZGzMMmt2AwADYGsBAAAAzMLbLtMzYx2GGADmZxYAwMDAmZAjF"
        },
        {
          ["name"] = "Divinetrôll",
          ["guild"] = "value",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 139815,
          ["ilvl"] = 323,
          ["crit"] = 926,
          ["haste"] = 1063,
          ["mastery"] = 629,
          ["vers"] = 271,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzDsNLzMmZMzwyYMLDLDDAwAAAAAAg0MziZMDGzWbAYADMD2GAAAAMzsst0yMjFLbMDAGzwYAwMDAzMDYA"
        },
        {
          ["name"] = "분홍파프리카",
          ["guild"] = "Mate",
          ["boss"] = "Sszorak",
          ["amount"] = 122404,
          ["ilvl"] = 328,
          ["crit"] = 985,
          ["haste"] = 1397,
          ["mastery"] = 272,
          ["vers"] = 499,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzYmZmx2yYMLzCDDAwAAAAAAg0MziZMzwY2aDADAMD2AAAAgZmltlWmZsYZjZAMGzwMDAmZAwMDYsA"
        },
        {
          ["name"] = "Lootgremlin",
          ["guild"] = "Foundation",
          ["boss"] = "Sszorak",
          ["amount"] = 122066,
          ["ilvl"] = 322,
          ["crit"] = 1065,
          ["haste"] = 1270,
          ["mastery"] = 431,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsMGzygZMAADAAAAAASjZbmxMYMbBADAMD2AAAAgZmltlWmZsYbjZAYGzwYAwMDAzMDYsA"
        },
        {
          ["name"] = "Ty",
          ["guild"] = "TURBO SAAB",
          ["boss"] = "Sszorak",
          ["amount"] = 118971,
          ["ilvl"] = 325,
          ["crit"] = 1154,
          ["haste"] = 965,
          ["mastery"] = 476,
          ["vers"] = 394,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMjZmZmx2yYYZMmxAAMAAAAAAINzYmxMYMbtBgBGwMYDAAAAmZW2WaZmxitNmBwYMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Chaddopala",
          ["guild"] = "Ritual",
          ["boss"] = "Sszorak",
          ["amount"] = 117840,
          ["ilvl"] = 322,
          ["crit"] = 2220,
          ["haste"] = 714,
          ["mastery"] = 724,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMjZmZmZsMGWGWmxAAAAAAAAANNzsMzYmZMmt2AwAGYGsNAAAAYmZZbplZGLW2wAgxMMGAMzAADwYB"
        },
        {
          ["name"] = "Starmi",
          ["guild"] = "Mici Bere si Manele",
          ["boss"] = "Sszorak",
          ["amount"] = 117247,
          ["ilvl"] = 325,
          ["crit"] = 1138,
          ["haste"] = 1178,
          ["mastery"] = 506,
          ["vers"] = 341,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsMGzygZMAADAAAAAASjZbmxMYMbBADAMD2AAAAgZmltlWmZsYbjZAYGzwYAwMDAzMDYsA"
        },
        {
          ["name"] = "Vengrynin",
          ["guild"] = "Soft Enrage",
          ["boss"] = "Sszorak",
          ["amount"] = 116805,
          ["ilvl"] = 321,
          ["crit"] = 1397,
          ["haste"] = 1016,
          ["mastery"] = 362,
          ["vers"] = 91,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzy8Az8AzMzM2WGjZZYbGDAwAAAAAAg0MzyMjZwY2aDADAMD2AAAAgZmltlWmZsYZjZAMGzwYAwMDAmZAjF"
        },
        {
          ["name"] = "Palaschuin",
          ["guild"] = "BigBrain",
          ["boss"] = "Sszorak",
          ["amount"] = 115589,
          ["ilvl"] = 324,
          ["crit"] = 1260,
          ["haste"] = 973,
          ["mastery"] = 449,
          ["vers"] = 225,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzYmhtxYWG2GGAgBAAAAAANNzsNzYmhZegt2AwADYgNAAAAYmZZbplZGLW2YGADmhxAgZGAMzAGL"
        },
        {
          ["name"] = "Hayrõ",
          ["guild"] = "Wisp",
          ["boss"] = "Sszorak",
          ["amount"] = 115052,
          ["ilvl"] = 325,
          ["crit"] = 1094,
          ["haste"] = 1300,
          ["mastery"] = 481,
          ["vers"] = 220,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzMzMsMGWGWmxAAMAAAAAAINzsMzYGMmt2AwAAzgNAAAAYmZZbplZGLW2YGAjxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Vivipld",
          ["guild"] = "Honolulu",
          ["boss"] = "Sszorak",
          ["amount"] = 114747,
          ["ilvl"] = 325,
          ["crit"] = 1350,
          ["haste"] = 869,
          ["mastery"] = 684,
          ["vers"] = 369,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZmZGzMsNGWGjZMAADAAAAAASzMLzMmZYmZLAYgBMD2GAAAAMzsst0yMjFLbYAMYGGDAmZAgBYsA"
        },
        {
          ["name"] = "Neronzeera",
          ["guild"] = "Cutting Bread",
          ["boss"] = "Sszorak",
          ["amount"] = 114590,
          ["ilvl"] = 323,
          ["crit"] = 1314,
          ["haste"] = 963,
          ["mastery"] = 576,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzy8Az8AzMzM2WGjZZYZYAAGAAAAAAkmZWmZMDGzWbAYgBMD2AAAAgZmltlWmZsYZDDgBzsZMAYmBgZmBMWA"
        },
        {
          ["name"] = "Domideus",
          ["guild"] = "velocity",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 141669,
          ["ilvl"] = 326,
          ["crit"] = 1290,
          ["haste"] = 934,
          ["mastery"] = 377,
          ["vers"] = 393,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzy8Az8AzMzM2WGDLzilhBAYAAAAAAQTzMLzMmZGjZrNAMwAGYDAAAAmZW2WaZmxitNMMwgZYMAYmBAzAMWA"
        },
        {
          ["name"] = "분홍파프리카",
          ["guild"] = "Mate",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 135431,
          ["ilvl"] = 328,
          ["crit"] = 985,
          ["haste"] = 1397,
          ["mastery"] = 272,
          ["vers"] = 499,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWmHYGzMzMz2yYMLzilhBAYAAAAAAQTzMmZMzMGj2AwAAGsBAAAAzMLbLtMzYxyGzwAjxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Markass",
          ["guild"] = "Vibrant",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 132824,
          ["ilvl"] = 326,
          ["crit"] = 1255,
          ["haste"] = 1173,
          ["mastery"] = 261,
          ["vers"] = 504,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWmZmHYmZmZsMGzysYZYAAGAAAAAA00MjZGzgxs1GAGYAzgNAAAAYmZZbplZGLWgBwYMDzMAYmBAzMgxC"
        },
        {
          ["name"] = "Oudpala",
          ["guild"] = "Dedicated Casuals",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 132686,
          ["ilvl"] = 326,
          ["crit"] = 956,
          ["haste"] = 1045,
          ["mastery"] = 693,
          ["vers"] = 463,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWmHYmZmZmx2yYMLDLDDAwAAAAAAgmmZWmZMDGzWbAYgBMD2AAAAgZmltlWmZsYZjZAMYGGDAmZAwMDYsA"
        },
        {
          ["name"] = "헬로혜오니",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 131935,
          ["ilvl"] = 322,
          ["crit"] = 1271,
          ["haste"] = 1202,
          ["mastery"] = 339,
          ["vers"] = 250,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZeAzyMzMzMzMsMGzywywAAMAAAAAAopZmlZGzMMzs1GAGYAzgNAAAAYmZZZplZGL2wMAGMDjBAzMAwAMWA"
        },
        {
          ["name"] = "Shivapal",
          ["guild"] = "Fragglene",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 131886,
          ["ilvl"] = 325,
          ["crit"] = 1351,
          ["haste"] = 1136,
          ["mastery"] = 398,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWmHYmHYmZmx2yYMLzilhBAAAAAAAAaamZZmxMzYMbtBgBGwMYDAAAAmZW2WaZmxitNmBwYMDjBAzMAwAMWA"
        },
        {
          ["name"] = "Burgerpeople",
          ["guild"] = "Retired Extremely Bad",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 131789,
          ["ilvl"] = 323,
          ["crit"] = 949,
          ["haste"] = 1042,
          ["mastery"] = 686,
          ["vers"] = 243,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWmHYmHYmZmx2yYMLzilhBAYAAAAAAQTzMLzMmBjZrNAMwAGYDAAAAmZW2WaZmxilNmBwYMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Kitee",
          ["guild"] = "For the Glory of JO JO",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 131251,
          ["ilvl"] = 323,
          ["crit"] = 744,
          ["haste"] = 1329,
          ["mastery"] = 775,
          ["vers"] = 171,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWmZmZmZmhlxYWGWGGAgBAAAAAANNzYmxMYMbtBgBGwMYDAAAAmZWWWaZmxitNmhBGMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Brewbypal",
          ["guild"] = "get help",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 130435,
          ["ilvl"] = 325,
          ["crit"] = 664,
          ["haste"] = 1337,
          ["mastery"] = 383,
          ["vers"] = 626,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 324
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWGzYGzM2WYYZWmlhBAAAAAAAAaamZZmxMzYMbtBgBAGYbAAAAwMzy2SLzMWsshhBGjZYMAYmBAzMgxC"
        },
        {
          ["name"] = "Mudkìp",
          ["guild"] = "Tempo",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 130214,
          ["ilvl"] = 322,
          ["crit"] = 1225,
          ["haste"] = 1172,
          ["mastery"] = 459,
          ["vers"] = 137,
          ["trinkets"] = {
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWmHYmHYmZmx2yYMLzilhBAYAAAAAAQTzMLzMmBjZrNAMwAmBbAAAAwMzy2SLzMWssxMAGjhZMAYmBAzAMWA"
        },
        {
          ["name"] = "Denerocx",
          ["guild"] = "The Next Step",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 111258,
          ["ilvl"] = 321,
          ["crit"] = 1209,
          ["haste"] = 1041,
          ["mastery"] = 171,
          ["vers"] = 430,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYmHYmZmx2yYMLzilZMAAAAAAAAQamZZmxMDjZrNAMwMwAbAAAAwMzyySLzMWssxMAYMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "분홍파프리카",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 106330,
          ["ilvl"] = 328,
          ["crit"] = 926,
          ["haste"] = 1442,
          ["mastery"] = 372,
          ["vers"] = 415,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWmZGzMzMjlxYWmFLDDAAAAAAAAkmZWmZMzwY2aDADMDMD2AAAAgZmttlWmZsYZjZAwYwMDAmZAwMDYsA"
        },
        {
          ["name"] = "Shivapal",
          ["guild"] = "Fragglene",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 99258,
          ["ilvl"] = 326,
          ["crit"] = 1353,
          ["haste"] = 1137,
          ["mastery"] = 398,
          ["vers"] = 235,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzy8Az8AzMzM2WGDLzilZMAAAAAAAAQamZZmxMDjZrNAMwAmBbAAAAwMzy2SLzMWstxMAYMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Nomöre",
          ["guild"] = "Quichons",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 96066,
          ["ilvl"] = 321,
          ["crit"] = 1081,
          ["haste"] = 1132,
          ["mastery"] = 328,
          ["vers"] = 378,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYGzMzMz2yYMLzilZMAAAAAAAAQTzMLzMmZYMbtBgBMwMYDAAAAmZ22WaZmxilNmBwYMMjBAzMAwAMWA"
        },
        {
          ["name"] = "Dretnos",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 95900,
          ["ilvl"] = 322,
          ["crit"] = 1003,
          ["haste"] = 1148,
          ["mastery"] = 506,
          ["vers"] = 552,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = nil,
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDz2YGzMzMz2yYMLzilZMAAAAAAAAQamZZmxMDjZrNAMwAmBbAAAAwMz22SLzMWssxMAPwYMMjBAzMAwAMWA"
        },
        {
          ["name"] = "Vivipld",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 95754,
          ["ilvl"] = 326,
          ["crit"] = 1320,
          ["haste"] = 921,
          ["mastery"] = 477,
          ["vers"] = 436,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDjxMzMzMjtlxYWG2mxAAAAAAAAANNzsMzYmhxs1GAGYADsNAAAAYmZZbplZGLW2wwADmZzYAwMDghBYsA"
        },
        {
          ["name"] = "Holyvi",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 87685,
          ["ilvl"] = 325,
          ["crit"] = 1093,
          ["haste"] = 1042,
          ["mastery"] = 920,
          ["vers"] = 193,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWmZmHYmZmZsMGzywywAAAAAAAAApZmlZGzMMmt2AwAzAzgNAAAAYmZbbplZGL22YGAMmhxAgZGAMzAGL"
        },
        {
          ["name"] = "Magicdn",
          ["guild"] = "Ethical",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 86970,
          ["ilvl"] = 325,
          ["crit"] = 980,
          ["haste"] = 1014,
          ["mastery"] = 372,
          ["vers"] = 979,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDz2YGzMzMz2yYMLzilZMAAAAAAAAQamZZmxMDjZrNAMwMwAbAAAAwMz22SLzMWssxMAYMDjBAzMAYmBMWA"
        },
        {
          ["name"] = "Horii",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 84562,
          ["ilvl"] = 327,
          ["crit"] = 964,
          ["haste"] = 1405,
          ["mastery"] = 694,
          ["vers"] = 292,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDz28AzYmZmx2yYMLzilhBAAAAAAAAaamZZmxMYMbtBgBGwMYDAAAAmZW2WaZmxilNMAYMDzMAYmBwYmBMWA"
        },
        {
          ["name"] = "Frostywi",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 81504,
          ["ilvl"] = 326,
          ["crit"] = 1132,
          ["haste"] = 1267,
          ["mastery"] = 549,
          ["vers"] = 213,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDz28AzYmZmx2yYMLzilhBAAAAAAAASzMLzMmZYMbtBgBGwMYDAAAAmZWWWaZmxilNMAGjZ2MGAMzAgZGwYB"
        },
        {
          ["name"] = "Nomöre",
          ["guild"] = "Quichons",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 129218,
          ["ilvl"] = 321,
          ["crit"] = 1081,
          ["haste"] = 1132,
          ["mastery"] = 328,
          ["vers"] = 378,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 308
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmZMzMzMsMGWGWGGAgBAAAAAApZGmxMzYmZrNAMwMwMYbAAAAwMz22SLzMWsshBghZYAAzMAYGgxC"
        },
        {
          ["name"] = "Taipeichina",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 127759,
          ["ilvl"] = 322,
          ["crit"] = 1103,
          ["haste"] = 1138,
          ["mastery"] = 631,
          ["vers"] = 288,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzYWmHYmHYGzM2WGDLDLzYAAAAAAAAg0MzmZMzMmZ2aDADMgB2AAAAgZmlllWmZsYbjZAwYGGDAmZAwMDYsA"
        },
        {
          ["name"] = "Rïÿn",
          ["guild"] = "Skill Issue",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 118988,
          ["ilvl"] = 321,
          ["crit"] = 857,
          ["haste"] = 1025,
          ["mastery"] = 726,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMz8AzMzMsMGzywywAAMAAAAAAopZGzMmZYMbtBgBGwMYDAAAAmZW2WaZmxitNMAGMDzMAYmBAzMgxC"
        },
        {
          ["name"] = "Ravenchest",
          ["guild"] = "NonSense",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 117423,
          ["ilvl"] = 320,
          ["crit"] = 959,
          ["haste"] = 937,
          ["mastery"] = 640,
          ["vers"] = 352,
          ["trinkets"] = {
            {
              ["id"] = 270163,
              ["name"] = "Sszorak's Ferocity",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMz8AzMzMsMGzywywAAMAAAAAAopZGzMmZYMbtBgBGwMYDAAAAmZW2WaZmxitNMAGMDzMAYmBAzMgxC"
        },
        {
          ["name"] = "Lightstic",
          ["guild"] = "Rage Against the Meta",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 115636,
          ["ilvl"] = 319,
          ["crit"] = 1031,
          ["haste"] = 1284,
          ["mastery"] = 274,
          ["vers"] = 221,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzDYWmZMzYmhlxYWGWGGAgBAAAAAApZmlZGzgxs1GAGYGYGsBAAAAzMLbLtMzYx2GzAgxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Guacamolen",
          ["guild"] = "Mental Apocalypse",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 115275,
          ["ilvl"] = 324,
          ["crit"] = 1044,
          ["haste"] = 691,
          ["mastery"] = 847,
          ["vers"] = 384,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNzDYWmZGzMzMsMGzywywAAMAAAAAAopZGzMmZYMbtBgBGwMYDAAAAmZW2WaZmxitNMAGMDzMAYmBAzMgxC"
        },
        {
          ["name"] = "Willpaladin",
          ["guild"] = "Deathstroke Division",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 114923,
          ["ilvl"] = 322,
          ["crit"] = 1035,
          ["haste"] = 869,
          ["mastery"] = 764,
          ["vers"] = 327,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250245,
              ["name"] = "Tumor of the Swarm",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzMzMsMGWGWmxAAAAAAAAANNzsYGzMMmt2AwAAzgtBAAAAzMbbLtMzYx2GzAgxMMGAMzAgZGwYB"
        },
        {
          ["name"] = "Logbewbble",
          ["guild"] = "Cute Anime Boys",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 114643,
          ["ilvl"] = 323,
          ["crit"] = 1057,
          ["haste"] = 1086,
          ["mastery"] = 802,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzy8AzMzMzMWWGDLDLzYAAGAAAAAA00MDzYmhxs1GAGYAzgtBAAAAzMLbLtMzYx2GGAwMMGAMzAwMzAGL"
        },
        {
          ["name"] = "Ayerio",
          ["guild"] = "Djungelpatrullen",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 114383,
          ["ilvl"] = 323,
          ["crit"] = 990,
          ["haste"] = 899,
          ["mastery"] = 441,
          ["vers"] = 581,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzMzMzMsNGzywyMGAAAAAAAAopZGmxMDjZLAYAgZw2AAAAgZmltlWmZsYbDDgxYGGDAmZAYmZAjF"
        },
        {
          ["name"] = "Podrawchill",
          ["guild"] = "Авангард Альфа",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 114372,
          ["ilvl"] = 325,
          ["crit"] = 1253,
          ["haste"] = 1381,
          ["mastery"] = 251,
          ["vers"] = 328,
          ["trinkets"] = {
            {
              ["id"] = 193757,
              ["name"] = "Ruby Whelp Shell",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzy8Az8AzMzM2WGjZZYZYAAGAAAAAA00MjZGzMMmt2AwAGYGsBAAAAzMLbLtMzYx2GzAYMmhxAgZGAMDwYB"
        }
      }
    },
    {
      ["spec"] = "Retribution",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Bombu",
          ["guild"] = "Anything to Live",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 255789,
          ["ilvl"] = 324,
          ["crit"] = 1152,
          ["haste"] = 861,
          ["mastery"] = 1101,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "Huggepung",
          ["guild"] = "Skattkistan",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 247953,
          ["ilvl"] = 323,
          ["crit"] = 1020,
          ["haste"] = 901,
          ["mastery"] = 1200,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYAAAAAAYmyYGmZsNmthZ2mxYMGmxCbDAzysNzMbNAAAwCgBAjZYGMjxsBMzMMmxgB"
        },
        {
          ["name"] = "Erxicn",
          ["guild"] = "傲  血  荣  耀",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 241815,
          ["ilvl"] = 325,
          ["crit"] = 912,
          ["haste"] = 924,
          ["mastery"] = 1116,
          ["vers"] = 183,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 315
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMDAAAAAAzUmlZYmZ2Gz2wMbzYMGDDLsNAMLz2Mzs1AAAALAGAwMmBmxY2AmZGGDDG"
        },
        {
          ["name"] = "公仔向日葵",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 240588,
          ["ilvl"] = 327,
          ["crit"] = 987,
          ["haste"] = 1029,
          ["mastery"] = 1179,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZAAAAAAYUmtZYmx24B2GmZbGzMGDzYhtBgZZ2mZmtGAAAYBwALYGzwAzYMbAzMDjhBD"
        },
        {
          ["name"] = "Âra",
          ["guild"] = "baited",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 237078,
          ["ilvl"] = 327,
          ["crit"] = 1083,
          ["haste"] = 888,
          ["mastery"] = 1185,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "Jeros",
          ["guild"] = "Simbiosis",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 235609,
          ["ilvl"] = 324,
          ["crit"] = 883,
          ["haste"] = 982,
          ["mastery"] = 1184,
          ["vers"] = 92,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZZbmZWGzYGAAAAAAjyYGmZsNmthZ2mxMjxwMWYDAzysNzMbNAAAwCgBAjZYGMjZmNgZmxMGGMA"
        },
        {
          ["name"] = "Atheryon",
          ["guild"] = "Durtarnir",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 235433,
          ["ilvl"] = 326,
          ["crit"] = 1232,
          ["haste"] = 622,
          ["mastery"] = 3082,
          ["vers"] = -140,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGzMWYDAzysNzMbNAAAwCgBAMDDMjZmNgZmxMGGMA"
        },
        {
          ["name"] = "Zbay",
          ["guild"] = "The Extendables",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 235282,
          ["ilvl"] = 320,
          ["crit"] = 1140,
          ["haste"] = 550,
          ["mastery"] = 1252,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAjyYGmZsNmthZ2mxMjxwMWYDAzysNzMbNAAAwCgBAjZYGMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "飞翔的锤子",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 235244,
          ["ilvl"] = 325,
          ["crit"] = 1124,
          ["haste"] = 798,
          ["mastery"] = 1174,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZZbmZWGzMzAAAAAAYmysNDzM2Gz2wMbzYMGDzYhFAMLz2Mzs1AAAALAGAGGMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "堤里奥佛丁",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 233391,
          ["ilvl"] = 324,
          ["crit"] = 959,
          ["haste"] = 1025,
          ["mastery"] = 1070,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270602,
              ["name"] = "Venomous Gladiator's Badge of Ferocity",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmysZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAAmZzMYGzMbAzMDjhBD"
        },
        {
          ["name"] = "Yonderwayz",
          ["guild"] = "Insert More Coins",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 232461,
          ["ilvl"] = 325,
          ["crit"] = 1018,
          ["haste"] = 878,
          ["mastery"] = 1133,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZGAAAAAAzUmtZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "신성은장식",
          ["guild"] = "Mate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 231994,
          ["ilvl"] = 324,
          ["crit"] = 1075,
          ["haste"] = 893,
          ["mastery"] = 1117,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZGAAAAAAzUGzwMjtZmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAGjZYGMjZmNgZmhxAMA"
        },
        {
          ["name"] = "徐小白丶",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 226119,
          ["ilvl"] = 332,
          ["crit"] = 1032,
          ["haste"] = 919,
          ["mastery"] = 1228,
          ["vers"] = 107,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAjysNDzM2Gz2wMbzYMGjZGLsBgZZ2mZmtGAAAYBwAgxMMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "Tehsu",
          ["guild"] = "Retreat",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224956,
          ["ilvl"] = 326,
          ["crit"] = 1292,
          ["haste"] = 773,
          ["mastery"] = 1006,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "Âra",
          ["guild"] = "baited",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 224666,
          ["ilvl"] = 327,
          ["crit"] = 1083,
          ["haste"] = 723,
          ["mastery"] = 1350,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "최고",
          ["guild"] = "인앤아웃",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 222515,
          ["ilvl"] = 319,
          ["crit"] = 1072,
          ["haste"] = 738,
          ["mastery"] = 1143,
          ["vers"] = 123,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMDAAAAAAjysMDzM2Gz2wMbzYMGDzYhtBgZZ2mZmtGAAAYBwAAmZzMYGjZDYmZYMMYA"
        },
        {
          ["name"] = "老干妈辣酱",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 220361,
          ["ilvl"] = 325,
          ["crit"] = 973,
          ["haste"] = 970,
          ["mastery"] = 1085,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZGAAAAAAjysZYmx2Y2GmZbGzMGDzYhNAMLz2Mzs1AAAALAGAMmhZwMmZ2AmZGGzYwA"
        },
        {
          ["name"] = "Bombu",
          ["guild"] = "Anything to Live",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 220250,
          ["ilvl"] = 322,
          ["crit"] = 1128,
          ["haste"] = 854,
          ["mastery"] = 1093,
          ["vers"] = 89,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "Renae",
          ["guild"] = "The Family Business",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 218567,
          ["ilvl"] = 324,
          ["crit"] = 1005,
          ["haste"] = 927,
          ["mastery"] = 1035,
          ["vers"] = 216,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGzMGDzYhNAMLz2Mzs1AAAALAGAMmhBmxMzGwMzwYYwA"
        },
        {
          ["name"] = "白夜之光",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 218216,
          ["ilvl"] = 326,
          ["crit"] = 887,
          ["haste"] = 938,
          ["mastery"] = 1205,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmZ2Gz2wMbzYMGDzYhNAMLz2Mzs0AAAALAGAwMMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "Трипофоб",
          ["guild"] = "Рестарт",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 367368,
          ["ilvl"] = 324,
          ["crit"] = 1082,
          ["haste"] = 802,
          ["mastery"] = 1153,
          ["vers"] = 129,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYUGzwMjtxsNMz2MmZMGmxCbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "Thatsaban",
          ["guild"] = "Unicorn Seven",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 366260,
          ["ilvl"] = 325,
          ["crit"] = 996,
          ["haste"] = 1018,
          ["mastery"] = 1071,
          ["vers"] = 160,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZZbmZWGzMzAAAAAAYmysYYmx2Y2GmZbGjxYMzYhNAMbz2Mzs1AAAALAGAMmhZwMmZ2AmZGGYwA"
        },
        {
          ["name"] = "Seqqxo",
          ["guild"] = "Endpoint",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 365988,
          ["ilvl"] = 322,
          ["crit"] = 1049,
          ["haste"] = 948,
          ["mastery"] = 979,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "Kivysn",
          ["guild"] = "monkaPickle",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 357848,
          ["ilvl"] = 325,
          ["crit"] = 1113,
          ["haste"] = 786,
          ["mastery"] = 1178,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZGAAAAAAzUGzwMjtxsNMz2MGjxwMWYDAzysNzMbNAAAwCgBAjZYgZMzsBMzMmxMGMA"
        },
        {
          ["name"] = "Pod",
          ["guild"] = "TRK",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 355781,
          ["ilvl"] = 323,
          ["crit"] = 1159,
          ["haste"] = 767,
          ["mastery"] = 1025,
          ["vers"] = 247,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "Zaylex",
          ["guild"] = "Rewind",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 355176,
          ["ilvl"] = 324,
          ["crit"] = 1119,
          ["haste"] = 897,
          ["mastery"] = 1080,
          ["vers"] = 89,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 331
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMMwMmZ2AmZGGzYwA"
        },
        {
          ["name"] = "阿慈谷日富美",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 354515,
          ["ilvl"] = 322,
          ["crit"] = 937,
          ["haste"] = 942,
          ["mastery"] = 1076,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGzMWYDAzysNzMbNAAAwCgBAMDDMjZmNgZmxMGGMA"
        },
        {
          ["name"] = "轻音",
          ["guild"] = "诗与远方",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 353823,
          ["ilvl"] = 323,
          ["crit"] = 1049,
          ["haste"] = 906,
          ["mastery"] = 1112,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZZbmZWGzMzAAAAAAYmysNDzM2Gz2wMbzYMGDzYhFAMLz2Mzs1AAAALAGAGGMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "Aziby",
          ["guild"] = "Iris",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 350816,
          ["ilvl"] = 326,
          ["crit"] = 962,
          ["haste"] = 866,
          ["mastery"] = 1092,
          ["vers"] = 217,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "진혈",
          ["guild"] = "난민촌",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 350394,
          ["ilvl"] = 324,
          ["crit"] = 1137,
          ["haste"] = 825,
          ["mastery"] = 1174,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxYmxCbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "Âra",
          ["guild"] = "baited",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 335078,
          ["ilvl"] = 327,
          ["crit"] = 1083,
          ["haste"] = 723,
          ["mastery"] = 1350,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "Pod",
          ["guild"] = "TRK",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 323051,
          ["ilvl"] = 323,
          ["crit"] = 1159,
          ["haste"] = 767,
          ["mastery"] = 1025,
          ["vers"] = 247,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "血鬼狂人",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 312023,
          ["ilvl"] = 324,
          ["crit"] = 912,
          ["haste"] = 1038,
          ["mastery"] = 1090,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMMwMmZ2AmZGGzYwA"
        },
        {
          ["name"] = "Erxicn",
          ["guild"] = "傲  血  荣  耀",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 311145,
          ["ilvl"] = 327,
          ["crit"] = 818,
          ["haste"] = 934,
          ["mastery"] = 1254,
          ["vers"] = 183,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAjysNDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1AAAALAGwAmxMwMmZ2AmZmxYYwA"
        },
        {
          ["name"] = "Flameqtz",
          ["guild"] = "Burden",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 309158,
          ["ilvl"] = 324,
          ["crit"] = 1204,
          ["haste"] = 686,
          ["mastery"] = 1232,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "Bombu",
          ["guild"] = "Anything to Live",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 307165,
          ["ilvl"] = 324,
          ["crit"] = 1152,
          ["haste"] = 861,
          ["mastery"] = 1101,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "Atheryon",
          ["guild"] = "Durtarnir",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 305150,
          ["ilvl"] = 326,
          ["crit"] = 1232,
          ["haste"] = 622,
          ["mastery"] = 1324,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGzMWYDAzysNzMbNAAAwCgBAMDDMjZmNgZmxMGGMA"
        },
        {
          ["name"] = "Soliddwarf",
          ["guild"] = "Misery",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 304133,
          ["ilvl"] = 326,
          ["crit"] = 1099,
          ["haste"] = 917,
          ["mastery"] = 1047,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "Ezee",
          ["guild"] = "Myth",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 304050,
          ["ilvl"] = 326,
          ["crit"] = 1062,
          ["haste"] = 864,
          ["mastery"] = 1148,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "Poloqq",
          ["guild"] = "Mirabelki",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 301258,
          ["ilvl"] = 327,
          ["crit"] = 1160,
          ["haste"] = 839,
          ["mastery"] = 1190,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "Calamitas",
          ["guild"] = "Fade",
          ["boss"] = "Sszorak",
          ["amount"] = 247163,
          ["ilvl"] = 325,
          ["crit"] = 1088,
          ["haste"] = 914,
          ["mastery"] = 1119,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGGDAAAAAAjysNDzM2Gz2wMbzYmxYMzYhtBgZZ2mZmtGAAAYBwAGMmxAmxMzGwMzwYAG"
        },
        {
          ["name"] = "Erxicn",
          ["guild"] = "傲  血  荣  耀",
          ["boss"] = "Sszorak",
          ["amount"] = 245592,
          ["ilvl"] = 327,
          ["crit"] = 822,
          ["haste"] = 941,
          ["mastery"] = 1288,
          ["vers"] = 183,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGGDAAAAAAjysNDzM2Gz2wMbzYMGDzYhtBgZZ2mZmtGAAAYBwAGwMmBmxMzGwMzMGDDG"
        },
        {
          ["name"] = "Soliddwarf",
          ["guild"] = "Misery",
          ["boss"] = "Sszorak",
          ["amount"] = 243573,
          ["ilvl"] = 326,
          ["crit"] = 1099,
          ["haste"] = 917,
          ["mastery"] = 1047,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMzsNmthZ2mxYMGmxCbDAzysNzMbNAAAwCgBAjZYGMjZmNgZmhxwgB"
        },
        {
          ["name"] = "血鬼狂人",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 241745,
          ["ilvl"] = 324,
          ["crit"] = 912,
          ["haste"] = 1038,
          ["mastery"] = 1090,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGmZAAAAAAYUmlZYmx2Y2GmZbGjxYYGLsNAMLz2Mzs1AAAALAGAMmhBmxMzGwMzwYGDG"
        },
        {
          ["name"] = "Tehsu",
          ["guild"] = "Retreat",
          ["boss"] = "Sszorak",
          ["amount"] = 241617,
          ["ilvl"] = 326,
          ["crit"] = 1292,
          ["haste"] = 773,
          ["mastery"] = 1006,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMmxgB"
        },
        {
          ["name"] = "Ezee",
          ["guild"] = "Myth",
          ["boss"] = "Sszorak",
          ["amount"] = 239751,
          ["ilvl"] = 326,
          ["crit"] = 1062,
          ["haste"] = 864,
          ["mastery"] = 1148,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGGDAAAAAAjysNDzM2Gz2wMbzYmxYMzYhtBgZZ2mZmtGAAAYBwAGMmxAmxMzGwMzwYAG"
        },
        {
          ["name"] = "Vcthree",
          ["guild"] = "CV",
          ["boss"] = "Sszorak",
          ["amount"] = 238123,
          ["ilvl"] = 325,
          ["crit"] = 1065,
          ["haste"] = 916,
          ["mastery"] = 1089,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGmZAAAAAAYmysMDzM2Gz2wMbzYMGDzYhtBgZZ2mZmtGAAAYBwAgxMMwMmZ2AmZGGDDG"
        },
        {
          ["name"] = "Эпикшао",
          ["guild"] = "Фаерфлай",
          ["boss"] = "Sszorak",
          ["amount"] = 237800,
          ["ilvl"] = 326,
          ["crit"] = 1013,
          ["haste"] = 930,
          ["mastery"] = 1186,
          ["vers"] = 69,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGmZAAAAAAYmyYGmZsNmthZ2mxYMGmxGbDAzysNzMbNAAAwCgBAjZYgZMzsBMzMMmxgB"
        },
        {
          ["name"] = "Âra",
          ["guild"] = "baited",
          ["boss"] = "Sszorak",
          ["amount"] = 236519,
          ["ilvl"] = 327,
          ["crit"] = 1083,
          ["haste"] = 888,
          ["mastery"] = 1185,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "Meq",
          ["guild"] = "Ethical",
          ["boss"] = "Sszorak",
          ["amount"] = 234664,
          ["ilvl"] = 327,
          ["crit"] = 1102,
          ["haste"] = 911,
          ["mastery"] = 3000,
          ["vers"] = -140,
          ["trinkets"] = {
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMGzMWYbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMmxgB"
        },
        {
          ["name"] = "Ezee",
          ["guild"] = "Myth",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 344609,
          ["ilvl"] = 326,
          ["crit"] = 1065,
          ["haste"] = 865,
          ["mastery"] = 1148,
          ["vers"] = 151,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "Âra",
          ["guild"] = "baited",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 317714,
          ["ilvl"] = 327,
          ["crit"] = 1083,
          ["haste"] = 888,
          ["mastery"] = 1185,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "徐小白丶",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 312452,
          ["ilvl"] = 332,
          ["crit"] = 1032,
          ["haste"] = 919,
          ["mastery"] = 1228,
          ["vers"] = 107,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 344
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYGzAAAAAAYmysNDzM2Gz2wMbzYMGjZGLsBgZZ2mZmtGAAAYBwAgxMMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "Pod",
          ["guild"] = "TRK",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 311481,
          ["ilvl"] = 325,
          ["crit"] = 1164,
          ["haste"] = 813,
          ["mastery"] = 1144,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "Flameqtz",
          ["guild"] = "Burden",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 310323,
          ["ilvl"] = 324,
          ["crit"] = 1174,
          ["haste"] = 859,
          ["mastery"] = 1137,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "Erxicn",
          ["guild"] = "傲  血  荣  耀",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 306219,
          ["ilvl"] = 325,
          ["crit"] = 928,
          ["haste"] = 940,
          ["mastery"] = 1116,
          ["vers"] = 183,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 318
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 315
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZGAAAAAAzUGzwMzsNmthZ2mxYMGGWYDAzysNzMbNAAAwCgBMgZMDMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "Elpal",
          ["guild"] = "Speakeasy",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 303992,
          ["ilvl"] = 322,
          ["crit"] = 964,
          ["haste"] = 1021,
          ["mastery"] = 914,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYMzAAAAAAYmyYGmZsNmthZ2mxMjxwMWYDAzysNzMbNAAAwCgBAjZYGMzMzsBMzMMGGMA"
        },
        {
          ["name"] = "Abaddon",
          ["guild"] = "Tusk",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 301254,
          ["ilvl"] = 325,
          ["crit"] = 1129,
          ["haste"] = 628,
          ["mastery"] = 1298,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMMGMA"
        },
        {
          ["name"] = "Remustr",
          ["guild"] = "Ascendancy",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 300585,
          ["ilvl"] = 324,
          ["crit"] = 1067,
          ["haste"] = 869,
          ["mastery"] = 1140,
          ["vers"] = 149,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZGAAAAAAzUGzwMzsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMgBjZYgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "Aish",
          ["guild"] = "Comfy",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 299310,
          ["ilvl"] = 326,
          ["crit"] = 1300,
          ["haste"] = 872,
          ["mastery"] = 880,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZGAAAAAAzUmtZYmx2Y2GmZbGzMGDzYhNAMLz2Mzs1AAAALAGAMGMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "Âra",
          ["guild"] = "baited",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 249180,
          ["ilvl"] = 327,
          ["crit"] = 1083,
          ["haste"] = 888,
          ["mastery"] = 1185,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "Yenvenger",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 232793,
          ["ilvl"] = 327,
          ["crit"] = 1001,
          ["haste"] = 952,
          ["mastery"] = 1154,
          ["vers"] = 117,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270165,
              ["name"] = "Keeper's Seething Core",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGGDAAAAAAjysMDzM2Gz2wMbzYMGDzYhtBgZZWmZmtGAAAYBwAwMmhZwMmZ2AmZGGDDG"
        },
        {
          ["name"] = "Neykprediger",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 228413,
          ["ilvl"] = 327,
          ["crit"] = 925,
          ["haste"] = 852,
          ["mastery"] = 1312,
          ["vers"] = 194,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAjysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1AAAALAGAmxMMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "신성은장식",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 385070,
          ["ilvl"] = 327,
          ["crit"] = 1086,
          ["haste"] = 877,
          ["mastery"] = 1121,
          ["vers"] = 1354,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAjyYGmZsNmthZ2mxMjxwMWYDAzysNzMbNAAAwCgBAjZYGMjZmNgZmxMGGMA"
        },
        {
          ["name"] = "Âra",
          ["guild"] = "baited",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 245774,
          ["ilvl"] = 327,
          ["crit"] = 1083,
          ["haste"] = 888,
          ["mastery"] = 1185,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMbAzYmZDYmZYMjBD"
        },
        {
          ["name"] = "Xatihr",
          ["guild"] = "Hatewatching",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 245713,
          ["ilvl"] = 324,
          ["crit"] = 1100,
          ["haste"] = 743,
          ["mastery"] = 1134,
          ["vers"] = 173,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZGAAAAAAjyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMgxYMDDMjZmNgZmxMGGMA"
        },
        {
          ["name"] = "최고",
          ["guild"] = "인앤아웃",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 245398,
          ["ilvl"] = 328,
          ["crit"] = 1218,
          ["haste"] = 754,
          ["mastery"] = 1154,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMDAAAAAAjysMDzM2Gz2wMbzYMGDzYhtBgZZ2mZmtGAAAYBwAAmZzMYGjZDYmZYMMYA"
        },
        {
          ["name"] = "Lunates",
          ["guild"] = "Tatortreiniger",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 245072,
          ["ilvl"] = 321,
          ["crit"] = 1144,
          ["haste"] = 1141,
          ["mastery"] = 708,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 193701,
              ["name"] = "Algeth'ar Puzzle Box",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmysZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAAmhZwMmZ2AmZGGzYwA"
        },
        {
          ["name"] = "Seraphim",
          ["guild"] = "Reforged",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 244864,
          ["ilvl"] = 324,
          ["crit"] = 1263,
          ["haste"] = 598,
          ["mastery"] = 1167,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "Lfegirls",
          ["guild"] = "Solids",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 243226,
          ["ilvl"] = 325,
          ["crit"] = 2841,
          ["haste"] = 931,
          ["mastery"] = 945,
          ["vers"] = -66,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwMWYDAzysNzMbNAAAwCgBgZMDzgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "Skilletto",
          ["guild"] = "Blur",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 240604,
          ["ilvl"] = 322,
          ["crit"] = 1062,
          ["haste"] = 673,
          ["mastery"] = 1079,
          ["vers"] = 173,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYUmtZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGAAAYBwAgxMMDmxMzGwMzwYYwA"
        },
        {
          ["name"] = "Ezee",
          ["guild"] = "Myth",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 240539,
          ["ilvl"] = 322,
          ["crit"] = 1008,
          ["haste"] = 997,
          ["mastery"] = 1019,
          ["vers"] = 83,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGzMWYDAzysNzMbNAAAwCgBAjZYgZMzsBMzMMGGMA"
        },
        {
          ["name"] = "旺旺屁",
          ["guild"] = "年少有为不自卑",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 239983,
          ["ilvl"] = 321,
          ["crit"] = 941,
          ["haste"] = 1030,
          ["mastery"] = 1182,
          ["vers"] = 14,
          ["trinkets"] = {
            {
              ["id"] = 270175,
              ["name"] = "Voracious Heart of Ula'tek",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            }
          },
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZZbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwMWYDAzysNzMbNAAAwCgBAjZYGMjZmNgZmhxMGMA"
        },
        {
          ["name"] = "Saven",
          ["guild"] = "Gulp",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 238192,
          ["ilvl"] = 323,
          ["crit"] = 1121,
          ["haste"] = 761,
          ["mastery"] = 1098,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270173,
              ["name"] = "Zul'jin's Guillotine Technique",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzyYmZGAAAAAAjysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtGAAAYBwAgxMMwMmZ2AmZGzYYwA"
        }
      }
    }
  }
}
