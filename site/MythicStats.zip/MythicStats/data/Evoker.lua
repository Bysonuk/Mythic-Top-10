MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.classes = MythicStatsDB.classes or {}
MythicStatsDB.classes["Evoker"] = {
  ["className"] = "Evoker",
  ["specs"] = {
    {
      ["spec"] = "Devastation",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Creachyy",
          ["guild"] = "Wasted Potential [UC]",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 244528,
          ["ilvl"] = 322,
          ["crit"] = 1204,
          ["haste"] = 593,
          ["mastery"] = 777,
          ["vers"] = 539,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 315
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmZmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Damwon",
          ["guild"] = "get help",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 243330,
          ["ilvl"] = 324,
          ["crit"] = 1461,
          ["haste"] = 761,
          ["mastery"] = 612,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmZmxYmZbmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Sparkyevo",
          ["guild"] = "Jade Falcons",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 240779,
          ["ilvl"] = 321,
          ["crit"] = 1237,
          ["haste"] = 751,
          ["mastery"] = 831,
          ["vers"] = 265,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGMDMYMTzMzMNjx2MmZmZmZmZGwMmZGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "星火龙",
          ["guild"] = "傲  血  荣  耀",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 238083,
          ["ilvl"] = 323,
          ["crit"] = 1458,
          ["haste"] = 703,
          ["mastery"] = 818,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDMDzwMDMYMTjZmpZM2mxMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Replayvoker",
          ["guild"] = "Phoenix",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 237732,
          ["ilvl"] = 324,
          ["crit"] = 1255,
          ["haste"] = 844,
          ["mastery"] = 795,
          ["vers"] = 252,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "伊瑟芮丝",
          ["guild"] = "剑心犹在",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 237574,
          ["ilvl"] = 322,
          ["crit"] = 1310,
          ["haste"] = 825,
          ["mastery"] = 721,
          ["vers"] = 256,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 318
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZamZmpZmx2MzMzMzMzMzAmxMzYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Zathir",
          ["guild"] = "Nerd Rage",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 234791,
          ["ilvl"] = 321,
          ["crit"] = 1071,
          ["haste"] = 904,
          ["mastery"] = 659,
          ["vers"] = 285,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 324
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDMDzwMgHAjZamZmpZM2mxMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBzYA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Imugi",
          ["guild"] = "Nerd Rage",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 233291,
          ["ilvl"] = 321,
          ["crit"] = 1224,
          ["haste"] = 477,
          ["mastery"] = 1270,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGmBmBjZamZmpZmx2MMzMzMzMzAMzMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Millzd",
          ["guild"] = "Infinity",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 232445,
          ["ilvl"] = 325,
          ["crit"] = 1402,
          ["haste"] = 735,
          ["mastery"] = 832,
          ["vers"] = 163,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGmZgBjZamZmpZM2mxMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Drbono",
          ["guild"] = "TURTLES KIMBLE",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 231742,
          ["ilvl"] = 325,
          ["crit"] = 1352,
          ["haste"] = 802,
          ["mastery"] = 901,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Wnipeg",
          ["guild"] = "Reko",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 222152,
          ["ilvl"] = 325,
          ["crit"] = 1281,
          ["haste"] = 796,
          ["mastery"] = 714,
          ["vers"] = 250,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Archimo",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 221770,
          ["ilvl"] = 323,
          ["crit"] = 1483,
          ["haste"] = 662,
          ["mastery"] = 647,
          ["vers"] = 224,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTzMzMNzM2mZmZmZmZmZGwMzMYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Blueprínt",
          ["guild"] = "Honestly",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 221560,
          ["ilvl"] = 326,
          ["crit"] = 1522,
          ["haste"] = 767,
          ["mastery"] = 843,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwM8AmBjZaMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Ксиона",
          ["guild"] = "Dubious content",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217208,
          ["ilvl"] = 323,
          ["crit"] = 1295,
          ["haste"] = 582,
          ["mastery"] = 896,
          ["vers"] = 201,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Gilgvoker",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 216986,
          ["ilvl"] = 329,
          ["crit"] = 1239,
          ["haste"] = 757,
          ["mastery"] = 1023,
          ["vers"] = 154,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Fazo",
          ["guild"] = "Epoch",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 213405,
          ["ilvl"] = 326,
          ["crit"] = 1193,
          ["haste"] = 843,
          ["mastery"] = 1014,
          ["vers"] = 147,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmZmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Stratoe",
          ["guild"] = "Honolulu",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209684,
          ["ilvl"] = 322,
          ["crit"] = 1378,
          ["haste"] = 739,
          ["mastery"] = 823,
          ["vers"] = 143,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGmhxMYMTjZmpZM2mxMzMzMzMzAMmxYmZZmZgBGD2glxox2AYGA2wAzMYYA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "星火龙",
          ["guild"] = "傲  血  荣  耀",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209661,
          ["ilvl"] = 327,
          ["crit"] = 1456,
          ["haste"] = 839,
          ["mastery"] = 695,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDMDzwMDMYMTjZmpZM2mxMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "亜菲利欧",
          ["guild"] = "Nxt",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 208753,
          ["ilvl"] = 323,
          ["crit"] = 1294,
          ["haste"] = 762,
          ["mastery"] = 843,
          ["vers"] = 171,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMwMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Fistlad",
          ["guild"] = "Rain",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 208565,
          ["ilvl"] = 324,
          ["crit"] = 1373,
          ["haste"] = 856,
          ["mastery"] = 702,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGmZgBjZamZmpZM2mxMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Replayvoker",
          ["guild"] = "Phoenix",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 347749,
          ["ilvl"] = 320,
          ["crit"] = 1341,
          ["haste"] = 984,
          ["mastery"] = 459,
          ["vers"] = 282,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGmZgBjZaMzMNjx2MmZmZmZmZGwMzMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Archimo",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 342575,
          ["ilvl"] = 323,
          ["crit"] = 1483,
          ["haste"] = 662,
          ["mastery"] = 647,
          ["vers"] = 224,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGmZgBjZamZmpZmx2MMzMzMzMzAmZmBzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Greenbari",
          ["guild"] = "Horror",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 339593,
          ["ilvl"] = 324,
          ["crit"] = 1233,
          ["haste"] = 742,
          ["mastery"] = 874,
          ["vers"] = 311,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "铁甲湾小宝",
          ["guild"] = "十年",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 331618,
          ["ilvl"] = 321,
          ["crit"] = 1332,
          ["haste"] = 644,
          ["mastery"] = 913,
          ["vers"] = 197,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZamZmpZmx2MzMzMzMzMzAmxMzYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Varaxion",
          ["guild"] = "raise",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 324925,
          ["ilvl"] = 322,
          ["crit"] = 1228,
          ["haste"] = 693,
          ["mastery"] = 752,
          ["vers"] = 286,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZamZmpZmx2MzMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "星火龙",
          ["guild"] = "傲  血  荣  耀",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 322465,
          ["ilvl"] = 327,
          ["crit"] = 1456,
          ["haste"] = 839,
          ["mastery"] = 695,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDMDzwMDMYMTjZmpZM2mxMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Mythvoker",
          ["guild"] = "Noctis",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 322377,
          ["ilvl"] = 323,
          ["crit"] = 1315,
          ["haste"] = 874,
          ["mastery"] = 714,
          ["vers"] = 274,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDMDzwMgBjZamZmpZM2mxMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Zathir",
          ["guild"] = "Nerd Rage",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 322251,
          ["ilvl"] = 321,
          ["crit"] = 1071,
          ["haste"] = 904,
          ["mastery"] = 659,
          ["vers"] = 285,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 324
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDMDzwMgHAjZamZmpZM2mxMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBzYA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Fistlad",
          ["guild"] = "Rain",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 321823,
          ["ilvl"] = 317,
          ["crit"] = 1414,
          ["haste"] = 644,
          ["mastery"] = 882,
          ["vers"] = 155,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGmZgBjZaMzMNjx2MmZmZmZmZGwMzMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Zyvo",
          ["guild"] = "Avalerion",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 320564,
          ["ilvl"] = 325,
          ["crit"] = 1425,
          ["haste"] = 732,
          ["mastery"] = 762,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDmBjZaMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Gilgvoker",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 367246,
          ["ilvl"] = 329,
          ["crit"] = 1239,
          ["haste"] = 757,
          ["mastery"] = 1023,
          ["vers"] = 154,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Blueprínt",
          ["guild"] = "Honestly",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 355809,
          ["ilvl"] = 326,
          ["crit"] = 1451,
          ["haste"] = 767,
          ["mastery"] = 843,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwM8AmBjZaMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Mythvoker",
          ["guild"] = "Noctis",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 354569,
          ["ilvl"] = 323,
          ["crit"] = 1315,
          ["haste"] = 874,
          ["mastery"] = 714,
          ["vers"] = 274,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDmZYGmBMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "星火龙",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 349615,
          ["ilvl"] = 323,
          ["crit"] = 1458,
          ["haste"] = 703,
          ["mastery"] = 818,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDMDzwMDMYMTjZmpZmx2MMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Kekr",
          ["guild"] = "HKM",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 334576,
          ["ilvl"] = 322,
          ["crit"] = 1272,
          ["haste"] = 756,
          ["mastery"] = 735,
          ["vers"] = 220,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Creetix",
          ["guild"] = "HKM",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 326257,
          ["ilvl"] = 325,
          ["crit"] = 1331,
          ["haste"] = 682,
          ["mastery"] = 918,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Romaño",
          ["guild"] = "Dinosaur Cowboys",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 324187,
          ["ilvl"] = 321,
          ["crit"] = 1280,
          ["haste"] = 765,
          ["mastery"] = 750,
          ["vers"] = 307,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGmZgBjZamZmpZmx2MMzMzMzMzAmxMGzMbzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Brandodragon",
          ["guild"] = "Wing It",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 323774,
          ["ilvl"] = 325,
          ["crit"] = 1206,
          ["haste"] = 672,
          ["mastery"] = 826,
          ["vers"] = 318,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 328
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Palinvoker",
          ["guild"] = "Might",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 323497,
          ["ilvl"] = 325,
          ["crit"] = 1222,
          ["haste"] = 749,
          ["mastery"] = 762,
          ["vers"] = 405,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDmBjZaMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Tarkux",
          ["guild"] = "Amazing Stories",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 319627,
          ["ilvl"] = 324,
          ["crit"] = 1342,
          ["haste"] = 846,
          ["mastery"] = 717,
          ["vers"] = 241,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Replayvoker",
          ["guild"] = "Phoenix",
          ["boss"] = "Sszorak",
          ["amount"] = 212999,
          ["ilvl"] = 325,
          ["crit"] = 1227,
          ["haste"] = 848,
          ["mastery"] = 831,
          ["vers"] = 255,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGzMGzwMDMYMTzMzMNjx2YmZmZmZmZGwMmxYmZbmZwMwYwGsMGN2GAzAwGGYmBDPA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Fistlad",
          ["guild"] = "Rain",
          ["boss"] = "Sszorak",
          ["amount"] = 208151,
          ["ilvl"] = 326,
          ["crit"] = 1394,
          ["haste"] = 926,
          ["mastery"] = 705,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGjxYGzMDMYMTjZmpZM2GmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMYYA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Zevithel",
          ["guild"] = "The Meme Team",
          ["boss"] = "Sszorak",
          ["amount"] = 204546,
          ["ilvl"] = 326,
          ["crit"] = 1193,
          ["haste"] = 821,
          ["mastery"] = 667,
          ["vers"] = 358,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGzMGzwMgBjZaMzMNjx2YmZmZmZmZGwMmZGzMLzMDmBGD2glxox2AYGA2wAzMYGPA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "星火龙",
          ["guild"] = "傲  血  荣  耀",
          ["boss"] = "Sszorak",
          ["amount"] = 204229,
          ["ilvl"] = 326,
          ["crit"] = 1450,
          ["haste"] = 938,
          ["mastery"] = 592,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzYMGzwMDMYMTjZmpZM2GmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMYYA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "灵雨濛",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 203716,
          ["ilvl"] = 326,
          ["crit"] = 1315,
          ["haste"] = 682,
          ["mastery"] = 1099,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzYmxYGMDMMjZaMzMNjx2YmZmZmZmZGwMmZYmZZmZwMwYwGsMGN2GAzAwGGYmBDPA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Wnipeg",
          ["guild"] = "Reko",
          ["boss"] = "Sszorak",
          ["amount"] = 203555,
          ["ilvl"] = 326,
          ["crit"] = 1194,
          ["haste"] = 892,
          ["mastery"] = 767,
          ["vers"] = 194,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGzMGzwMDMYMTjZmpZM2GzMzMzMzMzAmxMGzMLzMDmBGD2glxox2AYGA2wAzMYGPA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "칠성제로먹고싶다",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 202800,
          ["ilvl"] = 322,
          ["crit"] = 1341,
          ["haste"] = 880,
          ["mastery"] = 780,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGzMGzwMDmBjZaMzMNjx2YmZmZmZmZGwMmxYmZZmZwMwYwGsMGN2GAzAwGGYmBDPA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Kairoke",
          ["guild"] = "Arbeitsamt Orgrimmar",
          ["boss"] = "Sszorak",
          ["amount"] = 201402,
          ["ilvl"] = 326,
          ["crit"] = 1348,
          ["haste"] = 746,
          ["mastery"] = 650,
          ["vers"] = 390,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGzMGzwMgBjZaMzMNjx2YmZmZmZmZGwMmZGzMLzMDmBGD2glxox2AYGA2wAzMYGPA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Blueprínt",
          ["guild"] = "Honestly",
          ["boss"] = "Sszorak",
          ["amount"] = 200991,
          ["ilvl"] = 326,
          ["crit"] = 1592,
          ["haste"] = 767,
          ["mastery"] = 843,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGzMGzwM8AmBjZaMzMNjx2YmZmZmZmZGwMmxYmZZmZwMwYwGsMGN2GAzAwGGYmBDPA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "증강몰라용",
          ["guild"] = "콩송편",
          ["boss"] = "Sszorak",
          ["amount"] = 200187,
          ["ilvl"] = 322,
          ["crit"] = 1136,
          ["haste"] = 884,
          ["mastery"] = 862,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGzMGzYmZgBjZaMzMNjx2YmZmZmZmZGwMzYGzMLzMDmBYwGsMGN2GAzAwGGYmBDPA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Gilgvoker",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 320087,
          ["ilvl"] = 329,
          ["crit"] = 1239,
          ["haste"] = 757,
          ["mastery"] = 1023,
          ["vers"] = 154,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmZmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Blueprínt",
          ["guild"] = "Honestly",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 315942,
          ["ilvl"] = 326,
          ["crit"] = 1693,
          ["haste"] = 767,
          ["mastery"] = 843,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwM8AmBjZaMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Creetix",
          ["guild"] = "HKM",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 314606,
          ["ilvl"] = 323,
          ["crit"] = 1476,
          ["haste"] = 672,
          ["mastery"] = 731,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Zathir",
          ["guild"] = "Nerd Rage",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 312362,
          ["ilvl"] = 326,
          ["crit"] = 1375,
          ["haste"] = 845,
          ["mastery"] = 589,
          ["vers"] = 299,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDmZYGmB8AYMTzMzMNzM2mZmZmZmZmZGwMzMYmZZmZgBGD2glxox2AYGA2wAzMYGPA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Everker",
          ["guild"] = "Ancient Tempest",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 311089,
          ["ilvl"] = 325,
          ["crit"] = 1132,
          ["haste"] = 588,
          ["mastery"] = 1166,
          ["vers"] = 256,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzYmBMYMTjZmpZmx2MzMzMzMzMzAmxMzYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "灵雨濛",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 306694,
          ["ilvl"] = 326,
          ["crit"] = 1315,
          ["haste"] = 682,
          ["mastery"] = 1099,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDmZYGMDMYMTjZmpZmx2MzMzMzMzMzAmxMzYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Azalth",
          ["guild"] = "Fierce",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 306469,
          ["ilvl"] = 322,
          ["crit"] = 1107,
          ["haste"] = 1122,
          ["mastery"] = 580,
          ["vers"] = 288,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMzMzYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Tricklevoker",
          ["guild"] = "Proper Guild Name",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 305161,
          ["ilvl"] = 324,
          ["crit"] = 1411,
          ["haste"] = 923,
          ["mastery"] = 774,
          ["vers"] = 226,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "星火龙",
          ["guild"] = "傲  血  荣  耀",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 305055,
          ["ilvl"] = 327,
          ["crit"] = 1456,
          ["haste"] = 839,
          ["mastery"] = 695,
          ["vers"] = 206,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDMDzwMDMYMTjZmpZmx2MMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Fistlad",
          ["guild"] = "Rain",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 302425,
          ["ilvl"] = 326,
          ["crit"] = 1525,
          ["haste"] = 926,
          ["mastery"] = 705,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGmZgBjZamZmpZM2mxMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Gilgvoker",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 240584,
          ["ilvl"] = 324,
          ["crit"] = 1413,
          ["haste"] = 742,
          ["mastery"] = 840,
          ["vers"] = 138,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Gilgvoker",
          ["guild"] = "poptart corndoG",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 298763,
          ["ilvl"] = 325,
          ["crit"] = 1288,
          ["haste"] = 712,
          ["mastery"] = 987,
          ["vers"] = 154,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmZmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Brandodragon",
          ["guild"] = "Wing It",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 292343,
          ["ilvl"] = 325,
          ["crit"] = 1206,
          ["haste"] = 672,
          ["mastery"] = 826,
          ["vers"] = 318,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 328
            },
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMDMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Blueprínt",
          ["guild"] = "Honestly",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 281809,
          ["ilvl"] = 332,
          ["crit"] = 1304,
          ["haste"] = 735,
          ["mastery"] = 935,
          ["vers"] = 103,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwM8AmBjZaMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Staravia",
          ["guild"] = "Liquid",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 278000,
          ["ilvl"] = 317,
          ["crit"] = 1450,
          ["haste"] = 550,
          ["mastery"] = 675,
          ["vers"] = 211,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 318
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZamZmpZmx2MzMzMzMzMzAmZmxYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Hxssion",
          ["guild"] = "Mid Team",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 276141,
          ["ilvl"] = 323,
          ["crit"] = 1253,
          ["haste"] = 751,
          ["mastery"] = 935,
          ["vers"] = 204,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZamZmpZmx2MzMzMzMzMzAmxMzYmZZmZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Dat",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 272521,
          ["ilvl"] = 309,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "真红眼黑珑",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 272262,
          ["ilvl"] = 322,
          ["crit"] = 1202,
          ["haste"] = 790,
          ["mastery"] = 763,
          ["vers"] = 242,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzgZghZMTjZmpZmx2MzMzMzMzMzAmZmZGzMLjZgBGD2glxox2AYGA2wAzMY4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Mydargovoker",
          ["guild"] = "The Full Stick",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 270806,
          ["ilvl"] = 325,
          ["crit"] = 1302,
          ["haste"] = 747,
          ["mastery"] = 843,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 273796,
              ["name"] = "Vile Vial of Volatile Venom",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "Azalth",
          ["guild"] = "Fierce",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 267118,
          ["ilvl"] = 319,
          ["crit"] = 1076,
          ["haste"] = 1086,
          ["mastery"] = 576,
          ["vers"] = 287,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMLzMDMwYwGsMGN2GAzAwGGYmBz4BA",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        },
        {
          ["name"] = "某某人乀",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 266929,
          ["ilvl"] = 322,
          ["crit"] = 1408,
          ["haste"] = 905,
          ["mastery"] = 625,
          ["vers"] = 183,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDMDzghxAjZaMzMNjx2MmZmZmZmZGgZmZGzMLzMDMwYwGsMGN2GAzAwGGYmBDD",
          ["hero"] = {
            ["name"] = "Scalecommander",
            ["atlas"] = "talents-heroclass-evoker-scalecommander",
            ["icon"] = "inv_1205_ability_evoker_massdisintegration"
          }
        }
      }
    },
    {
      ["spec"] = "Preservation",
      ["role"] = "healer",
      ["metric"] = "HPS",
      ["players"] = {
        {
          ["name"] = "Nürokms",
          ["guild"] = "constant",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 434945,
          ["ilvl"] = 325,
          ["crit"] = 958,
          ["haste"] = 617,
          ["mastery"] = 1414,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Do",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 422686,
          ["ilvl"] = 321,
          ["crit"] = 1126,
          ["haste"] = 458,
          ["mastery"] = 1240,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzMzMmtZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "呆萌灬小弟",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 420613,
          ["ilvl"] = 323,
          ["crit"] = 1187,
          ["haste"] = 643,
          ["mastery"] = 1233,
          ["vers"] = 115,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAgZmZMjxYGhZAAAAmZGZGzMmtZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "抽烟的弟弟",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 420343,
          ["ilvl"] = 325,
          ["crit"] = 1040,
          ["haste"] = 579,
          ["mastery"] = 1239,
          ["vers"] = 297,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmxMzMbDAAgZMjZwYGZmZAAAAmZGZmZmxsMzMAYGzAbgFwMMB2gNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Sabrina",
          ["guild"] = "哆啦美梦",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 410755,
          ["ilvl"] = 319,
          ["crit"] = 1110,
          ["haste"] = 461,
          ["mastery"] = 1262,
          ["vers"] = 51,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMzYGhZAAAAmZGZGzMmlZmBAzYGYDsBmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Zeltronn",
          ["guild"] = "Miscreants",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 397015,
          ["ilvl"] = 323,
          ["crit"] = 1095,
          ["haste"] = 658,
          ["mastery"] = 1258,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAgZMjZYGzMZGDAAAwMzMZmZmxsMmBAzYGYBsAmhJwmhNDDgZGGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Mingevohh",
          ["guild"] = "",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 392076,
          ["ilvl"] = 316,
          ["crit"] = 1091,
          ["haste"] = 652,
          ["mastery"] = 1017,
          ["vers"] = 283,
          ["trinkets"] = {
            {
              ["id"] = 274495,
              ["name"] = "Pulse Seeker's Oculus",
              ["ilvl"] = 321
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAgZmZMjxYGhZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Mayyhem",
          ["guild"] = "Freakin Unicorns",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 388942,
          ["ilvl"] = 326,
          ["crit"] = 1307,
          ["haste"] = 851,
          ["mastery"] = 873,
          ["vers"] = 196,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbAAAMjZMDzYGZmZAAAAmZGZGzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "黄油啤酒灬",
          ["guild"] = "宝宝巴士",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 387384,
          ["ilvl"] = 324,
          ["crit"] = 1153,
          ["haste"] = 417,
          ["mastery"] = 1211,
          ["vers"] = 139,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Hardstackpls",
          ["guild"] = "IceBlast",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 387068,
          ["ilvl"] = 321,
          ["crit"] = 914,
          ["haste"] = 954,
          ["mastery"] = 876,
          ["vers"] = 234,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsNzMAYGzAbgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Mingevobb",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 436700,
          ["ilvl"] = 317,
          ["crit"] = 892,
          ["haste"] = 999,
          ["mastery"] = 794,
          ["vers"] = 161,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAgZmZMjxYGhZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "小双爱夏天",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 433327,
          ["ilvl"] = 325,
          ["crit"] = 1205,
          ["haste"] = 599,
          ["mastery"] = 1153,
          ["vers"] = 165,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwYGZmZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "大搅拌者",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 425402,
          ["ilvl"] = 310,
          ["crit"] = 1198,
          ["haste"] = 654,
          ["mastery"] = 913,
          ["vers"] = 218,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Farawaylight",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 424652,
          ["ilvl"] = 321,
          ["crit"] = 1190,
          ["haste"] = 570,
          ["mastery"] = 1085,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2mhxMbzYAAAjZMjxYGhZAAAAmZGZGzMzsMzMAYGzALgFwMMBWMsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Mingevohh",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 423999,
          ["ilvl"] = 322,
          ["crit"] = 1102,
          ["haste"] = 652,
          ["mastery"] = 931,
          ["vers"] = 283,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAgZmZMjxYGhZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Loneyev",
          ["guild"] = "Oblivion",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 417940,
          ["ilvl"] = 326,
          ["crit"] = 1240,
          ["haste"] = 442,
          ["mastery"] = 1309,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGz2MMmZbYAAgZMjZwYGNmZAAAAmZGZGzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Speed",
          ["guild"] = "LINE",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 416379,
          ["ilvl"] = 321,
          ["crit"] = 1144,
          ["haste"] = 487,
          ["mastery"] = 1204,
          ["vers"] = 216,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzAAAMjZMjxYGhZAAAAmZGZmZm5BmlZmBAzYGYDsAmhJwihNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "走位是没有的",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 415665,
          ["ilvl"] = 325,
          ["crit"] = 1285,
          ["haste"] = 515,
          ["mastery"] = 1057,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGz2MMGbzAAAMjZMjZGzMhZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Littleculu",
          ["guild"] = "Squirrel Squad",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 415412,
          ["ilvl"] = 323,
          ["crit"] = 1136,
          ["haste"] = 459,
          ["mastery"] = 1272,
          ["vers"] = 202,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 324
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjBGzIzMDAAAwMzMZmZmxsMzMAYGzAbgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Yookevo",
          ["guild"] = "Adequate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 414214,
          ["ilvl"] = 325,
          ["crit"] = 1349,
          ["haste"] = 117,
          ["mastery"] = 1518,
          ["vers"] = 189,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMj5BMGzMhZAAAAmZGZmZmxsMzMAYGzAbgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Jawavoker",
          ["guild"] = "Honolulu",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 402571,
          ["ilvl"] = 320,
          ["crit"] = 1354,
          ["haste"] = 489,
          ["mastery"] = 1167,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Groovii",
          ["guild"] = "comma",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 398182,
          ["ilvl"] = 326,
          ["crit"] = 1375,
          ["haste"] = 477,
          ["mastery"] = 1160,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzMZGzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Eruptiòn",
          ["guild"] = "Силентиум",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 390495,
          ["ilvl"] = 326,
          ["crit"] = 1398,
          ["haste"] = 444,
          ["mastery"] = 1235,
          ["vers"] = 146,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGz2MMmZbYAAgZMjZMGzIMDAAAwMzMZGzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Lohithwa",
          ["guild"] = "brb shower",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 387558,
          ["ilvl"] = 325,
          ["crit"] = 1062,
          ["haste"] = 903,
          ["mastery"] = 902,
          ["vers"] = 136,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwYGZmZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Mingevogg",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 385798,
          ["ilvl"] = 317,
          ["crit"] = 903,
          ["haste"] = 894,
          ["mastery"] = 801,
          ["vers"] = 346,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 318
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAgZmZMjxYGhZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Mingevoee",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 385720,
          ["ilvl"] = 317,
          ["crit"] = 1189,
          ["haste"] = 613,
          ["mastery"] = 1167,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2mhxMbzYAAgZmZMjxYGhZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Mingevoe",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 385581,
          ["ilvl"] = 312,
          ["crit"] = 948,
          ["haste"] = 678,
          ["mastery"] = 999,
          ["vers"] = 372,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 318
            },
            {
              ["id"] = 274495,
              ["name"] = "Pulse Seeker's Oculus",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAgZmZMjxYGhZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Clickdrake",
          ["guild"] = "BIG PULL ET AU LIT",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 384176,
          ["ilvl"] = 322,
          ["crit"] = 1163,
          ["haste"] = 705,
          ["mastery"] = 995,
          ["vers"] = 167,
          ["trinkets"] = {
            {
              ["id"] = 264507,
              ["name"] = "Crucible of Erratic Energies",
              ["ilvl"] = 295
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGz2MMmZbYAAgZMjZMGzIMDAAAwMzIzMzMPwsMzMAwYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Delivoker",
          ["guild"] = "Fierce",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 383521,
          ["ilvl"] = 324,
          ["crit"] = 1232,
          ["haste"] = 482,
          ["mastery"] = 1224,
          ["vers"] = 156,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGz2MMmZbAAAMjZMDGzIzMDAAAwMzMZGzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Dwagsy",
          ["guild"] = "velocity",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 380401,
          ["ilvl"] = 326,
          ["crit"] = 1157,
          ["haste"] = 415,
          ["mastery"] = 1412,
          ["vers"] = 87,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMj5BwYGNzMDAAAwMzIzYmxsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Dipp",
          ["guild"] = "azure",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 442627,
          ["ilvl"] = 323,
          ["crit"] = 931,
          ["haste"] = 485,
          ["mastery"] = 1819,
          ["vers"] = 38,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMzYGhZAAAAmZGZGzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Nethuraz",
          ["guild"] = "Momentus",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 430024,
          ["ilvl"] = 323,
          ["crit"] = 1252,
          ["haste"] = 611,
          ["mastery"] = 1199,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Funkyfrog",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 422369,
          ["ilvl"] = 318,
          ["crit"] = 1407,
          ["haste"] = 232,
          ["mastery"] = 1106,
          ["vers"] = 83,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAAjZMDGzMZmZAAAAmZGZmZmxsNz8AAYGzAbgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "그리움의잔향",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 419362,
          ["ilvl"] = 312,
          ["crit"] = 1097,
          ["haste"] = 499,
          ["mastery"] = 1267,
          ["vers"] = 118,
          ["trinkets"] = {
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2mhxMbzYAAgZmZMjxYGhZAAAAmZGZYmZmlZmBAGzAbgFwMMBWMsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Speed",
          ["guild"] = "LINE",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 417905,
          ["ilvl"] = 321,
          ["crit"] = 1144,
          ["haste"] = 487,
          ["mastery"] = 1204,
          ["vers"] = 216,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzAAAMjZMjxYGhZAAAAmZGZmZm5BmlZmBAzYGYDsAmhJwihNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 414354,
          ["ilvl"] = 325,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Meptune",
          ["guild"] = "第九联盟",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 413949,
          ["ilvl"] = 317,
          ["crit"] = 1101,
          ["haste"] = 473,
          ["mastery"] = 1343,
          ["vers"] = 113,
          ["trinkets"] = {
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            },
            {
              ["id"] = 268292,
              ["name"] = "Sporelord's Mycelial Insignia",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAgZMjBGzIzMDAAAwMzMZmZmxsMzMAYGzALgNwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Sylvthyr",
          ["guild"] = "Umbral Ultimatum",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 413166,
          ["ilvl"] = 324,
          ["crit"] = 1132,
          ["haste"] = 609,
          ["mastery"] = 1178,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMj5BYGzIzMDAAAwMzIzYmxsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Xè",
          ["guild"] = "Exiled",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 412995,
          ["ilvl"] = 324,
          ["crit"] = 1052,
          ["haste"] = 488,
          ["mastery"] = 1287,
          ["vers"] = 208,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjBGzMZmZGAAAwMzIzYm5BmlZmBAGzAbgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Yeaeyae",
          ["guild"] = "Rhapsody",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 411438,
          ["ilvl"] = 322,
          ["crit"] = 1130,
          ["haste"] = 530,
          ["mastery"] = 1138,
          ["vers"] = 240,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwYGZmZAAAAmZmJzYmxsMz8AAYGzAbgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Ng",
          ["guild"] = "Comfy",
          ["boss"] = "Sszorak",
          ["amount"] = 507870,
          ["ilvl"] = 322,
          ["crit"] = 1229,
          ["haste"] = 316,
          ["mastery"] = 1319,
          ["vers"] = 189,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 251792,
              ["name"] = "Glorious Crusader's Keepsake",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Notascalie",
          ["guild"] = "Dodge breath res me",
          ["boss"] = "Sszorak",
          ["amount"] = 485754,
          ["ilvl"] = 327,
          ["crit"] = 1339,
          ["haste"] = 614,
          ["mastery"] = 1181,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAwMjZMDGzIzMDAAAwMzMZGzMmlZGAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Jawavoker",
          ["guild"] = "Honolulu",
          ["boss"] = "Sszorak",
          ["amount"] = 484460,
          ["ilvl"] = 320,
          ["crit"] = 1354,
          ["haste"] = 489,
          ["mastery"] = 1167,
          ["vers"] = 96,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Speed",
          ["guild"] = "LINE",
          ["boss"] = "Sszorak",
          ["amount"] = 482731,
          ["ilvl"] = 322,
          ["crit"] = 1151,
          ["haste"] = 494,
          ["mastery"] = 1211,
          ["vers"] = 223,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzAAAMjZMjxYGhZAAAAmZGZmZm5BmlZmBAzYGYDsAmhJwihNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Coopge",
          ["guild"] = "Shade",
          ["boss"] = "Sszorak",
          ["amount"] = 475891,
          ["ilvl"] = 326,
          ["crit"] = 1150,
          ["haste"] = 660,
          ["mastery"] = 1147,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGz2MMmZbYAAgZMjZwYGNmZAAAAmZmJzYmxsMz8AAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Lohithwa",
          ["guild"] = "brb shower",
          ["boss"] = "Sszorak",
          ["amount"] = 470939,
          ["ilvl"] = 325,
          ["crit"] = 1065,
          ["haste"] = 903,
          ["mastery"] = 902,
          ["vers"] = 137,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwYGZmZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Ellipsism",
          ["guild"] = "冷涩",
          ["boss"] = "Sszorak",
          ["amount"] = 469830,
          ["ilvl"] = 322,
          ["crit"] = 1294,
          ["haste"] = 289,
          ["mastery"] = 1256,
          ["vers"] = 137,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 311
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGz2MMmZbYAAAjZMjxYGhZAAAAmZGZmZm5BmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Yêlenâxz",
          ["guild"] = "Bloody Tearz",
          ["boss"] = "Sszorak",
          ["amount"] = 468476,
          ["ilvl"] = 323,
          ["crit"] = 1348,
          ["haste"] = 212,
          ["mastery"] = 1320,
          ["vers"] = 182,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYmZ2MMzMbPADAAMjZMjxYGhZAAAAmZGZGzMPwsMzMAYGzAbgFwMMB2gNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Nürokms",
          ["guild"] = "constant",
          ["boss"] = "Sszorak",
          ["amount"] = 468219,
          ["ilvl"] = 325,
          ["crit"] = 958,
          ["haste"] = 617,
          ["mastery"] = 1414,
          ["vers"] = 100,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Elshà",
          ["guild"] = "YEP",
          ["boss"] = "Sszorak",
          ["amount"] = 466214,
          ["ilvl"] = 323,
          ["crit"] = 1408,
          ["haste"] = 778,
          ["mastery"] = 671,
          ["vers"] = 187,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGz2MMmZbYAAgZMjZwYGZmZAAAAmZGZGzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Drággin",
          ["guild"] = "vodka",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 503485,
          ["ilvl"] = 325,
          ["crit"] = 1446,
          ["haste"] = 502,
          ["mastery"] = 1009,
          ["vers"] = 69,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGz2MMmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Jawavoker",
          ["guild"] = "Honolulu",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 501316,
          ["ilvl"] = 321,
          ["crit"] = 1855,
          ["haste"] = 370,
          ["mastery"] = 1445,
          ["vers"] = -26,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Eliåna",
          ["guild"] = "Above Average",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 492260,
          ["ilvl"] = 322,
          ["crit"] = 1352,
          ["haste"] = 659,
          ["mastery"] = 846,
          ["vers"] = 140,
          ["trinkets"] = {
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "泷妹妹",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 485855,
          ["ilvl"] = 322,
          ["crit"] = 1007,
          ["haste"] = 649,
          ["mastery"] = 1227,
          ["vers"] = 279,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYmZ2MMzMbPADAAYMjZMGzIMDAAAwMzMZmZmxsMzMAYGzALgFwMMB2gNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Groovii",
          ["guild"] = "comma",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 469932,
          ["ilvl"] = 326,
          ["crit"] = 1375,
          ["haste"] = 477,
          ["mastery"] = 1160,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzMZGzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Xiyankfh",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 467681,
          ["ilvl"] = 327,
          ["crit"] = 1156,
          ["haste"] = 427,
          ["mastery"] = 915,
          ["vers"] = 626,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMj5BwYGZmZAAAAmZmJzYmxsMzMAYGzAbgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Reaoharu",
          ["guild"] = "애옹",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 467630,
          ["ilvl"] = 324,
          ["crit"] = 1270,
          ["haste"] = 364,
          ["mastery"] = 1267,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAAjZMPgxYGhZAAAAmZGNzYmZmlZmBAzYGYBsAmhJwihNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Yêlenâxz",
          ["guild"] = "Bloody Tearz",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 467395,
          ["ilvl"] = 324,
          ["crit"] = 1353,
          ["haste"] = 214,
          ["mastery"] = 1321,
          ["vers"] = 182,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYmZ2MMzMbPADAAMjZMjxYGhZAAAAmZGZGzMPwsMzMAYGzAbgFwMMB2gNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "龙龙呆",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 466966,
          ["ilvl"] = 325,
          ["crit"] = 1150,
          ["haste"] = 516,
          ["mastery"] = 1245,
          ["vers"] = 147,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZmZMjxYGhZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Vescovo",
          ["guild"] = "",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 466434,
          ["ilvl"] = 323,
          ["crit"] = 1072,
          ["haste"] = 583,
          ["mastery"] = 1318,
          ["vers"] = 144,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbAAAMjZMjxYGhZAAAAmZGZGzMzsMzMAYGzAbgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Jawavoker",
          ["guild"] = "Honolulu",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 476799,
          ["ilvl"] = 328,
          ["crit"] = 1413,
          ["haste"] = 534,
          ["mastery"] = 1245,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYm5BmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "松婴丶",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 463390,
          ["ilvl"] = 325,
          ["crit"] = 1226,
          ["haste"] = 425,
          ["mastery"] = 1253,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAAjZMjxYGhZAAAAmZGZGzMzsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Hoovk",
          ["guild"] = "Fragglene",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 454373,
          ["ilvl"] = 327,
          ["crit"] = 1338,
          ["haste"] = 541,
          ["mastery"] = 1183,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmZMmZbYAAgZMjZwYmpxMzAAAAmZGZGzMmlxMAYGzALgFwMMB2MsZYAMzwA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Hastydwagon",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 452112,
          ["ilvl"] = 323,
          ["crit"] = 1191,
          ["haste"] = 501,
          ["mastery"] = 1336,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGz2MMmZbYAAgZMjZwYGNmZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Vokeformer",
          ["guild"] = "DMG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 451271,
          ["ilvl"] = 326,
          ["crit"] = 1102,
          ["haste"] = 546,
          ["mastery"] = 1265,
          ["vers"] = 132,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbAAAYMjZwYGNmZAAAAmZmJzMzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Strangesalt",
          ["guild"] = "Infinity",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 446125,
          ["ilvl"] = 326,
          ["crit"] = 954,
          ["haste"] = 794,
          ["mastery"] = 1375,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMj5BwYGNmZAAAAmZmJzYmxsMzMAYGzAbgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "뽀또에용",
          ["guild"] = "Mate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 424791,
          ["ilvl"] = 331,
          ["crit"] = 1155,
          ["haste"] = 418,
          ["mastery"] = 1539,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGz2MMmZbYAAgZMj5BwYGZmZAAAAmZGZGzMPwsMzMAYGzALgFwMMBWMsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "宇宙耀变龙",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 417327,
          ["ilvl"] = 327,
          ["crit"] = 1168,
          ["haste"] = 364,
          ["mastery"] = 1352,
          ["vers"] = 169,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1295132,
            ["name"] = "Liquid Luster"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2mhxMbzYAAAjZMjxYGhZAAAAmZGZGzMzsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Draguzzy",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 415896,
          ["ilvl"] = 327,
          ["crit"] = 1243,
          ["haste"] = 473,
          ["mastery"] = 1274,
          ["vers"] = 98,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Viserioker",
          ["guild"] = "Sabotage",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 413290,
          ["ilvl"] = 323,
          ["crit"] = 1540,
          ["haste"] = 328,
          ["mastery"] = 1225,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 249809,
              ["name"] = "Locus-Walker's Ribbon",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjBGzIzMDAAAwMzMNzYmxsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "뽀또에용",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 480963,
          ["ilvl"] = 331,
          ["crit"] = 990,
          ["haste"] = 418,
          ["mastery"] = 1704,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmZMmZbYAAgZMjBmZGZmZAAAAmZGZGzMPwsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "희찬아잘하자",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 460121,
          ["ilvl"] = 329,
          ["crit"] = 1267,
          ["haste"] = 388,
          ["mastery"] = 1354,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYmZ2MjxMbPADAAMjZMjx4BmJMzAAAAmZGZGzMPwsMmBAzYGYBsAmhJwGsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Drizzy",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 435187,
          ["ilvl"] = 329,
          ["crit"] = 1524,
          ["haste"] = 421,
          ["mastery"] = 1170,
          ["vers"] = 133,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDegZMYmZ2MjZmZ7BYAAgZMjZMGPwMhZGAAAwMzIzYm5BmlxMAYGzALgFwMMB2gNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Киринари",
          ["guild"] = "Проксима",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 407804,
          ["ilvl"] = 320,
          ["crit"] = 943,
          ["haste"] = 728,
          ["mastery"] = 1246,
          ["vers"] = 136,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 308
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMj5BYGzIzMDAAAwMzIzYmxsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Sabrina",
          ["guild"] = "哆啦美梦",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 406185,
          ["ilvl"] = 324,
          ["crit"] = 1043,
          ["haste"] = 564,
          ["mastery"] = 1253,
          ["vers"] = 147,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYmZ2MMzMbPADAAMjZMjZGzIMDAAAwMzIzYmxsMzMAYGzAbgNwMMB2gNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "龙龙呆",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 403710,
          ["ilvl"] = 325,
          ["crit"] = 1150,
          ["haste"] = 516,
          ["mastery"] = 1245,
          ["vers"] = 147,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjZYGzmhZmZbYAAgZmZMjxYGhZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "抽烟的弟弟",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 402142,
          ["ilvl"] = 319,
          ["crit"] = 925,
          ["haste"] = 684,
          ["mastery"] = 1302,
          ["vers"] = 295,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbAAAMjZMDGzIzMDAAAwMzIzMzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Wynds",
          ["guild"] = "Púlse",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 400950,
          ["ilvl"] = 319,
          ["crit"] = 1142,
          ["haste"] = 535,
          ["mastery"] = 1251,
          ["vers"] = 179,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 249343,
              ["name"] = "Gaze of the Alnseer",
              ["ilvl"] = 298
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGz2MMmZbYAAgZMjBGzIzMDAAAwMzMZmZmxsMzMAYGzALgFwMMB2MsZYAMzMGA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "麻辣茄子",
          ["guild"] = "BabyMonster",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 397442,
          ["ilvl"] = 326,
          ["crit"] = 1263,
          ["haste"] = 446,
          ["mastery"] = 1228,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGz2MMmZbYAAgZMjZwYGNmZAAAAmZGZGzMmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Lohithwa",
          ["guild"] = "brb shower",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 393478,
          ["ilvl"] = 321,
          ["crit"] = 841,
          ["haste"] = 828,
          ["mastery"] = 1226,
          ["vers"] = 44,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwYGZmZAAAAmZGZGzMmlZmBAzYGYDsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "大二饼",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 393452,
          ["ilvl"] = 321,
          ["crit"] = 1219,
          ["haste"] = 412,
          ["mastery"] = 1296,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270162,
              ["name"] = "Soulcoiler Ritual Vessel",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzYAAgZMj5BMGzIMDAAAwMzIzYmZmtZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        },
        {
          ["name"] = "Anonymous",
          ["guild"] = "",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 392089,
          ["ilvl"] = 320,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "从降生到残骸",
          ["guild"] = "Forever  Friends",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 388362,
          ["ilvl"] = 324,
          ["crit"] = 1160,
          ["haste"] = 697,
          ["mastery"] = 976,
          ["vers"] = 511,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZwMjBzY2MMzMbzAAAMjZMwYmJzMDAAAwMzIzYmZmlZmBAzYGYBsAmhJwmhNDDgZmxA",
          ["hero"] = {
            ["name"] = "Flameshaper",
            ["atlas"] = "talents-heroclass-evoker-flameshaper",
            ["icon"] = "ability_evoker_dragonrage2"
          }
        }
      }
    },
    {
      ["spec"] = "Augmentation",
      ["role"] = "dps",
      ["metric"] = "DPS",
      ["players"] = {
        {
          ["name"] = "Spyrocosplay",
          ["guild"] = "Divinum",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 222012,
          ["ilvl"] = 325,
          ["crit"] = 835,
          ["haste"] = 575,
          ["mastery"] = 1746,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZGjZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Cocofotm",
          ["guild"] = "Ethical",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 221860,
          ["ilvl"] = 327,
          ["crit"] = 1106,
          ["haste"] = 278,
          ["mastery"] = 3581,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZmZMjZAAAAAAAAgZYMDGTNzMzMAAAAYGzYMzsMmZgZYgxMWYBGYGGagFMzYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Dajo",
          ["guild"] = "Resonate",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 218448,
          ["ilvl"] = 324,
          ["crit"] = 939,
          ["haste"] = 800,
          ["mastery"] = 1356,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZmZMjZAAAAAAAAwMDjZwYqxMzMAAAAYGzYMzsMmZgZYgxMWYBGYGGagFMzYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Batchester",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 218230,
          ["ilvl"] = 327,
          ["crit"] = 883,
          ["haste"] = 243,
          ["mastery"] = 2138,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAmZGPgZwYqxMzMAAAAYGzYMzsMmZgZYgxMWYBGYGGagFMGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Juravoker",
          ["guild"] = "Oblivion",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 217703,
          ["ilvl"] = 326,
          ["crit"] = 716,
          ["haste"] = 504,
          ["mastery"] = 1994,
          ["vers"] = 158,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMMmBjpmZmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Olbahamut",
          ["guild"] = "Vestige",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 216912,
          ["ilvl"] = 328,
          ["crit"] = 1005,
          ["haste"] = 304,
          ["mastery"] = 1885,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZmZMjZAAAAAAAAgZGPgZwYqZmZmBAAAAzYGjZmlxMDMDDMmxCLwAzwQDsgZGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Dreamsweet",
          ["guild"] = "vodka",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 216205,
          ["ilvl"] = 324,
          ["crit"] = 1118,
          ["haste"] = 152,
          ["mastery"] = 1944,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZGjZMzGAAAAAMAAYmZgBjpGzMzAAAAgZMzMmZWGzMwMMwYGLsADMDDNwCmZMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Tizaxyr",
          ["guild"] = "Northern Sky",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215860,
          ["ilvl"] = 326,
          ["crit"] = 1052,
          ["haste"] = 296,
          ["mastery"] = 1747,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAgZmZbmZGMDzMLzMzMjZAAAAAAAAwMDj5BYGTNmZmBAAAAzYGjZmlxMDMjZgxMWYBGYGGagFMGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Drakthycus",
          ["guild"] = "Frenzied Apes",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215825,
          ["ilvl"] = 325,
          ["crit"] = 972,
          ["haste"] = 389,
          ["mastery"] = 1672,
          ["vers"] = 162,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAADjZwYqZmZmBAAAAzYmZMzsMmZgZWMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "영능턴종영능",
          ["guild"] = "인앤아웃",
          ["boss"] = "Nek'zali the Soulcoiler",
          ["amount"] = 215764,
          ["ilvl"] = 326,
          ["crit"] = 1187,
          ["haste"] = 542,
          ["mastery"] = 1449,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZmZMjZAAAAAADAAMDjZwYqxMzMAAAAYGzYMzsMmZgZYgxMWYBGYGGagFMzYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Wekeed",
          ["guild"] = "Mate",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217526,
          ["ilvl"] = 328,
          ["crit"] = 794,
          ["haste"] = 651,
          ["mastery"] = 1693,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAgZGjZwYqxMzMAAAAYGzYMzsMmZgZWMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Batchester",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 217153,
          ["ilvl"] = 326,
          ["crit"] = 1118,
          ["haste"] = 191,
          ["mastery"] = 1940,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmxMbzMzgBzMLzMmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Olbahamut",
          ["guild"] = "Vestige",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 214760,
          ["ilvl"] = 328,
          ["crit"] = 1005,
          ["haste"] = 304,
          ["mastery"] = 1885,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZmZMjZAAAAAAAAgZGPgZwYqZmZmBAAAAzYGjZmlxMDMDDMmxCLwAzwQDsgZGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Hog",
          ["guild"] = "Drama",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 214615,
          ["ilvl"] = 325,
          ["crit"] = 854,
          ["haste"] = 493,
          ["mastery"] = 1517,
          ["vers"] = 220,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZGjZMzGAAAAAAAAmhxMYM1MzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "영능턴종영능",
          ["guild"] = "인앤아웃",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 212349,
          ["ilvl"] = 324,
          ["crit"] = 1119,
          ["haste"] = 539,
          ["mastery"] = 1484,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmxMbzMzgBzMLzMjZMzGAAAAAMAAwMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Надуватель",
          ["guild"] = "У беляша",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 212000,
          ["ilvl"] = 325,
          ["crit"] = 1087,
          ["haste"] = 296,
          ["mastery"] = 1711,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZmxMjZAAAAAAAAgZGjZwYqxMzMAAAAYGzYMzsMmZgZYgxMWYBGYGGagFMzYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Cocofotm",
          ["guild"] = "Ethical",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209888,
          ["ilvl"] = 327,
          ["crit"] = 1106,
          ["haste"] = 278,
          ["mastery"] = 3581,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZmZMjZAAAAAAAAgZYMDGTNzMzMAAAAYGzYMzsMmZgZYgxMWYBGYGGagFMzYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Bigmoevoker",
          ["guild"] = "",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 209692,
          ["ilvl"] = 327,
          ["crit"] = nil,
          ["haste"] = nil,
          ["mastery"] = nil,
          ["vers"] = nil,
          ["trinkets"] = {

          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "",
          ["hero"] = nil
        },
        {
          ["name"] = "Gingievoker",
          ["guild"] = "쉽지않네",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 207491,
          ["ilvl"] = 321,
          ["crit"] = 1040,
          ["haste"] = 596,
          ["mastery"] = 1294,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 315
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 315
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmxMbzMzgBzMLzMjZMzGAAAAAAAAzMDmhZM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCmZMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Weeb",
          ["guild"] = "Lucid",
          ["boss"] = "Entombed Sentinels",
          ["amount"] = 206897,
          ["ilvl"] = 327,
          ["crit"] = 978,
          ["haste"] = 231,
          ["mastery"] = 1994,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmxMbzMzgBzMLzMmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Olbahamut",
          ["guild"] = "Vestige",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 309830,
          ["ilvl"] = 326,
          ["crit"] = 1237,
          ["haste"] = 481,
          ["mastery"] = 1475,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAgZYMPAGTNzMzMAAAAYGzMjZmlxMDMziBGzYhFYgZYoBWwYMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Alltekk",
          ["guild"] = "Winters Heart",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 303102,
          ["ilvl"] = 323,
          ["crit"] = 1002,
          ["haste"] = 828,
          ["mastery"] = 1283,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAYMzgZwYqZmZmBAAAAzYGjZmlxMDMziBGzYhFYgZYoBWwYMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Curris",
          ["guild"] = "Proper Guild Name",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 302262,
          ["ilvl"] = 322,
          ["crit"] = 1204,
          ["haste"] = 216,
          ["mastery"] = 1654,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMmZbmZGMYmZZmZmZMzGAAAAAAAAzM8AmBzM1YmZGAAAAMjZMmZWGzMwMLGYMjFWgBmhhGYBjxMDAM",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "고향김치만두",
          ["guild"] = "Lumpen",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 296493,
          ["ilvl"] = 317,
          ["crit"] = 1463,
          ["haste"] = 392,
          ["mastery"] = 1007,
          ["vers"] = 168,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMmZbmZGMYmZZmZmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxAjZswCMwMM0ALYMmZAgB",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Evook",
          ["guild"] = "Blur",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 295852,
          ["ilvl"] = 324,
          ["crit"] = 1128,
          ["haste"] = 371,
          ["mastery"] = 1576,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMmZbmZmxyAzsMjZmxMbAAAAAwAAAzAzgxUjZmZAAAAwMmZGzMLjZGYmFDMmxCLwAzwQDsgxYmBYwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Hatedspec",
          ["guild"] = "Medium",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 295649,
          ["ilvl"] = 323,
          ["crit"] = 828,
          ["haste"] = 572,
          ["mastery"] = 1699,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAgZYMPAGTNzMzMAAAAYGzMjZmtxMDMziBGzYhFYgZYoBWwYMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Cocofotm",
          ["guild"] = "Ethical",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 295643,
          ["ilvl"] = 322,
          ["crit"] = 1337,
          ["haste"] = 320,
          ["mastery"] = 1475,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250214,
              ["name"] = "Lightspire Core",
              ["ilvl"] = 311
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzYmZMzGAAAAAAAAmhxMYM1MzMzAAAAgZMjxMzyYmBmZxAjZswCMwMM0ALYMmZAgB",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Twimight",
          ["guild"] = "Pathogen",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 294257,
          ["ilvl"] = 318,
          ["crit"] = 921,
          ["haste"] = 348,
          ["mastery"] = 1637,
          ["vers"] = 42,
          ["trinkets"] = {
            {
              ["id"] = 273794,
              ["name"] = "Knot of Writhing Serpents",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMmZbmZGMYmZZmZmZMzGAAAAAAAAmZ8AmBjpmZmZGAAAAMjZMmZWGzMwMLGYMjFWgBmhhGYBjxMDAM",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Aldragon",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 293668,
          ["ilvl"] = 323,
          ["crit"] = 1003,
          ["haste"] = 533,
          ["mastery"] = 1394,
          ["vers"] = 133,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAgZYMDGTNzMzMAAAAYGzYMzsMmZgZWMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "龙眠听雨时",
          ["guild"] = "",
          ["boss"] = "Vashnik the Malignant",
          ["amount"] = 292611,
          ["ilvl"] = 315,
          ["crit"] = 1085,
          ["haste"] = 346,
          ["mastery"] = 1365,
          ["vers"] = 124,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 274493,
              ["name"] = "Effigy of Ula'tek's Faithful",
              ["ilvl"] = 305
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMmZbmZGMYmZZmZmZMzGAAAAAAAAmZghZmpGzMzAAAAgZMzMmZWGzMwMLGYMjFWgBmhhGYBjxMDAM",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "혜지코스타스",
          ["guild"] = "Mate",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 307264,
          ["ilvl"] = 326,
          ["crit"] = 1041,
          ["haste"] = 713,
          ["mastery"] = 1393,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMjxMYM1YmZGAAAAMDjxMzyYmBmhBGzYhFYgZYoBWwYmZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "영능턴종영능",
          ["guild"] = "인앤아웃",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 306571,
          ["ilvl"] = 324,
          ["crit"] = 1119,
          ["haste"] = 539,
          ["mastery"] = 1484,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAYAAgZYMDGTNmZmBAAAAzYGjZmlxMDMDDMmxCLwAzwQDsgxYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Wekeed",
          ["guild"] = "Mate",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 300161,
          ["ilvl"] = 328,
          ["crit"] = 794,
          ["haste"] = 651,
          ["mastery"] = 1693,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAgZGjZwYqxMzMAAAAYGzYMzsMmZgZWMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Tizaxyr",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 299712,
          ["ilvl"] = 327,
          ["crit"] = 1052,
          ["haste"] = 296,
          ["mastery"] = 1747,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAgZmZbmZGMDzMLzMzMjZAAAAAAAAwMDj5BYGTNmZmBAAAAzYGjZmlxMDMjZgxMWYBGYGGagFMGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Vrdragongirl",
          ["guild"] = "Myth",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 296883,
          ["ilvl"] = 327,
          ["crit"] = 980,
          ["haste"] = 440,
          ["mastery"] = 1767,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMDjZwYqxMzMAAAAYGzMjZmlxMDMDDMmxCLwAzwQDsgxYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Polp",
          ["guild"] = "",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 294116,
          ["ilvl"] = 326,
          ["crit"] = 1178,
          ["haste"] = 419,
          ["mastery"] = 1504,
          ["vers"] = 127,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAgBAAmhxgZM1MzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwYMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Batchester",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 292234,
          ["ilvl"] = 327,
          ["crit"] = 883,
          ["haste"] = 243,
          ["mastery"] = 2138,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMMmhZM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Cocofotm",
          ["guild"] = "Ethical",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 292072,
          ["ilvl"] = 327,
          ["crit"] = 1106,
          ["haste"] = 278,
          ["mastery"] = 1857,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMDjZwYqZmZmBAAAAzYGjZmlxMDMDDMmxCLwAzwQDsgxYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Blorkie",
          ["guild"] = "Arctic Avengers",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 290658,
          ["ilvl"] = 324,
          ["crit"] = 1227,
          ["haste"] = 224,
          ["mastery"] = 1650,
          ["vers"] = 79,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = nil,
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMz4BMDGTNmZmBAAAAzYmZMzsMmZgZYgxMWYBGYGGagFMGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "迷路的牛师傅",
          ["guild"] = "翡翠湖畔",
          ["boss"] = "The Lost Explorers",
          ["amount"] = 289324,
          ["ilvl"] = 327,
          ["crit"] = 1135,
          ["haste"] = 512,
          ["mastery"] = 1298,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            },
            {
              ["id"] = 248583,
              ["name"] = "Drum of Renewed Bonds",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMmZbmZGMDzMLzMzMjZ2AAAAAwAAAmZ8AmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhNYgZYoBWwYMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Olbahamut",
          ["guild"] = "Vestige",
          ["boss"] = "Sszorak",
          ["amount"] = 231696,
          ["ilvl"] = 328,
          ["crit"] = 1005,
          ["haste"] = 304,
          ["mastery"] = 1885,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZmZMjZAAAAAAAAgZGPgZwYqZmZmBAAAAzYGjZmlxMDMDDMmxCLwAzwQDsgZGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Mornafah",
          ["guild"] = "",
          ["boss"] = "Sszorak",
          ["amount"] = 229898,
          ["ilvl"] = 322,
          ["crit"] = 1201,
          ["haste"] = 463,
          ["mastery"] = 1518,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAwMmZbmZGMYmZZmZMjZ2AAAAAgBAgxMgBjpGzMzAAAAgZMzMmZWGzMwMmBGzYhFYgZYoBWwMjZGgBD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "영능턴종영능",
          ["guild"] = "인앤아웃",
          ["boss"] = "Sszorak",
          ["amount"] = 224388,
          ["ilvl"] = 326,
          ["crit"] = 1187,
          ["haste"] = 542,
          ["mastery"] = 1449,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmxMbzMzgBzMLzMjZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Dajo",
          ["guild"] = "Resonate",
          ["boss"] = "Sszorak",
          ["amount"] = 222067,
          ["ilvl"] = 324,
          ["crit"] = 939,
          ["haste"] = 800,
          ["mastery"] = 1497,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAwMzMbzMzgBzMLzMjZMDAAAAAAAAmZYMDGTNmZmBAAAAzYGjZmlxMDMjZgxMWYBGYGGagFMzYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Wekeed",
          ["guild"] = "Mate",
          ["boss"] = "Sszorak",
          ["amount"] = 220669,
          ["ilvl"] = 328,
          ["crit"] = 794,
          ["haste"] = 651,
          ["mastery"] = 1693,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAgZGjZwYqxMzMAAAAYGzYMzsMmZgZWMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Tempaug",
          ["guild"] = "Cutting Bread",
          ["boss"] = "Sszorak",
          ["amount"] = 218952,
          ["ilvl"] = 323,
          ["crit"] = 922,
          ["haste"] = 517,
          ["mastery"] = 1435,
          ["vers"] = 261,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAwMmZbmZGMYmZZmZMjZ2AAAAAAAAwMjxMYM1YmZGAAAAMjZMmZWGzMwMmBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "고향김치만두",
          ["guild"] = "Lumpen",
          ["boss"] = "Sszorak",
          ["amount"] = 217966,
          ["ilvl"] = 322,
          ["crit"] = 1171,
          ["haste"] = 409,
          ["mastery"] = 1482,
          ["vers"] = 125,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZGjZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Augmentfluup",
          ["guild"] = "Hatewatching",
          ["boss"] = "Sszorak",
          ["amount"] = 217454,
          ["ilvl"] = 325,
          ["crit"] = 980,
          ["haste"] = 306,
          ["mastery"] = 3610,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAgZmZbmZGMDzMLzYmZMzGAAAAAMAAYmBMYM1YmZGAAAAMjZmxMzyYmBmxMwYGLsADMDDNwCGjZGgBD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Dreamsweet",
          ["guild"] = "vodka",
          ["boss"] = "Sszorak",
          ["amount"] = 217313,
          ["ilvl"] = 324,
          ["crit"] = 1118,
          ["haste"] = 152,
          ["mastery"] = 1944,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZGjZMzGAAAAAMAAYmZgBjpGzMzAAAAgZMzMmZWGzMwMMwYGLsADMDDNwCmZMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "혜지코스타스",
          ["guild"] = "Mate",
          ["boss"] = "Sszorak",
          ["amount"] = 216858,
          ["ilvl"] = 326,
          ["crit"] = 1041,
          ["haste"] = 713,
          ["mastery"] = 1393,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236616,
            ["name"] = "Light's Potential"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZGjZMzGAAAAAAAAmZMmBjpGzMzAAAAgZYMmZWGzMwMMwYGLsADMDDNwCmZmZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "영능턴종영능",
          ["guild"] = "인앤아웃",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 300580,
          ["ilvl"] = 326,
          ["crit"] = 1187,
          ["haste"] = 542,
          ["mastery"] = 1449,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAgZmZbmZGMDzMLzMzMjZAAAAAADAAmZYMPAGTNmZmBAAAAzYGjZmlxMDMjZgxMWYBGYGGagFMGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Polp",
          ["guild"] = "Scary maze",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 292392,
          ["ilvl"] = 326,
          ["crit"] = 1183,
          ["haste"] = 422,
          ["mastery"] = 1504,
          ["vers"] = 127,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAgBAAmhxgZM1MzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwYMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Juravoker",
          ["guild"] = "Oblivion",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 292359,
          ["ilvl"] = 326,
          ["crit"] = 716,
          ["haste"] = 504,
          ["mastery"] = 1853,
          ["vers"] = 159,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMMmBjpmZmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Tizaxyr",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 290583,
          ["ilvl"] = 326,
          ["crit"] = 1052,
          ["haste"] = 296,
          ["mastery"] = 1747,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAgZmZbmZGMDzMLzMzMjZAAAAAAAAwMDj5BYGTNmZmBAAAAzYGjZmlxMDMjZgxMWYBGYGGagFMGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Надуватель",
          ["guild"] = "У беляша",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 289287,
          ["ilvl"] = 326,
          ["crit"] = 1107,
          ["haste"] = 278,
          ["mastery"] = 1711,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 250215,
              ["name"] = "Freightrunner's Flask",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMzYMDGTNmZmBAAAAzYGjZmlxMDMDDMmxCLwAzwQDsgxYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Dreamsweet",
          ["guild"] = "vodka",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 288897,
          ["ilvl"] = 324,
          ["crit"] = 1118,
          ["haste"] = 152,
          ["mastery"] = 1944,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAgBAAzMDMYM1YmZGAAAAMjZmxMz2YmBmhBGzYhFYgZYoBWwYMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Nutnut",
          ["guild"] = "velocity",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 288685,
          ["ilvl"] = 326,
          ["crit"] = 991,
          ["haste"] = 351,
          ["mastery"] = 1828,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 308
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAgZmZbmZGMYmZZmZmZMDAAAAAAAAmZ4BMDGTNzMzMAAAAYGzYMzsMmZgZWmBGzYhFYgZYoBWwYMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Evook",
          ["guild"] = "Blur",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 288094,
          ["ilvl"] = 325,
          ["crit"] = 1129,
          ["haste"] = 371,
          ["mastery"] = 1578,
          ["vers"] = 185,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzMWmBzsMjZmxMAAAAAgBAAmBMYM1YmZGAAAAMzMzMmZWGzMwMMwYGLsADMDDNwCGjZGgBD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Twimight",
          ["guild"] = "Pathogen",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 287834,
          ["ilvl"] = 328,
          ["crit"] = 911,
          ["haste"] = 266,
          ["mastery"] = 2037,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMz4BMDGTNzMzMAAAAYGzYMzsMmZgZYgxMWYBGYGGagFMGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Olbahamut",
          ["guild"] = "Vestige",
          ["boss"] = "The Twin Fangs",
          ["amount"] = 286699,
          ["ilvl"] = 328,
          ["crit"] = 1013,
          ["haste"] = 307,
          ["mastery"] = 1885,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMz4BMDGTNzMzMAAAAYGzYMzsMmZgZYgxMWYBGYGGagFMGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Blueprínt",
          ["guild"] = "Honestly",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 260611,
          ["ilvl"] = 326,
          ["crit"] = 1099,
          ["haste"] = 329,
          ["mastery"] = 1751,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMMmBjpmZmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Smoppings",
          ["guild"] = "Sabotage",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 259840,
          ["ilvl"] = 326,
          ["crit"] = 930,
          ["haste"] = 479,
          ["mastery"] = 1730,
          ["vers"] = 44,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 331
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMDjZwYqZmZmBAAAAzYGjZmlxMDMDDMmxCLwAzwQDsgxYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Tizaxyr",
          ["guild"] = "Northern Sky",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 255239,
          ["ilvl"] = 326,
          ["crit"] = 1052,
          ["haste"] = 296,
          ["mastery"] = 1747,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 324
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAgZmZbmZGMDzMLzMzMjZAAAAAAAAwMDj5BwYqZmZmBAAAAzYGjZmlxMDMjZgxMWYBGYGGagFMGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Polp",
          ["guild"] = "Scary maze",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 250515,
          ["ilvl"] = 330,
          ["crit"] = 1148,
          ["haste"] = 421,
          ["mastery"] = 1587,
          ["vers"] = 129,
          ["trinkets"] = {
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGmZMzGAAAAAMAAwMMGMjpmZmZGAAAAMjZMmZWGzMwMLGYMjFWgBmhhGYBjxMDAM",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Geasszz",
          ["guild"] = "Wave",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 248926,
          ["ilvl"] = 326,
          ["crit"] = 879,
          ["haste"] = 470,
          ["mastery"] = 1806,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMmZbmZGM8AzMLzMzMjZAAAAAAAAwMzYMDGTNmZmBAAAAGzYMzsMmZgZWMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Cocofotm",
          ["guild"] = "Ethical",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 247822,
          ["ilvl"] = 325,
          ["crit"] = 1106,
          ["haste"] = 278,
          ["mastery"] = 3581,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 249346,
              ["name"] = "Vaelgor's Final Stare",
              ["ilvl"] = 298
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMDzMDGTNzMzMAAAAwYGjZmlxMDMDDMmxCLwAzwQDsgxYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Thicknscaly",
          ["guild"] = "poptart corndoG",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 243774,
          ["ilvl"] = 325,
          ["crit"] = 1080,
          ["haste"] = 176,
          ["mastery"] = 1897,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAgZYMDGTNmZmBAAAAzYmZMzsMmZgZWMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Batchester",
          ["guild"] = "Tony Halme Pro Skater",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 239285,
          ["ilvl"] = 328,
          ["crit"] = 815,
          ["haste"] = 305,
          ["mastery"] = 2154,
          ["vers"] = 46,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzYmZMzGAAAAAAAAmhx8AMjpmZmZGAAAAMjZMmZWGzMwMLGYMjFWgBmhhGYBjxMDAM",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Bite",
          ["guild"] = "Incarnate",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 237099,
          ["ilvl"] = 326,
          ["crit"] = 860,
          ["haste"] = 795,
          ["mastery"] = 1471,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 328
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMMzAjpGzMzAAAAgZmZMmZWGzMwMMwYGLsADMDDNwCGzMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Nikovoker",
          ["guild"] = "Quichons",
          ["boss"] = "The Coiled Altar",
          ["amount"] = 236042,
          ["ilvl"] = 326,
          ["crit"] = 1006,
          ["haste"] = 373,
          ["mastery"] = 1764,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAgZmZbmZGMDzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmxMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Blueprínt",
          ["guild"] = "Honestly",
          ["boss"] = "Ula'tek",
          ["amount"] = 449491,
          ["ilvl"] = 333,
          ["crit"] = 955,
          ["haste"] = 433,
          ["mastery"] = 3716,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAgxMbzMzgBzMLzMzMjZ2AAAAAAAAYmZgBjpmZmZGAAAAMjZmxMzyYmBmZZGYMjFWgBmhhGYBjxMDAM",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "혜지코스타스",
          ["guild"] = "Mate",
          ["boss"] = "Ula'tek",
          ["amount"] = 339265,
          ["ilvl"] = 328,
          ["crit"] = 978,
          ["haste"] = 748,
          ["mastery"] = 3292,
          ["vers"] = -137,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270167,
              ["name"] = "Wavecaller's Seastone",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzYmZMzGAAAAAAAAmZMmBjpGzMzAAAAgZYMmZWGzMwMLGYMjFWgBmhhGYBjZmZAgB",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "难瘦呀",
          ["guild"] = "利刃",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 261796,
          ["ilvl"] = 327,
          ["crit"] = 948,
          ["haste"] = 420,
          ["mastery"] = 1869,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMDjZwYqZmZmBAAAAzYGjZmtxMDMDDMmxCLwAzwQDsgxYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Wekeed",
          ["guild"] = "Mate",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 249007,
          ["ilvl"] = 328,
          ["crit"] = 794,
          ["haste"] = 651,
          ["mastery"] = 1693,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270169,
              ["name"] = "Hex Lord's Dooming Idol",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAgZGjZwYqxMzMAAAAYGzYMzsMmZgZWMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Cocofotm",
          ["guild"] = "Ethical",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 240222,
          ["ilvl"] = 327,
          ["crit"] = 1106,
          ["haste"] = 278,
          ["mastery"] = 3581,
          ["vers"] = -231,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 334
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZmZMjZAAAAAAAAgZYmZwYqZmZmBAAAAGzYMzsMmZgZYgxMWYBGYGGagFMzYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Revogre",
          ["guild"] = "Revoke",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 239120,
          ["ilvl"] = 326,
          ["crit"] = 946,
          ["haste"] = 790,
          ["mastery"] = 1255,
          ["vers"] = 101,
          ["trinkets"] = {
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270164,
              ["name"] = "Gebbo's Bottomless Bag",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmxMbzMzgBzMLzMjZMzGAAAAAAAAMMmBjpmZmZGAAAAMjZmxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Psyrievo",
          ["guild"] = "baited",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 232156,
          ["ilvl"] = 326,
          ["crit"] = 1227,
          ["haste"] = 347,
          ["mastery"] = 1595,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZGjZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Djolero",
          ["guild"] = "Ascendance",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 232112,
          ["ilvl"] = 323,
          ["crit"] = 1054,
          ["haste"] = 426,
          ["mastery"] = 1470,
          ["vers"] = 205,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 315
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZGjZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoBWwMjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Whatsupdøgx",
          ["guild"] = "The Next Step",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 231546,
          ["ilvl"] = 324,
          ["crit"] = 924,
          ["haste"] = 310,
          ["mastery"] = 1846,
          ["vers"] = 94,
          ["trinkets"] = {
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 324
            },
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 334
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZmZmZMDAAAAAAAAMDjZwYqxMzMAAAAYGzMjZmlxMDMDDMmxCLwAzwQDsgxYmBAG",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Krismanx",
          ["guild"] = "Internet Friends",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 230167,
          ["ilvl"] = 327,
          ["crit"] = 1088,
          ["haste"] = 271,
          ["mastery"] = 1684,
          ["vers"] = 95,
          ["trinkets"] = {
            {
              ["id"] = 270170,
              ["name"] = "Vexhul's Everflowing Gland",
              ["ilvl"] = 334
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzMzMjZAAAAAAAAgZGjZwYqxMzMAAAAYGzYMzsMmZgZWMwYGLsADMDDNwCGjZGAYA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Tizaxyr",
          ["guild"] = "Northern Sky",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 228767,
          ["ilvl"] = 326,
          ["crit"] = 1181,
          ["haste"] = 224,
          ["mastery"] = 1688,
          ["vers"] = 145,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 321
            },
            {
              ["id"] = 270161,
              ["name"] = "Fang of Umbral Malignance",
              ["ilvl"] = 328
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAwMzMbzMzgBzMLzMjZMDAAAAAAAAmZYMPAGTNzMzMAAAAYGzYMzsMmZgZMDMmxCLwAzwQDsgZGzMAwA",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        },
        {
          ["name"] = "Weeb",
          ["guild"] = "Lucid",
          ["boss"] = "Nymrissa Wavecaller",
          ["amount"] = 227678,
          ["ilvl"] = 324,
          ["crit"] = 897,
          ["haste"] = 225,
          ["mastery"] = 2006,
          ["vers"] = nil,
          ["trinkets"] = {
            {
              ["id"] = 270168,
              ["name"] = "Font of Venomous Rage",
              ["ilvl"] = 318
            },
            {
              ["id"] = 250224,
              ["name"] = "Mindpiercer's Sigil",
              ["ilvl"] = 321
            }
          },
          ["gear"] = nil,
          ["potion"] = {
            ["id"] = 1236994,
            ["name"] = "Potion of Recklessness"
          },
          ["talents"] = "CEcBAAAAAAAAAAAAAAAAAAAAAMmZmZbmZGMYmZZGjZMzGAAAAAMAAwMDMMjpmZmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCmZMzAAD",
          ["hero"] = {
            ["name"] = "Chronowarden",
            ["atlas"] = "talents-heroclass-evoker-chronowarden",
            ["icon"] = "inv_ability_chronowardenevoker_chronoflame"
          }
        }
      }
    }
  }
}
