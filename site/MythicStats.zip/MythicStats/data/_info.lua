MythicStatsDB = MythicStatsDB or {}
MythicStatsDB.zone = "The Venomous Abyss"
MythicStatsDB.updated = "2026-09-18 20:27 UTC"
MythicStatsDB.region = "All regions"
MythicStatsDB.bosses = {
  "Nek'zali the Soulcoiler",
  "Entombed Sentinels",
  "Vashnik the Malignant",
  "The Lost Explorers",
  "Sszorak",
  "The Twin Fangs",
  "The Coiled Altar",
  "Ula'tek",
  "Nymrissa Wavecaller",
  "Kith'ix"
}
